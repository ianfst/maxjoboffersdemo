import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material';
import CssBaseline from '@mui/material/CssBaseline';
import { ExecutiveLanding } from './components/marketing/ExecutiveLanding';
import { DashboardMockup } from './components/dashboard/DashboardMockup';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1a237e', // Deep blue for executive feel
      light: '#534bae',
      dark: '#000051',
    },
    secondary: {
      main: '#c5a572', // Gold for premium feel
      light: '#f8d7a3',
      dark: '#947644',
    },
    background: {
      default: '#f5f5f7',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
    },
    h2: {
      fontWeight: 600,
    },
    h3: {
      fontWeight: 600,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
          fontWeight: 600,
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          <Route path="/" element={<ExecutiveLanding />} />
          <Route path="/dashboard" element={<DashboardMockup />} />
          {/* Add more routes as needed */}
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
