export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  salary?: {
    min: number;
    max: number;
    currency: string;
  };
  type: 'full-time' | 'part-time' | 'contract' | 'temporary';
  level: 'executive' | 'senior' | 'mid-level' | 'entry';
  postDate: string;
  source: string;
  applicationUrl?: string;
  status?: ApplicationStatus;
}

export interface Resume {
  id: string;
  title: string;
  content: string;
  targetRole: string;
  lastModified: string;
  atsScore: number;
  keywords: string[];
  isBase: boolean;
}

export interface ApplicationStatus {
  status: 'saved' | 'in-progress' | 'applied' | 'interviewing' | 'offered' | 'rejected';
  lastUpdated: string;
  notes?: string;
  nextSteps?: {
    type: 'resume-review' | 'interview-prep' | 'follow-up';
    dueDate: string;
    completed: boolean;
  }[];
}

export interface ResumeOptimizationRequest {
  baseResumeId: string;
  jobId: string;
  customInstructions?: string;
}

export interface InterviewPrepSession {
  id: string;
  jobId: string;
  type: 'behavioral' | 'technical' | 'leadership' | 'case-study';
  questions: InterviewQuestion[];
  scheduledFor?: string;
  completed: boolean;
  feedback?: string;
}

export interface InterviewQuestion {
  id: string;
  question: string;
  category: string;
  sampleAnswer?: string;
  userAnswer?: string;
  feedback?: string;
  rating?: number;
}
