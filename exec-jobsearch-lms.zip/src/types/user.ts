export type MembershipTier = 'free' | 'standard' | 'platinum';

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  membershipTier: MembershipTier;
  createdAt: string;
  profileImage?: string;
  retirementAssetsVerified: boolean;
}

export interface UserProgress {
  resumesCreated: number;
  resumeWeeklyGoal: number;
  linkedInPosts: number;
  linkedInWeeklyGoal: number;
  lastUpdated: string;
}

export interface FeatureAccess {
  aiTools: boolean;
  premiumContent: boolean;
  coaching: boolean;
  doneForYou: boolean;
  financialPlanning: boolean;
}

export const getTierFeatures = (tier: MembershipTier): FeatureAccess => {
  const baseFeatures = {
    aiTools: false,
    premiumContent: false,
    coaching: false,
    doneForYou: false,
    financialPlanning: false,
  };

  switch (tier) {
    case 'platinum':
      return {
        ...baseFeatures,
        aiTools: true,
        premiumContent: true,
        coaching: true,
        doneForYou: true,
        financialPlanning: true,
      };
    case 'standard':
      return {
        ...baseFeatures,
        aiTools: true,
        premiumContent: true,
      };
    default:
      return baseFeatures;
  }
};
