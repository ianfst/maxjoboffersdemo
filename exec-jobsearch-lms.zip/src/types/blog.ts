export interface BlogPost {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  slug: string;
  coverImage?: string;
  status: 'pending' | 'approved' | 'rejected' | 'published';
  createdAt: string;
  type: 'comment' | 'review' | 'question';
  publishedAt?: string;
  readingTime?: string;
  tags: string[];
  hasUnmoderatedComments?: boolean;
  views?: number;
  likes?: number;
  shares?: number;
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  comments?: Array<{
    id: string;
    content: string;
    author: string;
    createdAt: string;
    status: 'pending' | 'approved' | 'rejected';
  }>;
}

export interface BlogCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

export interface BlogTag {
  id: string;
  name: string;
  slug: string;
  count: number;
}
