export interface InterviewPrep {
  id: string;
  userId: string;
  jobId: string;
  resumeId: string;
  status: 'in_progress' | 'completed';
  requirementsAnalysis: RequirementsAnalysis;
  experienceMapping: ExperienceMapping[];
  practiceQuestions: PracticeQuestion[];
  behavioralExamples: BehavioralExample[];
  behavioralPrep: BehavioralPrep;
  technicalPrep: TechnicalPrep;
  companyResearch: CompanyResearch;
  createdAt: Date;
  updatedAt: Date;
}

export interface RequirementsAnalysis {
  id: string;
  mustHaveSkills: SkillMatch[];
  niceToHaveSkills: SkillMatch[];
  experienceRequirements: ExperienceRequirement[];
  educationRequirements: string[];
  certificationRequirements: string[];
  missingRequirements: string[];
  overallMatch: number;
}

export interface SkillMatch {
  skill: string;
  matched: boolean;
  relevantExperience?: string[];
  proficiencyLevel?: number;
  yearsOfExperience?: number;
  lastUsed?: Date;
}

export interface ExperienceRequirement {
  area: string;
  yearsRequired: number;
  matched: boolean;
  relevantExperience?: string[];
}

export interface ExperienceMapping {
  id: string;
  jobRequirement: string;
  relevantExperiences: {
    role: string;
    company: string;
    description: string;
    achievements: string[];
    skills: string[];
    duration: string;
    impact: string;
  }[];
  strengthLevel: 'strong' | 'moderate' | 'weak';
  improvementSuggestions?: string[];
}

export interface PracticeQuestion {
  id: string;
  category: 'technical' | 'behavioral' | 'general';
  question: string;
  context?: string;
  suggestedAnswer?: string;
  relatedRequirements: string[];
  difficulty: 'easy' | 'medium' | 'hard';
  userAnswer?: string;
  feedback?: string;
  status: 'not_started' | 'in_progress' | 'completed';
}

export interface BehavioralPrep {
  examples: BehavioralExample[];
  competencyAreas: CompetencyArea[];
}

export interface CompetencyArea {
  area: string;
  description: string;
  keyAttributes: string[];
  commonQuestions: string[];
  tips?: string[];
}

export interface BehavioralExample {
  id: string;
  situation: string;
  task: string;
  action: string;
  result: string;
  skills: string[];
  competencyArea: string;
  keywords: string[];
  impact: string;
  metrics?: string[];
  relatedRequirements: string[];
  improvement?: string;
}

export interface TechnicalPrep {
  id: string;
  requiredTechnologies: TechnologyPrep[];
  systemDesign?: SystemDesignPrep[];
  codeExercises?: CodeExercise[];
  conceptReview?: ConceptReview[];
}

export interface TechnologyPrep {
  technology: string;
  proficiency: number;
  lastUsed?: Date;
  keyFeatures: string[];
  commonQuestions: string[];
  practiceProjects?: string[];
  resources?: string[];
  notes?: string;
}

export interface SystemDesignPrep {
  topic: string;
  requirements: string[];
  components: string[];
  considerations: string[];
  diagram?: string;
  tradeoffs: string[];
  scalabilityNotes?: string;
}

export interface CodeExercise {
  id: string;
  title: string;
  difficulty: 'easy' | 'medium' | 'hard';
  problem: string;
  hints: string[];
  solution?: string;
  explanation?: string;
  relatedConcepts: string[];
  completed: boolean;
}

export interface ConceptReview {
  concept: string;
  understanding: 'weak' | 'moderate' | 'strong';
  keyPoints: string[];
  examples: string[];
  resources: string[];
  notes?: string;
}

export interface CompanyResearch {
  id: string;
  companyOverview: {
    mission: string;
    values: string[];
    culture: string;
    products: string[];
    recentNews: string[];
  };
  teamInfo?: {
    department: string;
    teamSize: number;
    keyProjects: string[];
    technologies: string[];
  };
  interviewProcess?: {
    stages: string[];
    typicalQuestions: string[];
    interviewerBackgrounds: string[];
  };
  preparationNotes: string[];
}

export interface InterviewFeedback {
  id: string;
  prepId: string;
  questionId: string;
  answer: string;
  feedback: string;
  strengths: string[];
  improvements: string[];
  score: number;
  notes?: string;
  createdAt: Date;
}

export interface MockInterview {
  id: string;
  prepId: string;
  date: Date;
  duration: number;
  type: 'technical' | 'behavioral' | 'mixed';
  questions: PracticeQuestion[];
  feedback?: InterviewFeedback[];
  recording?: string;
  notes?: string;
  overallScore?: number;
}
