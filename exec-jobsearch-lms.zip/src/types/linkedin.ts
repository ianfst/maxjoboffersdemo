export interface BlogSeries {
  id: string;
  title: string;
  description: string;
  partCount: number;
  status: 'draft' | 'approved' | 'in_progress' | 'completed';
  blogs: Blog[];
  targetGroups: LinkedInGroup[];
  hashtags: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Blog {
  id: string;
  seriesId: string;
  partNumber: number;
  title: string;
  content: string;
  wordCount: number;
  infographicUrl?: string;
  status: 'draft' | 'approved' | 'scheduled' | 'posted';
  scheduledFor?: Date;
  postedTo: LinkedInGroup[];
  hashtags: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface LinkedInGroup {
  id: string;
  name: string;
  url: string;
  requiresApproval: boolean;
  lastPostStatus: 'success' | 'pending' | 'failed';
  lastPostDate?: Date;
}

export interface BlogSchedule {
  monday: { time: string; period: 'afternoon' };
  tuesday: { time: string; period: 'morning' };
  wednesday: { time: string; period: 'morning' };
  thursday: { time: string; period: 'morning' };
}

export interface BlogOutline {
  seriesTitle: string;
  description: string;
  partCount: number;
  blogTitles: string[];
  targetGroups: LinkedInGroup[];
  suggestedHashtags: string[];
}

export interface CanvaTemplate {
  id: string;
  name: string;
  previewUrl: string;
  category: string;
  dimensions: {
    width: number;
    height: number;
  };
}

export interface LinkedInConnection {
  id: string;
  name: string;
  title: string;
  company: string;
  connectionDegree: 1 | 2 | 3;
  profileUrl: string;
  isTalentAcquisition: boolean;
  sharedGroups: LinkedInGroup[];
  sharedConnections: number;
  lastInteraction?: Date;
  notes: string;
  status: 'pending' | 'connected' | 'messaged' | 'responded';
}

export interface NetworkingCampaign {
  id: string;
  targetCompany: string;
  status: 'active' | 'paused' | 'completed';
  metrics: {
    connectionsRequested: number;
    connectionsAccepted: number;
    messagesExchanged: number;
    meetingsScheduled: number;
  };
  connections: {
    firstDegree: LinkedInConnection[];
    secondDegree: LinkedInConnection[];
    talentAcquisition: LinkedInConnection[];
    groupMembers: LinkedInConnection[];
  };
  messageTemplates: MessageTemplate[];
  createdAt: Date;
  updatedAt: Date;
}

export interface MessageTemplate {
  id: string;
  name: string;
  type: 'connection_request' | 'follow_up' | 'group_member' | 'shared_connection' | 'talent_acquisition';
  content: string;
  variables: string[];
  performanceMetrics: {
    sent: number;
    accepted: number;
    responded: number;
    meetings: number;
  };
}

export interface NetworkingStrategy {
  id: string;
  name: string;
  targetRoles: string[];
  industries: string[];
  connectionSequence: {
    steps: Array<{
      type: 'connect' | 'message' | 'follow_up';
      delay: number; // days
      templateId: string;
    }>;
  };
  groupEngagementStrategy: {
    postFrequency: number; // days
    commentFrequency: number; // days
    likeFrequency: number; // days
  };
  activeCompanies: string[];
}
