export enum SubscriptionStatus {
  PastDue = 'past_due',
  CancelAtPeriodEnd = 'cancel_at_period_end',
  Active = 'active',
  Deleted = 'deleted',
}

export enum PaymentPlanId {
  Basic = 'basic',
  Professional = 'professional',
  Enterprise = 'enterprise',
  Credits10 = 'credits10',
  Credits50 = 'credits50',
  Credits100 = 'credits100',
}

export interface PaymentPlan {
  id: PaymentPlanId;
  name: string;
  description: string;
  price: number;
  features: string[];
  aiCredits: number;
  effect: PaymentPlanEffect;
}

export type PaymentPlanEffect = 
  | { kind: 'subscription'; aiCreditsPerMonth: number }
  | { kind: 'credits'; amount: number };

export const PAYMENT_PLANS: Record<PaymentPlanId, PaymentPlan> = {
  [PaymentPlanId.Basic]: {
    id: PaymentPlanId.Basic,
    name: 'Basic',
    description: 'Perfect for getting started with AI-powered content creation',
    price: 29,
    features: [
      '50 AI credits per month',
      'Basic blog templates',
      'SEO optimization',
      'Email support',
    ],
    aiCredits: 50,
    effect: { kind: 'subscription', aiCreditsPerMonth: 50 },
  },
  [PaymentPlanId.Professional]: {
    id: PaymentPlanId.Professional,
    name: 'Professional',
    description: 'For serious content creators and growing businesses',
    price: 79,
    features: [
      '200 AI credits per month',
      'Advanced blog templates',
      'Priority SEO optimization',
      'Image generation',
      'Priority support',
    ],
    aiCredits: 200,
    effect: { kind: 'subscription', aiCreditsPerMonth: 200 },
  },
  [PaymentPlanId.Enterprise]: {
    id: PaymentPlanId.Enterprise,
    name: 'Enterprise',
    description: 'Custom solutions for large organizations',
    price: 299,
    features: [
      'Unlimited AI credits',
      'Custom blog templates',
      'Advanced analytics',
      'Custom integrations',
      '24/7 dedicated support',
    ],
    aiCredits: -1, // Unlimited
    effect: { kind: 'subscription', aiCreditsPerMonth: -1 },
  },
  [PaymentPlanId.Credits10]: {
    id: PaymentPlanId.Credits10,
    name: '10 Credits',
    description: 'Try out our AI features',
    price: 10,
    features: [
      '10 AI credits',
      'Never expires',
      'Basic templates',
      'Email support',
    ],
    aiCredits: 10,
    effect: { kind: 'credits', amount: 10 },
  },
  [PaymentPlanId.Credits50]: {
    id: PaymentPlanId.Credits50,
    name: '50 Credits',
    description: 'Most popular credit package',
    price: 45,
    features: [
      '50 AI credits',
      'Never expires',
      'All templates',
      'Priority support',
    ],
    aiCredits: 50,
    effect: { kind: 'credits', amount: 50 },
  },
  [PaymentPlanId.Credits100]: {
    id: PaymentPlanId.Credits100,
    name: '100 Credits',
    description: 'Best value for power users',
    price: 80,
    features: [
      '100 AI credits',
      'Never expires',
      'All templates',
      'Priority support',
      'Custom templates',
    ],
    aiCredits: 100,
    effect: { kind: 'credits', amount: 100 },
  },
};
