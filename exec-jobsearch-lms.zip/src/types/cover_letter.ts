export interface CoverLetter {
  id: string;
  userId: string;
  jobId?: string;  // Optional if it's a template
  resumeId?: string;  // Optional if it's a template
  title: string;
  content: string;
  isTemplate: boolean;
  templateId?: string;  // References template if this is a customized version
  version: number;
  status: 'draft' | 'final';
  createdAt: Date;
  updatedAt: Date;
  analysis?: CoverLetterAnalysis;
}

export interface CoverLetterTemplate {
  id: string;
  name: string;
  description: string;
  content: string;
  variables: CoverLetterVariable[];
  style: 'professional' | 'creative' | 'modern' | 'traditional';
  industry?: string;
  jobLevel?: string;
  tone: 'formal' | 'casual' | 'balanced';
  createdAt: Date;
  updatedAt: Date;
}

export interface CoverLetterVariable {
  name: string;
  description: string;
  type: 'text' | 'list' | 'paragraph';
  required: boolean;
  defaultValue?: string;
  options?: string[];  // For list type variables
}

export interface CoverLetterAnalysis {
  keyPoints: string[];
  tone: string;
  clarity: number;
  impact: number;
  relevance: number;
  suggestions: string[];
  wordCount: number;
  readabilityScore: number;
}

export interface CoverLetterGenRequest {
  jobId: string;
  resumeId: string;
  templateId?: string;
  style?: 'professional' | 'creative' | 'modern' | 'traditional';
  tone?: 'formal' | 'casual' | 'balanced';
  keyPoints?: string[];
  customInstructions?: string;
}

export interface CoverLetterCustomization {
  achievements: string[];
  skills: string[];
  experience: string[];
  companyKnowledge: string[];
  cultureFit: string[];
  jobRequirements: string[];
}
