export interface FeatureAccess {
  aiTools: boolean;
  premiumContent: boolean;
  coaching: boolean;
  doneForYou: boolean;
  financialPlanning: boolean;
}

export type FeatureKey = keyof FeatureAccess;
