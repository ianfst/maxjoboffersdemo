export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  requirements: string[];
  salary?: {
    min: number;
    max: number;
    currency: string;
  };
  type: 'full-time' | 'part-time' | 'contract' | 'internship';
  remote: 'no' | 'hybrid' | 'full';
  postedDate: Date;
  applicationDeadline?: Date;
  source: string;  // LinkedIn, Indeed, etc.
  sourceUrl: string;
  skills: string[];
  experience: {
    min: number;
    max?: number;
    unit: 'years' | 'months';
  };
  education?: {
    level: string;
    field?: string;
  };
  benefits?: string[];
  status: 'active' | 'expired' | 'filled';
  applicationsCount?: number;
  matchScore?: number;  // AI-calculated match score with user's profile
}

export interface JobSearchFilters {
  keywords?: string;
  location?: string;
  remote?: boolean;
  jobType?: ('full-time' | 'part-time' | 'contract' | 'internship')[];
  experienceLevel?: {
    min?: number;
    max?: number;
  };
  salary?: {
    min?: number;
    max?: number;
    currency?: string;
  };
  postedWithin?: 'day' | 'week' | 'month' | 'any';
  skills?: string[];
  companies?: string[];
  sources?: string[];
  educationLevel?: string[];
  sortBy?: 'relevance' | 'date' | 'salary' | 'matchScore';
}

export interface JobApplication {
  id: string;
  jobId: string;
  userId: string;
  resumeId: string;
  coverLetterId?: string;
  status: 'draft' | 'applied' | 'interviewing' | 'offered' | 'rejected' | 'accepted' | 'withdrawn';
  appliedDate: Date;
  lastStatusUpdate: Date;
  followUpsSent: number;
  notes?: string;
  nextSteps?: string;
  interviews?: Interview[];
}

export interface Interview {
  id: string;
  applicationId: string;
  type: 'phone' | 'video' | 'onsite' | 'technical' | 'other';
  scheduledDate: Date;
  duration: number;  // in minutes
  interviewers?: string[];
  location?: string;
  videoLink?: string;
  preparation?: {
    keyPoints: string[];
    questions: string[];
    research: string[];
  };
  feedback?: string;
  outcome?: 'pending' | 'passed' | 'failed' | 'no_show';
}

export interface SavedSearch {
  id: string;
  userId: string;
  name: string;
  filters: JobSearchFilters;
  emailFrequency?: 'daily' | 'weekly' | 'never';
  createdAt: Date;
  lastRunAt: Date;
  resultCount: number;
}
