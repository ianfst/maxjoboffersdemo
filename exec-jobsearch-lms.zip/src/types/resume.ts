export type ResumeFormat = 'chronological' | 'functional' | 'hybrid' | 'executive' | 'technical';
export type FileFormat = 'DOCX' | 'PDF';

export interface ResumeTemplate {
  id: string;
  name: string;
  description: string;
  format: ResumeFormat;
  structure: {
    sections: string[];
    layout: string;
  };
  styleSettings: {
    fonts: string[];
    spacing: number;
    margins: number[];
  };
  industryFocus?: string;
  atsOptimized: boolean;
}

export interface ResumeVersion {
  id: string;
  userId: string;
  version: number;
  content: string;
  format: ResumeFormat;
  fileFormat: FileFormat;
  createdAt: Date;
  updatedAt: Date;
  isOriginal: boolean;
  jobId?: string;  // If this version was created for a specific job
  jobRequirements?: {
    skills: string[];
    experience: string[];
    education: string[];
  };
  aiSuggestions?: string[];
  status: 'draft' | 'final';
  templateId?: string;
}

export interface ResumeSection {
  id: string;
  resumeId: string;
  type: 'experience' | 'education' | 'skills' | 'summary';
  content: string;
  order: number;
  achievements: string[];
  keywords: string[];
  metrics?: {
    value: number;
    unit: string;
    description: string;
  }[];
}

export interface Experience {
  id: string;
  company: string;
  title: string;
  startDate: Date;
  endDate?: Date;
  location: string;
  description: string;
  achievements: string[];
  skills: string[];
  keywords: string[];
  impactMetrics?: {
    metric: string;
    value: number;
    unit: string;
  }[];
  certifications?: string[];
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  graduationDate: Date;
  gpa?: number;
  achievements: string[];
  coursework?: string[];
  certifications?: string[];
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  proficiency: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  yearsOfExperience: number;
  lastUsed?: Date;
}

export interface Application {
  id: string;
  userId: string;
  jobId: string;
  resumeId: string;
  coverLetterId?: string;
  status: 'applied' | 'interviewing' | 'offered' | 'rejected';
  appliedDate: Date;
  lastInteraction?: Date;
  nextSteps?: {
    type: string;
    date: Date;
    description: string;
  }[];
  notes?: string;
  followUpReminders?: {
    date: Date;
    type: string;
    message: string;
    sent: boolean;
  }[];
}

export interface JobMatch {
  id: string;
  userId: string;
  jobId: string;
  resumeId: string;
  skillMatchScore: number;
  experienceMatchScore: number;
  educationMatchScore: number;
  overallMatchScore: number;
  missingSkills?: string[];
  suggestedResumeUpdates?: {
    section: string;
    suggestion: string;
    priority: 'high' | 'medium' | 'low';
  }[];
}

export interface ResumeAnalysis {
  id: string;
  resumeId: string;
  keySkills: string[];
  experienceHighlights: string[];
  suggestedImprovements: string[];
  keywordScore: number;
  formatScore: number;
  contentScore: number;
  overallScore: number;
  analyzedAt: Date;
  atsCompatibility?: {
    score: number;
    issues: string[];
    suggestions: string[];
  };
  jobMatchScore?: number;
  improvementPriority?: {
    section: string;
    issues: string[];
    priority: 'high' | 'medium' | 'low';
  }[];
  skillGaps?: {
    missing: string[];
    weak: string[];
    suggested: string[];
  };
}
