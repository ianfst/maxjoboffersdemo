import { MembershipTier } from '../types/membership';

export interface FeatureAccess {
  canAccessWebinars: boolean;
  canAccessFinancialPlanning: boolean;
  canAccessPremiumContent: boolean;
  maxResumes: number;
  maxLinkedInPosts: number;
}

export const getTierFeatures = (tier: MembershipTier): FeatureAccess => {
  switch (tier) {
    case 'platinum':
      return {
        canAccessWebinars: true,
        canAccessFinancialPlanning: true,
        canAccessPremiumContent: true,
        maxResumes: 10,
        maxLinkedInPosts: 5,
      };
    case 'standard':
      return {
        canAccessWebinars: true,
        canAccessFinancialPlanning: false,
        canAccessPremiumContent: false,
        maxResumes: 5,
        maxLinkedInPosts: 3,
      };
    default:
      return {
        canAccessWebinars: false,
        canAccessFinancialPlanning: false,
        canAccessPremiumContent: false,
        maxResumes: 1,
        maxLinkedInPosts: 1,
      };
  }
};
