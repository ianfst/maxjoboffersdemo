interface AnonymizationRules {
  [key: string]: {
    type: 'mask' | 'hash' | 'truncate' | 'redact' | 'preserve';
    options?: {
      preserveLength?: boolean;
      preserveFormat?: boolean;
      maskChar?: string;
      truncateLength?: number;
      salt?: string;
    };
  };
}

class Anonymizer {
  private static instance: Anonymizer;
  
  private readonly defaultRules: AnonymizationRules = {
    email: {
      type: 'mask',
      options: {
        preserveFormat: true,
        maskChar: '*'
      }
    },
    phone: {
      type: 'mask',
      options: {
        preserveFormat: true,
        maskChar: '*'
      }
    },
    name: {
      type: 'truncate',
      options: {
        truncateLength: 1
      }
    },
    address: {
      type: 'redact'
    },
    ip: {
      type: 'mask',
      options: {
        preserveFormat: true,
        maskChar: '*'
      }
    },
    ssn: {
      type: 'mask',
      options: {
        preserveLength: true,
        maskChar: '*'
      }
    }
  };

  private constructor() {}

  static getInstance(): Anonymizer {
    if (!Anonymizer.instance) {
      Anonymizer.instance = new Anonymizer();
    }
    return Anonymizer.instance;
  }

  anonymizeData(
    data: any,
    customRules: AnonymizationRules = {}
  ): any {
    const rules = { ...this.defaultRules, ...customRules };
    
    if (typeof data !== 'object' || data === null) {
      return data;
    }

    if (Array.isArray(data)) {
      return data.map(item => this.anonymizeData(item, customRules));
    }

    const result: any = {};
    
    for (const [key, value] of Object.entries(data)) {
      const rule = this.findMatchingRule(key, rules);
      
      if (rule) {
        result[key] = this.applyAnonymization(value, rule);
      } else if (typeof value === 'object' && value !== null) {
        result[key] = this.anonymizeData(value, customRules);
      } else {
        result[key] = value;
      }
    }

    return result;
  }

  private findMatchingRule(
    key: string,
    rules: AnonymizationRules
  ): AnonymizationRules[string] | null {
    const normalizedKey = key.toLowerCase();
    
    // Direct match
    if (rules[normalizedKey]) {
      return rules[normalizedKey];
    }

    // Pattern matching
    for (const [ruleKey, rule] of Object.entries(rules)) {
      if (normalizedKey.includes(ruleKey)) {
        return rule;
      }
    }

    return null;
  }

  private applyAnonymization(
    value: any,
    rule: AnonymizationRules[string]
  ): any {
    if (typeof value !== 'string') {
      return value;
    }

    switch (rule.type) {
      case 'mask':
        return this.maskValue(value, rule.options);
      
      case 'hash':
        return this.hashValue(value, rule.options?.salt);
      
      case 'truncate':
        return this.truncateValue(value, rule.options?.truncateLength || 1);
      
      case 'redact':
        return '[REDACTED]';
      
      case 'preserve':
        return value;
      
      default:
        return value;
    }
  }

  private maskValue(
    value: string,
    options?: AnonymizationRules[string]['options']
  ): string {
    const maskChar = options?.maskChar || '*';

    if (options?.preserveFormat) {
      // Preserve email format
      if (value.includes('@')) {
        const [local, domain] = value.split('@');
        const maskedLocal = local[0] + maskChar.repeat(local.length - 1);
        return `${maskedLocal}@${domain}`;
      }
      
      // Preserve phone format
      if (/^\+?\d[\d\s-]+$/.test(value)) {
        return value.replace(/\d(?=\d{4})/g, maskChar);
      }
    }

    if (options?.preserveLength) {
      return maskChar.repeat(value.length);
    }

    return maskChar.repeat(4);
  }

  private hashValue(value: string, salt: string = ''): string {
    // Simple hash function for demonstration
    // In production, use a proper cryptographic hash function
    let hash = 0;
    const str = value + salt;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(36);
  }

  private truncateValue(value: string, length: number): string {
    return value.slice(0, length) + (value.length > length ? '...' : '');
  }

  // Utility method to detect potentially sensitive data
  detectSensitiveData(data: any): string[] {
    const sensitivePatterns = {
      email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/,
      phone: /(\+\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/,
      ssn: /\d{3}-?\d{2}-?\d{4}/,
      creditCard: /\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}/
    };

    const sensitiveFields: string[] = [];

    const checkValue = (value: any, path: string) => {
      if (typeof value === 'string') {
        for (const [type, pattern] of Object.entries(sensitivePatterns)) {
          if (pattern.test(value)) {
            sensitiveFields.push(`${path} (${type})`);
          }
        }
      } else if (typeof value === 'object' && value !== null) {
        for (const [key, val] of Object.entries(value)) {
          checkValue(val, path ? `${path}.${key}` : key);
        }
      }
    };

    checkValue(data, '');
    return sensitiveFields;
  }
}

export const anonymizer = Anonymizer.getInstance();
