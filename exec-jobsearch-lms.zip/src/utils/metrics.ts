import { Counter, Histogram } from 'prom-client';

// Request count metric
export const requestCounter = new Counter({
  name: 'app_request_count_total',
  help: 'Total number of requests',
  labelNames: ['method', 'endpoint', 'status'],
});

// Error count metric
export const errorCounter = new Counter({
  name: 'app_error_count_total',
  help: 'Total number of errors',
  labelNames: ['type', 'message'],
});

// Request duration metric
export const requestDurationHistogram = new Histogram({
  name: 'app_request_duration_seconds',
  help: 'Request duration in seconds',
  labelNames: ['method', 'endpoint'],
  buckets: [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10],
});

// Memory usage metric
export const memoryGauge = new Counter({
  name: 'app_memory_usage_bytes',
  help: 'Memory usage in bytes',
});

// Active users metric
export const activeUsersGauge = new Counter({
  name: 'app_active_users_total',
  help: 'Number of active users',
});

// API error rate metric
export const apiErrorCounter = new Counter({
  name: 'app_api_error_count_total',
  help: 'Total number of API errors',
  labelNames: ['endpoint', 'status'],
});

// Component render time metric
export const componentRenderHistogram = new Histogram({
  name: 'app_component_render_duration_seconds',
  help: 'Component render duration in seconds',
  labelNames: ['component'],
  buckets: [0.01, 0.05, 0.1, 0.5, 1],
});
