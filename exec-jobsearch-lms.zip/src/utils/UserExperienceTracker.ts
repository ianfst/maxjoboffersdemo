import { useEffect, useRef } from 'react';
import api from '../api/config';

interface UserAction {
  type: string;
  path: string;
  timestamp: number;
  metadata?: Record<string, any>;
}

interface HeatmapData {
  x: number;
  y: number;
  timestamp: number;
  elementId?: string;
  elementType?: string;
}

class UserExperienceTracker {
  private static instance: UserExperienceTracker;
  private actions: UserAction[] = [];
  private heatmapData: HeatmapData[] = [];
  private sessionId: string;
  private batchSize = 50;
  private batchTimeout = 5000; // 5 seconds
  private timer: NodeJS.Timeout | null = null;

  private constructor() {
    this.sessionId = this.generateSessionId();
    this.setupUnloadHandler();
  }

  static getInstance(): UserExperienceTracker {
    if (!UserExperienceTracker.instance) {
      UserExperienceTracker.instance = new UserExperienceTracker();
    }
    return UserExperienceTracker.instance;
  }

  private generateSessionId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private setupUnloadHandler(): void {
    window.addEventListener('beforeunload', () => {
      this.flushData(true);
    });
  }

  private async flushData(immediate = false): Promise<void> {
    if (this.actions.length === 0 && this.heatmapData.length === 0) {
      return;
    }

    if (!immediate && this.actions.length < this.batchSize) {
      if (this.timer === null) {
        this.timer = setTimeout(() => {
          this.flushData(true);
          this.timer = null;
        }, this.batchTimeout);
      }
      return;
    }

    try {
      await api.post('/api/analytics/user-experience', {
        sessionId: this.sessionId,
        actions: this.actions,
        heatmapData: this.heatmapData
      });

      this.actions = [];
      this.heatmapData = [];
    } catch (error) {
      console.error('Failed to send UX data:', error);
    }
  }

  trackAction(type: string, metadata?: Record<string, any>): void {
    this.actions.push({
      type,
      path: window.location.pathname,
      timestamp: Date.now(),
      metadata
    });

    this.flushData();
  }

  trackClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    this.heatmapData.push({
      x: event.pageX,
      y: event.pageY,
      timestamp: Date.now(),
      elementId: target.id,
      elementType: target.tagName.toLowerCase()
    });

    this.flushData();
  }

  trackScroll(percentage: number): void {
    this.trackAction('scroll', { percentage });
  }

  trackDwellTime(component: string, duration: number): void {
    this.trackAction('dwell_time', { component, duration });
  }

  trackFormInteraction(formId: string, fieldId: string, action: string): void {
    this.trackAction('form_interaction', { formId, fieldId, action });
  }

  trackError(error: Error, componentId: string): void {
    this.trackAction('error', {
      message: error.message,
      componentId,
      stack: error.stack
    });
  }
}

export const useUserExperience = (componentId: string) => {
  const tracker = UserExperienceTracker.getInstance();
  const startTime = useRef(Date.now());

  useEffect(() => {
    const handleClick = (event: MouseEvent) => {
      tracker.trackClick(event);
    };

    const handleScroll = () => {
      const scrollPercentage = 
        (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      tracker.trackScroll(Math.round(scrollPercentage));
    };

    window.addEventListener('click', handleClick);
    window.addEventListener('scroll', handleScroll);

    return () => {
      const endTime = Date.now();
      const duration = endTime - startTime.current;
      tracker.trackDwellTime(componentId, duration);

      window.removeEventListener('click', handleClick);
      window.removeEventListener('scroll', handleScroll);
    };
  }, [componentId]);

  return {
    trackFormInteraction: (formId: string, fieldId: string, action: string) => {
      tracker.trackFormInteraction(formId, fieldId, action);
    },
    trackError: (error: Error) => {
      tracker.trackError(error, componentId);
    }
  };
};

export default UserExperienceTracker;
