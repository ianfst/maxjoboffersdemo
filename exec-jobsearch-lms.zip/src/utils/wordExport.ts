import { Document, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, BorderStyle, WidthType, AlignmentType, IParagraphOptions } from 'docx';
import { saveAs } from 'file-saver';
import { Buffer } from 'buffer';

export interface ResumeSection {
  type: 'heading' | 'text' | 'bullets' | 'table';
  content: string | string[];
  level?: number;
  format?: {
    bold?: boolean;
    italic?: boolean;
    size?: number;
    color?: string;
    spacing?: number;
  };
}

export interface ResumeTemplate {
  id: string;
  name: string;
  description: string;
  preview: string; // URL to preview image
  styles: {
    headingFont: string;
    bodyFont: string;
    primaryColor: string;
    secondaryColor: string;
    spacing: {
      beforeSection: number;
      afterSection: number;
      betweenItems: number;
    };
    margins: {
      top: number;
      bottom: number;
      left: number;
      right: number;
    };
  };
  structure?: {
    order: string[];
    sections: {
      [key: string]: {
        type: string;
        title?: string;
        maxLength?: number;
        columns?: number;
        format?: string;
        items?: {
          order: string[];
          format: {
            [key: string]: {
              bold?: boolean;
              italic?: boolean;
              size?: number;
              align?: string;
              bullets?: boolean;
              indent?: number;
            };
          };
        };
      };
    };
  };
}

const templates: ResumeTemplate[] = [
  {
    id: 'custom-professional',
    name: 'Custom Professional',
    description: 'Optimized format with proven success for executive roles',
    preview: '/templates/custom-professional.png',
    styles: {
      headingFont: 'Helvetica',
      bodyFont: 'Helvetica',
      primaryColor: '2E5BFF',
      secondaryColor: '6B7280',
      spacing: {
        beforeSection: 400,
        afterSection: 200,
        betweenItems: 100
      },
      margins: {
        top: 1440,
        bottom: 1440,
        left: 1440,
        right: 1440
      }
    },
    structure: {
      order: [
        'contact',
        'summary',
        'expertise',
        'highlights',
        'experience',
        'education',
        'certifications',
        'technical',
        'additional'
      ],
      sections: {
        contact: {
          type: 'contact',
          title: '',
          format: 'centered',
          spacing: { after: 300 }
        },
        summary: {
          type: 'paragraph',
          title: 'EXECUTIVE SUMMARY',
          maxLength: 500,
          format: {
            style: 'concise',
            alignment: 'justified',
            spacing: { after: 400 }
          }
        },
        expertise: {
          type: 'columns',
          title: 'CORE COMPETENCIES',
          columns: 3,
          format: {
            style: 'compact',
            bullets: 'arrow',
            spacing: { between: 150 }
          }
        },
        highlights: {
          type: 'achievements',
          title: 'CAREER HIGHLIGHTS',
          format: {
            style: 'metrics',
            maxItems: 4,
            layout: 'grid'
          }
        },
        experience: {
          type: 'timeline',
          title: 'PROFESSIONAL EXPERIENCE',
          items: {
            order: ['title', 'company', 'location', 'dates', 'overview', 'achievements'],
            format: {
              title: { bold: true, size: 12, case: 'upper' },
              company: { bold: true, size: 12 },
              location: { italic: true },
              dates: { align: 'right', format: 'MMM YYYY' },
              overview: { style: 'concise', maxLength: 200 },
              achievements: { 
                bullets: true, 
                indent: 1,
                prefix: '▪',
                maxItems: 6,
                style: 'impact' 
              }
            }
          }
        },
        education: {
          type: 'list',
          title: 'EDUCATION',
          format: {
            style: 'reverse',
            details: ['degree', 'institution', 'year', 'honors'],
            spacing: { between: 200 }
          }
        },
        certifications: {
          type: 'list',
          title: 'CERTIFICATIONS & LICENSES',
          format: {
            style: 'columns',
            columns: 2,
            details: ['name', 'issuer', 'year'],
            sort: 'recent'
          }
        },
        technical: {
          type: 'categories',
          title: 'TECHNICAL PROFICIENCIES',
          format: {
            style: 'grouped',
            layout: 'table',
            categories: [
              'Leadership & Strategy',
              'Technical Skills',
              'Industry Knowledge',
              'Tools & Platforms'
            ]
          }
        },
        additional: {
          type: 'list',
          title: 'ADDITIONAL QUALIFICATIONS',
          format: {
            style: 'concise',
            categories: [
              'Languages',
              'Publications',
              'Speaking Engagements',
              'Board Positions',
              'Professional Affiliations'
            ],
            optional: true
          }
        }
      }
    },
    styles: {
      headingFont: 'Helvetica',
      bodyFont: 'Helvetica',
      primaryColor: '2E5BFF',
      secondaryColor: '6B7280',
      fontSize: {
        heading1: 16,
        heading2: 14,
        body: 11
      },
      spacing: {
        beforeSection: 400,
        afterSection: 300,
        betweenItems: 150,
        paragraphs: 200
      },
      margins: {
        top: 1440,
        bottom: 1440,
        left: 1440,
        right: 1440
      }
    }
  },
  {
    id: 'executive-modern',
    name: 'Executive Modern',
    description: 'Clean, professional layout with modern typography',
    preview: '/templates/executive-modern.png',
    styles: {
      headingFont: 'Helvetica',
      bodyFont: 'Helvetica',
      primaryColor: '2E5BFF',
      secondaryColor: '6B7280',
      spacing: {
        beforeSection: 400,
        afterSection: 200,
        betweenItems: 100
      },
      margins: {
        top: 1440, // 1 inch in twips
        bottom: 1440,
        left: 1440,
        right: 1440
      }
    }
  },
  {
    id: 'traditional-elegant',
    name: 'Traditional Elegant',
    description: 'Classic format preferred by established industries',
    preview: '/templates/traditional-elegant.png',
    styles: {
      headingFont: 'Times New Roman',
      bodyFont: 'Times New Roman',
      primaryColor: '000000',
      secondaryColor: '666666',
      spacing: {
        beforeSection: 300,
        afterSection: 200,
        betweenItems: 120
      },
      margins: {
        top: 1440,
        bottom: 1440,
        left: 1800, // 1.25 inch margins
        right: 1800
      }
    }
  },
  {
    id: 'tech-forward',
    name: 'Tech Forward',
    description: 'Modern design with emphasis on skills and achievements',
    preview: '/templates/tech-forward.png',
    styles: {
      headingFont: 'Arial',
      bodyFont: 'Arial',
      primaryColor: '0F172A',
      secondaryColor: '3B82F6',
      spacing: {
        beforeSection: 360,
        afterSection: 240,
        betweenItems: 120
      },
      margins: {
        top: 1440,
        bottom: 1440,
        left: 1440,
        right: 1440
      }
    }
  }
];

export class WordExporter {
  private template: ResumeTemplate;
  private structure: any;
  
  constructor(templateId: string) {
    const template = templates.find(t => t.id === templateId);
    if (!template) {
      throw new Error('Template not found');
    }
    this.template = template;
    this.structure = template.structure || {};
  }

  private createHeading(text: string, level: number): Paragraph {
    const style = this.template.styles;
    return new Paragraph({
      text,
      heading: level as HeadingLevel,
      spacing: {
        before: style.spacing.beforeSection,
        after: style.spacing.afterSection
      },
      font: {
        name: style.headingFont
      },
      color: style.primaryColor
    });
  }

  private createTextParagraph(text: string, format?: IParagraphOptions): Paragraph {
    const style = this.template.styles;
    return new Paragraph({
      children: [
        new TextRun({
          text,
          font: {
            name: style.bodyFont
          },
          ...format
        })
      ],
      spacing: {
        before: style.spacing.betweenItems
      }
    });
  }

  private createBulletList(items: string[]): Paragraph[] {
    return items.map(item => 
      new Paragraph({
        text: item,
        bullet: {
          level: 0
        },
        spacing: {
          before: this.template.styles.spacing.betweenItems
        }
      })
    );
  }

  async exportToWord(sections: ResumeSection[]): Promise<Blob> {
    const doc = new Document({
      sections: [{
        properties: {
          page: {
            margin: this.template.styles.margins
          }
        },
        children: this.generateContent(sections)
      }]
    });

    const buffer = await doc.save();
    return new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  }

  private generateContent(sections: ResumeSection[]): Paragraph[] {
    const content: Paragraph[] = [];

    if (this.structure.order) {
      this.structure.order.forEach(sectionId => {
        const section = this.structure.sections[sectionId];
        if (section) {
          const sectionContent = sections.find(s => s.type === section.type);
          if (sectionContent) {
            content.push(...this.createSection(section, sectionContent.content));
          }
        }
      });
    } else {
      sections.forEach(section => {
        switch (section.type) {
          case 'heading':
            content.push(this.createHeading(section.content as string, section.level || 1));
            break;
          case 'text':
            content.push(this.createTextParagraph(section.content as string, section.format));
            break;
          case 'bullets':
            content.push(...this.createBulletList(section.content as string[]));
            break;
          case 'table':
            // Add table support if needed
            break;
        }
      });
    }

    return content;
  }

  private createSection(section: any, content: any): Paragraph[] {
    const paragraphs: Paragraph[] = [];
    
    // Add section title if present
    if (section.title) {
      paragraphs.push(this.createHeading(section.title, 1));
    }

    switch (section.type) {
      case 'contact':
        paragraphs.push(...this.createContactSection(content));
        break;
      case 'paragraph':
        paragraphs.push(this.createTextParagraph(content));
        break;
      case 'columns':
        paragraphs.push(...this.createColumnsSection(content, section.columns));
        break;
      case 'timeline':
        paragraphs.push(...this.createTimelineSection(content, section.items));
        break;
      case 'list':
        paragraphs.push(...this.createListSection(content, section.format));
        break;
      case 'categories':
        paragraphs.push(...this.createCategoriesSection(content));
        break;
    }

    return paragraphs;
  }

  private createContactSection(contact: any): Paragraph[] {
    return [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({
            text: contact.name,
            bold: true,
            size: 28
          })
        ]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ text: contact.email }),
          new TextRun({ text: ' • ' }),
          new TextRun({ text: contact.phone }),
          new TextRun({ text: ' • ' }),
          new TextRun({ text: contact.location })
        ]
      })
    ];
  }

  private createColumnsSection(items: string[], columns: number): Paragraph[] {
    // Create a table for the columns
    const table = new Table({
      width: {
        size: 100,
        type: WidthType.PERCENTAGE
      },
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
        insideHorizontal: { style: BorderStyle.NONE },
        insideVertical: { style: BorderStyle.NONE }
      },
      rows: this.chunkArray(items, columns).map(chunk =>
        new TableRow({
          children: chunk.map(item =>
            new TableCell({
              children: [
                new Paragraph({
                  bullet: { level: 0 },
                  text: item
                })
              ]
            })
          )
        })
      )
    });

    return [table];
  }

  private createTimelineSection(experiences: any[], format: any): Paragraph[] {
    const paragraphs: Paragraph[] = [];

    experiences.forEach(exp => {
      // Title and Company line
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({
              text: exp.title,
              ...format.title
            }),
            new TextRun({ text: ' - ' }),
            new TextRun({
              text: exp.company,
              ...format.company
            })
          ]
        })
      );

      // Location and Dates line
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({
              text: exp.location,
              ...format.location
            }),
            new TextRun({ text: '  ' }),
            new TextRun({
              text: exp.dates,
              ...format.dates
            })
          ]
        })
      );

      // Achievements
      exp.achievements.forEach((achievement: string) => {
        paragraphs.push(
          new Paragraph({
            text: achievement,
            bullet: { level: 0 },
            indent: format.achievements.indent
          })
        );
      });

      // Add spacing after each experience
      paragraphs.push(
        new Paragraph({
          spacing: { after: this.template.styles.spacing.betweenItems }
        })
      );
    });

    return paragraphs;
  }

  private chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  private createListSection(items: string[], format: string): Paragraph[] {
    const paragraphs: Paragraph[] = [];

    items.forEach(item => {
      paragraphs.push(
        new Paragraph({
          text: item,
          bullet: { level: 0 },
          spacing: {
            before: this.template.styles.spacing.betweenItems
          }
        })
      );
    });

    return paragraphs;
  }

  private createCategoriesSection(categories: any[]): Paragraph[] {
    const paragraphs: Paragraph[] = [];

    categories.forEach(category => {
      paragraphs.push(
        new Paragraph({
          text: category.name,
          bold: true,
          spacing: {
            before: this.template.styles.spacing.beforeSection
          }
        })
      );

      category.items.forEach(item => {
        paragraphs.push(
          new Paragraph({
            text: item,
            bullet: { level: 0 },
            spacing: {
              before: this.template.styles.spacing.betweenItems
            }
          })
        );
      });
    });

    return paragraphs;
  }
}

export const downloadResume = async (
  sections: ResumeSection[],
  templateId: string,
  fileName: string
): Promise<void> => {
  try {
    const exporter = new WordExporter(templateId);
    const blob = await exporter.exportToWord(sections);
    saveAs(blob, `${fileName}.docx`);
  } catch (error) {
    console.error('Error exporting to Word:', error);
    throw error;
  }
};
