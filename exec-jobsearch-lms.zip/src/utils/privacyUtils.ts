import { securityUtils } from './securityUtils';

interface DataRetentionRules {
  [key: string]: {
    retentionPeriod: number; // in days
    sensitivityLevel: 'low' | 'medium' | 'high';
    encryptionRequired: boolean;
    allowedUsage: string[];
  };
}

class PrivacyUtils {
  private static instance: PrivacyUtils;
  
  // Define data retention and handling rules
  private dataRetentionRules: DataRetentionRules = {
    'personal.contact': {
      retentionPeriod: 365 * 2, // 2 years
      sensitivityLevel: 'high',
      encryptionRequired: true,
      allowedUsage: ['communication', 'account', 'support']
    },
    'personal.financial': {
      retentionPeriod: 365 * 7, // 7 years
      sensitivityLevel: 'high',
      encryptionRequired: true,
      allowedUsage: ['financial-services', 'account']
    },
    'personal.professional': {
      retentionPeriod: 365 * 5, // 5 years
      sensitivityLevel: 'medium',
      encryptionRequired: true,
      allowedUsage: ['career-services', 'recommendations', 'marketing']
    },
    'ai.interaction': {
      retentionPeriod: 365, // 1 year
      sensitivityLevel: 'high',
      encryptionRequired: true,
      allowedUsage: ['service-improvement', 'support']
    },
    'marketing.preferences': {
      retentionPeriod: 365 * 3, // 3 years
      sensitivityLevel: 'low',
      encryptionRequired: false,
      allowedUsage: ['marketing', 'communications', 'preferences']
    }
  };

  private constructor() {
    this.setupPrivacyControls();
  }

  static getInstance(): PrivacyUtils {
    if (!PrivacyUtils.instance) {
      PrivacyUtils.instance = new PrivacyUtils();
    }
    return PrivacyUtils.instance;
  }

  private setupPrivacyControls() {
    // Setup periodic data cleanup
    setInterval(() => {
      this.cleanupExpiredData();
    }, 24 * 60 * 60 * 1000); // Daily cleanup
  }

  async storePrivateData(
    category: keyof DataRetentionRules,
    data: any,
    purpose: string
  ): Promise<void> {
    const rules = this.dataRetentionRules[category];
    
    if (!rules) {
      throw new Error(`Invalid data category: ${category}`);
    }

    if (!rules.allowedUsage.includes(purpose)) {
      throw new Error(`Invalid purpose '${purpose}' for category '${category}'`);
    }

    const metadata = {
      category,
      timestamp: new Date().toISOString(),
      expiresAt: new Date(Date.now() + rules.retentionPeriod * 24 * 60 * 60 * 1000).toISOString(),
      purpose,
      sensitivityLevel: rules.sensitivityLevel
    };

    const storageKey = `private_${category}_${Date.now()}`;

    if (rules.encryptionRequired) {
      await securityUtils.withSecureContext(async () => {
        securityUtils.setSecureItem(
          storageKey,
          JSON.stringify({ data, metadata }),
          rules.retentionPeriod * 24 * 60
        );
      });
    } else {
      localStorage.setItem(
        storageKey,
        JSON.stringify({ data, metadata })
      );
    }
  }

  async retrievePrivateData(
    category: keyof DataRetentionRules,
    purpose: string
  ): Promise<any[]> {
    const rules = this.dataRetentionRules[category];
    
    if (!rules) {
      throw new Error(`Invalid data category: ${category}`);
    }

    if (!rules.allowedUsage.includes(purpose)) {
      throw new Error(`Invalid purpose '${purpose}' for category '${category}'`);
    }

    const results: any[] = [];
    const prefix = `private_${category}_`;

    // Search in secure storage first
    if (rules.encryptionRequired) {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith(prefix)) {
          const data = securityUtils.getSecureItem(key);
          if (data) {
            try {
              const parsed = JSON.parse(data);
              if (new Date(parsed.metadata.expiresAt) > new Date()) {
                results.push(parsed.data);
              }
            } catch (e) {
              console.error('Error parsing private data:', e);
            }
          }
        }
      }
    } else {
      // Search in regular storage
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith(prefix)) {
          try {
            const item = localStorage.getItem(key);
            if (item) {
              const parsed = JSON.parse(item);
              if (new Date(parsed.metadata.expiresAt) > new Date()) {
                results.push(parsed.data);
              }
            }
          } catch (e) {
            console.error('Error parsing private data:', e);
          }
        }
      }
    }

    return results;
  }

  private async cleanupExpiredData(): Promise<void> {
    const now = new Date();

    for (const category in this.dataRetentionRules) {
      const prefix = `private_${category}_`;
      const rules = this.dataRetentionRules[category];

      if (rules.encryptionRequired) {
        // Cleanup secure storage
        for (let i = localStorage.length - 1; i >= 0; i--) {
          const key = localStorage.key(i);
          if (key?.startsWith(prefix)) {
            const data = securityUtils.getSecureItem(key);
            if (data) {
              try {
                const parsed = JSON.parse(data);
                if (new Date(parsed.metadata.expiresAt) <= now) {
                  securityUtils.removeSecureItem(key);
                }
              } catch (e) {
                console.error('Error parsing private data during cleanup:', e);
                securityUtils.removeSecureItem(key);
              }
            }
          }
        }
      } else {
        // Cleanup regular storage
        for (let i = localStorage.length - 1; i >= 0; i--) {
          const key = localStorage.key(i);
          if (key?.startsWith(prefix)) {
            try {
              const item = localStorage.getItem(key);
              if (item) {
                const parsed = JSON.parse(item);
                if (new Date(parsed.metadata.expiresAt) <= now) {
                  localStorage.removeItem(key);
                }
              }
            } catch (e) {
              console.error('Error parsing private data during cleanup:', e);
              localStorage.removeItem(key);
            }
          }
        }
      }
    }
  }

  getDataRetentionRules(): DataRetentionRules {
    return { ...this.dataRetentionRules };
  }

  validateDataUsage(category: keyof DataRetentionRules, purpose: string): boolean {
    const rules = this.dataRetentionRules[category];
    return rules?.allowedUsage.includes(purpose) || false;
  }
}

export const privacyUtils = PrivacyUtils.getInstance();
