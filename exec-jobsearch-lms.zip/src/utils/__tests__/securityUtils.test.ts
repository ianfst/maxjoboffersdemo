import { securityUtils, SecurityContext } from '../securityUtils';
import { act } from '@testing-library/react';

describe('SecurityUtils', () => {
  let securityContext: SecurityContext;
  
  beforeEach(() => {
    localStorage.clear();
    jest.useFakeTimers();
    securityContext = new SecurityContext();
  });

  afterEach(() => {
    localStorage.clear();
    jest.useRealTimers();
    securityContext.cleanup();
  });

  describe('Secure Storage', () => {
    it('should store and retrieve secure items', () => {
      const testKey = 'testKey';
      const testValue = 'testValue';
      
      securityUtils.setSecureItem(testKey, testValue);
      expect(securityUtils.getSecureItem(testKey)).toBe(testValue);
    });

    it('should handle item expiration', () => {
      const testKey = 'expiringKey';
      const testValue = 'expiringValue';
      
      securityUtils.setSecureItem(testKey, testValue, 1); // 1 minute expiry
      
      // Fast forward 2 minutes
      act(() => {
        jest.advanceTimersByTime(2 * 60 * 1000);
      });
      
      expect(securityUtils.getSecureItem(testKey)).toBeNull();
    });

    it('should remove items', () => {
      const testKey = 'removeKey';
      const testValue = 'removeValue';
      
      securityUtils.setSecureItem(testKey, testValue);
      securityUtils.removeSecureItem(testKey);
      
      expect(securityUtils.getSecureItem(testKey)).toBeNull();
    });
  });

  describe('Security Context', () => {
    it('should initialize with default values', () => {
      expect(securityContext.isActive()).toBe(true);
      expect(securityContext.getLastActivity()).toBeDefined();
    });

    it('should update activity timestamp', () => {
      const initialTimestamp = securityContext.getLastActivity();
      jest.advanceTimersByTime(1000);
      securityContext.updateActivity();
      expect(securityContext.getLastActivity()).toBeGreaterThan(initialTimestamp);
    });

    it('should handle session timeout', () => {
      jest.advanceTimersByTime(31 * 60 * 1000); // 31 minutes
      expect(securityContext.isActive()).toBe(false);
    });

    it('should clean up on visibility change', () => {
      const mockVisibilityState = jest.spyOn(document, 'visibilityState', 'get');
      mockVisibilityState.mockReturnValue('hidden');
      
      document.dispatchEvent(new Event('visibilitychange'));
      
      expect(securityContext.getVisibilityValue()).toBeNull();
      mockVisibilityState.mockRestore();
    });

    it('should handle encryption/decryption', () => {
      const testData = { sensitive: 'data' };
      const encrypted = securityContext.encrypt(testData);
      const decrypted = securityContext.decrypt(encrypted);
      expect(decrypted).toEqual(testData);
    });

    it('should handle secure operations', async () => {
      const sensitiveData = 'sensitive';
      const result = await securityUtils.withSecureContext(async () => {
        securityUtils.setSecureItem('sensitive', sensitiveData);
        return 'operation complete';
      }, ['sensitive']);

      expect(result).toBe('operation complete');
      expect(securityUtils.getSecureItem('sensitive')).toBeNull();
    });

    it('should clean up on visibility change', () => {
      const testKey = 'visibilityKey';
      const testValue = 'visibilityValue';
      
      securityUtils.setSecureItem(testKey, testValue);
      
      // Simulate tab becoming hidden
      Object.defineProperty(document, 'hidden', {
        configurable: true,
        get: () => true
      });
      
      document.dispatchEvent(new Event('visibilitychange'));
      
      expect(securityUtils.getSecureItem(testKey)).toBeNull();
    });
  });

  describe('Automatic Cleanup', () => {
    it('should periodically clean up expired items', () => {
      const testKey1 = 'cleanupKey1';
      const testKey2 = 'cleanupKey2';
      
      securityUtils.setSecureItem(testKey1, 'value1', 1); // 1 minute expiry
      securityUtils.setSecureItem(testKey2, 'value2', 10); // 10 minutes expiry
      
      // Fast forward 5 minutes
      act(() => {
        jest.advanceTimersByTime(5 * 60 * 1000);
      });
      
      expect(securityUtils.getSecureItem(testKey1)).toBeNull();
      expect(securityUtils.getSecureItem(testKey2)).toBe('value2');
    });
  });

  describe('Security Requirements', () => {
    it('should validate security requirements', () => {
      // Mock secure context
      Object.defineProperty(window, 'isSecureContext', {
        configurable: true,
        get: () => true
      });

      expect(securityUtils.validateSecurityRequirements()).toBe(true);
    });

    it('should detect insecure context', () => {
      // Mock insecure context
      Object.defineProperty(window, 'isSecureContext', {
        configurable: true,
        get: () => false
      });

      expect(securityUtils.validateSecurityRequirements()).toBe(false);
    });
  });
});
