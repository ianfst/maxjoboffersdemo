import { securityUtils } from './securityUtils';
import { sessionManager } from './sessionManager';

type AuditEventType = 
  | 'data.access'
  | 'data.modify'
  | 'consent.update'
  | 'ai.interaction'
  | 'privacy.setting'
  | 'security.event'
  | 'marketing.preference';

interface AuditEvent {
  type: AuditEventType;
  action: string;
  timestamp: string;
  userId?: string;
  details: Record<string, any>;
  sensitiveData: boolean;
  ipAddress?: string;
  userAgent?: string;
}

class AuditLogger {
  private static instance: AuditLogger;
  private readonly RETENTION_DAYS = 365; // 1 year retention
  private readonly MAX_BATCH_SIZE = 100;
  private eventQueue: AuditEvent[] = [];

  private constructor() {
    this.setupPeriodicFlush();
    this.setupStorageCleanup();
  }

  static getInstance(): AuditLogger {
    if (!AuditLogger.instance) {
      AuditLogger.instance = new AuditLogger();
    }
    return AuditLogger.instance;
  }

  private setupPeriodicFlush() {
    setInterval(() => {
      this.flushEvents();
    }, 5 * 60 * 1000); // Flush every 5 minutes
  }

  private setupStorageCleanup() {
    setInterval(() => {
      this.cleanupOldEvents();
    }, 24 * 60 * 60 * 1000); // Clean daily
  }

  async logEvent(
    type: AuditEventType,
    action: string,
    details: Record<string, any>,
    sensitiveData: boolean = false
  ) {
    const session = sessionManager.getSessionState();
    
    const event: AuditEvent = {
      type,
      action,
      timestamp: new Date().toISOString(),
      userId: session.userId || undefined,
      details: this.sanitizeDetails(details),
      sensitiveData,
      ipAddress: await this.getIpAddress(),
      userAgent: navigator.userAgent
    };

    this.eventQueue.push(event);

    // Flush if queue is getting large
    if (this.eventQueue.length >= this.MAX_BATCH_SIZE) {
      await this.flushEvents();
    }
  }

  private sanitizeDetails(details: Record<string, any>): Record<string, any> {
    const sanitized: Record<string, any> = {};
    
    for (const [key, value] of Object.entries(details)) {
      // Remove sensitive patterns
      if (typeof value === 'string') {
        // Mask email addresses
        if (value.includes('@')) {
          sanitized[key] = value.replace(/([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})/i, '***@$2');
        }
        // Mask phone numbers
        else if (/\d{3}[-.]?\d{3}[-.]?\d{4}/.test(value)) {
          sanitized[key] = '***-***-****';
        }
        // Mask other sensitive data
        else if (key.toLowerCase().includes('password') || 
                 key.toLowerCase().includes('token') || 
                 key.toLowerCase().includes('secret')) {
          sanitized[key] = '********';
        }
        else {
          sanitized[key] = value;
        }
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }

  private async getIpAddress(): Promise<string | undefined> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      console.error('Failed to get IP address:', error);
      return undefined;
    }
  }

  private async flushEvents() {
    if (this.eventQueue.length === 0) return;

    const events = [...this.eventQueue];
    this.eventQueue = [];

    try {
      // Store sensitive events securely
      const sensitiveEvents = events.filter(e => e.sensitiveData);
      if (sensitiveEvents.length > 0) {
        await securityUtils.withSecureContext(async () => {
          const key = `audit_sensitive_${Date.now()}`;
          securityUtils.setSecureItem(
            key,
            JSON.stringify(sensitiveEvents),
            this.RETENTION_DAYS * 24 * 60
          );
        });
      }

      // Store non-sensitive events
      const nonSensitiveEvents = events.filter(e => !e.sensitiveData);
      if (nonSensitiveEvents.length > 0) {
        const key = `audit_${Date.now()}`;
        localStorage.setItem(key, JSON.stringify(nonSensitiveEvents));
      }
    } catch (error) {
      console.error('Failed to flush audit events:', error);
      // Restore events to queue
      this.eventQueue = [...events, ...this.eventQueue];
    }
  }

  private async cleanupOldEvents() {
    const now = Date.now();
    const retentionMs = this.RETENTION_DAYS * 24 * 60 * 60 * 1000;

    // Clean up localStorage
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (key?.startsWith('audit_')) {
        const timestamp = parseInt(key.split('_')[1]);
        if (now - timestamp > retentionMs) {
          localStorage.removeItem(key);
        }
      }
    }
  }

  async getAuditTrail(
    type?: AuditEventType,
    startDate?: Date,
    endDate?: Date
  ): Promise<AuditEvent[]> {
    const events: AuditEvent[] = [];

    // Flush current events first
    await this.flushEvents();

    // Helper to check if event matches filters
    const matchesFilter = (event: AuditEvent) => {
      if (type && event.type !== type) return false;
      if (startDate && new Date(event.timestamp) < startDate) return false;
      if (endDate && new Date(event.timestamp) > endDate) return false;
      return true;
    };

    // Collect from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith('audit_')) {
        try {
          const item = localStorage.getItem(key);
          if (item) {
            const storedEvents: AuditEvent[] = JSON.parse(item);
            events.push(...storedEvents.filter(matchesFilter));
          }
        } catch (error) {
          console.error('Error reading audit events:', error);
        }
      }
    }

    return events.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }
}

export const auditLogger = AuditLogger.getInstance();
