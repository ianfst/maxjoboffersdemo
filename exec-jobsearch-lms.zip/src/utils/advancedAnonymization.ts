import { anonymizer } from './anonymizer';
import CryptoJS from 'crypto-js';

interface TokenizationConfig {
  tokenSalt: string;
  tokenExpiry: number; // in minutes
}

interface GeneralizationRules {
  [key: string]: {
    type: 'range' | 'category' | 'topBottom';
    rules: any;
  };
}

class AdvancedAnonymizationService {
  private static instance: AdvancedAnonymizationService;
  private tokenizationConfig: TokenizationConfig = {
    tokenSalt: 'your-secure-salt',
    tokenExpiry: 60
  };

  private generalizationRules: GeneralizationRules = {
    age: {
      type: 'range',
      rules: [
        { min: 0, max: 18, label: '<18' },
        { min: 19, max: 25, label: '19-25' },
        { min: 26, max: 35, label: '26-35' },
        { min: 36, max: 50, label: '36-50' },
        { min: 51, max: 150, label: '>50' }
      ]
    },
    salary: {
      type: 'range',
      rules: [
        { min: 0, max: 50000, label: '<50k' },
        { min: 50001, max: 100000, label: '50k-100k' },
        { min: 100001, max: 150000, label: '100k-150k' },
        { min: 150001, max: 200000, label: '150k-200k' },
        { min: 200001, max: Infinity, label: '>200k' }
      ]
    },
    location: {
      type: 'category',
      rules: {
        granularity: ['street', 'city', 'state', 'country']
      }
    },
    title: {
      type: 'category',
      rules: {
        categories: {
          'engineering': ['Software Engineer', 'Developer', 'Architect'],
          'management': ['Manager', 'Director', 'VP'],
          'finance': ['Accountant', 'Financial Analyst', 'Controller']
        }
      }
    }
  };

  private constructor() {}

  static getInstance(): AdvancedAnonymizationService {
    if (!AdvancedAnonymizationService.instance) {
      AdvancedAnonymizationService.instance = new AdvancedAnonymizationService();
    }
    return AdvancedAnonymizationService.instance;
  }

  // Tokenization
  tokenize(value: string): string {
    const timestamp = Date.now();
    const token = CryptoJS.SHA256(
      `${value}${this.tokenizationConfig.tokenSalt}${Math.floor(timestamp / (this.tokenizationConfig.tokenExpiry * 60000))}`
    ).toString();
    
    return `TOK_${token.substr(0, 16)}`;
  }

  // K-Anonymity
  applyKAnonymity(
    data: any[],
    sensitiveFields: string[],
    k: number
  ): any[] {
    const groups = new Map<string, any[]>();
    
    // Group records by quasi-identifiers
    data.forEach(record => {
      const key = sensitiveFields
        .map(field => this.generalizeValue(record[field], field))
        .join('|');
      
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(record);
    });

    // Apply suppression or generalization to groups smaller than k
    const anonymizedData: any[] = [];
    groups.forEach((group, key) => {
      if (group.length >= k) {
        anonymizedData.push(...group);
      } else {
        // Suppress or further generalize small groups
        const suppressedGroup = group.map(record => ({
          ...record,
          ...Object.fromEntries(
            sensitiveFields.map(field => [field, '[SUPPRESSED]'])
          )
        }));
        anonymizedData.push(...suppressedGroup);
      }
    });

    return anonymizedData;
  }

  // L-Diversity
  applyLDiversity(
    data: any[],
    sensitiveField: string,
    l: number
  ): any[] {
    const groups = new Map<string, any[]>();
    
    // Group records
    data.forEach(record => {
      const key = Object.entries(record)
        .filter(([field]) => field !== sensitiveField)
        .map(([_, value]) => value)
        .join('|');
      
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(record);
    });

    // Ensure l-diversity in each group
    const anonymizedData: any[] = [];
    groups.forEach((group, key) => {
      const uniqueValues = new Set(
        group.map(record => record[sensitiveField])
      );
      
      if (uniqueValues.size >= l) {
        anonymizedData.push(...group);
      } else {
        // Suppress groups that don't meet l-diversity
        const suppressedGroup = group.map(record => ({
          ...record,
          [sensitiveField]: '[SUPPRESSED]'
        }));
        anonymizedData.push(...suppressedGroup);
      }
    });

    return anonymizedData;
  }

  // T-Closeness
  applyTCloseness(
    data: any[],
    sensitiveField: string,
    t: number
  ): any[] {
    // Calculate global distribution
    const globalDist = this.calculateDistribution(
      data.map(record => record[sensitiveField])
    );

    const groups = new Map<string, any[]>();
    
    // Group records
    data.forEach(record => {
      const key = Object.entries(record)
        .filter(([field]) => field !== sensitiveField)
        .map(([_, value]) => value)
        .join('|');
      
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(record);
    });

    // Ensure t-closeness in each group
    const anonymizedData: any[] = [];
    groups.forEach((group, key) => {
      const groupDist = this.calculateDistribution(
        group.map(record => record[sensitiveField])
      );
      
      if (this.calculateEMD(globalDist, groupDist) <= t) {
        anonymizedData.push(...group);
      } else {
        // Suppress groups that don't meet t-closeness
        const suppressedGroup = group.map(record => ({
          ...record,
          [sensitiveField]: '[SUPPRESSED]'
        }));
        anonymizedData.push(...suppressedGroup);
      }
    });

    return anonymizedData;
  }

  // Differential Privacy
  addDifferentialPrivacy(
    value: number,
    epsilon: number,
    sensitivity: number
  ): number {
    const noise = this.laplaceMechanism(epsilon, sensitivity);
    return value + noise;
  }

  // Helper methods
  private generalizeValue(value: any, field: string): any {
    const rules = this.generalizationRules[field];
    if (!rules) return value;

    switch (rules.type) {
      case 'range':
        const numValue = Number(value);
        const range = rules.rules.find(
          (r: any) => numValue >= r.min && numValue <= r.max
        );
        return range ? range.label : value;

      case 'category':
        if (field === 'location') {
          return this.generalizeLocation(value, rules.rules.granularity);
        }
        return this.generalizeCategory(value, rules.rules.categories);

      default:
        return value;
    }
  }

  private generalizeLocation(
    location: string,
    granularity: string[]
  ): string {
    const parts = location.split(',').map(p => p.trim());
    const index = granularity.indexOf(parts.length > 0 ? 'city' : 'country');
    return parts.slice(index).join(', ');
  }

  private generalizeCategory(
    value: string,
    categories: Record<string, string[]>
  ): string {
    for (const [category, values] of Object.entries(categories)) {
      if (values.some(v => value.toLowerCase().includes(v.toLowerCase()))) {
        return category;
      }
    }
    return value;
  }

  private calculateDistribution(values: any[]): Map<any, number> {
    const dist = new Map<any, number>();
    values.forEach(value => {
      dist.set(value, (dist.get(value) || 0) + 1);
    });
    return dist;
  }

  private calculateEMD(
    dist1: Map<any, number>,
    dist2: Map<any, number>
  ): number {
    // Simple EMD calculation
    let emd = 0;
    const allValues = new Set([...dist1.keys(), ...dist2.keys()]);
    
    allValues.forEach(value => {
      const p1 = (dist1.get(value) || 0) / dist1.size;
      const p2 = (dist2.get(value) || 0) / dist2.size;
      emd += Math.abs(p1 - p2);
    });
    
    return emd;
  }

  private laplaceMechanism(
    epsilon: number,
    sensitivity: number
  ): number {
    const u = Math.random() - 0.5;
    return sensitivity * Math.log(1 - 2 * Math.abs(u)) * Math.sign(u) / epsilon;
  }
}

export const advancedAnonymization = AdvancedAnonymizationService.getInstance();
