import { privacyUtils } from './privacyUtils';
import { anonymizer } from './anonymizer';
import { auditLogger } from './auditLogger';

interface ExportOptions {
  includeAuditLogs?: boolean;
  anonymizeData?: boolean;
  format?: 'json' | 'csv';
  categories?: string[];
}

class DataExportService {
  private static instance: DataExportService;

  private readonly dataCategories = [
    'personal.contact',
    'personal.professional',
    'personal.financial',
    'ai.interaction',
    'marketing.preferences'
  ];

  private constructor() {}

  static getInstance(): DataExportService {
    if (!DataExportService.instance) {
      DataExportService.instance = new DataExportService();
    }
    return DataExportService.instance;
  }

  async exportUserData(
    userId: string,
    options: ExportOptions = {}
  ): Promise<Blob> {
    const {
      includeAuditLogs = true,
      anonymizeData = false,
      format = 'json',
      categories = this.dataCategories
    } = options;

    try {
      // Log export request
      await auditLogger.logEvent(
        'data.access',
        'export_user_data',
        { userId, options },
        false
      );

      // Gather all user data
      const userData = await this.gatherUserData(userId, categories);

      // Get audit logs if requested
      let auditLogs = [];
      if (includeAuditLogs) {
        auditLogs = await auditLogger.getAuditTrail(
          undefined,
          undefined,
          undefined
        );
      }

      // Combine all data
      let exportData = {
        metadata: {
          exportDate: new Date().toISOString(),
          userId,
          includedCategories: categories,
          dataFormat: format,
          privacyNotice: this.getPrivacyNotice()
        },
        userData,
        ...(includeAuditLogs && { auditLogs })
      };

      // Anonymize if requested
      if (anonymizeData) {
        exportData = anonymizer.anonymizeData(exportData);
      }

      // Convert to requested format
      return this.formatData(exportData, format);
    } catch (error) {
      console.error('Error exporting user data:', error);
      throw new Error('Failed to export user data');
    }
  }

  private async gatherUserData(
    userId: string,
    categories: string[]
  ): Promise<Record<string, any>> {
    const userData: Record<string, any> = {};

    for (const category of categories) {
      try {
        const data = await privacyUtils.retrievePrivateData(
          category as any,
          'data-export'
        );
        if (data.length > 0) {
          userData[category] = data;
        }
      } catch (error) {
        console.error(`Error gathering ${category} data:`, error);
        userData[category] = { error: 'Data retrieval failed' };
      }
    }

    return userData;
  }

  private async formatData(
    data: any,
    format: 'json' | 'csv'
  ): Promise<Blob> {
    if (format === 'json') {
      return new Blob(
        [JSON.stringify(data, null, 2)],
        { type: 'application/json' }
      );
    }

    // Convert to CSV
    const csvRows = [];
    const flattenObject = (obj: any, prefix = ''): Record<string, string> => {
      const flat: Record<string, string> = {};
      
      for (const [key, value] of Object.entries(obj)) {
        const newKey = prefix ? `${prefix}.${key}` : key;
        
        if (typeof value === 'object' && value !== null) {
          Object.assign(flat, flattenObject(value, newKey));
        } else {
          flat[newKey] = String(value);
        }
      }
      
      return flat;
    };

    const flatData = flattenObject(data);
    const headers = Object.keys(flatData);
    
    csvRows.push(headers.join(','));
    csvRows.push(headers.map(header => flatData[header]).join(','));

    return new Blob(
      [csvRows.join('\n')],
      { type: 'text/csv' }
    );
  }

  private getPrivacyNotice(): string {
    return `This data export contains personal information protected under applicable privacy laws. 
    By accessing this data, you agree to handle it in accordance with these laws and our privacy policy. 
    This export was generated upon user request and may contain sensitive information. 
    Please handle this data with appropriate care and security measures.`;
  }

  // Utility method to validate export request
  async validateExportRequest(
    userId: string,
    options: ExportOptions
  ): Promise<{ valid: boolean; errors: string[] }> {
    const errors: string[] = [];

    // Check user authorization
    const session = await privacyUtils.retrievePrivateData(
      'personal.contact',
      'validation'
    );
    if (!session.length || session[0].userId !== userId) {
      errors.push('User not authorized to export this data');
    }

    // Validate categories
    if (options.categories) {
      const invalidCategories = options.categories.filter(
        cat => !this.dataCategories.includes(cat)
      );
      if (invalidCategories.length > 0) {
        errors.push(`Invalid categories: ${invalidCategories.join(', ')}`);
      }
    }

    // Validate format
    if (options.format && !['json', 'csv'].includes(options.format)) {
      errors.push('Invalid export format');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }
}

export const dataExport = DataExportService.getInstance();
