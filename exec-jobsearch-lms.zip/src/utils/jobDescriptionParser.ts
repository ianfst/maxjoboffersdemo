import { JSDOM } from 'jsdom';

export interface ParsedJobDescription {
  title: string;
  company: string;
  location: string;
  description: string;
  requirements: string[];
  qualifications: string[];
}

export class JobDescriptionParser {
  private static commonJobBoards = [
    {
      domain: 'linkedin.com',
      selectors: {
        title: '.job-details-jobs-unified-top-card__job-title',
        company: '.job-details-jobs-unified-top-card__company-name',
        location: '.job-details-jobs-unified-top-card__bullet',
        description: '.job-details-jobs-unified-top-card__job-description',
        requirements: '.job-details-jobs-unified-top-card__job-requirements'
      }
    },
    {
      domain: 'indeed.com',
      selectors: {
        title: '.jobsearch-JobInfoHeader-title',
        company: '.jobsearch-InlineCompanyRating-companyHeader',
        location: '.jobsearch-JobInfoHeader-subtitle',
        description: '#jobDescriptionText'
      }
    },
    {
      domain: 'glassdoor.com',
      selectors: {
        title: '.job-title',
        company: '.employer-name',
        location: '.location',
        description: '.jobDescriptionContent'
      }
    },
    {
      domain: 'ziprecruiter.com',
      selectors: {
        title: '.job_title',
        company: '.hiring_company_text',
        location: '.location',
        description: '.jobDescriptionSection',
        requirements: '.job-requirements'
      }
    },
    {
      domain: 'monster.com',
      selectors: {
        title: '.job-title',
        company: '.company',
        location: '.location',
        description: '.job-description',
        requirements: '.job-requirements'
      }
    },
    {
      domain: 'careerbuilder.com',
      selectors: {
        title: '.job-title',
        company: '.company-name',
        location: '.location',
        description: '.description-section',
        requirements: '.requirements-section'
      }
    },
    {
      domain: 'theladders.com',
      selectors: {
        title: '.job-title-text',
        company: '.company-name',
        location: '.location',
        description: '.job-description',
        requirements: '.job-requirements'
      }
    },
    {
      domain: 'dice.com',
      selectors: {
        title: '[data-cy="jobTitle"]',
        company: '.company-header-name',
        location: '.location-description',
        description: '.job-description',
        requirements: '.requirements-section'
      }
    },
    {
      domain: 'careers.google.com',
      selectors: {
        title: '.gc-job-detail-title',
        company: '.gc-job-detail-company',
        location: '.gc-job-detail-location',
        description: '.gc-job-detail-description',
        requirements: '.gc-job-qualifications'
      }
    },
    {
      domain: 'jobs.google.com',
      selectors: {
        title: '.p1zr0e',  // Google Jobs aggregator selectors
        company: '.sMzDkb',
        location: '.nJlQNd',
        description: '.HBvzbc',
        requirements: '.WbZuDe'
      }
    }
  ];

  static async parseFromUrl(url: string): Promise<ParsedJobDescription> {
    try {
      const response = await fetch(url);
      const html = await response.text();
      return this.parseHtml(html, url);
    } catch (error) {
      console.error('Error fetching job description:', error);
      throw new Error('Failed to fetch job description');
    }
  }

  static parseHtml(html: string, url: string): ParsedJobDescription {
    const dom = new JSDOM(html);
    const document = dom.window.document;

    // Determine which job board we're dealing with
    const jobBoard = this.commonJobBoards.find(board => url.includes(board.domain));
    
    if (jobBoard) {
      // Use specific selectors for the job board
      const selectors = jobBoard.selectors;
      const parsed = {
        title: this.getTextContent(document, selectors.title),
        company: this.getTextContent(document, selectors.company),
        location: this.getTextContent(document, selectors.location),
        description: this.getTextContent(document, selectors.description),
        requirements: this.extractListItems(document, 'requirements'),
        qualifications: this.extractListItems(document, 'qualifications')
      };

      // Special handling for Google Jobs aggregator
      if (url.includes('jobs.google.com')) {
        // Extract structured data if available
        const scriptElements = document.querySelectorAll('script[type="application/ld+json"]');
        for (const script of Array.from(scriptElements)) {
          try {
            const jsonData = JSON.parse(script.textContent || '');
            if (jsonData['@type'] === 'JobPosting') {
              return {
                title: jsonData.title || parsed.title,
                company: jsonData.hiringOrganization?.name || parsed.company,
                location: jsonData.jobLocation?.address?.addressLocality || parsed.location,
                description: jsonData.description || parsed.description,
                requirements: jsonData.skills || parsed.requirements,
                qualifications: jsonData.qualifications || parsed.qualifications
              };
            }
          } catch (e) {
            console.warn('Error parsing structured data:', e);
          }
        }
      }

      return parsed;
    } else {
      // Generic parsing for unknown job boards
      return this.genericParse(document);
    }
  }

  private static getTextContent(document: Document, selector: string): string {
    const element = document.querySelector(selector);
    return element ? element.textContent?.trim() || '' : '';
  }

  private static extractListItems(document: Document, type: 'requirements' | 'qualifications'): string[] {
    // Look for common patterns in job descriptions
    const patterns = [
      `${type}:`,
      `${type.charAt(0).toUpperCase() + type.slice(1)}:`,
      `Key ${type}:`,
      `Required ${type}:`,
      `Minimum ${type}:`
    ];

    let items: string[] = [];
    
    // Try to find lists after these patterns
    for (const pattern of patterns) {
      const regex = new RegExp(`${pattern}[\\s\\S]*?<ul>(.*?)</ul>`, 'i');
      const match = document.documentElement.innerHTML.match(regex);
      
      if (match) {
        const ul = new JSDOM(match[1]).window.document.querySelector('ul');
        if (ul) {
          items = Array.from(ul.querySelectorAll('li')).map(li => li.textContent?.trim() || '');
          break;
        }
      }
    }

    // If no structured list is found, try to extract from paragraphs
    if (items.length === 0) {
      const paragraphs = document.querySelectorAll('p');
      items = Array.from(paragraphs)
        .filter(p => p.textContent?.toLowerCase().includes(type))
        .map(p => p.textContent?.trim() || '');
    }

    return items;
  }

  private static genericParse(document: Document): ParsedJobDescription {
    // Try to find the job title (usually the first large heading)
    const title = document.querySelector('h1')?.textContent || '';

    // Look for company name in common locations
    const companySelectors = [
      '[class*="company"]',
      '[class*="employer"]',
      'meta[property="og:site_name"]'
    ];
    const company = this.findFirstMatch(document, companySelectors);

    // Look for location
    const locationSelectors = [
      '[class*="location"]',
      '[class*="address"]',
      '[class*="city"]'
    ];
    const location = this.findFirstMatch(document, locationSelectors);

    // Get the main content
    const description = document.body.textContent || '';

    return {
      title,
      company,
      location,
      description,
      requirements: this.extractListItems(document, 'requirements'),
      qualifications: this.extractListItems(document, 'qualifications')
    };
  }

  private static findFirstMatch(document: Document, selectors: string[]): string {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element?.textContent) {
        return element.textContent.trim();
      }
    }
    return '';
  }
}
