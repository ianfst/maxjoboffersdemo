import { ApiResponse } from '../types/api';
import { InterviewPrep } from '../types/interview';

export class ApiError extends Error {
  status?: number;
  data?: any;

  constructor(message: string, status?: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

export const handleApiError = async (error: any, response?: Response): Promise<string> => {
  if (error instanceof ApiError) {
    return error.message;
  }

  if (!response?.ok && response?.status) {
    try {
      const data = await response.json();
      return data.error || data.message || `Server error (${response.status})`;
    } catch {
      return `Server error (${response.status})`;
    }
  }
  
  if (error instanceof Error) {
    return error.message || 'Unknown error';
  }
  
  return error?.message || error?.toString() || 'An unexpected error occurred';
};

export const validateInterviewPrep = (data: any): data is InterviewPrep => {
  return (
    data &&
    typeof data === 'object' &&
    typeof data.id === 'string' &&
    typeof data.status === 'string'
  );
};

export const validateResponse = async (response: Response): Promise<any> => {
  let data;
  try {
    data = await response.json();
  } catch (e) {
    throw new ApiError('Invalid JSON response from server');
  }

  if (!response.ok) {
    throw new ApiError(data.error || `Server error (${response.status})`, response.status, data);
  }

  if (!data) {
    throw new ApiError('Empty response from server');
  }

  if (data.error) {
    throw new ApiError(data.error, response.status, data);
  }

  return data;
};

export const fetchNetworkingStats = async (): Promise<any> => {
  // In a real app, this would make an API call
  return Promise.resolve({
    campaigns: {
      active: 3,
      paused: 1,
      completed: 5,
    },
    metrics: {
      connectionRate: 75,
      responseRate: 85,
      meetingRate: 35,
    },
  });
};

export const updateCampaignStatus = async (campaignId: string, status: string): Promise<ApiResponse<{ success: boolean }>> => {
  // In a real app, this would make an API call
  return Promise.resolve({
    data: { success: true },
    status: 'success',
  });
};

export const analyzeMessage = async (message: string): Promise<ApiResponse<{
  score: number;
  suggestions: string[];
  tone: string;
  engagement_probability: number;
}>> => {
  // In a real app, this would make an API call
  return Promise.resolve({
    data: {
      score: 85,
      suggestions: ['Add more personalization', 'Include a specific call to action'],
      tone: 'professional',
      engagement_probability: 0.75,
    },
    status: 'success',
  });
};

export const generateImprovedMessage = async (message: string): Promise<ApiResponse<{
  message: string;
  changes: string[];
}>> => {
  // In a real app, this would make an API call
  return Promise.resolve({
    data: {
      message: 'Improved message content',
      changes: ['Added personalization', 'Enhanced call to action'],
    },
    status: 'success',
  });
};

export const fetchIndustryInsights = async (industry: string): Promise<ApiResponse<any>> => {
  // In a real app, this would make an API call
  return Promise.resolve({
    data: {
      industryGrowth: {
        yearOverYear: 15,
        quarterOverQuarter: 4.5,
        forecast: 18,
      },
      hiringTrends: {
        seniorRoles: {
          growth: 25,
          inDemandTitles: ['CTO', 'VP Engineering', 'Director of Product'],
        },
      },
    },
    status: 'success',
  });
};

export const fetchCompanyMovements = async (industry: string): Promise<ApiResponse<any>> => {
  // In a real app, this would make an API call
  return Promise.resolve({
    data: [
      { company: 'Tech Corp', movement: 'Expansion', details: 'New division' },
      { company: 'Finance Inc', movement: 'Restructuring', details: 'Leadership changes' },
    ],
    status: 'success',
  });
};
