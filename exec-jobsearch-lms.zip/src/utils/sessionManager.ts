import { BehaviorSubject } from 'rxjs';
import { jwtDecode } from 'jwt-decode';

interface TokenData {
  exp: number;
  sub: string;
  role: string;
}

interface SessionState {
  isValid: boolean;
  expiresAt: number | null;
  userId: string | null;
  role: string | null;
}

class SessionManager {
  private static instance: SessionManager;
  private sessionState$ = new BehaviorSubject<SessionState>({
    isValid: false,
    expiresAt: null,
    userId: null,
    role: null
  });

  private constructor() {
    // Initialize session state from storage
    this.checkSession();
    
    // Set up expiry check interval
    setInterval(() => this.checkSession(), 60000); // Check every minute
  }

  static getInstance(): SessionManager {
    if (!SessionManager.instance) {
      SessionManager.instance = new SessionManager();
    }
    return SessionManager.instance;
  }

  private checkSession() {
    const token = localStorage.getItem('token');
    if (!token) {
      this.updateSessionState({
        isValid: false,
        expiresAt: null,
        userId: null,
        role: null
      });
      return;
    }

    try {
      const decoded = jwtDecode<TokenData>(token);
      const now = Math.floor(Date.now() / 1000);
      
      // Add 5-minute buffer to expiry time
      const isValid = decoded.exp > (now + 300);
      
      this.updateSessionState({
        isValid,
        expiresAt: decoded.exp,
        userId: decoded.sub,
        role: decoded.role
      });

      // If token is about to expire, trigger refresh
      if (decoded.exp < (now + 600)) { // 10-minute warning
        this.triggerTokenRefresh();
      }
    } catch (error) {
      console.error('Error decoding token:', error);
      this.clearSession();
    }
  }

  private updateSessionState(state: SessionState) {
    this.sessionState$.next(state);
  }

  private async triggerTokenRefresh() {
    const event = new CustomEvent('token-refresh-needed');
    window.dispatchEvent(event);
  }

  clearSession() {
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    this.updateSessionState({
      isValid: false,
      expiresAt: null,
      userId: null,
      role: null
    });
  }

  getSessionState() {
    return this.sessionState$.value;
  }

  observeSessionState(callback: (state: SessionState) => void) {
    return this.sessionState$.subscribe(callback);
  }

  hasRole(requiredRole: string | string[]): boolean {
    const { role, isValid } = this.sessionState$.value;
    if (!isValid || !role) return false;

    const roles = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
    return roles.includes(role);
  }

  isSessionValid(): boolean {
    return this.sessionState$.value.isValid;
  }

  getTimeUntilExpiry(): number | null {
    const { expiresAt } = this.sessionState$.value;
    if (!expiresAt) return null;
    
    return Math.max(0, expiresAt - Math.floor(Date.now() / 1000));
  }
}

export const sessionManager = SessionManager.getInstance();
