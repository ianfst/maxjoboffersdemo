import CryptoJS from 'crypto-js';

// Extend Performance interface to include Chrome's memory property
interface ExtendedPerformance extends Performance {
  memory?: {
    jsHeapSizeLimit: number;
    totalJSHeapSize: number;
    usedJSHeapSize: number;
  };
}

declare global {
  interface Window {
    performance: ExtendedPerformance;
  }
}

export interface SecurityContext {
  isSecure: boolean;
  encryptionEnabled: boolean;
  sessionValid: boolean;
}

class SecurityUtils {
  private static instance: SecurityUtils;
  private readonly storagePrefix = 'secure_';
  private readonly sensitiveKeys = ['token', 'refreshToken', 'password'];

  private constructor() {
    this.setupSecurityListeners();
  }

  static getInstance(): SecurityUtils {
    if (!SecurityUtils.instance) {
      SecurityUtils.instance = new SecurityUtils();
    }
    return SecurityUtils.instance;
  }

  private setupSecurityListeners() {
    // Listen for visibility changes to clear sensitive data when tab is hidden
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.clearSensitiveMemory();
      }
    });

    // Listen for tab/window close
    window.addEventListener('beforeunload', () => {
      this.clearSensitiveMemory();
    });

    // Periodic cleanup of expired items
    setInterval(() => this.cleanupExpiredItems(), 300000); // Every 5 minutes
  }

  private getEncryptionKey(): string {
    // Use a combination of browser fingerprint and session-specific data
    const fingerprint = [
      navigator.userAgent,
      screen.width,
      screen.height,
      new Date().getTimezoneOffset()
    ].join('|');
    
    return CryptoJS.SHA256(fingerprint).toString();
  }

  private encrypt(data: string): string {
    return CryptoJS.AES.encrypt(data, this.getEncryptionKey()).toString();
  }

  private decrypt(encryptedData: string): string {
    try {
      const bytes = CryptoJS.AES.decrypt(encryptedData, this.getEncryptionKey());
      return bytes.toString(CryptoJS.enc.Utf8);
    } catch (error) {
      console.error('Decryption failed:', error);
      return '';
    }
  }

  setSecureItem(key: string, value: string, expiresInMinutes: number = 60): void {
    const expiresAt = Date.now() + (expiresInMinutes * 60 * 1000);
    const data = {
      value,
      expiresAt
    };
    
    const encryptedData = this.encrypt(JSON.stringify(data));
    localStorage.setItem(`${this.storagePrefix}${key}`, encryptedData);
  }

  getSecureItem(key: string): string | null {
    const encryptedData = localStorage.getItem(`${this.storagePrefix}${key}`);
    if (!encryptedData) return null;

    try {
      const decryptedData = this.decrypt(encryptedData);
      if (!decryptedData) return null;

      const data = JSON.parse(decryptedData);
      
      // Check expiration
      if (data.expiresAt < Date.now()) {
        this.removeSecureItem(key);
        return null;
      }

      return data.value;
    } catch (error) {
      console.error('Error retrieving secure item:', error);
      return null;
    }
  }

  removeSecureItem(key: string): void {
    localStorage.removeItem(`${this.storagePrefix}${key}`);
  }

  private cleanupExpiredItems(): void {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith(this.storagePrefix)) {
        this.getSecureItem(key.replace(this.storagePrefix, '')); // This will remove if expired
      }
    }
  }

  private clearSensitiveMemory(): void {
    // Clear sensitive data from localStorage
    this.sensitiveKeys.forEach(key => {
      this.removeSecureItem(key);
    });

    // Clear variables
    if (window.performance && window.performance.memory) {
      try {
        // Force garbage collection if possible
        window.performance.memory.jsHeapSizeLimit = 0;
      } catch (e) {
        // Ignore errors
      }
    }
  }

  // Utility method to safely handle sensitive data
  async withSecureContext<T>(
    operation: () => Promise<T>,
    sensitiveKeys: string[] = []
  ): Promise<T> {
    try {
      return await operation();
    } finally {
      // Clear any sensitive data
      sensitiveKeys.forEach(key => {
        this.removeSecureItem(key);
      });
    }
  }

  // Method to validate security requirements
  validateSecurityRequirements(): boolean {
    return (
      window.isSecureContext && // Check if running in secure context (HTTPS)
      !this.isInIframe() && // Check if running in iframe
      this.hasRequiredApis() // Check if required security APIs are available
    );
  }

  private isInIframe(): boolean {
    try {
      return window !== window.parent;
    } catch {
      return true;
    }
  }

  private hasRequiredApis(): boolean {
    return (
      'crypto' in window &&
      'localStorage' in window &&
      'sessionStorage' in window &&
      'addEventListener' in window
    );
  }
}

export const securityUtils = SecurityUtils.getInstance();
