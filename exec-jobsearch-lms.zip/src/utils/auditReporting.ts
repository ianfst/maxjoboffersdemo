import { auditLogger } from './auditLogger';
import { anonymizer } from './anonymizer';

interface AuditReport {
  summary: {
    totalEvents: number;
    eventsByType: Record<string, number>;
    timeRange: {
      start: string;
      end: string;
    };
    riskMetrics: {
      highRiskEvents: number;
      failedAttempts: number;
      unusualPatterns: number;
    };
  };
  details: {
    securityEvents: AuditEvent[];
    privacyEvents: AuditEvent[];
    consentEvents: AuditEvent[];
    dataAccessEvents: AuditEvent[];
  };
  recommendations: string[];
}

interface ReportOptions {
  startDate?: Date;
  endDate?: Date;
  eventTypes?: string[];
  includeRiskAnalysis?: boolean;
  anonymize?: boolean;
}

class AuditReportingService {
  private static instance: AuditReportingService;

  private constructor() {}

  static getInstance(): AuditReportingService {
    if (!AuditReportingService.instance) {
      AuditReportingService.instance = new AuditReportingService();
    }
    return AuditReportingService.instance;
  }

  async generateReport(options: ReportOptions = {}): Promise<AuditReport> {
    const {
      startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
      endDate = new Date(),
      eventTypes = ['all'],
      includeRiskAnalysis = true,
      anonymize = true
    } = options;

    try {
      // Fetch audit events
      const events = await auditLogger.getAuditTrail(
        undefined,
        startDate,
        endDate
      );

      // Generate report sections
      const summary = this.generateSummary(events);
      const details = this.categorizeEvents(events);
      const recommendations = this.generateRecommendations(events);

      // Add risk analysis if requested
      if (includeRiskAnalysis) {
        summary.riskMetrics = this.analyzeRisks(events);
      }

      let report: AuditReport = {
        summary,
        details,
        recommendations
      };

      // Anonymize if requested
      if (anonymize) {
        report = anonymizer.anonymizeData(report);
      }

      return report;
    } catch (error) {
      console.error('Error generating audit report:', error);
      throw new Error('Failed to generate audit report');
    }
  }

  private generateSummary(events: AuditEvent[]): AuditReport['summary'] {
    const eventsByType: Record<string, number> = {};
    
    events.forEach(event => {
      eventsByType[event.type] = (eventsByType[event.type] || 0) + 1;
    });

    return {
      totalEvents: events.length,
      eventsByType,
      timeRange: {
        start: events[events.length - 1]?.timestamp || '',
        end: events[0]?.timestamp || ''
      },
      riskMetrics: {
        highRiskEvents: 0,
        failedAttempts: 0,
        unusualPatterns: 0
      }
    };
  }

  private categorizeEvents(events: AuditEvent[]): AuditReport['details'] {
    return {
      securityEvents: events.filter(e => e.type === 'security.event'),
      privacyEvents: events.filter(e => e.type === 'privacy.setting'),
      consentEvents: events.filter(e => e.type === 'consent.update'),
      dataAccessEvents: events.filter(e => e.type === 'data.access')
    };
  }

  private analyzeRisks(events: AuditEvent[]): AuditReport['summary']['riskMetrics'] {
    const metrics = {
      highRiskEvents: 0,
      failedAttempts: 0,
      unusualPatterns: 0
    };

    // Group events by user and time
    const userEvents: Record<string, AuditEvent[]> = {};
    events.forEach(event => {
      if (event.userId) {
        if (!userEvents[event.userId]) {
          userEvents[event.userId] = [];
        }
        userEvents[event.userId].push(event);
      }
    });

    // Analyze patterns
    Object.values(userEvents).forEach(userEventList => {
      // Check for rapid successive attempts
      const rapidAttempts = this.detectRapidAttempts(userEventList);
      metrics.unusualPatterns += rapidAttempts;

      // Check for failed operations
      const failures = userEventList.filter(e => 
        e.details.status === 'failed' ||
        e.details.error
      ).length;
      metrics.failedAttempts += failures;

      // Check for high-risk operations
      const highRisk = userEventList.filter(e =>
        e.type === 'security.event' ||
        (e.type === 'data.access' && e.details.sensitive) ||
        e.details.risk === 'high'
      ).length;
      metrics.highRiskEvents += highRisk;
    });

    return metrics;
  }

  private detectRapidAttempts(events: AuditEvent[]): number {
    let rapidAttempts = 0;
    const THRESHOLD_MS = 1000; // 1 second

    for (let i = 1; i < events.length; i++) {
      const timeDiff = new Date(events[i-1].timestamp).getTime() -
                      new Date(events[i].timestamp).getTime();
      if (timeDiff < THRESHOLD_MS) {
        rapidAttempts++;
      }
    }

    return rapidAttempts;
  }

  private generateRecommendations(events: AuditEvent[]): string[] {
    const recommendations: string[] = [];
    const metrics = this.analyzeRisks(events);

    // Add recommendations based on metrics
    if (metrics.failedAttempts > 10) {
      recommendations.push(
        'High number of failed attempts detected. Consider implementing additional authentication measures.'
      );
    }

    if (metrics.unusualPatterns > 5) {
      recommendations.push(
        'Unusual access patterns detected. Review security policies and implement rate limiting.'
      );
    }

    if (metrics.highRiskEvents > 0) {
      recommendations.push(
        'High-risk operations detected. Consider implementing additional approval workflows.'
      );
    }

    // Add general recommendations
    recommendations.push(
      'Regularly review and update access controls',
      'Implement continuous monitoring for suspicious activities',
      'Maintain up-to-date security training for all users'
    );

    return recommendations;
  }

  // Generate compliance report
  async generateComplianceReport(): Promise<any> {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const report = await this.generateReport({
      startDate: thirtyDaysAgo,
      includeRiskAnalysis: true,
      anonymize: true
    });

    return {
      ...report,
      compliance: {
        gdprCompliance: this.checkGDPRCompliance(report),
        ccpaCompliance: this.checkCCPACompliance(report),
        hipaaCompliance: this.checkHIPAACompliance(report)
      }
    };
  }

  private checkGDPRCompliance(report: AuditReport): any {
    return {
      dataAccessRequests: report.details.dataAccessEvents.length,
      consentUpdates: report.details.consentEvents.length,
      dataRetentionCompliance: true, // Implement actual check
      recommendations: [
        'Regularly review data retention policies',
        'Ensure all data access requests are logged',
        'Maintain up-to-date data processing agreements'
      ]
    };
  }

  private checkCCPACompliance(report: AuditReport): any {
    return {
      optOutRequests: report.details.privacyEvents.filter(
        e => e.action === 'opt_out'
      ).length,
      dataRequests: report.details.dataAccessEvents.length,
      recommendations: [
        'Review opt-out mechanism effectiveness',
        'Ensure proper data categorization',
        'Update privacy notices regularly'
      ]
    };
  }

  private checkHIPAACompliance(report: AuditReport): any {
    return {
      securityIncidents: report.details.securityEvents.length,
      dataAccessAudits: report.details.dataAccessEvents.length,
      recommendations: [
        'Implement regular security assessments',
        'Review access control policies',
        'Maintain incident response procedures'
      ]
    };
  }
}

export const auditReporting = AuditReportingService.getInstance();
