import { aiLearning } from './aiLearning';

interface ReviewStage {
  name: string;
  role: string;
  prompt: string;
  priority: number;
}

interface ReviewResult {
  suggestions: string[];
  improvements: {
    section: string;
    current: string;
    suggested: string;
    reasoning: string;
  }[];
  score: number;
  perspective: string;
}

class ResumeReviewSystem {
  private static instance: ResumeReviewSystem;

  private readonly reviewStages: ReviewStage[] = [
    {
      name: 'initial_optimization',
      role: 'Expert Resume Writer',
      prompt: `You are an expert resume writer with deep experience in executive hiring.
Follow these steps:
1. Analyze the resume's current format and content
2. Identify key achievements and metrics
3. Enhance professional language and impact
4. Ensure ATS compatibility
5. Maintain industry-specific terminology`,
      priority: 1
    },
    {
      name: 'technical_review',
      role: 'Industry Expert',
      prompt: `As an industry expert in {{industry}}, review this resume for:
1. Technical accuracy and relevance
2. Industry-specific achievements
3. Current technology and methodology alignment
4. Professional certifications and qualifications
5. Industry buzzwords and terminology`,
      priority: 2
    },
    {
      name: 'hiring_manager_review',
      role: 'Hiring Manager',
      prompt: `Act as the hiring manager. Review the job description against this resume and assess:
1. Perfect fit analysis
2. Areas needing improvement
3. Missing key qualifications
4. Experience alignment
5. Cultural fit indicators
Then provide specific improvements and edits to make this resume perfect for the role.`,
      priority: 3
    }
  ];

  private constructor() {}

  static getInstance(): ResumeReviewSystem {
    if (!ResumeReviewSystem.instance) {
      ResumeReviewSystem.instance = new ResumeReviewSystem();
    }
    return ResumeReviewSystem.instance;
  }

  async performComprehensiveReview(
    resume: string,
    jobDescription: string,
    industry: string
  ): Promise<ReviewResult[]> {
    const results: ReviewResult[] = [];
    let currentResume = resume;

    // Perform each review stage in sequence
    for (const stage of this.reviewStages) {
      const result = await this.executeReviewStage(
        stage,
        currentResume,
        jobDescription,
        industry
      );
      
      results.push(result);
      
      // Apply improvements to the resume for the next stage
      currentResume = await this.applyImprovements(currentResume, result);
      
      // Record interaction for AI learning
      await this.recordReviewInteraction(stage, result);
    }

    // Final hiring manager perspective review
    const finalReview = await this.performFinalHiringManagerReview(
      currentResume,
      jobDescription
    );

    results.push(finalReview);

    return results;
  }

  private async executeReviewStage(
    stage: ReviewStage,
    resume: string,
    jobDescription: string,
    industry: string
  ): Promise<ReviewResult> {
    // Prepare context-aware prompt
    const contextualizedPrompt = this.preparePrompt(
      stage.prompt,
      { industry, role: stage.role }
    );

    // Simulate AI review (in real implementation, this would call the AI service)
    const review: ReviewResult = {
      suggestions: [],
      improvements: [],
      score: 0,
      perspective: stage.role
    };

    // Record this review for learning
    await aiLearning.recordInteraction({
      promptId: stage.name,
      input: resume,
      output: JSON.stringify(review),
      feedback: {
        rating: review.score,
        successMetrics: {
          relevance: 0.9,
          specificity: 0.85,
          actionability: 0.95
        }
      },
      metadata: {
        timestamp: new Date().toISOString(),
        userId: 'system',
        context: {
          stage: stage.name,
          role: stage.role,
          industry
        }
      }
    });

    return review;
  }

  private async performFinalHiringManagerReview(
    resume: string,
    jobDescription: string
  ): Promise<ReviewResult> {
    const hiringManagerPrompt = `
    Act as the hiring manager. Review the job description against your latest resume and assess:

    1. Evaluate this resume specifically against the job requirements:
       - Required skills and experience match
       - Achievement alignment with role expectations
       - Leadership and management capabilities (if applicable)
       - Technical expertise demonstration

    2. Identify any gaps or areas for enhancement:
       - Missing key qualifications
       - Weak or unclear experience descriptions
       - Insufficient quantifiable results
       - Industry-specific terminology gaps

    3. Assess overall presentation:
       - Executive presence in language
       - Strategic impact demonstration
       - Career progression clarity
       - Professional branding effectiveness

    4. Make specific improvements:
       - Enhance relevant achievements
       - Strengthen alignment with job requirements
       - Add missing key qualifications
       - Optimize keywords and phrases

    5. Final polish:
       - Ensure perfect formatting
       - Verify all improvements maintain authenticity
       - Confirm ATS optimization
       - Review for perfect grammar and tone

    After analysis, provide:
    1. Specific improvements needed
    2. Exact edits to implement
    3. Final verification of perfect job fit
    `;

    // Simulate hiring manager review
    const review: ReviewResult = {
      suggestions: [
        'Strengthen leadership impact metrics',
        'Add specific industry certifications',
        'Enhance technical skill demonstrations'
      ],
      improvements: [
        {
          section: 'Professional Experience',
          current: 'Led team of 10 developers',
          suggested: 'Directed 10-person development team, delivering 3 major products generating $2.5M in revenue',
          reasoning: 'Added specific metrics and business impact'
        }
      ],
      score: 4.5,
      perspective: 'Hiring Manager'
    };

    // Record this final review
    await aiLearning.recordInteraction({
      promptId: 'final_hiring_manager_review',
      input: resume,
      output: JSON.stringify(review),
      feedback: {
        rating: review.score,
        successMetrics: {
          jobFitAlignment: 0.92,
          improvementQuality: 0.88,
          specificity: 0.95
        }
      },
      metadata: {
        timestamp: new Date().toISOString(),
        userId: 'system',
        context: {
          stage: 'final_review',
          role: 'Hiring Manager'
        }
      }
    });

    return review;
  }

  private async applyImprovements(
    resume: string,
    review: ReviewResult
  ): Promise<string> {
    let improvedResume = resume;

    // Apply each suggested improvement
    for (const improvement of review.improvements) {
      improvedResume = improvedResume.replace(
        improvement.current,
        improvement.suggested
      );
    }

    return improvedResume;
  }

  private async recordReviewInteraction(
    stage: ReviewStage,
    result: ReviewResult
  ): Promise<void> {
    // Record interaction for learning system
    await aiLearning.recordInteraction({
      promptId: stage.name,
      input: 'resume_content',
      output: JSON.stringify(result),
      feedback: {
        rating: result.score,
        comments: `Review from ${stage.role} perspective`
      },
      metadata: {
        timestamp: new Date().toISOString(),
        userId: 'system',
        context: {
          stage: stage.name,
          role: stage.role
        }
      }
    });
  }

  private preparePrompt(
    prompt: string,
    context: Record<string, string>
  ): string {
    let preparedPrompt = prompt;
    for (const [key, value] of Object.entries(context)) {
      preparedPrompt = preparedPrompt.replace(
        new RegExp(`{{${key}}}`, 'g'),
        value
      );
    }
    return preparedPrompt;
  }

  // Analytics methods
  async getReviewStats(): Promise<{
    averageScore: number;
    commonImprovements: string[];
    effectivenessByStage: Record<string, number>;
  }> {
    // Implementation would analyze review history
    return {
      averageScore: 4.2,
      commonImprovements: [],
      effectivenessByStage: {}
    };
  }
}

export const resumeReview = ResumeReviewSystem.getInstance();
