interface ErrorLogData {
  message: string;
  stack?: string;
  componentName?: string;
  errorInfo?: React.ErrorInfo;
  timestamp?: string;
}

// Simple logging utility that could be expanded to use a proper logging service
export const logError = (data: ErrorLogData): void => {
  console.error('Error:', data);
  
  // TODO: Send to error tracking service (e.g., Sentry)
  // if (process.env.NODE_ENV === 'production') {
  //   sendToErrorTrackingService(error, errorInfo);
  // }
};
