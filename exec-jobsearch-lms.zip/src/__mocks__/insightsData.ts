export const mockInsightsData = {
  industryGrowth: {
    yearOverYear: 15,
    quarterOverQuarter: 4.5,
    forecast: 18,
  },
  hiringTrends: {
    seniorRoles: {
      growth: 25,
      inDemandTitles: [
        'CTO',
        'VP Engineering',
        'Director of Product',
      ],
    },
    midLevelRoles: {
      growth: 15,
      inDemandTitles: [
        'Senior Engineer',
        'Product Manager',
        'Tech Lead',
      ],
    },
  },
  skillDemand: [
    {
      name: 'Cloud Architecture',
      demand: 'High',
      growth: 35,
    },
    {
      name: 'AI/ML',
      demand: 'Very High',
      growth: 45,
    },
    {
      name: 'Cybersecurity',
      demand: 'High',
      growth: 30,
    },
  ],
  salaryTrends: {
    executiveLevel: {
      range: '$180K - $250K',
      growth: 8,
    },
    seniorLevel: {
      range: '$140K - $180K',
      growth: 5,
    },
  },
  marketOpportunities: {
    emergingSectors: [
      {
        name: 'Quantum Computing',
        growth: 150,
        maturity: 'Early',
      },
      {
        name: 'Green Tech',
        growth: 85,
        maturity: 'Growing',
      },
    ],
    establishedSectors: [
      {
        name: 'Cloud Services',
        growth: 25,
        maturity: 'Mature',
      },
    ],
  },
  competitiveLandscape: {
    marketLeaders: [
      {
        name: 'Tech Corp',
        marketShare: 25,
        hiring: true,
      },
      {
        name: 'Innovation Inc',
        marketShare: 20,
        hiring: true,
      },
    ],
    upcomingPlayers: [
      {
        name: 'StartupX',
        growth: 150,
        hiring: true,
      },
    ],
  },
  networkingOpportunities: {
    events: [
      {
        name: 'Tech Leadership Summit',
        date: '2025-04-15',
        type: 'Conference',
      },
      {
        name: 'Innovation Meetup',
        date: '2025-03-20',
        type: 'Networking',
      },
    ],
    groups: [
      {
        name: 'Tech Executives Network',
        members: 5000,
        activity: 'Very Active',
      },
    ],
  },
  futureTrends: {
    sixMonthForecast: [
      {
        trend: 'Remote Work Tools',
        probability: 90,
        impact: 'High',
      },
      {
        trend: 'AI Integration',
        probability: 85,
        impact: 'Very High',
      },
    ],
  },
};
