export const mockNetworkingData = {
  campaigns: {
    active: 3,
    paused: 1,
    completed: 5,
  },
  metrics: {
    connectionRate: 75,
    responseRate: 85,
    meetingRate: 35,
    opportunityRate: 25,
  },
  industryDistribution: {
    technology: 45,
    finance: 30,
    healthcare: 25,
  },
  connectionQuality: {
    highValue: 60,
    medium: 30,
    low: 10,
  },
  trends: {
    weeklyGrowth: 15,
    monthlyGrowth: 45,
    quarterlyGrowth: 120,
  },
  recommendations: [
    {
      name: 'John Smith',
      title: 'CTO at Tech Corp',
      matchScore: 95,
      commonConnections: 12,
    },
    {
      name: 'Sarah Johnson',
      title: 'VP Engineering',
      matchScore: 90,
      commonConnections: 8,
    },
  ],
  messageTemplates: {
    topPerforming: [
      {
        id: 'template1',
        name: 'Technology Leadership',
        responseRate: 85,
        usageCount: 150,
      },
      {
        id: 'template2',
        name: 'Industry Transition',
        responseRate: 80,
        usageCount: 120,
      },
    ],
  },
};
