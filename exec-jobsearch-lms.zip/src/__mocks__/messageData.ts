export const mockMessageData = {
  templates: {
    initial_connection: [
      {
        id: 'template1',
        name: 'Value-Based Connection',
        content: 'Hi {{name}}, I noticed your work in {{industry}} and would love to connect to share insights about {{topic}}.',
        performance: {
          responseRate: 85,
          meetings: 45,
          opportunities: 25,
        },
      },
      {
        id: 'template2',
        name: 'Mutual Interest',
        content: 'Hi {{name}}, I see we share an interest in {{topic}}. Would love to connect and exchange perspectives.',
        performance: {
          responseRate: 80,
          meetings: 40,
          opportunities: 20,
        },
      },
    ],
    follow_up: [
      {
        id: 'template3',
        name: 'Post-Event Follow-up',
        content: 'Hi {{name}}, Great meeting you at {{event}}. Would love to continue our discussion about {{topic}}.',
        performance: {
          responseRate: 90,
          meetings: 60,
          opportunities: 35,
        },
      },
    ],
  },
  analysis: {
    tone_metrics: {
      professional: 85,
      friendly: 75,
      engaging: 80,
    },
    content_metrics: {
      personalization: 90,
      relevance: 85,
      clarity: 95,
    },
    improvement_areas: [
      'Add more specific value proposition',
      'Include mutual connections or interests',
      'Strengthen call-to-action',
    ],
  },
  keywords: {
    industry: [
      'digital transformation',
      'innovation',
      'leadership',
      'strategy',
    ],
    role: [
      'executive',
      'director',
      'manager',
      'leader',
    ],
    skills: [
      'strategic planning',
      'team building',
      'change management',
      'growth',
    ],
  },
  engagement_patterns: {
    best_times: {
      days: ['Tuesday', 'Wednesday', 'Thursday'],
      hours: ['9-11am', '2-4pm'],
    },
    response_windows: {
      initial: '24h',
      follow_up: '48h',
    },
  },
};
