import { useState, useEffect } from 'react';
import { User, UserProgress, FeatureAccess, getTierFeatures } from '../types/user';
import api from '../api/config';

interface UseUserReturn {
  user: User | null;
  progress: UserProgress | null;
  features: FeatureAccess;
  isLoading: boolean;
  error: Error | null;
  refreshUser: () => Promise<void>;
}

export const useUser = (): UseUserReturn => {
  const [user, setUser] = useState<User | null>(null);
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [features, setFeatures] = useState<FeatureAccess>(getTierFeatures('free'));
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchUserData = async () => {
    try {
      const [userResponse, progressResponse] = await Promise.all([
        api.get('/api/user/profile'),
        api.get('/api/user/progress')
      ]);

      const userData = userResponse.data;
      setUser(userData);
      setFeatures(getTierFeatures(userData.membershipTier));
      setProgress(progressResponse.data);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch user data'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  const refreshUser = async () => {
    setIsLoading(true);
    await fetchUserData();
  };

  return {
    user,
    progress,
    features,
    isLoading,
    error,
    refreshUser
  };
};
