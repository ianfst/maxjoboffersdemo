import { useState, useCallback, useRef, useEffect } from 'react';
import { debounce } from 'lodash';
import zxcvbn from 'zxcvbn';

interface FormValidation {
  [key: string]: {
    isValid: boolean;
    message?: string;
  };
}

interface PasswordStrength {
  score: number;
  feedback: {
    warning: string;
    suggestions: string[];
  };
}

interface UseSecureFormOptions {
  validateOnChange?: boolean;
  debounceMs?: number;
  sanitize?: boolean;
  maxLength?: number;
  preventPaste?: boolean;
}

export const useSecureForm = <T extends Record<string, any>>(
  initialValues: T,
  validationRules: Record<keyof T, (value: any) => boolean | string>,
  options: UseSecureFormOptions = {}
) => {
  const {
    validateOnChange = true,
    debounceMs = 300,
    sanitize = true,
    maxLength = 1000,
    preventPaste = false
  } = options;

  const [values, setValues] = useState<T>(initialValues);
  const [validation, setValidation] = useState<FormValidation>({});
  const [passwordStrength, setPasswordStrength] = useState<PasswordStrength | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const submitCount = useRef(0);
  const lastSubmitTime = useRef(0);

  // Sanitize input to prevent XSS
  const sanitizeInput = (value: string): string => {
    if (!sanitize) return value;
    return value
      .replace(/[<>]/g, '') // Remove < and >
      .slice(0, maxLength); // Limit length
  };

  // Debounced validation
  const debouncedValidate = useCallback(
    debounce((name: keyof T, value: any) => {
      const validationResult = validationRules[name](value);
      setValidation(prev => ({
        ...prev,
        [name]: {
          isValid: typeof validationResult === 'boolean' ? validationResult : false,
          message: typeof validationResult === 'string' ? validationResult : undefined
        }
      }));
    }, debounceMs),
    [validationRules]
  );

  // Handle input changes
  const handleChange = useCallback((name: keyof T, value: any) => {
    const sanitizedValue = typeof value === 'string' ? sanitizeInput(value) : value;
    
    setValues(prev => ({ ...prev, [name]: sanitizedValue }));
    
    if (validateOnChange) {
      debouncedValidate(name, sanitizedValue);
    }

    // Check password strength if field name contains 'password'
    if (typeof value === 'string' && name.toString().toLowerCase().includes('password')) {
      const result = zxcvbn(value);
      setPasswordStrength({
        score: result.score,
        feedback: result.feedback
      });
    }
  }, [validateOnChange, debouncedValidate]);

  // Handle form submission
  const handleSubmit = async (
    onSubmit: (values: T) => Promise<void>,
    onError?: (error: Error) => void
  ) => {
    try {
      // Prevent rapid submissions
      const now = Date.now();
      if (now - lastSubmitTime.current < 1000) {
        throw new Error('Please wait before submitting again');
      }
      
      // Update submission tracking
      submitCount.current += 1;
      lastSubmitTime.current = now;
      setIsSubmitting(true);

      // Validate all fields
      const validationResults = await Promise.all(
        Object.entries(validationRules).map(async ([key, validate]) => {
          const result = validate(values[key]);
          return [key, result];
        })
      );

      const newValidation: FormValidation = {};
      let hasErrors = false;

      validationResults.forEach(([key, result]) => {
        newValidation[key] = {
          isValid: typeof result === 'boolean' ? result : false,
          message: typeof result === 'string' ? result : undefined
        };
        if (!newValidation[key].isValid) hasErrors = true;
      });

      setValidation(newValidation);

      if (hasErrors) {
        throw new Error('Please fix form errors before submitting');
      }

      await onSubmit(values);
    } catch (error) {
      onError?.(error as Error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle paste events
  const handlePaste = useCallback((e: ClipboardEvent) => {
    if (preventPaste) {
      e.preventDefault();
    }
  }, [preventPaste]);

  useEffect(() => {
    if (preventPaste) {
      document.addEventListener('paste', handlePaste);
      return () => document.removeEventListener('paste', handlePaste);
    }
  }, [handlePaste, preventPaste]);

  return {
    values,
    validation,
    passwordStrength,
    isSubmitting,
    submitCount: submitCount.current,
    handleChange,
    handleSubmit,
    reset: () => {
      setValues(initialValues);
      setValidation({});
      setPasswordStrength(null);
    }
  };
};
