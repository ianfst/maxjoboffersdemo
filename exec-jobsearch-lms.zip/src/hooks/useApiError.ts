import { useState, useCallback } from 'react';
import { AxiosError } from 'axios';

interface ApiError {
  message: string;
  code?: string;
  details?: unknown;
}

export const useApiError = () => {
  const [error, setError] = useState<ApiError | null>(null);

  const handleError = useCallback((error: unknown) => {
    if (error instanceof AxiosError) {
      setError({
        message: error.response?.data?.message || 'An error occurred',
        code: error.response?.data?.code || error.code,
        details: error.response?.data
      });
    } else if (error instanceof Error) {
      setError({
        message: error.message,
        code: 'UNKNOWN_ERROR'
      });
    } else {
      setError({
        message: 'An unexpected error occurred',
        code: 'UNKNOWN_ERROR'
      });
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    error,
    handleError,
    clearError
  };
};
