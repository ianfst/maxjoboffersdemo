import React, { useEffect } from 'react';
import { useRouter } from 'next/router';
import DashboardContainer from '../components/dashboard/DashboardContainer';
import { ThemeProvider, createTheme } from '@mui/material';
import { useAuth } from '../hooks/useAuth';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
  typography: {
    h4: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
  },
});

const Home = () => {
  const router = useRouter();
  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.replace('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <ThemeProvider theme={theme}>
      <DashboardContainer />
    </ThemeProvider>
  );
};

export default Home;
