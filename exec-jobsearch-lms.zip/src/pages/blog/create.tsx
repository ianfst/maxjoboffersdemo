import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Container,
  Paper,
  Tab,
  Tabs,
  TextField,
  Typography,
  Alert,
  Chip,
} from '@mui/material';
import { useRouter } from 'next/router';
import { BlogEditor } from '../../components/blog/BlogEditor';
import { aiService } from '../../services/ai';
import { creditService, CreditCheck } from '../../services/credits';
import { useAuth } from '../../hooks/useAuth';
import api from '../../api/config';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`blog-tabpanel-${index}`}
      aria-labelledby={`blog-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

export default function CreateBlogPost() {
  const router = useRouter();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(0);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [creditInfo, setCreditInfo] = useState<CreditCheck | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check available credits on component mount
    const checkCredits = async () => {
      if (user?.id) {
        const check = await creditService.checkCredits(user.id, 'blogIdeas');
        setCreditInfo(check);
      }
    };
    checkCredits();
  }, [user?.id]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleAIContentSave = async (generatedContent: string) => {
    setContent(generatedContent);
    setActiveTab(1); // Switch to manual editor
  };

  const handlePublish = async () => {
    if (!title || !content) return;

    setLoading(true);
    try {
      if (!user?.id) {
        throw new Error('User not authenticated');
      }

      // Generate SEO metadata
      const seoMetadata = await aiService.generateSEOMetadata(`${title}\n\n${content}`);

      // Create blog post
      await api.post('/api/blog/posts', {
        id: 'temp-' + Date.now(), // This will be replaced by the server
        title,
        content,
        excerpt: content.substring(0, 200) + '...',
        slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        status: 'pending',
        type: 'comment',
        createdAt: new Date().toISOString(),
        publishedAt: new Date().toISOString(),
        readingTime: Math.ceil(content.split(/\s+/).length / 200) + ' min',
        author: {
          id: user.id,
          name: `${user.first_name} ${user.last_name}`,
          avatar: user.avatar,
        },
        tags: [],
        hasUnmoderatedComments: false,
        views: 0,
        likes: 0,
        shares: 0,
        seoMetadata,
      });

      router.push('/blog');
    } catch (error: any) {
      setError(error.message || 'Error publishing post');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Credit Status */}
      {creditInfo && (
        <Paper sx={{ mb: 4, p: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="subtitle1">
              AI Credits:
            </Typography>
            {creditInfo.creditsRemaining === -1 ? (
              <Chip
                label="Unlimited"
                color="success"
                variant="outlined"
              />
            ) : (
              <Chip
                label={`${creditInfo.creditsRemaining} credits remaining`}
                color={creditInfo.creditsRemaining > 10 ? 'success' : 'warning'}
                variant="outlined"
              />
            )}
            <Button
              variant="outlined"
              size="small"
              onClick={() => router.push('/pricing')}
            >
              Get More Credits
            </Button>
          </Box>
        </Paper>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 4 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Paper sx={{ mb: 4, p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Create New Blog Post
        </Typography>
        <TextField
          fullWidth
          label="Post Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          sx={{ mb: 4 }}
        />

        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs
            value={activeTab}
            onChange={handleTabChange}
            aria-label="blog editor tabs"
          >
            <Tab label="AI Assistant" />
            <Tab label="Manual Editor" />
          </Tabs>
        </Box>

        <TabPanel value={activeTab} index={0}>
          <BlogEditor onSave={handleAIContentSave} />
        </TabPanel>

        <TabPanel value={activeTab} index={1}>
          <TextField
            fullWidth
            multiline
            minRows={20}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write your blog post content here..."
            variant="outlined"
          />
        </TabPanel>
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
        <Button
          variant="outlined"
          onClick={() => router.push('/blog')}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handlePublish}
          disabled={!title || !content || loading}
        >
          Publish Post
        </Button>
      </Box>
    </Container>
  );
}
