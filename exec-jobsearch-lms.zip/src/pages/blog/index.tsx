import React, { useState } from 'react';
import {
  Grid,
  Typography,
  TextField,
  InputAdornment,
  Box,
  Pagination,
} from '@mui/material';
import { Search as SearchIcon } from '@mui/icons-material';
import BlogLayout from '../../components/blog/BlogLayout';
import BlogCard from '../../components/blog/BlogCard';
import BlogSidebar from '../../components/blog/BlogSidebar';
import { BlogPost, BlogCategory, BlogTag } from '../../types/blog';
import api from '../../api/config';

interface BlogIndexProps {
  posts: BlogPost[];
  categories: BlogCategory[];
  tags: BlogTag[];
  popularPosts: Array<{
    title: string;
    slug: string;
    publishedAt: string;
  }>;
  totalPages: number;
}

const POSTS_PER_PAGE = 6;

const BlogIndex = ({ posts: initialPosts, categories, tags, popularPosts, totalPages }: BlogIndexProps) => {
  const [posts, setPosts] = useState(initialPosts);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    try {
      const response = await api.get('/api/blog/search', {
        params: { query }
      });
      setPosts(response.data.posts);
    } catch (error) {
      console.error('Error searching posts:', error);
    }
  };

  const handlePageChange = async (event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    try {
      const response = await api.get('/api/blog/posts', {
        params: {
          page: value,
          limit: POSTS_PER_PAGE,
          search: searchQuery
        }
      });
      setPosts(response.data.posts);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };

  return (
    <BlogLayout
      title="Executive Blog"
      description="Insights, strategies, and expert advice for executive career development"
      sidebar={
        <BlogSidebar
          categories={categories}
          tags={tags}
          popularPosts={popularPosts}
        />
      }
    >
      {/* Search Bar */}
      <Box sx={{ mb: 4 }}>
        <TextField
          fullWidth
          placeholder="Search articles..."
          variant="outlined"
          onChange={(e) => handleSearch(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {/* Featured Post */}
      {posts.length > 0 && (
        <Box sx={{ mb: 6 }}>
          <BlogCard post={posts[0]} variant="featured" />
        </Box>
      )}

      {/* Post Grid */}
      <Grid container spacing={4}>
        {posts.slice(1).map((post) => (
          <Grid item xs={12} sm={6} key={post.id}>
            <BlogCard post={post} />
          </Grid>
        ))}
      </Grid>

      {/* Pagination */}
      {totalPages > 1 && (
        <Box sx={{ mt: 6, display: 'flex', justifyContent: 'center' }}>
          <Pagination
            count={totalPages}
            page={page}
            onChange={handlePageChange}
            color="primary"
            size="large"
          />
        </Box>
      )}

      {posts.length === 0 && (
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <Typography variant="h5" color="text.secondary" gutterBottom>
            No posts found
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Try adjusting your search or browse our categories
          </Typography>
        </Box>
      )}
    </BlogLayout>
  );
};

export async function getServerSideProps() {
  try {
    const [postsRes, categoriesRes, tagsRes, popularPostsRes] = await Promise.all([
      api.get('/api/blog/posts', { params: { page: 1, limit: POSTS_PER_PAGE } }),
      api.get('/api/blog/categories'),
      api.get('/api/blog/tags'),
      api.get('/api/blog/popular-posts')
    ]);

    return {
      props: {
        posts: postsRes.data.posts,
        categories: categoriesRes.data.categories,
        tags: tagsRes.data.tags,
        popularPosts: popularPostsRes.data.posts,
        totalPages: Math.ceil(postsRes.data.total / POSTS_PER_PAGE)
      }
    };
  } catch (error) {
    console.error('Error fetching blog data:', error);
    return {
      props: {
        posts: [],
        categories: [],
        tags: [],
        popularPosts: [],
        totalPages: 0
      }
    };
  }
}

export default BlogIndex;
