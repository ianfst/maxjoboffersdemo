import React from 'react';
import { GetServerSideProps } from 'next';
import {
  Box,
  Typography,
  Avatar,
  Chip,
  Divider,
  Paper,
  Grid,
} from '@mui/material';
import { useRouter } from 'next/router';
import BlogLayout from '../../components/blog/BlogLayout';
import BlogCard from '../../components/blog/BlogCard';
import { BlogPost } from '../../types/blog';
import api from '../../api/config';

interface BlogPostPageProps {
  post: BlogPost;
  relatedPosts: BlogPost[];
}

const BlogPostPage = ({ post, relatedPosts }: BlogPostPageProps) => {
  const router = useRouter();

  if (router.isFallback) {
    return (
      <BlogLayout>
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <Typography>Loading...</Typography>
        </Box>
      </BlogLayout>
    );
  }

  return (
    <BlogLayout>
      {/* Hero Section */}
      <Box sx={{ mb: 6 }}>
        {post.coverImage && (
          <Box
            sx={{
              height: { xs: 300, md: 500 },
              width: '100%',
              position: 'relative',
              mb: 4,
              borderRadius: 2,
              overflow: 'hidden',
            }}
          >
            <img
              src={post.coverImage}
              alt={post.title}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          </Box>
        )}

        <Typography
          variant="h1"
          sx={{
            fontSize: { xs: '2.5rem', md: '3.5rem' },
            fontWeight: 700,
            mb: 3,
          }}
        >
          {post.title}
        </Typography>

        {/* Author and Meta Info */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 2,
            mb: 4,
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Avatar
              src={post.author.avatar}
              alt={post.author.name}
              sx={{ width: 40, height: 40, mr: 1 }}
            />
            <Box>
              <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                {post.author.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : 'Not published'} · {post.readingTime}
              </Typography>
            </Box>
          </Box>

          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            {post.tags.map((tag) => (
              <Chip
                key={tag}
                label={tag}
                onClick={() => router.push(`/blog/tag/${tag}`)}
                size="small"
              />
            ))}
          </Box>
        </Box>
      </Box>

      {/* Content */}
      <Paper sx={{ p: { xs: 3, md: 6 }, mb: 6 }}>
        <Typography
          component="div"
          className="blog-content"
          dangerouslySetInnerHTML={{ __html: post.content }}
          sx={{
            '& h2': {
              fontSize: '1.875rem',
              fontWeight: 700,
              mt: 6,
              mb: 3,
            },
            '& h3': {
              fontSize: '1.5rem',
              fontWeight: 600,
              mt: 4,
              mb: 2,
            },
            '& p': {
              mb: 3,
              lineHeight: 1.8,
            },
            '& img': {
              maxWidth: '100%',
              height: 'auto',
              borderRadius: 1,
              my: 4,
            },
            '& blockquote': {
              borderLeft: '4px solid',
              borderColor: 'primary.main',
              pl: 3,
              py: 1,
              my: 4,
              fontStyle: 'italic',
            },
            '& ul, & ol': {
              mt: 2,
              mb: 4,
              pl: 4,
            },
            '& li': {
              mb: 1,
            },
            '& pre': {
              p: 3,
              borderRadius: 1,
              overflow: 'auto',
              backgroundColor: 'grey.100',
            },
            '& code': {
              fontFamily: 'monospace',
            },
          }}
        />
      </Paper>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <Box>
          <Typography variant="h4" sx={{ mb: 4 }}>
            Related Posts
          </Typography>
          <Grid container spacing={4}>
            {relatedPosts.map((relatedPost) => (
              <Grid item xs={12} md={4} key={relatedPost.id}>
                <BlogCard post={relatedPost} />
              </Grid>
            ))}
          </Grid>
        </Box>
      )}
    </BlogLayout>
  );
};

export const getServerSideProps: GetServerSideProps = async ({ params }) => {
  try {
    const [postRes, relatedPostsRes] = await Promise.all([
      api.get(`/api/blog/posts/${params?.slug}`),
      api.get(`/api/blog/posts/${params?.slug}/related`)
    ]);

    return {
      props: {
        post: postRes.data,
        relatedPosts: relatedPostsRes.data
      }
    };
  } catch (error) {
    return {
      notFound: true
    };
  }
};

export default BlogPostPage;
