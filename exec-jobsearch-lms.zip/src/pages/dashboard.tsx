import React from 'react';
import DashboardMockup from '../components/dashboard/DashboardMockup';

const DashboardPage: React.FC = () => {
  return <DashboardMockup />;
};

export default DashboardPage;
