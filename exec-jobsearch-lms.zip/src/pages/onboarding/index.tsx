import { useState } from 'react';
import { useRouter } from 'next/router';
import {
  Box,
  Container,
  Stepper,
  Step,
  StepLabel,
  Paper,
  Typography,
} from '@mui/material';
import { useAuth } from '../../hooks/useAuth';
import ProfileForm from '../../components/onboarding/ProfileForm';
import CareerGoalsForm from '../../components/onboarding/CareerGoalsForm';
import MembershipForm from '../../components/onboarding/MembershipForm';
import FinancialVerificationForm from '../../components/onboarding/FinancialVerificationForm';

interface OnboardingData {
  profile: {
    firstName?: string;
    lastName?: string;
    title?: string;
    company?: string;
    industry?: string;
  };
  careerGoals: {
    shortTerm?: string;
    longTerm?: string;
    interests?: string[];
  };
  membership: {
    tier?: 'standard' | 'premium' | 'platinum';
  };
  financialVerification: {
    income?: number;
    assets?: number;
    verified?: boolean;
  };
}

const steps = [
  'Complete Your Profile',
  'Career Goals',
  'Choose Membership',
  'Financial Verification'
];

const OnboardingPage = () => {
  const router = useRouter();
  const { user } = useAuth();
  const [activeStep, setActiveStep] = useState(0);
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    profile: {},
    careerGoals: {},
    membership: {},
    financialVerification: {}
  });

  const handleNext = (data: any) => {
    setOnboardingData(prev => ({
      ...prev,
      [getStepKey(activeStep)]: data
    }));
    
    if (activeStep === steps.length - 1) {
      // Complete onboarding
      router.push('/dashboard');
    } else {
      setActiveStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep(prev => prev - 1);
  };

  const getStepKey = (step: number): string => {
    const keys = ['profile', 'careerGoals', 'membership', 'financialVerification'];
    return keys[step];
  };

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <ProfileForm
            initialData={onboardingData.profile}
            onSubmit={handleNext}
          />
        );
      case 1:
        return (
          <CareerGoalsForm
            initialData={onboardingData.careerGoals}
            onSubmit={handleNext}
            onBack={handleBack}
          />
        );
      case 2:
        return (
          <MembershipForm
            initialData={onboardingData.membership}
            onSubmit={handleNext}
            onBack={handleBack}
          />
        );
      case 3:
        return (
          <FinancialVerificationForm
            initialData={onboardingData.financialVerification}
            onSubmit={handleNext}
            onBack={handleBack}
            showForm={onboardingData.membership?.tier === 'platinum'}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 8 }}>
        <Paper elevation={2} sx={{ p: 4 }}>
          <Typography variant="h4" component="h1" align="center" gutterBottom>
            Welcome to Executive LMS
          </Typography>
          
          <Stepper activeStep={activeStep} sx={{ py: 4 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>

          <Box sx={{ mt: 4 }}>
            {getStepContent(activeStep)}
          </Box>
        </Paper>
      </Box>
    </Container>
  );
};

export default OnboardingPage;
