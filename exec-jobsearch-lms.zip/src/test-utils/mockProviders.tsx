import React, { createContext, useContext, useState, useCallback } from 'react';
import { User } from '../types/user';

// Auth Context Types
interface AuthContextState {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  isAuthenticated: boolean;
}

interface AuthContextValue extends AuthContextState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  signup: (userData: any) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  clearError: () => void;
}

// AI Context Types
interface AIContextState {
  isProcessing: boolean;
  error: Error | null;
  lastResponse: any;
}

interface AIContextValue extends AIContextState {
  generateContent: (prompt: string, options?: any) => Promise<any>;
  analyzeContent: (content: string, type: string) => Promise<any>;
  clearError: () => void;
}

// Create Contexts
export const AuthContext = createContext<AuthContextValue | null>(null);
export const AIContext = createContext<AIContextValue | null>(null);

// Mock Providers
interface MockAuthProviderProps {
  children: React.ReactNode;
  initialUser?: User | null;
  mockHandlers?: Partial<AuthContextValue>;
}

export const MockAuthProvider: React.FC<MockAuthProviderProps> = ({
  children,
  initialUser = null,
  mockHandlers = {}
}) => {
  const [state, setState] = useState<AuthContextState>({
    user: initialUser,
    isLoading: false,
    error: null,
    isAuthenticated: !!initialUser
  });

  const login = useCallback(async (email: string, password: string) => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    try {
      const user = createMockUser({ email });
      setState(prev => ({
        ...prev,
        user,
        isAuthenticated: true,
        isLoading: false
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: error as Error,
        isLoading: false
      }));
      throw error;
    }
  }, []);

  const logout = useCallback(async () => {
    setState(prev => ({
      ...prev,
      user: null,
      isAuthenticated: false
    }));
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  const value: AuthContextValue = {
    ...state,
    login,
    logout,
    signup: mockHandlers.signup || jest.fn(),
    resetPassword: mockHandlers.resetPassword || jest.fn(),
    clearError
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

interface MockAIProviderProps {
  children: React.ReactNode;
  config?: {
    isProcessing?: boolean;
    error?: Error | null;
  };
  mockHandlers?: Partial<AIContextValue>;
}

export const MockAIProvider: React.FC<MockAIProviderProps> = ({
  children,
  config = {},
  mockHandlers = {}
}) => {
  const [state, setState] = useState<AIContextState>({
    isProcessing: config.isProcessing || false,
    error: config.error || null,
    lastResponse: null
  });

  const generateContent = useCallback(async (prompt: string, options?: any) => {
    setState(prev => ({ ...prev, isProcessing: true, error: null }));
    try {
      const response = { content: `Mock response for: ${prompt}`, ...options };
      setState(prev => ({
        ...prev,
        lastResponse: response,
        isProcessing: false
      }));
      return response;
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: error as Error,
        isProcessing: false
      }));
      throw error;
    }
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  const value: AIContextValue = {
    ...state,
    generateContent,
    analyzeContent: mockHandlers.analyzeContent || jest.fn(),
    clearError
  };

  return (
    <AIContext.Provider value={value}>
      {children}
    </AIContext.Provider>
  );
};

// Test data factories
export const createMockUser = (overrides = {}): User => ({
  id: 'test-user-id',
  email: 'test@example.com',
  name: 'Test User',
  role: 'user',
  ...overrides
});

// Mock API responses with typed error handling
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: Record<string, any>
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export const mockApiResponses = {
  success: {
    status: 200,
    json: () => Promise.resolve({ success: true }),
    ok: true,
  },
  error: {
    status: 400,
    json: () => Promise.resolve({ error: 'Bad Request' }),
    ok: false,
  },
  networkError: {
    status: 500,
    json: () => Promise.reject(new ApiError('Network Error', 500)),
    ok: false,
  },
  unauthorized: {
    status: 401,
    json: () => Promise.resolve({ error: 'Unauthorized' }),
    ok: false,
  },
  forbidden: {
    status: 403,
    json: () => Promise.resolve({ error: 'Forbidden' }),
    ok: false,
  }
};

// Custom hooks for accessing mock contexts in tests
export const useAuthContext = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext must be used within MockAuthProvider');
  }
  return context;
};

export const useAIContext = () => {
  const context = useContext(AIContext);
  if (!context) {
    throw new Error('useAIContext must be used within MockAIProvider');
  }
  return context;
};
