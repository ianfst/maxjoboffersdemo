import React from 'react';
import { render, RenderOptions, RenderResult } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MockAuthProvider, MockAIProvider, createMockUser } from './mockProviders';
import { User } from '../types/user';

// Test query client with default options
const createTestQueryClient = () => new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      cacheTime: 0,
    },
  },
});

// Types for render options
interface CustomRenderOptions extends Omit<RenderOptions, 'wrapper'> {
  route?: string;
  initialEntries?: string[];
  user?: User | null;
  withAuth?: boolean;
  withAI?: boolean;
  mockHandlers?: {
    auth?: any;
    ai?: any;
  };
}

// Main render utility
export const renderWithProviders = (
  ui: React.ReactElement,
  {
    route = '/',
    initialEntries = ['/'],
    user = null,
    withAuth = true,
    withAI = true,
    mockHandlers = {},
    ...renderOptions
  }: CustomRenderOptions = {}
): RenderResult & { user: typeof userEvent } => {
  const testQueryClient = createTestQueryClient();

  const AllTheProviders: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    let wrapped = children;

    // Add providers from innermost to outermost
    if (withAI) {
      wrapped = (
        <MockAIProvider config={{}} mockHandlers={mockHandlers.ai}>
          {wrapped}
        </MockAIProvider>
      );
    }

    if (withAuth) {
      wrapped = (
        <MockAuthProvider initialUser={user} mockHandlers={mockHandlers.auth}>
          {wrapped}
        </MockAuthProvider>
      );
    }

    return (
      <QueryClientProvider client={testQueryClient}>
        <MemoryRouter initialEntries={initialEntries}>
          <Routes>
            <Route path={route} element={wrapped} />
          </Routes>
        </MemoryRouter>
      </QueryClientProvider>
    );
  };

  return {
    user: userEvent.setup(),
    ...render(ui, { wrapper: AllTheProviders, ...renderOptions })
  };
};

// Navigation test helpers
export const verifyStepState = async (
  getByTestId: Function,
  stepId: string,
  expectedState: 'active' | 'completed' | 'pending'
) => {
  const step = getByTestId(`step-${stepId}`);
  expect(step).toHaveAttribute('data-state', expectedState);
};

export const navigateAndVerify = async (
  user: ReturnType<typeof userEvent.setup>,
  getByRole: Function,
  getByTestId: Function,
  buttonText: string,
  nextStepId: string
) => {
  await user.click(getByRole('button', { name: buttonText }));
  await verifyStepState(getByTestId, nextStepId, 'active');
};

// Form test helpers
export const fillFormFields = async (
  user: ReturnType<typeof userEvent.setup>,
  getByLabelText: Function,
  fields: Record<string, string>
) => {
  for (const [label, value] of Object.entries(fields)) {
    const input = getByLabelText(label);
    await user.clear(input);
    await user.type(input, value);
  }
};

// Mock data generators
export const createMockFormData = (overrides = {}) => ({
  title: 'Test Title',
  description: 'Test Description',
  category: 'test',
  ...overrides
});

// Mock API handlers
export const mockApiSuccess = (data: any) => () =>
  Promise.resolve({ ok: true, json: () => Promise.resolve(data) });

export const mockApiError = (status: number, message: string) => () =>
  Promise.reject(new Error(message));

// Async test helpers
export const waitForLoadingToComplete = async (queryByTestId: Function) => {
  await new Promise(resolve => setTimeout(resolve, 0)); // Let any pending state updates complete
  expect(queryByTestId('loading-spinner')).not.toBeInTheDocument();
};

// Test cleanup utility
export const cleanupTest = () => {
  localStorage.clear();
  sessionStorage.clear();
};

// Type guards for better error handling
export const isErrorWithMessage = (error: unknown): error is { message: string } => {
  return (
    typeof error === 'object' &&
    error !== null &&
    'message' in error &&
    typeof (error as any).message === 'string'
  );
};

// Constants for testing
export const TEST_IDS = {
  loadingSpinner: 'loading-spinner',
  errorMessage: 'error-message',
  successMessage: 'success-message',
} as const;
