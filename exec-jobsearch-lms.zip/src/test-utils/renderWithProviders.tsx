import React from 'react';
import { render, RenderOptions } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import { QueryClient, QueryClientProvider } from 'react-query';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { theme } from '../styles/theme';
import { MockAuthProvider, MockAIProvider, createMockUser } from './mockProviders';
import { User } from '../types/user';

interface CustomRenderOptions extends Omit<RenderOptions, 'wrapper'> {
  route?: string;
  routeConfig?: Array<{ path: string; element: React.ReactElement }>;
  queryClient?: QueryClient;
  mockUser?: User | null;
  mockAIConfig?: {
    isProcessing?: boolean;
    error?: Error | null;
  };
  withAuth?: boolean;
  withAI?: boolean;
}

// Create a custom render function that includes providers
export function renderWithProviders(
  ui: React.ReactElement,
  {
    route = '/',
    routeConfig = [],
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
          cacheTime: 0,
          staleTime: 0,
        },
      },
    }),
    mockUser = null,
    mockAIConfig = { isProcessing: false, error: null },
    withAuth = true,
    withAI = false,
    ...renderOptions
  }: CustomRenderOptions = {}
) {
  function Wrapper({ children }: { children: React.ReactNode }) {
    const wrappedChildren = (
      <Routes>
        <Route path={route} element={children} />
        {routeConfig.map(({ path, element }) => (
          <Route key={path} path={path} element={element} />
        ))}
      </Routes>
    );

    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider theme={theme}>
          <MemoryRouter initialEntries={[route]}>
            {withAuth ? (
              <MockAuthProvider initialUser={mockUser}>
                {withAI ? (
                  <MockAIProvider config={mockAIConfig}>
                    {wrappedChildren}
                  </MockAIProvider>
                ) : (
                  wrappedChildren
                )}
              </MockAuthProvider>
            ) : withAI ? (
              <MockAIProvider config={mockAIConfig}>
                {wrappedChildren}
              </MockAIProvider>
            ) : (
              wrappedChildren
            )}
          </MemoryRouter>
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  return {
    ...render(ui, { wrapper: Wrapper, ...renderOptions }),
    queryClient,
    mockUser: mockUser || createMockUser(),
  };
}
