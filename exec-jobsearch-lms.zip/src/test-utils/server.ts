import { setupServer } from 'msw/node';
import { rest } from 'msw';

// Create test server instance
export const server = setupServer();

// Common handlers that can be reused across tests
export const handlers = {
  auth: {
    login: rest.post('/api/auth/login', (req, res, ctx) => {
      return res(
        ctx.status(200),
        ctx.json({
          user: {
            id: 'test-user-id',
            email: 'test@example.com',
            name: 'Test User',
            role: 'user',
          },
          token: 'test-token',
        })
      );
    }),
  },
  ai: {
    generate: rest.post('/api/ai/generate', (req, res, ctx) => {
      return res(
        ctx.status(200),
        ctx.json({
          content: 'Generated content for testing',
          status: 'success',
        })
      );
    }),
  },
  interview: {
    create: rest.post('/api/interview-prep/create', (req, res, ctx) => {
      return res(
        ctx.status(200),
        ctx.json({
          interviewPrep: {
            id: 'test-prep-id',
            status: 'in_progress',
            steps: {
              requirementsAnalysis: { status: 'pending', data: null },
              experienceMapping: { status: 'pending', data: null },
              behavioralPrep: { status: 'pending', data: null },
            },
          },
        })
      );
    }),
  },
};

// Helper to reset handlers
export const resetHandlers = () => server.resetHandlers();

// Helper to use custom handlers
export const useCustomHandlers = (customHandlers: any[]) => {
  server.use(...customHandlers);
};

export * from 'msw';
