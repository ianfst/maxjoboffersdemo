import { createContext, useEffect, useState, ReactNode, useContext, useCallback } from 'react';
import api from '../api/config';
import { AxiosError } from 'axios';
import { useApiError } from '../hooks/useApiError';

export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  membership_tier: string;
  token_balance: number;
  avatar?: string;
  created_at?: string;
}

export interface SignupData {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  confirm_password?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (userData: SignupData) => Promise<void>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<void>;
  error: ApiError | null;
  clearError: () => void;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

const TOKEN_EXPIRY_BUFFER = 300000; // 5 minutes in milliseconds
const MAX_LOGIN_ATTEMPTS = 5;
const LOGIN_ATTEMPT_RESET_TIME = 900000; // 15 minutes in milliseconds

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loginAttempts, setLoginAttempts] = useState<{ count: number; lastAttempt: number }>({
    count: 0,
    lastAttempt: 0,
  });
  const { error, handleError, clearError } = useApiError();

  useEffect(() => {
    checkAuth();
    startTokenRefreshTimer();
  }, []);

  const startTokenRefreshTimer = useCallback(() => {
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiryTime = payload.exp * 1000; // Convert to milliseconds
      const timeUntilRefresh = expiryTime - Date.now() - TOKEN_EXPIRY_BUFFER;

      if (timeUntilRefresh > 0) {
        setTimeout(() => {
          refreshToken();
        }, timeUntilRefresh);
      } else {
        refreshToken();
      }
    } catch (error) {
      console.error('Error parsing token:', error);
    }
  }, []);

  const checkAuth = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setIsLoading(false);
        return;
      }

      const response = await api.get('/api/auth/me');
      setUser(response.data.user);
    } catch (err) {
      handleError(err);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, [handleError]);

  const handleAuthError = (error: unknown) => {
    if (error instanceof AxiosError) {
      switch (error.response?.status) {
        case 401:
          throw new Error('Authentication failed');
        case 429:
          throw new Error('Too many attempts, please try again later');
        default:
          throw new Error(error.response?.data?.message || 'Authentication failed');
      }
    }
    throw new Error('Network error');
  };

  const checkLoginAttempts = () => {
    const now = Date.now();
    if (now - loginAttempts.lastAttempt > LOGIN_ATTEMPT_RESET_TIME) {
      setLoginAttempts({ count: 1, lastAttempt: now });
      return;
    }

    if (loginAttempts.count >= MAX_LOGIN_ATTEMPTS) {
      throw new Error('Too many login attempts. Please try again later.');
    }

    setLoginAttempts({
      count: loginAttempts.count + 1,
      lastAttempt: now,
    });
  };

  const login = useCallback(async (email: string, password: string) => {
    try {
      checkLoginAttempts();

      const response = await api.post('/api/auth/login', { email, password });
      const { token, refreshToken: refresh, user: userData } = response.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('refreshToken', refresh);
      setUser(userData);
      startTokenRefreshTimer();
      
      // Reset login attempts on successful login
      setLoginAttempts({ count: 0, lastAttempt: 0 });
    } catch (err) {
      handleError(err);
      throw err;
    }
  }, [handleError, startTokenRefreshTimer]);

  const signup = useCallback(async (userData: SignupData) => {
    try {
      if (userData.password !== userData.confirm_password) {
        handleError(new Error('Passwords do not match'));
        return;
      }

      const { confirm_password, ...signupData } = userData;
      const response = await api.post('/api/auth/signup', signupData);
      const { token, refreshToken: refresh, user: newUser } = response.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('refreshToken', refresh);
      setUser(newUser);
      startTokenRefreshTimer();
    } catch (err) {
      handleError(err);
      throw err;
    }
  }, [handleError, startTokenRefreshTimer]);

  const logout = useCallback(async () => {
    try {
      await api.post('/api/auth/logout');
      setUser(null);
    } catch (err) {
      handleError(err);
      throw err;
    }
  }, [handleError]);

  const refreshToken = useCallback(async () => {
    try {
      const refresh = localStorage.getItem('refreshToken');
      if (!refresh) {
        throw new Error('No refresh token');
      }

      const response = await api.post('/api/auth/refresh-token', {
        refreshToken: refresh,
      });

      const { token } = response.data;
      localStorage.setItem('token', token);
      startTokenRefreshTimer();
    } catch (err) {
      handleError(err);
      throw err;
    }
  }, [handleError, startTokenRefreshTimer]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        logout,
        refreshToken,
        error,
        clearError
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
