import React from 'react';
import { render, act, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { AuthProvider, useAuth } from '../AuthContext';
import api from '../../api/config';

// Mock JWT token parsing
const mockJwtToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjk5OTk5OTk5OTl9.signature';

// Mock axios
jest.mock('../../api/config', () => ({
  get: jest.fn(),
  post: jest.fn(),
}));

// Mock local storage
const mockLocalStorage = {
  store: {} as { [key: string]: string },
  getItem: function(key: string) {
    return this.store[key] || null;
  },
  setItem: function(key: string, value: string) {
    this.store[key] = value;
  },
  clear: function() {
    this.store = {};
  }
};

Object.defineProperty(window, 'localStorage', {
  value: mockLocalStorage,
  writable: true
});

const TestComponent = () => {
  const { user, isLoading, login, signup, logout, error, clearError } = useAuth();
  return (
    <div>
      {isLoading && <div data-testid="loading">Loading...</div>}
      {error && <div data-testid="error">{error.message}</div>}
      {!isLoading && (
        <div data-testid="content">
          {user ? `Welcome ${user.email}` : 'Please log in'}
          <button onClick={() => login('test@example.com', 'password')}>Login</button>
          <button onClick={() => signup({
            email: 'test@example.com',
            password: 'password',
            confirm_password: 'password',
            first_name: 'Test',
            last_name: 'User'
          })}>Signup</button>
          <button onClick={logout}>Logout</button>
          {error && <button onClick={clearError}>Clear Error</button>}
        </div>
      )}
    </div>
  );
};

describe('AuthContext', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockLocalStorage.clear();
    jest.useFakeTimers();
  });

  afterEach(() => {
    mockLocalStorage.clear();
    jest.useRealTimers();
  });

  it('provides loading state initially', async () => {
    mockLocalStorage.setItem('token', mockJwtToken);
    const mockUser = { id: '1', email: 'test@example.com' };
    
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: { user: mockUser }
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    expect(screen.getByTestId('loading')).toBeInTheDocument();

    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });

    expect(screen.getByText(`Welcome ${mockUser.email}`)).toBeInTheDocument();
  });

  it('handles successful login', async () => {
    const mockUser = {
      id: '1',
      email: 'test@example.com'
    };

    (api.post as jest.Mock).mockResolvedValueOnce({
      data: { user: mockUser, token: mockJwtToken, refreshToken: 'refresh-token' }
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });

    const loginButton = screen.getByText('Login');
    await act(async () => {
      fireEvent.click(loginButton);
    });

    await waitFor(() => {
      expect(screen.getByText(`Welcome ${mockUser.email}`)).toBeInTheDocument();
      expect(mockLocalStorage.getItem('token')).toBe(mockJwtToken);
      expect(mockLocalStorage.getItem('refreshToken')).toBe('refresh-token');
    });
  });

  it('handles login failure', async () => {
    const errorMessage = 'Invalid credentials';
    (api.post as jest.Mock).mockRejectedValueOnce({
      response: { data: { message: errorMessage }, status: 401 }
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });

    const loginButton = screen.getByText('Login');
    await act(async () => {
      fireEvent.click(loginButton);
    });

    await waitFor(() => {
      expect(screen.getByTestId('error')).toHaveTextContent(errorMessage);
    });
  });

  it('handles rate limiting', async () => {
    (api.post as jest.Mock).mockRejectedValue({
      response: { status: 429, data: { message: 'Too many attempts' } }
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });

    const loginButton = screen.getByText('Login');

    // Attempt multiple logins
    for (let i = 0; i < 5; i++) {
      await act(async () => {
        fireEvent.click(loginButton);
      });
    }

    await waitFor(() => {
      expect(screen.getByTestId('error')).toHaveTextContent('Too many attempts');
    });
  });

  it('handles token refresh', async () => {
    mockLocalStorage.setItem('token', mockJwtToken);
    mockLocalStorage.setItem('refreshToken', 'valid-refresh-token');

    // Mock initial auth check
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: { user: { id: '1', email: 'test@example.com' } }
    });

    // Mock token refresh
    (api.post as jest.Mock).mockResolvedValueOnce({
      data: { token: 'new-token' }
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    // Fast-forward past token expiry buffer
    jest.advanceTimersByTime(300000); // 5 minutes

    await waitFor(() => {
      expect(mockLocalStorage.getItem('token')).toBe('new-token');
    });
  });

  it('clears error state', async () => {
    (api.post as jest.Mock).mockRejectedValueOnce({
      response: { data: { message: 'Error occurred' }, status: 400 }
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });

    const loginButton = screen.getByText('Login');
    await act(async () => {
      fireEvent.click(loginButton);
    });

    await waitFor(() => {
      expect(screen.getByTestId('error')).toBeInTheDocument();
    });

    const clearButton = screen.getByText('Clear Error');
    fireEvent.click(clearButton);

    expect(screen.queryByTestId('error')).not.toBeInTheDocument();
  });
});
