import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1B365D', // deep navy
      light: '#2B4B7E',
      dark: '#12243D',
    },
    secondary: {
      main: '#C6A052', // warm gold
      light: '#D4B778',
      dark: '#9E7F41',
    },
    grey: {
      100: '#F5F5F5', // light gray
      200: '#EEEEEE',
      300: '#E0E0E0',
    },
    background: {
      default: '#FFFFFF',
      paper: '#F5F5F5',
    },
  },
  typography: {
    fontFamily: '"Inter", "Helvetica", "Arial", sans-serif',
    h1: {
      fontSize: '2.5rem',
      fontWeight: 600,
      color: '#1B365D',
    },
    h2: {
      fontSize: '2rem',
      fontWeight: 600,
      color: '#1B365D',
    },
    h3: {
      fontSize: '1.75rem',
      fontWeight: 500,
      color: '#1B365D',
    },
    body1: {
      fontSize: '1rem',
      color: '#333333',
    },
    button: {
      textTransform: 'none',
      fontWeight: 500,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          padding: '10px 24px',
        },
        contained: {
          boxShadow: 'none',
          '&:hover': {
            boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.05)',
        },
      },
    },
  },
});

export default theme;
