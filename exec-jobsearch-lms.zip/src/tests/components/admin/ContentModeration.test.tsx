import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { ContentModeration } from '../../../components/admin/ContentModeration';
import { BlogPost } from '../../../types/blog';

const mockPost: BlogPost = {
  id: '1',
  title: 'Test Post',
  content: 'Test content',
  status: 'published',
  createdAt: '2025-03-04T09:00:00Z',
  excerpt: 'Test excerpt',
  slug: 'test-post',
  type: 'review',
  tags: ['test'],
  author: {
    id: '1',
    name: 'Test User',
    avatar: 'https://example.com/avatar.jpg'
  }
};

describe('ContentModeration', () => {
  it('renders content moderation component', () => {
    render(<ContentModeration posts={[mockPost]} onStatusChange={jest.fn()} />);
    expect(screen.getByText('Test Post')).toBeInTheDocument();
  });

  it('handles post status updates', () => {
    const onStatusChange = jest.fn();
    render(<ContentModeration posts={[mockPost]} onStatusChange={onStatusChange} />);
    
    const approveButton = screen.getByLabelText('Approve post');
    fireEvent.click(approveButton);
    
    expect(onStatusChange).toHaveBeenCalledWith(mockPost.id, 'approved');
  });
});
