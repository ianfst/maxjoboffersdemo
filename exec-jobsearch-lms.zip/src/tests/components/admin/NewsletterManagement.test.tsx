import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import { NewsletterManagement } from '../../../components/admin/NewsletterManagement';
import { QueryClient, QueryClientProvider } from 'react-query';
import api from '../../../api/config';
import { NewsletterSubscriber } from '../../../services/newsletter';

// Mock api
jest.mock('../../../api/config', () => ({
  get: jest.fn(),
  post: jest.fn(),
}));

describe('NewsletterManagement', () => {
  let queryClient: QueryClient;

  beforeEach(() => {
    jest.clearAllMocks();
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
          cacheTime: 0,
        },
      },
    });

    // Mock initial subscriber data
    (api.get as jest.Mock).mockResolvedValue({
      data: {
        subscribers: [
          {
            email: 'test@example.com',
            name: 'Test User',
            subscribed: true,
            subscribedAt: '2025-03-04T08:00:00Z',
            preferences: {
              frequency: 'weekly',
              categories: ['tech', 'business']
            }
          },
          {
            email: 'test2@example.com',
            name: 'Test User 2',
            subscribed: false,
            subscribedAt: '2025-03-04T08:00:00Z'
          }
        ]
      }
    });
  });

  afterEach(() => {
    queryClient.clear();
  });

  const renderComponent = (props: any = {}) => {
    return render(
      <QueryClientProvider client={queryClient}>
        <NewsletterManagement {...props} />
      </QueryClientProvider>
    );
  };

  it('renders subscriber list', async () => {
    renderComponent();
    
    await waitFor(() => {
      expect(screen.getByText('test@example.com')).toBeInTheDocument();
      expect(screen.getByText('test2@example.com')).toBeInTheDocument();
    });

    expect(screen.getByText('Active')).toBeInTheDocument();
    expect(screen.getByText('Unsubscribed')).toBeInTheDocument();
  });

  it('creates and previews blog digest', async () => {
    // Mock digest creation
    (api.post as jest.Mock).mockResolvedValueOnce({
      data: {
        digest: 'Test digest content'
      }
    });

    renderComponent();

    await waitFor(() => {
      expect(screen.getByText(/Create Blog Digest/i)).toBeInTheDocument();
    });

    await act(async () => {
      fireEvent.click(screen.getByText(/Create Blog Digest/i));
    });

    await waitFor(() => {
      expect(screen.getByText('Test digest content')).toBeInTheDocument();
    });
  });

  it('sends newsletter to selected subscribers', async () => {
    // Mock digest creation
    (api.post as jest.Mock).mockResolvedValueOnce({
      data: {
        digest: 'Test digest content'
      }
    });

    // Mock successful send
    (api.post as jest.Mock).mockResolvedValueOnce({
      data: { success: true }
    });

    renderComponent();

    // Wait for component to load
    await waitFor(() => {
      expect(screen.getByText(/Create Blog Digest/i)).toBeInTheDocument();
    });

    // Create digest
    await act(async () => {
      fireEvent.click(screen.getByText(/Create Blog Digest/i));
    });

    // Wait for preview dialog
    await waitFor(() => {
      expect(screen.getByText('Test digest content')).toBeInTheDocument();
    });

    // Click "Send Newsletter" in preview dialog
    await act(async () => {
      const buttons = screen.getAllByRole('button');
      const sendButton = buttons.find(button => button.textContent === 'Send Newsletter');
      if (!sendButton) throw new Error('Send Newsletter button not found');
      fireEvent.click(sendButton);
    });

    // Wait for send dialog and select subscriber
    await waitFor(() => {
      const checkboxes = screen.getAllByRole('checkbox');
      expect(checkboxes.length).toBeGreaterThan(0);
      fireEvent.click(checkboxes[1]); // Click the first subscriber checkbox (index 1 because index 0 is the "select all" checkbox)
    });

    // Send newsletter
    await act(async () => {
      fireEvent.click(screen.getByText('Send'));
    });

    await waitFor(() => {
      expect(api.post).toHaveBeenCalledWith('/api/newsletter/send', {
        recipients: ['test@example.com'],
        content: 'Test digest content'
      });
    });
  });

  it('handles API errors gracefully', async () => {
    // Mock API error
    (api.post as jest.Mock).mockRejectedValueOnce(new Error('API Error'));

    renderComponent();

    await waitFor(() => {
      expect(screen.getByText(/Create Blog Digest/i)).toBeInTheDocument();
    });

    await act(async () => {
      fireEvent.click(screen.getByText(/Create Blog Digest/i));
    });

    await waitFor(() => {
      expect(screen.getByText(/Error creating digest/i)).toBeInTheDocument();
    });
  });

  it('renders newsletter management component', () => {
    const mockSubscribers: NewsletterSubscriber[] = [
      {
        id: '1',
        email: 'test@example.com',
        name: 'Test User',
        subscribed: true,
        subscribedAt: '2025-03-04T09:00:00Z'
      }
    ];

    renderComponent({ subscribers: mockSubscribers, onUpdate: jest.fn() });
    expect(screen.getByText('Newsletter Management')).toBeInTheDocument();
  });

  it('handles subscriber selection', () => {
    const mockSubscribers: NewsletterSubscriber[] = [
      {
        id: '1',
        email: 'test@example.com',
        name: 'Test User',
        subscribed: true,
        subscribedAt: '2025-03-04T09:00:00Z'
      }
    ];

    renderComponent({ subscribers: mockSubscribers, onUpdate: jest.fn() });
    const checkbox = screen.getByRole('checkbox', { name: /select test@example.com/i });
    fireEvent.click(checkbox);
    expect(checkbox).toBeChecked();
  });
});
