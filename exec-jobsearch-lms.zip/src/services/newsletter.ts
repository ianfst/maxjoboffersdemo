import { BlogPost } from '../types/blog';

export interface NewsletterSubscriber {
  id: string;
  email: string;
  name?: string;
  subscribed: boolean;
  subscribedAt: string;
  unsubscribedAt?: string;
  preferences?: {
    frequency: 'daily' | 'weekly' | 'monthly';
    categories: string[];
  };
}

export interface NewsletterTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  variables: string[];
}

export const newsletterService = {
  async subscribe(email: string, name?: string): Promise<NewsletterSubscriber> {
    const response = await fetch('/api/newsletter/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, name }),
    });

    if (!response.ok) {
      throw new Error('Failed to subscribe to newsletter');
    }

    return response.json();
  },

  async unsubscribe(email: string): Promise<void> {
    const response = await fetch('/api/newsletter/unsubscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });

    if (!response.ok) {
      throw new Error('Failed to unsubscribe from newsletter');
    }
  },

  async updatePreferences(
    email: string,
    preferences: NewsletterSubscriber['preferences']
  ): Promise<NewsletterSubscriber> {
    const response = await fetch('/api/newsletter/preferences', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, preferences }),
    });

    if (!response.ok) {
      throw new Error('Failed to update newsletter preferences');
    }

    return response.json();
  },

  async sendNewsletter(
    template: NewsletterTemplate,
    subscribers: NewsletterSubscriber[],
    variables: Record<string, string>
  ): Promise<void> {
    const response = await fetch('/api/newsletter/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        template,
        subscribers,
        variables,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to send newsletter');
    }
  },

  async createBlogDigest(posts: BlogPost[]): Promise<NewsletterTemplate> {
    // Create a newsletter template from recent blog posts
    const template: NewsletterTemplate = {
      id: `blog-digest-${Date.now()}`,
      name: 'Blog Digest',
      subject: 'Latest Blog Posts from Executive Career Guide',
      content: this.generateDigestContent(posts),
      variables: ['subscriber_name'],
    };

    const response = await fetch('/api/newsletter/templates', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(template),
    });

    if (!response.ok) {
      throw new Error('Failed to create blog digest template');
    }

    return response.json();
  },

  generateDigestContent(posts: BlogPost[]): string {
    const intro = 'Here are our latest insights and guides for executive career development:';
    
    const postList = posts
      .map(
        (post) => `
          <h2><a href="/blog/${post.slug}">${post.title}</a></h2>
          <p>${post.excerpt}</p>
          <p><small>By ${post.author.name} · ${post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : 'Not published'}</small></p>
        `
      )
      .join('\n');

    const footer = `
      <hr>
      <p>
        You're receiving this because you subscribed to our newsletter.
        <a href="{{unsubscribe_url}}">Unsubscribe</a> or
        <a href="{{preferences_url}}">update your preferences</a>.
      </p>
    `;

    return `
      <p>Dear {{subscriber_name}},</p>
      <p>${intro}</p>
      ${postList}
      ${footer}
    `;
  },
};
