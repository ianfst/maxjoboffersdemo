import OpenAI from 'openai';
import { BlogPost } from '../types/blog';
import { creditService } from './credits';

// Helper function to get OpenAI client
const getOpenAIClient = () => {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error('OpenAI API key is not configured');
  }
  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true // Only for development
  });
};

export interface BlogPostIdeas {
  title: string;
  description: string;
  targetAudience: string;
  keyPoints: string[];
  estimatedReadingTime: number;
  suggestedTags: string[];
}

export interface BlogPostOutline {
  title: string;
  introduction: string;
  sections: {
    heading: string;
    content: string[];
    keyTakeaway: string;
  }[];
  conclusion: string;
  callToAction: string;
}

export interface BlogPostSEO {
  title: string;
  description: string;
  keywords: string[];
  socialMediaDescription: string;
}

export const aiService = {
  async generateBlogIdeas(userId: string, topic: string): Promise<BlogPostIdeas[]> {
    // Check credits before proceeding
    const canUseCredits = await creditService.useCredits(userId, 'blogIdeas');
    if (!canUseCredits) {
      throw new Error('Insufficient credits to generate blog ideas');
    }

    try {
      const openai = getOpenAIClient();
      const completion = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an expert content strategist for an executive career development platform.'
          },
          {
            role: 'user',
            content: `Generate blog post ideas about ${topic} that would be valuable for executives and career professionals.`
          }
        ],
        tools: [{
          type: 'function',
          function: {
            name: 'generateBlogIdeas',
            description: 'Generates blog post ideas with detailed information',
            parameters: {
              type: 'object',
              properties: {
                ideas: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      title: {
                        type: 'string',
                        description: 'Engaging title for the blog post'
                      },
                      description: {
                        type: 'string',
                        description: 'Brief description of the post content'
                      },
                      targetAudience: {
                        type: 'string',
                        description: 'Specific executive audience segment'
                      },
                      keyPoints: {
                        type: 'array',
                        items: { type: 'string' },
                        description: 'Main points to cover'
                      },
                      estimatedReadingTime: {
                        type: 'number',
                        description: 'Estimated reading time in minutes'
                      },
                      suggestedTags: {
                        type: 'array',
                        items: { type: 'string' },
                        description: 'Relevant tags for the post'
                      }
                    }
                  }
                }
              },
              required: ['ideas']
            }
          }
        }],
        tool_choice: {
          type: 'function',
          function: { name: 'generateBlogIdeas' }
        }
      });

      const result = completion.choices[0]?.message?.tool_calls?.[0]?.function?.arguments;
      return result ? JSON.parse(result).ideas : [];
    } catch (error) {
      console.error('Error generating blog ideas:', error);
      throw error;
    }
  },

  async generateBlogOutline(topic: string): Promise<BlogPostOutline | undefined> {
    try {
      const openai = getOpenAIClient();
      const completion = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an expert content writer specializing in executive career development.'
          },
          {
            role: 'user',
            content: `Create a detailed outline for a blog post about ${topic}.`
          }
        ],
        tools: [{
          type: 'function',
          function: {
            name: 'generateBlogOutline',
            description: 'Generates a detailed blog post outline',
            parameters: {
              type: 'object',
              properties: {
                title: {
                  type: 'string',
                  description: 'Blog post title'
                },
                introduction: {
                  type: 'string',
                  description: 'Engaging introduction paragraph'
                },
                sections: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      heading: {
                        type: 'string',
                        description: 'Section heading'
                      },
                      content: {
                        type: 'array',
                        items: { type: 'string' },
                        description: 'Key points for the section'
                      },
                      keyTakeaway: {
                        type: 'string',
                        description: 'Main takeaway from this section'
                      }
                    }
                  }
                },
                conclusion: {
                  type: 'string',
                  description: 'Concluding paragraph'
                },
                callToAction: {
                  type: 'string',
                  description: 'Engaging call to action'
                }
              },
              required: ['title', 'introduction', 'sections', 'conclusion', 'callToAction']
            }
          }
        }],
        tool_choice: {
          type: 'function',
          function: { name: 'generateBlogOutline' }
        }
      });

      const result = completion.choices[0]?.message?.tool_calls?.[0]?.function?.arguments;
      return result ? JSON.parse(result) : undefined;
    } catch (error) {
      console.error('Error generating blog outline:', error);
      throw error;
    }
  },

  async generateSEOMetadata(content: string): Promise<BlogPostSEO | undefined> {
    try {
      const openai = getOpenAIClient();
      const completion = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an SEO expert specializing in executive career content.'
          },
          {
            role: 'user',
            content: `Generate SEO metadata for a blog post with content: ${content.substring(0, 500)}...`
          }
        ],
        tools: [{
          type: 'function',
          function: {
            name: 'generateSEOMetadata',
            description: 'Generates SEO metadata for a blog post',
            parameters: {
              type: 'object',
              properties: {
                title: {
                  type: 'string',
                  description: 'SEO-optimized title'
                },
                description: {
                  type: 'string',
                  description: 'Meta description for search engines'
                },
                keywords: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Relevant keywords'
                },
                socialMediaDescription: {
                  type: 'string',
                  description: 'Description optimized for social sharing'
                }
              },
              required: ['title', 'description', 'keywords', 'socialMediaDescription']
            }
          }
        }],
        tool_choice: {
          type: 'function',
          function: { name: 'generateSEOMetadata' }
        }
      });

      const result = completion.choices[0]?.message?.tool_calls?.[0]?.function?.arguments;
      return result ? JSON.parse(result) : undefined;
    } catch (error) {
      console.error('Error generating SEO metadata:', error);
      throw error;
    }
  }
};
