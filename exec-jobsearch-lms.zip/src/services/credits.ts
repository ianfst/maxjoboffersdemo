import { SubscriptionStatus } from '../types/payment';

export interface CreditCheck {
  canProceed: boolean;
  reason?: string;
  creditsRequired: number;
  creditsRemaining: number;
}

export interface CreditCost {
  blogIdeas: number;
  blogOutline: number;
  seoMetadata: number;
  imageGeneration: number;
}

export const AI_CREDIT_COSTS: CreditCost = {
  blogIdeas: 1,
  blogOutline: 2,
  seoMetadata: 1,
  imageGeneration: 2,
};

export const creditService = {
  async checkCredits(
    userId: string,
    operation: keyof CreditCost
  ): Promise<CreditCheck> {
    try {
      // Get user's current credits and subscription status
      const response = await fetch(`/api/users/${userId}/credits`);
      const { credits, subscriptionStatus } = await response.json();

      const creditsRequired = AI_CREDIT_COSTS[operation];
      const hasUnlimitedCredits = subscriptionStatus === SubscriptionStatus.Active;
      const hasEnoughCredits = credits >= creditsRequired;

      if (hasUnlimitedCredits) {
        return {
          canProceed: true,
          creditsRequired,
          creditsRemaining: -1,
        };
      }

      if (!hasEnoughCredits) {
        return {
          canProceed: false,
          reason: 'Insufficient credits',
          creditsRequired,
          creditsRemaining: credits,
        };
      }

      return {
        canProceed: true,
        creditsRequired,
        creditsRemaining: credits,
      };
    } catch (error) {
      console.error('Error checking credits:', error);
      return {
        canProceed: false,
        reason: 'Error checking credits',
        creditsRequired: AI_CREDIT_COSTS[operation],
        creditsRemaining: 0,
      };
    }
  },

  async useCredits(
    userId: string,
    operation: keyof CreditCost
  ): Promise<boolean> {
    try {
      const creditCheck = await this.checkCredits(userId, operation);
      if (!creditCheck.canProceed) {
        return false;
      }

      // Deduct credits
      const response = await fetch(`/api/users/${userId}/credits/use`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: AI_CREDIT_COSTS[operation],
          operation,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to use credits');
      }

      return true;
    } catch (error) {
      console.error('Error using credits:', error);
      return false;
    }
  },

  async getCreditHistory(userId: string): Promise<{
    operation: string;
    amount: number;
    timestamp: string;
  }[]> {
    try {
      const response = await fetch(`/api/users/${userId}/credits/history`);
      return await response.json();
    } catch (error) {
      console.error('Error getting credit history:', error);
      return [];
    }
  },
};
