import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

export interface FileUploadProgress {
  percent: number;
  loaded: number;
  total: number;
}

export interface FileUploadError {
  message: string;
  code: string;
}

export const ALLOWED_IMAGE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp',
];

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

const s3Client = new S3Client({
  region: process.env.AWS_REGION || 'us-west-2',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
  },
});

export const fileUploadService = {
  validateFile(file: File): FileUploadError | null {
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      return {
        message: 'Invalid file type. Please upload an image (JPEG, PNG, GIF, or WebP).',
        code: 'INVALID_TYPE',
      };
    }

    if (file.size > MAX_FILE_SIZE) {
      return {
        message: 'File is too large. Maximum size is 5MB.',
        code: 'FILE_TOO_LARGE',
      };
    }

    return null;
  },

  async uploadFile(
    file: File,
    onProgress?: (progress: FileUploadProgress) => void
  ): Promise<string> {
    const error = this.validateFile(file);
    if (error) {
      throw error;
    }

    const key = `blog-images/${Date.now()}-${file.name}`;
    const command = new PutObjectCommand({
      Bucket: process.env.AWS_S3_BUCKET || '',
      Key: key,
      Body: file,
      ContentType: file.type,
    });

    try {
      await s3Client.send(command);
      return key;
    } catch (error) {
      console.error('Error uploading file:', error);
      throw {
        message: 'Failed to upload file',
        code: 'UPLOAD_FAILED',
      };
    }
  },

  async getDownloadUrl(key: string): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: process.env.AWS_S3_BUCKET || '',
      Key: key,
    });

    try {
      return await getSignedUrl(s3Client, command, { expiresIn: 3600 });
    } catch (error) {
      console.error('Error generating download URL:', error);
      throw {
        message: 'Failed to generate download URL',
        code: 'URL_GENERATION_FAILED',
      };
    }
  },

  async uploadBlogImage(
    file: File,
    onProgress?: (progress: FileUploadProgress) => void
  ): Promise<{ url: string; key: string }> {
    const key = await this.uploadFile(file, onProgress);
    const url = await this.getDownloadUrl(key);
    return { url, key };
  },
};
