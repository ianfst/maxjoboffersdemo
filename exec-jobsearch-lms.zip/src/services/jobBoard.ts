import { Job, Resume, ResumeOptimizationRequest, ApplicationStatus } from '../types/jobApplication';

const API_BASE = '/api';

export const jobBoardService = {
  async searchJobs(query: string, filters: {
    level?: string[],
    type?: string[],
    location?: string,
    salary?: { min?: number, max?: number }
  }): Promise<Job[]> {
    const params = new URLSearchParams();
    params.set('query', query);
    if (filters.level?.length) params.set('level', filters.level.join(','));
    if (filters.type?.length) params.set('type', filters.type.join(','));
    if (filters.location) params.set('location', filters.location);
    if (filters.salary?.min) params.set('minSalary', filters.salary.min.toString());
    if (filters.salary?.max) params.set('maxSalary', filters.salary.max.toString());

    const response = await fetch(`${API_BASE}/jobs/search?${params}`);
    if (!response.ok) throw new Error('Failed to search jobs');
    return response.json();
  },

  async saveJob(jobId: string): Promise<ApplicationStatus> {
    const response = await fetch(`${API_BASE}/jobs/${jobId}/save`, {
      method: 'POST'
    });
    if (!response.ok) throw new Error('Failed to save job');
    return response.json();
  },

  async getBaseResumes(): Promise<Resume[]> {
    const response = await fetch(`${API_BASE}/resumes/base`);
    if (!response.ok) throw new Error('Failed to fetch base resumes');
    return response.json();
  },

  async optimizeResume(request: ResumeOptimizationRequest): Promise<Resume> {
    const response = await fetch(`${API_BASE}/resumes/optimize`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });
    if (!response.ok) throw new Error('Failed to optimize resume');
    return response.json();
  },

  async updateApplicationStatus(jobId: string, status: Partial<ApplicationStatus>): Promise<ApplicationStatus> {
    const response = await fetch(`${API_BASE}/jobs/${jobId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(status)
    });
    if (!response.ok) throw new Error('Failed to update application status');
    return response.json();
  }
};
