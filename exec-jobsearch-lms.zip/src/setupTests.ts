import '@testing-library/jest-dom';

// Add TextEncoder polyfill
const { TextEncoder, TextDecoder } = require('util');
global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

// Add Response polyfill
const { Response, Request, Headers } = require('whatwg-fetch');
global.Response = Response;
global.Request = Request;
global.Headers = Headers;

// Add BroadcastChannel polyfill
class MockBroadcastChannel {
  constructor(channel) {
    this.channel = channel;
  }
  postMessage() {}
  close() {}
  addEventListener() {}
  removeEventListener() {}
}
global.BroadcastChannel = MockBroadcastChannel;
