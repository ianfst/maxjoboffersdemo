export const mockDashboardData = {
  user: {
    name: "John Doe",
    avatar: "https://ui-avatars.com/api/?name=John+Doe",
    membershipTier: "platinum",
    role: "Software Engineer"
  },
  careerProgress: {
    goalsCompleted: 7,
    totalGoals: 10,
    nextMilestone: "Complete ATS optimization",
    metrics: {
      resumesCreated: 3,
      connectionsBuilt: 25,
      interviewsPracticed: 5
    }
  },
  networking: {
    activeConnections: 45,
    pendingOutreach: 8,
    upcomingEvents: [
      {
        title: "Tech Leadership Networking",
        date: "2025-03-20",
        type: "networking",
        participants: 50
      },
      {
        title: "Resume Workshop",
        date: "2025-03-25",
        type: "workshop",
        participants: 30
      }
    ]
  },
  resumeProgress: {
    activeVersions: 2,
    lastOptimized: "2025-03-10",
    atsScore: 85,
    improvementSuggestions: [
      "Add more quantifiable achievements",
      "Optimize keywords for tech industry"
    ],
    targetCompanies: [
      {
        name: "TechCorp",
        matchScore: 85,
        keyRequirements: ["React", "TypeScript", "AWS"]
      },
      {
        name: "InnovateSoft",
        matchScore: 78,
        keyRequirements: ["Node.js", "Python", "Docker"]
      }
    ]
  },
  coaching: {
    upcomingSessions: [
      {
        coachName: "Sarah Wilson",
        date: "2025-03-18",
        focus: "Interview Preparation",
        duration: 60
      }
    ],
    completedSessions: 4,
    nextMilestone: "Mock Interview Practice"
  },
  resources: {
    recentResources: [
      {
        title: "Negotiation Strategies",
        type: "video",
        category: "Career Growth",
        accessed: "2025-03-12"
      },
      {
        title: "Resume Templates",
        type: "template",
        category: "Job Search",
        accessed: "2025-03-13"
      }
    ],
    recommendedContent: [
      {
        title: "Leadership in Tech",
        relevanceScore: 95,
        type: "article"
      },
      {
        title: "Advanced System Design",
        relevanceScore: 88,
        type: "video"
      }
    ]
  }
};
