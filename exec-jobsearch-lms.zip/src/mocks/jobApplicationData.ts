import { Job, Resume, InterviewPrepSession } from '../types/jobApplication';

export const mockJobs: Job[] = [
  {
    id: "1",
    title: "Chief Technology Officer",
    company: "TechVision Enterprises",
    location: "San Francisco, CA",
    description: "Leading technology strategy and digital transformation initiatives for a rapidly growing SaaS company.",
    requirements: [
      "15+ years of technology leadership experience",
      "Track record of successful digital transformation",
      "Strong background in cloud architecture and cybersecurity",
      "Experience with AI/ML implementation"
    ],
    responsibilities: [
      "Define and execute technology strategy",
      "Lead a team of 100+ engineers",
      "Drive innovation and digital transformation",
      "Manage technology budget and vendor relationships"
    ],
    salary: {
      min: 250000,
      max: 400000,
      currency: "USD"
    },
    type: "full-time",
    level: "executive",
    postDate: "2025-03-01",
    source: "LinkedIn",
    applicationUrl: "https://techvision.com/careers/cto"
  },
  {
    id: "2",
    title: "VP of Engineering",
    company: "InnovateTech Solutions",
    location: "Remote (US)",
    description: "Leading engineering teams and driving technical excellence in a high-growth startup environment.",
    requirements: [
      "10+ years of engineering leadership",
      "Experience scaling engineering teams",
      "Strong system design background",
      "Startup experience preferred"
    ],
    responsibilities: [
      "Build and lead engineering teams",
      "Define technical roadmap",
      "Establish engineering best practices",
      "Drive technical innovation"
    ],
    type: "full-time",
    level: "executive",
    postDate: "2025-03-10",
    source: "Indeed"
  }
];

export const mockBaseResumes: Resume[] = [
  {
    id: "1",
    title: "Technology Executive Resume",
    content: "Experienced technology leader with a track record of driving digital transformation...",
    targetRole: "CTO/VP Engineering",
    lastModified: "2025-02-15",
    atsScore: 85,
    keywords: ["digital transformation", "technology leadership", "innovation"],
    isBase: true
  },
  {
    id: "2",
    title: "Product Leadership Resume",
    content: "Product-focused technology executive with experience in scaling SaaS platforms...",
    targetRole: "VP Product/CPO",
    lastModified: "2025-02-20",
    atsScore: 82,
    keywords: ["product strategy", "SaaS", "leadership"],
    isBase: true
  }
];

export const mockInterviewSessions: InterviewPrepSession[] = [
  {
    id: "1",
    jobId: "1",
    type: "leadership",
    questions: [
      {
        id: "1",
        question: "How do you approach digital transformation in a large organization?",
        category: "leadership",
        sampleAnswer: "I follow a systematic approach that begins with assessing current technology landscape..."
      },
      {
        id: "2",
        question: "Describe a situation where you had to make a difficult technical decision that impacted business strategy.",
        category: "leadership",
        sampleAnswer: "In my previous role, we faced a critical decision regarding our cloud infrastructure..."
      }
    ],
    completed: false
  },
  {
    id: "2",
    jobId: "1",
    type: "technical",
    questions: [
      {
        id: "3",
        question: "How would you design a system architecture for a global SaaS platform?",
        category: "technical",
        sampleAnswer: "The architecture would need to consider several key factors..."
      },
      {
        id: "4",
        question: "What's your approach to implementing AI/ML in enterprise applications?",
        category: "technical",
        sampleAnswer: "My approach to AI/ML implementation follows these key steps..."
      }
    ],
    completed: false
  }
];
