import { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  SelectChangeEvent,
} from '@mui/material';
import api from '../../api/config';

interface ProfileFormProps {
  initialData: any;
  onSubmit: (data: any) => void;
}

const ProfileForm = ({ initialData, onSubmit }: ProfileFormProps) => {
  const [formData, setFormData] = useState({
    currentRole: initialData.currentRole || '',
    yearsOfExperience: initialData.yearsOfExperience || '',
    industry: initialData.industry || '',
    location: initialData.location || '',
    linkedinUrl: initialData.linkedinUrl || '',
    bio: initialData.bio || '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    // Clear error when field is edited
    if (errors[e.target.name]) {
      setErrors(prev => ({
        ...prev,
        [e.target.name]: ''
      }));
    }
  };

  const handleSelectChange = (e: SelectChangeEvent) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    // Clear error when field is edited
    if (errors[e.target.name]) {
      setErrors(prev => ({
        ...prev,
        [e.target.name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.currentRole) {
      newErrors.currentRole = 'Current role is required';
    }
    if (!formData.yearsOfExperience) {
      newErrors.yearsOfExperience = 'Years of experience is required';
    }
    if (!formData.industry) {
      newErrors.industry = 'Industry is required';
    }
    if (!formData.location) {
      newErrors.location = 'Location is required';
    }
    if (formData.linkedinUrl && !formData.linkedinUrl.includes('linkedin.com')) {
      newErrors.linkedinUrl = 'Please enter a valid LinkedIn URL';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      // Update profile in backend
      await api.post('/api/user/profile', formData);
      onSubmit(formData);
    } catch (error) {
      console.error('Error updating profile:', error);
      // Handle error appropriately
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Typography variant="h6" gutterBottom>
        Tell us about your professional background
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Current Role"
            name="currentRole"
            value={formData.currentRole}
            onChange={handleInputChange}
            error={!!errors.currentRole}
            helperText={errors.currentRole}
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Years of Experience"
            name="yearsOfExperience"
            type="number"
            value={formData.yearsOfExperience}
            onChange={handleInputChange}
            error={!!errors.yearsOfExperience}
            helperText={errors.yearsOfExperience}
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <FormControl fullWidth required error={!!errors.industry}>
            <InputLabel>Industry</InputLabel>
            <Select
              name="industry"
              value={formData.industry}
              onChange={handleSelectChange}
              label="Industry"
            >
              <MenuItem value="technology">Technology</MenuItem>
              <MenuItem value="finance">Finance</MenuItem>
              <MenuItem value="healthcare">Healthcare</MenuItem>
              <MenuItem value="manufacturing">Manufacturing</MenuItem>
              <MenuItem value="retail">Retail</MenuItem>
              <MenuItem value="consulting">Consulting</MenuItem>
              <MenuItem value="other">Other</MenuItem>
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Location"
            name="location"
            value={formData.location}
            onChange={handleInputChange}
            error={!!errors.location}
            helperText={errors.location}
            required
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="LinkedIn Profile URL"
            name="linkedinUrl"
            value={formData.linkedinUrl}
            onChange={handleInputChange}
            error={!!errors.linkedinUrl}
            helperText={errors.linkedinUrl}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Professional Bio"
            name="bio"
            multiline
            rows={4}
            value={formData.bio}
            onChange={handleInputChange}
            placeholder="Tell us about your professional journey and what you hope to achieve..."
          />
        </Grid>
      </Grid>

      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          size="large"
        >
          Continue
        </Button>
      </Box>
    </Box>
  );
};

export default ProfileForm;
