import { useState } from 'react';
import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  Grid,
  TextField,
  Typography,
  Slider,
  Stack,
} from '@mui/material';
import api from '../../api/config';

interface CareerGoalsFormProps {
  initialData: any;
  onSubmit: (data: any) => void;
  onBack: () => void;
}

const CareerGoalsForm = ({ initialData, onSubmit, onBack }: CareerGoalsFormProps) => {
  const [formData, setFormData] = useState({
    targetRole: initialData.targetRole || '',
    targetIndustry: initialData.targetIndustry || '',
    timeframe: initialData.timeframe || 6,
    goals: initialData.goals || {
      roleTransition: false,
      salaryIncrease: false,
      skillDevelopment: false,
      leadershipGrowth: false,
      networkExpansion: false,
    },
    desiredSalary: initialData.desiredSalary || '',
    challenges: initialData.challenges || '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, checked, type } = e.target;
    
    if (type === 'checkbox') {
      setFormData(prev => ({
        ...prev,
        goals: {
          ...prev.goals,
          [name]: checked
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleTimeframeChange = (_: Event, newValue: number | number[]) => {
    setFormData(prev => ({
      ...prev,
      timeframe: newValue as number
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // Update career goals in backend
      await api.post('/api/user/career-goals', formData);
      onSubmit(formData);
    } catch (error) {
      console.error('Error updating career goals:', error);
      // Handle error appropriately
    }
  };

  const timeframeMarks = [
    { value: 3, label: '3 months' },
    { value: 6, label: '6 months' },
    { value: 12, label: '1 year' },
    { value: 24, label: '2 years' },
  ];

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Typography variant="h6" gutterBottom>
        Set Your Career Goals
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Target Role"
            name="targetRole"
            value={formData.targetRole}
            onChange={handleChange}
            required
            placeholder="e.g., Chief Technology Officer, VP of Operations"
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Target Industry"
            name="targetIndustry"
            value={formData.targetIndustry}
            onChange={handleChange}
            required
            placeholder="e.g., Technology, Healthcare, Finance"
          />
        </Grid>

        <Grid item xs={12}>
          <FormControl component="fieldset" fullWidth>
            <FormLabel component="legend">Career Goals</FormLabel>
            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.goals.roleTransition}
                    onChange={handleChange}
                    name="roleTransition"
                  />
                }
                label="Transition to a new role"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.goals.salaryIncrease}
                    onChange={handleChange}
                    name="salaryIncrease"
                  />
                }
                label="Increase salary"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.goals.skillDevelopment}
                    onChange={handleChange}
                    name="skillDevelopment"
                  />
                }
                label="Develop new skills"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.goals.leadershipGrowth}
                    onChange={handleChange}
                    name="leadershipGrowth"
                  />
                }
                label="Grow leadership capabilities"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.goals.networkExpansion}
                    onChange={handleChange}
                    name="networkExpansion"
                  />
                }
                label="Expand professional network"
              />
            </FormGroup>
          </FormControl>
        </Grid>

        <Grid item xs={12}>
          <Typography gutterBottom>Target Timeframe</Typography>
          <Slider
            value={formData.timeframe}
            onChange={handleTimeframeChange}
            min={3}
            max={24}
            step={null}
            marks={timeframeMarks}
            valueLabelDisplay="auto"
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Desired Salary Range"
            name="desiredSalary"
            value={formData.desiredSalary}
            onChange={handleChange}
            placeholder="e.g., $150,000 - $200,000"
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Current Career Challenges"
            name="challenges"
            multiline
            rows={4}
            value={formData.challenges}
            onChange={handleChange}
            placeholder="What are the main challenges you're facing in reaching your career goals?"
          />
        </Grid>
      </Grid>

      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
        <Button
          onClick={onBack}
          variant="outlined"
        >
          Back
        </Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
        >
          Continue
        </Button>
      </Box>
    </Box>
  );
};

export default CareerGoalsForm;
