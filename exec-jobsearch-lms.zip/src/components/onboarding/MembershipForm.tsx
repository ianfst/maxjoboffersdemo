import { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Grid,
  Typography,
  Radio,
  RadioGroup,
  FormControlLabel,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import api from '../../api/config';

interface MembershipFormProps {
  initialData: any;
  onSubmit: (data: any) => void;
  onBack: () => void;
}

const membershipTiers = {
  standard: {
    name: 'Standard',
    price: 99,
    features: [
      'Access to basic job search resources',
      'Weekly group coaching sessions',
      'Resume review',
      'Basic networking opportunities',
    ],
  },
  premium: {
    name: 'Premium',
    price: 199,
    features: [
      'All Standard features',
      'One-on-one coaching sessions',
      'Advanced career planning',
      'Priority support',
      'Industry-specific networking events',
    ],
  },
  platinum: {
    name: 'Platinum',
    price: 499,
    features: [
      'All Premium features',
      'Executive mentor matching',
      'Personalized career roadmap',
      'Board position opportunities',
      'Executive networking events',
      'Lifetime access to resources',
    ],
  },
};

const MembershipForm = ({ initialData, onSubmit, onBack }: MembershipFormProps) => {
  const [selectedTier, setSelectedTier] = useState(initialData.tier || 'standard');

  const handleTierChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedTier(event.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // Update membership selection in backend
      await api.post('/api/user/membership', { tier: selectedTier });
      onSubmit({ tier: selectedTier });
    } catch (error) {
      console.error('Error updating membership:', error);
      // Handle error appropriately
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Typography variant="h6" gutterBottom>
        Choose Your Membership Plan
      </Typography>

      <Typography variant="body1" color="text.secondary" paragraph>
        Select the membership tier that best fits your career goals and needs.
      </Typography>

      <RadioGroup
        value={selectedTier}
        onChange={handleTierChange}
      >
        <Grid container spacing={3}>
          {Object.entries(membershipTiers).map(([tier, details]) => (
            <Grid item xs={12} md={4} key={tier}>
              <Card 
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  border: selectedTier === tier ? 2 : 1,
                  borderColor: selectedTier === tier ? 'primary.main' : 'grey.300',
                }}
              >
                <CardHeader
                  title={details.name}
                  titleTypography={{ variant: 'h6' }}
                  sx={{
                    bgcolor: selectedTier === tier ? 'primary.light' : 'grey.100',
                    color: selectedTier === tier ? 'primary.main' : 'text.primary',
                  }}
                />
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography variant="h4" color="primary" gutterBottom>
                    ${details.price}
                    <Typography component="span" variant="body2" color="text.secondary">
                      /month
                    </Typography>
                  </Typography>

                  <Divider sx={{ my: 2 }} />

                  <List dense>
                    {details.features.map((feature, index) => (
                      <ListItem key={index} disableGutters>
                        <ListItemIcon sx={{ minWidth: 36 }}>
                          <CheckCircleOutlineIcon color="primary" fontSize="small" />
                        </ListItemIcon>
                        <ListItemText primary={feature} />
                      </ListItem>
                    ))}
                  </List>

                  <FormControlLabel
                    value={tier}
                    control={<Radio />}
                    label="Select Plan"
                    sx={{ mt: 2 }}
                  />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </RadioGroup>

      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
        <Button
          onClick={onBack}
          variant="outlined"
        >
          Back
        </Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
        >
          Continue
        </Button>
      </Box>
    </Box>
  );
};

export default MembershipForm;
