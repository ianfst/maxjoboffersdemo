import { useState } from 'react';
import {
  Box,
  Button,
  Grid,
  TextField,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  SelectChangeEvent,
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import api from '../../api/config';

interface FinancialVerificationFormProps {
  initialData: any;
  onSubmit: (data: any) => void;
  onBack: () => void;
  showForm: boolean;
}

const FinancialVerificationForm = ({
  initialData,
  onSubmit,
  onBack,
  showForm,
}: FinancialVerificationFormProps) => {
  const [formData, setFormData] = useState({
    currentSalary: initialData.currentSalary || '',
    companyName: initialData.companyName || '',
    employmentStartDate: initialData.employmentStartDate || null,
    employmentType: initialData.employmentType || '',
    documentType: initialData.documentType || '',
    documentFile: null as File | null,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSelectChange = (e: SelectChangeEvent) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({
        ...prev,
        documentFile: e.target.files![0]
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const formDataToSend = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        if (value !== null) {
          formDataToSend.append(key, value);
        }
      });

      await api.post('/api/user/financial-verification', formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setSuccess(true);
      onSubmit(formData);
    } catch (error) {
      console.error('Error submitting financial verification:', error);
      setError('Failed to submit financial verification. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!showForm) {
    return (
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Typography variant="h6" gutterBottom>
          Financial Verification Not Required
        </Typography>
        <Typography color="text.secondary" paragraph>
          Your selected membership tier does not require financial verification.
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={() => onSubmit({})}
        >
          Continue
        </Button>
      </Box>
    );
  }

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Typography variant="h6" gutterBottom>
        Financial Verification
      </Typography>

      <Typography color="text.secondary" paragraph>
        To ensure eligibility for the Platinum tier, please provide your employment and income details.
        All information will be kept strictly confidential.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Financial verification submitted successfully!
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Current Annual Salary"
            name="currentSalary"
            type="number"
            value={formData.currentSalary}
            onChange={handleInputChange}
            required
            InputProps={{
              startAdornment: <Typography>$</Typography>,
            }}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Company Name"
            name="companyName"
            value={formData.companyName}
            onChange={handleInputChange}
            required
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePicker
              label="Employment Start Date"
              value={formData.employmentStartDate}
              onChange={(newValue) => {
                setFormData(prev => ({
                  ...prev,
                  employmentStartDate: newValue
                }));
              }}
              slotProps={{
                textField: {
                  fullWidth: true,
                  required: true,
                }
              }}
            />
          </LocalizationProvider>
        </Grid>

        <Grid item xs={12} sm={6}>
          <FormControl fullWidth required>
            <InputLabel>Employment Type</InputLabel>
            <Select
              name="employmentType"
              value={formData.employmentType}
              onChange={handleSelectChange}
              label="Employment Type"
            >
              <MenuItem value="full-time">Full-time</MenuItem>
              <MenuItem value="part-time">Part-time</MenuItem>
              <MenuItem value="contract">Contract</MenuItem>
              <MenuItem value="self-employed">Self-employed</MenuItem>
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12}>
          <FormControl fullWidth required>
            <InputLabel>Document Type</InputLabel>
            <Select
              name="documentType"
              value={formData.documentType}
              onChange={handleSelectChange}
              label="Document Type"
            >
              <MenuItem value="pay-stub">Recent Pay Stub</MenuItem>
              <MenuItem value="w2">W-2</MenuItem>
              <MenuItem value="tax-return">Tax Return</MenuItem>
              <MenuItem value="offer-letter">Offer Letter</MenuItem>
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12}>
          <Button
            variant="outlined"
            component="label"
            fullWidth
          >
            Upload Verification Document
            <input
              type="file"
              hidden
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileChange}
              required
            />
          </Button>
          {formData.documentFile && (
            <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 1 }}>
              Selected file: {formData.documentFile.name}
            </Typography>
          )}
        </Grid>
      </Grid>

      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between' }}>
        <Button
          onClick={onBack}
          variant="outlined"
          disabled={loading}
        >
          Back
        </Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          disabled={loading}
        >
          {loading ? <CircularProgress size={24} /> : 'Complete'}
        </Button>
      </Box>
    </Box>
  );
};

export default FinancialVerificationForm;
