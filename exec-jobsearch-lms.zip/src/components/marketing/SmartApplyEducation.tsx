import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Button,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  useTheme
} from '@mui/material';
import {
  Warning,
  CheckCircle,
  Block,
  TrendingDown,
  Psychology,
  Speed,
  Insights,
  PersonalVideo,
  AutoAwesome
} from '@mui/icons-material';

export const SmartApplyEducation: React.FC = () => {
  const theme = useTheme();

  const autoApplyRisks = [
    {
      icon: <Block color="error" />,
      title: "Account Bans",
      description: "Job boards actively detect and ban automated applications, potentially blocking your access permanently."
    },
    {
      icon: <TrendingDown color="error" />,
      title: "Lower Success Rate",
      description: "Generic, non-tailored applications are easily spotted and rejected by both ATS systems and recruiters."
    },
    {
      icon: <Warning color="error" />,
      title: "Missed Opportunities",
      description: "Auto-appliers skip crucial customization opportunities that could make your application stand out."
    },
    {
      icon: <Psychology color="error" />,
      title: "Wrong Fit Applications",
      description: "Bulk applying leads to matches with jobs that don't align with your skills or career goals."
    }
  ];

  const smartApplyBenefits = [
    {
      icon: <Speed color="primary" />,
      title: "Intelligent Matching",
      description: "Our AI analyzes job requirements and scores your fit before you invest time in applying."
    },
    {
      icon: <Insights color="primary" />,
      title: "Strategic Customization",
      description: "Automatically tailor your resume and cover letter to highlight relevant skills and experience."
    },
    {
      icon: <PersonalVideo color="primary" />,
      title: "ATS Optimization",
      description: "Ensure your application passes Applicant Tracking Systems with our smart formatting tools."
    },
    {
      icon: <AutoAwesome color="primary" />,
      title: "Quality Applications",
      description: "Submit thoughtful, well-crafted applications that demonstrate genuine interest and fit."
    }
  ];

  return (
    <Box sx={{ py: 6, px: 2, maxWidth: 1200, mx: 'auto' }}>
      <Typography 
        variant="h3" 
        align="center" 
        gutterBottom
        sx={{ 
          fontWeight: 'bold',
          mb: 4
        }}
      >
        Why Smart Apply Beats Auto-Apply
      </Typography>

      <Grid container spacing={4}>
        {/* Warning Section */}
        <Grid item xs={12} md={6}>
          <Card 
            sx={{ 
              height: '100%',
              backgroundColor: theme.palette.error.light,
              color: theme.palette.error.contrastText
            }}
          >
            <CardContent>
              <Typography 
                variant="h5" 
                gutterBottom
                sx={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1,
                  color: theme.palette.error.dark
                }}
              >
                <Warning />
                The Hidden Costs of Auto-Appliers
              </Typography>
              
              <List>
                {autoApplyRisks.map((risk, index) => (
                  <ListItem key={index}>
                    <ListItemIcon sx={{ color: theme.palette.error.dark }}>
                      {risk.icon}
                    </ListItemIcon>
                    <ListItemText 
                      primary={risk.title}
                      secondary={risk.description}
                      secondaryTypographyProps={{
                        sx: { color: theme.palette.error.dark }
                      }}
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Smart Apply Benefits */}
        <Grid item xs={12} md={6}>
          <Card 
            sx={{ 
              height: '100%',
              backgroundColor: theme.palette.primary.light,
              color: theme.palette.primary.contrastText
            }}
          >
            <CardContent>
              <Typography 
                variant="h5" 
                gutterBottom
                sx={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1,
                  color: theme.palette.primary.dark
                }}
              >
                <CheckCircle />
                The Smart Apply Advantage
              </Typography>
              
              <List>
                {smartApplyBenefits.map((benefit, index) => (
                  <ListItem key={index}>
                    <ListItemIcon sx={{ color: theme.palette.primary.dark }}>
                      {benefit.icon}
                    </ListItemIcon>
                    <ListItemText 
                      primary={benefit.title}
                      secondary={benefit.description}
                      secondaryTypographyProps={{
                        sx: { color: theme.palette.primary.dark }
                      }}
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Statistics Section */}
      <Box sx={{ mt: 6, mb: 4 }}>
        <Typography variant="h5" align="center" gutterBottom>
          The Numbers Don't Lie
        </Typography>
        <Grid container spacing={3} sx={{ mt: 2 }}>
          <Grid item xs={12} sm={4}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h3" color="error">
                  85%
                </Typography>
                <Typography variant="body1">
                  of auto-applied applications are rejected without review
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h3" color="primary">
                  3x
                </Typography>
                <Typography variant="body1">
                  higher interview rate with Smart Apply
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h3" color="success.main">
                  92%
                </Typography>
                <Typography variant="body1">
                  ATS pass rate with our optimization
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>

      {/* Call to Action */}
      <Box 
        sx={{ 
          textAlign: 'center',
          mt: 6,
          p: 4,
          backgroundColor: theme.palette.background.paper,
          borderRadius: 2
        }}
      >
        <Typography variant="h4" gutterBottom>
          Ready to Apply Smarter?
        </Typography>
        <Typography variant="body1" sx={{ mb: 3 }}>
          Stop wasting time with automated rejections. Start getting real results with Smart Apply.
        </Typography>
        <Button 
          variant="contained" 
          size="large"
          href="/smart-apply-demo"
          sx={{ 
            px: 4,
            py: 1.5,
            fontSize: '1.1rem'
          }}
        >
          Try Smart Apply Now
        </Button>
      </Box>
    </Box>
  );
};
