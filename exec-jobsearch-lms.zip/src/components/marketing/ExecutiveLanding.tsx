import React from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Divider,
  useTheme,
  alpha,
  Paper,
} from '@mui/material';
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
} from '@mui/lab';
import {
  TrendingUp,
  Psychology,
  BusinessCenter,
  People,
  TrackChanges,
  Visibility,
  VisibilityOff,
  Speed,
  Analytics,
  AutoGraph,
} from '@mui/icons-material';

export const ExecutiveLanding: React.FC = () => {
  const theme = useTheme();

  const marketStats = [
    {
      title: "Hidden Job Market",
      percentage: "80%",
      description: "of executive positions are never advertised",
      icon: <VisibilityOff fontSize="large" />,
      color: theme.palette.primary.main,
    },
    {
      title: "Visible Job Market",
      percentage: "20%",
      description: "of positions appear on job boards",
      icon: <Visibility fontSize="large" />,
      color: theme.palette.secondary.main,
    },
  ];

  const experienceHighlights = [
    {
      year: "18+",
      title: "Years of Excellence",
      description: "Guiding executives to their dream positions",
    },
    {
      year: "250K+",
      title: "Executives Placed",
      description: "Across Fortune 500 companies and startups",
    },
    {
      year: "92%",
      title: "Success Rate",
      description: "Landing preferred positions within 6 months",
    },
  ];

  const marketingPoints = [
    {
      icon: <Psychology color="primary" />,
      title: "AI-Powered Personal Branding",
      description: "Our advanced AI analyzes your experience and market trends to craft a compelling executive narrative that resonates with your target industry.",
    },
    {
      icon: <TrackChanges color="primary" />,
      title: "Hidden Market Access",
      description: "Tap into our exclusive network and AI-driven insights to uncover opportunities before they hit the market.",
    },
    {
      icon: <AutoGraph color="primary" />,
      title: "Strategic Career Positioning",
      description: "Leverage our deep industry knowledge to position yourself for roles that align with your career trajectory.",
    },
    {
      icon: <Analytics color="primary" />,
      title: "Data-Driven Approach",
      description: "Utilize real-time market analytics and industry insights to make informed career decisions.",
    },
  ];

  return (
    <Box sx={{ overflow: 'hidden' }}>
      {/* Hero Section */}
      <Box
        sx={{
          background: `linear-gradient(45deg, ${theme.palette.primary.main} 30%, ${theme.palette.primary.dark} 90%)`,
          color: 'white',
          py: 12,
          position: 'relative',
          '&::after': {
            content: '""',
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            height: '4rem',
            background: `linear-gradient(to top right, transparent 49%, white 51%)`,
          },
        }}
      >
        <Container maxWidth="lg">
          <Grid container spacing={6} alignItems="center">
            <Grid item xs={12} md={7}>
              <Typography variant="h1" sx={{ fontSize: { xs: '2.5rem', md: '3.5rem' }, mb: 2, fontWeight: 'bold' }}>
                Transform Your Executive Journey
              </Typography>
              <Typography variant="h5" sx={{ mb: 4, opacity: 0.9 }}>
                18 Years of Excellence in Executive Placement,
                Now Enhanced by Cutting-Edge Technology
              </Typography>
              <Button
                variant="contained"
                size="large"
                sx={{
                  backgroundColor: 'white',
                  color: theme.palette.primary.main,
                  '&:hover': {
                    backgroundColor: alpha(theme.palette.common.white, 0.9),
                  },
                  px: 4,
                  py: 1.5,
                }}
              >
                Start Your Journey
              </Button>
            </Grid>
            <Grid item xs={12} md={5}>
              <Box
                component="img"
                src="/assets/executive-success.png"
                alt="Executive Success"
                sx={{
                  width: '100%',
                  maxWidth: 500,
                  borderRadius: 2,
                  boxShadow: 3,
                }}
              />
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Experience Stats */}
      <Container maxWidth="lg" sx={{ mt: -8, position: 'relative', zIndex: 1 }}>
        <Grid container spacing={3}>
          {experienceHighlights.map((stat, index) => (
            <Grid item xs={12} md={4} key={index}>
              <Paper
                elevation={3}
                sx={{
                  p: 3,
                  textAlign: 'center',
                  height: '100%',
                  backgroundColor: 'white',
                }}
              >
                <Typography variant="h2" color="primary" sx={{ fontWeight: 'bold', mb: 1 }}>
                  {stat.year}
                </Typography>
                <Typography variant="h6" gutterBottom>
                  {stat.title}
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  {stat.description}
                </Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Market Breakdown */}
      <Container maxWidth="lg" sx={{ mt: 8 }}>
        <Typography variant="h3" align="center" gutterBottom sx={{ fontWeight: 'bold' }}>
          Mastering Both Markets
        </Typography>
        <Typography variant="h6" align="center" sx={{ mb: 6, color: 'text.secondary' }}>
          Our unique approach targets both visible and hidden job markets
        </Typography>
        <Grid container spacing={4}>
          {marketStats.map((stat, index) => (
            <Grid item xs={12} md={6} key={index}>
              <Card 
                sx={{ 
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  p: 4,
                  textAlign: 'center',
                  backgroundColor: alpha(stat.color, 0.05),
                }}
              >
                <Box sx={{ color: stat.color, mb: 2 }}>
                  {stat.icon}
                </Box>
                <Typography variant="h2" sx={{ color: stat.color, fontWeight: 'bold', mb: 1 }}>
                  {stat.percentage}
                </Typography>
                <Typography variant="h5" gutterBottom>
                  {stat.title}
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  {stat.description}
                </Typography>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Our Approach */}
      <Container maxWidth="lg" sx={{ mt: 12, mb: 8 }}>
        <Typography variant="h3" align="center" gutterBottom sx={{ fontWeight: 'bold' }}>
          The Executive Edge
        </Typography>
        <Typography variant="h6" align="center" sx={{ mb: 6, color: 'text.secondary' }}>
          Combining decades of executive placement expertise with cutting-edge technology
        </Typography>
        <Grid container spacing={4}>
          {marketingPoints.map((point, index) => (
            <Grid item xs={12} md={6} key={index}>
              <Card sx={{ height: '100%', p: 3 }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    {point.icon}
                    <Typography variant="h6" sx={{ ml: 2 }}>
                      {point.title}
                    </Typography>
                  </Box>
                  <Typography variant="body1" color="text.secondary">
                    {point.description}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Success Timeline */}
      <Box sx={{ bgcolor: 'background.default', py: 8 }}>
        <Container maxWidth="lg">
          <Typography variant="h3" align="center" gutterBottom sx={{ fontWeight: 'bold' }}>
            Your Path to Success
          </Typography>
          <Typography variant="h6" align="center" sx={{ mb: 6, color: 'text.secondary' }}>
            A proven process refined over 18 years of executive placement excellence
          </Typography>
          <Timeline position="alternate">
            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="primary">
                  <BusinessCenter />
                </TimelineDot>
                <TimelineConnector />
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="h6">Personal Brand Development</Typography>
                <Typography color="text.secondary">
                  AI-powered analysis of your experience and market positioning
                </Typography>
              </TimelineContent>
            </TimelineItem>
            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="primary">
                  <TrendingUp />
                </TimelineDot>
                <TimelineConnector />
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="h6">Market Opportunity Analysis</Typography>
                <Typography color="text.secondary">
                  Deep dive into both visible and hidden job markets
                </Typography>
              </TimelineContent>
            </TimelineItem>
            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="primary">
                  <People />
                </TimelineDot>
                <TimelineConnector />
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="h6">Network Activation</Typography>
                <Typography color="text.secondary">
                  Strategic networking and relationship building
                </Typography>
              </TimelineContent>
            </TimelineItem>
            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="primary">
                  <Speed />
                </TimelineDot>
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="h6">Position Acquisition</Typography>
                <Typography color="text.secondary">
                  Targeted approach to secure your ideal role
                </Typography>
              </TimelineContent>
            </TimelineItem>
          </Timeline>
        </Container>
      </Box>

      {/* Call to Action */}
      <Box
        sx={{
          bgcolor: theme.palette.primary.main,
          color: 'white',
          py: 8,
          textAlign: 'center',
        }}
      >
        <Container maxWidth="md">
          <Typography variant="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
            Ready to Transform Your Career?
          </Typography>
          <Typography variant="h6" sx={{ mb: 4, opacity: 0.9 }}>
            Join thousands of successful executives who have leveraged our expertise
          </Typography>
          <Button
            variant="contained"
            size="large"
            sx={{
              backgroundColor: 'white',
              color: theme.palette.primary.main,
              '&:hover': {
                backgroundColor: alpha(theme.palette.common.white, 0.9),
              },
              px: 6,
              py: 2,
              fontSize: '1.2rem',
            }}
          >
            Get Started Now
          </Button>
        </Container>
      </Box>
    </Box>
  );
};
