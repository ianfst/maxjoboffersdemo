import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  Chip,
  Skeleton,
} from '@mui/material';
import { format } from 'date-fns';
import { useQuery } from 'react-query';
import api from '../../api/config';

interface Webinar {
  id: number;
  title: string;
  description: string;
  datetime: string;
  registrationUrl: string;
}

export const WebinarList = () => {
  const { data: webinars, isLoading, error } = useQuery<Webinar[]>(
    'webinars',
    async () => {
      const response = await api.get('/api/webinars');
      return response.data;
    }
  );

  if (isLoading) {
    return (
      <Grid container spacing={2}>
        {[1, 2].map((i) => (
          <Grid item xs={12} md={6} key={i}>
            <Card>
              <CardContent>
                <Skeleton variant="text" width="20%" data-testid="skeleton" />
                <Skeleton variant="text" width="80%" height={40} data-testid="skeleton" />
                <Skeleton variant="text" width="60%" data-testid="skeleton" />
                <Skeleton variant="rectangular" width={100} height={36} data-testid="skeleton" />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    );
  }

  if (error) {
    return (
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Typography color="error">
          Unable to load webinars. Please try again later.
        </Typography>
      </Box>
    );
  }

  if (!webinars?.length) {
    return (
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Typography>No upcoming webinars at this time.</Typography>
      </Box>
    );
  }

  return (
    <Grid container spacing={2}>
      {webinars.map((webinar) => (
        <Grid item xs={12} md={6} key={webinar.id}>
          <Card>
            <CardContent>
              <Chip
                label={format(new Date(webinar.datetime), 'MMM d, yyyy')}
                color="primary"
                size="small"
                sx={{ mb: 1 }}
              />
              <Typography variant="h6" gutterBottom>
                {webinar.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                {webinar.description}
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Button
                  variant="contained"
                  color="primary"
                  href={webinar.registrationUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Register Now
                </Button>
                <Typography variant="caption" color="text.secondary">
                  {format(new Date(webinar.datetime), 'h:mm a')}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};
