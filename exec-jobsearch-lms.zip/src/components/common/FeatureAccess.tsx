import React from 'react';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import { Lock as LockIcon, Star as StarIcon } from '@mui/icons-material';
import { useUser } from '../../hooks/useUser';
import { useRouter } from 'next/router';
import { FeatureAccess as FeatureAccessType, FeatureKey } from '@/types/features';

interface FeatureAccessProps {
  feature: string;
  features: FeatureAccessType;
  children: React.ReactNode;
}

const featureToKey: Record<string, FeatureKey> = {
  'ai_tools': 'aiTools',
  'premium_content': 'premiumContent',
  'coaching': 'coaching',
  'done_for_you': 'doneForYou',
  'financial_planning': 'financialPlanning'
};

export const FeatureAccess: React.FC<FeatureAccessProps> = ({ feature, features, children }) => {
  const { user } = useUser();
  const router = useRouter();
  const [upgradeDialogOpen, setUpgradeDialogOpen] = React.useState(false);

  const getRequiredTier = (feature: string) => {
    const featureTiers: Record<string, string> = {
      ai_tools: 'premium',
      premium_content: 'premium',
      coaching: 'premium',
      done_for_you: 'platinum',
      financial_planning: 'platinum'
    };
    return featureTiers[feature] || 'free';
  };

  const featureKey = featureToKey[feature];
  const hasAccess = featureKey ? features[featureKey] : false;
  const requiredTier = getRequiredTier(feature);

  if (hasAccess) {
    return <>{children}</>;
  }

  const handleUpgradeClick = () => {
    setUpgradeDialogOpen(false);
    router.push('/pricing');
  };

  return (
    <>
      <Card variant="outlined" sx={{ opacity: 0.7 }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <LockIcon color="action" />
            <Typography variant="h6">
              {requiredTier.charAt(0).toUpperCase() + requiredTier.slice(1)} Feature
            </Typography>
          </Box>
          <Typography variant="body2" color="text.secondary" paragraph>
            Upgrade to {requiredTier} to access this feature
          </Typography>
          <Button
            variant="contained"
            startIcon={<StarIcon />}
            onClick={() => setUpgradeDialogOpen(true)}
          >
            Upgrade Now
          </Button>
        </CardContent>
      </Card>

      <Dialog
        open={upgradeDialogOpen}
        onClose={() => setUpgradeDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Upgrade to {requiredTier}</DialogTitle>
        <DialogContent>
          <Typography paragraph>
            This feature requires a {requiredTier} membership. Upgrade now to unlock:
          </Typography>
          {requiredTier === 'standard' ? (
            <Box component="ul">
              <Typography component="li">Full access to AI tools</Typography>
              <Typography component="li">Premium course content</Typography>
              <Typography component="li">Advanced features</Typography>
            </Box>
          ) : (
            <Box component="ul">
              <Typography component="li">Dedicated career coaching</Typography>
              <Typography component="li">Done-for-you services</Typography>
              <Typography component="li">Financial planning consultation</Typography>
            </Box>
          )}
          {requiredTier === 'platinum' && (
            <Typography sx={{ mt: 2 }} color="primary">
              Free upgrade available with $150,000+ in retirement assets!
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUpgradeDialogOpen(false)}>Not Now</Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleUpgradeClick}
          >
            View Plans
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
