import React, { useState, useRef, useEffect } from 'react';
import {
  TextField,
  InputAdornment,
  IconButton,
  Tooltip,
  Box,
  Typography,
  CircularProgress,
} from '@mui/material';
import { Visibility, VisibilityOff, Lock } from '@mui/icons-material';
import { securityUtils } from '../../utils/securityUtils';

interface SecureInputProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'email' | 'tel' | 'password';
  sensitiveData?: boolean;
  autoMask?: boolean;
  validation?: (value: string) => string | true;
  required?: boolean;
  helperText?: string;
}

export const SecureInput: React.FC<SecureInputProps> = ({
  id,
  label,
  value,
  onChange,
  type = 'text',
  sensitiveData = false,
  autoMask = false,
  validation,
  required = false,
  helperText,
}) => {
  const [showValue, setShowValue] = useState(!sensitiveData);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout>();
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-mask after inactivity
  useEffect(() => {
    if (autoMask && showValue) {
      const hideTimeout = setTimeout(() => {
        setShowValue(false);
      }, 30000); // 30 seconds

      return () => clearTimeout(hideTimeout);
    }
  }, [autoMask, showValue, value]);

  // Clear value from memory when component unmounts
  useEffect(() => {
    return () => {
      if (sensitiveData) {
        securityUtils.removeSecureItem(id);
      }
    };
  }, [id, sensitiveData]);

  const handleChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    
    // Clear previous timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Validate input
    if (validation) {
      const validationResult = validation(newValue);
      if (validationResult !== true) {
        setError(validationResult as string);
      } else {
        setError(null);
      }
    }

    // Handle sensitive data
    if (sensitiveData) {
      setIsProcessing(true);
      try {
        // Store in secure storage
        securityUtils.setSecureItem(id, newValue, 5); // 5 minutes expiry
        
        // Clear value from memory after short delay
        timeoutRef.current = setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.value = '•'.repeat(newValue.length);
          }
        }, 1000);
      } finally {
        setIsProcessing(false);
      }
    }

    onChange(newValue);
  };

  const toggleShowValue = () => {
    setShowValue(!showValue);
    
    // If showing sensitive data, set a timeout to hide it
    if (!showValue && sensitiveData) {
      setTimeout(() => {
        setShowValue(false);
      }, 30000); // 30 seconds
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    if (sensitiveData) {
      // Prevent paste for sensitive data
      e.preventDefault();
      setError('Pasting is disabled for security reasons');
    }
  };

  const handleCopy = (e: React.ClipboardEvent) => {
    if (sensitiveData) {
      // Prevent copy for sensitive data
      e.preventDefault();
      setError('Copying is disabled for security reasons');
    }
  };

  const displayValue = showValue ? value : '•'.repeat(value.length);

  return (
    <Box sx={{ position: 'relative' }}>
      <TextField
        id={id}
        label={label}
        value={displayValue}
        onChange={handleChange}
        onPaste={handlePaste}
        onCopy={handleCopy}
        type={showValue ? type : 'password'}
        required={required}
        fullWidth
        error={!!error}
        helperText={error || helperText}
        inputRef={inputRef}
        InputProps={{
          startAdornment: sensitiveData && (
            <InputAdornment position="start">
              <Tooltip title="This field is encrypted">
                <Lock color="primary" />
              </Tooltip>
            </InputAdornment>
          ),
          endAdornment: (
            <InputAdornment position="end">
              {isProcessing ? (
                <CircularProgress size={20} />
              ) : (
                sensitiveData && (
                  <IconButton
                    aria-label="toggle value visibility"
                    onClick={toggleShowValue}
                    edge="end"
                  >
                    {showValue ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                )
              )}
            </InputAdornment>
          ),
        }}
      />
      {sensitiveData && (
        <Typography
          variant="caption"
          color="text.secondary"
          sx={{ mt: 0.5, display: 'block' }}
        >
          This field is encrypted and automatically masked for security
        </Typography>
      )}
    </Box>
  );
};
