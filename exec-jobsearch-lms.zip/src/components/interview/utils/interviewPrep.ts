import { InterviewPrep } from '../../../types/interview';
import { ApiError, handleApiError, validateResponse } from '../../../utils/api';

const API_BASE_URL = 'http://localhost:3000/api';

export async function initializeInterviewPrep(jobId: string, resumeId: string): Promise<InterviewPrep> {
  if (!jobId || !resumeId) {
    throw new ApiError('Missing required job or resume ID');
  }

  const response = await fetch(`${API_BASE_URL}/interview-prep/create`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ jobId, resumeId }),
  });

  const data = await validateResponse(response);
  
  if (!data.interviewPrep || !validateInterviewPrep(data.interviewPrep)) {
    throw new ApiError('Invalid interview prep data received from server');
  }

  return data.interviewPrep;
}

export async function completeInterviewStep(prepId: string, stepName: string, data: any): Promise<void> {
  const response = await fetch(`${API_BASE_URL}/interview-prep/${prepId}/steps/${stepName}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ data }),
  });

  await validateResponse(response);
}
