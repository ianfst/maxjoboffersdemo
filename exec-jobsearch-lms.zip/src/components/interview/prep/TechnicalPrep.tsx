import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
  Rating,
  IconButton,
  Tabs,
  Tab,
  TextField,
  LinearProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Tooltip
} from '@mui/material';
import {
  Code as CodeIcon,
  Architecture as ArchitectureIcon,
  School as SchoolIcon,
  Build as BuildIcon,
  Assignment as AssignmentIcon,
  CheckCircle as CheckCircleIcon,
  ExpandMore as ExpandMoreIcon,
  Link as LinkIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  PlayArrow as RunIcon
} from '@mui/icons-material';
import { TechnicalPrep as ITechnicalPrep, TechnologyPrep, SystemDesignPrep, CodeExercise, ConceptReview } from '../../../types/interview';
import MonacoEditor from '@monaco-editor/react';

interface TechnicalPrepProps {
  interviewPrep: any;
  data: ITechnicalPrep | null;
  onUpdate: (data: ITechnicalPrep) => void;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`technical-prep-tabpanel-${index}`}
      aria-labelledby={`technical-prep-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

export const TechnicalPrep: React.FC<TechnicalPrepProps> = ({
  interviewPrep,
  data,
  onUpdate
}) => {
  const [loading, setLoading] = useState(!data);
  const [techPrep, setTechPrep] = useState<ITechnicalPrep | null>(data);
  const [selectedTechnology, setSelectedTechnology] = useState<TechnologyPrep | null>(null);
  const [selectedDesign, setSelectedDesign] = useState<SystemDesignPrep | null>(null);
  const [selectedExercise, setSelectedExercise] = useState<CodeExercise | null>(null);
  const [selectedConcept, setSelectedConcept] = useState<ConceptReview | null>(null);
  const [tabValue, setTabValue] = useState(0);
  const [exerciseCode, setExerciseCode] = useState('');
  const [exerciseOutput, setExerciseOutput] = useState('');
  const [runningCode, setRunningCode] = useState(false);

  useEffect(() => {
    if (!data) {
      fetchTechnicalPrep();
    }
  }, [data]);

  const fetchTechnicalPrep = async () => {
    try {
      const response = await fetch(`/api/interview-prep/${interviewPrep.id}/technical-prep`);
      if (!response.ok) throw new Error('Failed to fetch technical prep');
      
      const prepData = await response.json();
      setTechPrep(prepData);
      onUpdate(prepData);
    } catch (err) {
      console.error('Failed to fetch technical preparation:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleRunCode = async () => {
    if (!selectedExercise) return;

    setRunningCode(true);
    try {
      const response = await fetch('/api/interview-prep/run-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code: exerciseCode,
          language: 'javascript',
          exerciseId: selectedExercise.id
        }),
      });

      if (!response.ok) throw new Error('Failed to run code');

      const result = await response.json();
      setExerciseOutput(result.output);
    } catch (err) {
      console.error('Failed to run code:', err);
      setExerciseOutput('Error running code');
    } finally {
      setRunningCode(false);
    }
  };

  const renderTechnologyCard = (tech: TechnologyPrep) => (
    <Card
      key={tech.technology}
      sx={{ mb: 2, cursor: 'pointer' }}
      onClick={() => setSelectedTechnology(tech)}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{tech.technology}</Typography>
          <Rating value={tech.proficiency} readOnly precision={0.5} />
        </Box>
        <Box sx={{ mt: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
          {tech.keyFeatures.slice(0, 3).map((feature, index) => (
            <Chip
              key={index}
              label={feature}
              size="small"
              variant="outlined"
            />
          ))}
          {tech.keyFeatures.length > 3 && (
            <Chip
              label={`+${tech.keyFeatures.length - 3} more`}
              size="small"
              variant="outlined"
            />
          )}
        </Box>
      </CardContent>
    </Card>
  );

  const renderSystemDesignCard = (design: SystemDesignPrep) => (
    <Card
      key={design.topic}
      sx={{ mb: 2, cursor: 'pointer' }}
      onClick={() => setSelectedDesign(design)}
    >
      <CardContent>
        <Typography variant="h6" gutterBottom>
          {design.topic}
        </Typography>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
          {design.requirements.slice(0, 3).map((req, index) => (
            <Chip
              key={index}
              label={req}
              size="small"
              variant="outlined"
            />
          ))}
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Typography variant="body2" color="text.secondary">
            Components: {design.components.length}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Considerations: {design.considerations.length}
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );

  const renderCodeExerciseCard = (exercise: CodeExercise) => (
    <Card
      key={exercise.id}
      sx={{ mb: 2, cursor: 'pointer' }}
      onClick={() => setSelectedExercise(exercise)}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{exercise.title}</Typography>
          <Chip
            label={exercise.difficulty}
            color={
              exercise.difficulty === 'easy' ? 'success' :
              exercise.difficulty === 'medium' ? 'warning' : 'error'
            }
            size="small"
          />
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {exercise.description}
        </Typography>
      </CardContent>
    </Card>
  );

  const renderConceptReviewCard = (concept: ConceptReview) => (
    <Card
      key={concept.topic}
      sx={{ mb: 2, cursor: 'pointer' }}
      onClick={() => setSelectedConcept(concept)}
    >
      <CardContent>
        <Typography variant="h6" gutterBottom>
          {concept.topic}
        </Typography>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
          {concept.subtopics.slice(0, 3).map((subtopic, index) => (
            <Chip
              key={index}
              label={subtopic}
              size="small"
              variant="outlined"
            />
          ))}
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {concept.resources.slice(0, 2).map((resource, index) => (
            <Chip
              key={index}
              icon={<LinkIcon />}
              label={resource}
              size="small"
              component="a"
              href={resource}
              target="_blank"
              clickable
            />
          ))}
        </Box>
      </CardContent>
    </Card>
  );

  if (loading) {
    return <LinearProgress />;
  }

  if (!techPrep) {
    return null;
  }

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={tabValue} onChange={handleTabChange} aria-label="technical prep tabs">
          <Tab icon={<BuildIcon />} label="Technologies" />
          <Tab icon={<ArchitectureIcon />} label="System Design" />
          <Tab icon={<CodeIcon />} label="Code Exercises" />
          <Tab icon={<SchoolIcon />} label="Concept Review" />
        </Tabs>
      </Box>

      <TabPanel value={tabValue} index={0}>
        <Grid container spacing={3}>
          {techPrep.technologies.map(renderTechnologyCard)}
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        <Grid container spacing={3}>
          {techPrep.systemDesign.map(renderSystemDesignCard)}
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={2}>
        <Grid container spacing={3}>
          {techPrep.codeExercises.map(renderCodeExerciseCard)}
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={3}>
        <Grid container spacing={3}>
          {techPrep.conceptReviews.map(renderConceptReviewCard)}
        </Grid>
      </TabPanel>

      <Dialog
        open={!!selectedTechnology}
        onClose={() => setSelectedTechnology(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedTechnology && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                {selectedTechnology.technology}
                <Rating value={selectedTechnology.proficiency} readOnly precision={0.5} />
              </Box>
            </DialogTitle>
            <DialogContent>
              <Typography variant="h6" gutterBottom>Key Features</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {selectedTechnology.keyFeatures.map((feature, index) => (
                  <Chip
                    key={index}
                    label={feature}
                    variant="outlined"
                  />
                ))}
              </Box>

              <Typography variant="h6" gutterBottom>Examples</Typography>
              <List>
                {selectedTechnology.examples.map((example, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <CheckCircleIcon color="success" />
                    </ListItemIcon>
                    <ListItemText primary={example} />
                  </ListItem>
                ))}
              </List>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setSelectedTechnology(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      <Dialog
        open={!!selectedDesign}
        onClose={() => setSelectedDesign(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedDesign && (
          <>
            <DialogTitle>{selectedDesign.topic}</DialogTitle>
            <DialogContent>
              <Typography variant="h6" gutterBottom>Requirements</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {selectedDesign.requirements.map((req, index) => (
                  <Chip
                    key={index}
                    label={req}
                    variant="outlined"
                  />
                ))}
              </Box>

              <Typography variant="h6" gutterBottom>Components</Typography>
              <List>
                {selectedDesign.components.map((component, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <BuildIcon />
                    </ListItemIcon>
                    <ListItemText primary={component} />
                  </ListItem>
                ))}
              </List>

              <Typography variant="h6" gutterBottom>Considerations</Typography>
              <List>
                {selectedDesign.considerations.map((consideration, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <AssignmentIcon />
                    </ListItemIcon>
                    <ListItemText primary={consideration} />
                  </ListItem>
                ))}
              </List>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setSelectedDesign(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      <Dialog
        open={!!selectedExercise}
        onClose={() => setSelectedExercise(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedExercise && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                {selectedExercise.title}
                <Chip
                  label={selectedExercise.difficulty}
                  color={
                    selectedExercise.difficulty === 'easy' ? 'success' :
                    selectedExercise.difficulty === 'medium' ? 'warning' : 'error'
                  }
                  size="small"
                />
              </Box>
            </DialogTitle>
            <DialogContent>
              <Typography variant="body1" gutterBottom>
                {selectedExercise.description}
              </Typography>

              <Box sx={{ mt: 3 }}>
                <Typography variant="h6" gutterBottom>Solution</Typography>
                <MonacoEditor
                  height="300px"
                  language="javascript"
                  theme="vs-dark"
                  value={exerciseCode || selectedExercise.starterCode}
                  onChange={(value) => setExerciseCode(value || '')}
                  options={{
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    fontSize: 14,
                  }}
                />
              </Box>

              <Box sx={{ mt: 3 }}>
                <Typography variant="h6" gutterBottom>Test Cases</Typography>
                <List>
                  {selectedExercise.testCases.map((testCase, index) => (
                    <ListItem key={index}>
                      <ListItemIcon>
                        <AssignmentIcon />
                      </ListItemIcon>
                      <ListItemText primary={testCase} />
                    </ListItem>
                  ))}
                </List>
              </Box>

              {exerciseOutput && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="h6" gutterBottom>Output</Typography>
                  <Paper sx={{ p: 2, bgcolor: 'grey.100' }}>
                    <Typography variant="body2" component="pre">
                      {exerciseOutput}
                    </Typography>
                  </Paper>
                </Box>
              )}
            </DialogContent>
            <DialogActions>
              <Button
                onClick={handleRunCode}
                variant="contained"
                color="primary"
                startIcon={<RunIcon />}
                disabled={runningCode}
              >
                Run Code
              </Button>
              <Button onClick={() => setSelectedExercise(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      <Dialog
        open={!!selectedConcept}
        onClose={() => setSelectedConcept(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedConcept && (
          <>
            <DialogTitle>{selectedConcept.topic}</DialogTitle>
            <DialogContent>
              <Typography variant="h6" gutterBottom>Subtopics</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {selectedConcept.subtopics.map((subtopic, index) => (
                  <Chip
                    key={index}
                    label={subtopic}
                    variant="outlined"
                  />
                ))}
              </Box>

              <Typography variant="h6" gutterBottom>Resources</Typography>
              <List>
                {selectedConcept.resources.map((resource, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <LinkIcon />
                    </ListItemIcon>
                    <ListItemText
                      primary={resource}
                      primaryTypographyProps={{
                        component: 'a',
                        href: resource,
                        target: '_blank',
                        sx: { textDecoration: 'none' }
                      }}
                    />
                  </ListItem>
                ))}
              </List>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setSelectedConcept(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};
