import React, { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Stepper,
  Step,
  StepLabel,
  Button,
  TextField,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
  Tooltip,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Help as HelpIcon,
  ExpandMore as ExpandMoreIcon,
  Save as SaveIcon,
  Assignment as AssignmentIcon
} from '@mui/icons-material';

interface InterviewStrategyProps {
  onUpdate: (strategy: any) => void;
}

interface StrategyPoint {
  id: string;
  category: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  talkingPoints: string[];
}

const STRATEGY_CATEGORIES = [
  'Opening Approach',
  'Value Proposition',
  'Leadership Style',
  'Achievement Highlights',
  'Industry Knowledge',
  'Company Research',
  'Culture Fit',
  'Future Vision',
  'Compensation Discussion',
  'Closing Strategy'
];

export const InterviewStrategy: React.FC<InterviewStrategyProps> = ({ onUpdate }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [strategies, setStrategies] = useState<StrategyPoint[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [currentStrategy, setCurrentStrategy] = useState<Partial<StrategyPoint> | null>(null);
  const [talkingPoint, setTalkingPoint] = useState('');

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleDialogOpen = (strategy?: StrategyPoint) => {
    if (strategy) {
      setCurrentStrategy(strategy);
    } else {
      setCurrentStrategy({
        id: Math.random().toString(),
        talkingPoints: [],
        priority: 'medium'
      });
    }
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
    setCurrentStrategy(null);
    setTalkingPoint('');
  };

  const handleAddTalkingPoint = () => {
    if (currentStrategy && talkingPoint.trim()) {
      setCurrentStrategy({
        ...currentStrategy,
        talkingPoints: [...(currentStrategy.talkingPoints || []), talkingPoint.trim()]
      });
      setTalkingPoint('');
    }
  };

  const handleRemoveTalkingPoint = (index: number) => {
    if (currentStrategy) {
      const newPoints = [...currentStrategy.talkingPoints];
      newPoints.splice(index, 1);
      setCurrentStrategy({
        ...currentStrategy,
        talkingPoints: newPoints
      });
    }
  };

  const handleSaveStrategy = () => {
    if (currentStrategy?.id) {
      if (strategies.find(s => s.id === currentStrategy.id)) {
        setStrategies(prev =>
          prev.map(strategy => (strategy.id === currentStrategy.id ? currentStrategy as StrategyPoint : strategy))
        );
      } else {
        setStrategies(prev => [...prev, currentStrategy as StrategyPoint]);
      }
      onUpdate(strategies);
      handleDialogClose();
    }
  };

  const handleDeleteStrategy = (id: string) => {
    setStrategies(prev => prev.filter(strategy => strategy.id !== id));
    onUpdate(strategies.filter(strategy => strategy.id !== id));
  };

  const renderStrategyForm = () => (
    <Box sx={{ pt: 2 }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            select
            label="Category"
            value={currentStrategy?.category || ''}
            onChange={(e) => setCurrentStrategy({ ...currentStrategy, category: e.target.value })}
            SelectProps={{
              native: true
            }}
          >
            <option value="">Select a category</option>
            {STRATEGY_CATEGORIES.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Strategy Description"
            value={currentStrategy?.description || ''}
            onChange={(e) => setCurrentStrategy({ ...currentStrategy, description: e.target.value })}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            select
            label="Priority"
            value={currentStrategy?.priority || 'medium'}
            onChange={(e) => setCurrentStrategy({ ...currentStrategy, priority: e.target.value as 'high' | 'medium' | 'low' })}
            SelectProps={{
              native: true
            }}
          >
            <option value="high">High Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="low">Low Priority</option>
          </TextField>
        </Grid>
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <TextField
              fullWidth
              label="Add Talking Point"
              value={talkingPoint}
              onChange={(e) => setTalkingPoint(e.target.value)}
            />
            <Button
              variant="contained"
              onClick={handleAddTalkingPoint}
              disabled={!talkingPoint.trim()}
            >
              Add
            </Button>
          </Box>
        </Grid>
        <Grid item xs={12}>
          <List>
            {currentStrategy?.talkingPoints?.map((point, index) => (
              <ListItem
                key={index}
                secondaryAction={
                  <IconButton onClick={() => handleRemoveTalkingPoint(index)}>
                    <DeleteIcon />
                  </IconButton>
                }
              >
                <ListItemText primary={point} />
              </ListItem>
            ))}
          </List>
        </Grid>
      </Grid>
    </Box>
  );

  const renderStrategyCard = (strategy: StrategyPoint) => (
    <Paper elevation={2} sx={{ mb: 2, p: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="h6">{strategy.category}</Typography>
          <Chip
            label={strategy.priority.toUpperCase()}
            color={
              strategy.priority === 'high'
                ? 'error'
                : strategy.priority === 'medium'
                ? 'warning'
                : 'default'
            }
            size="small"
            sx={{ mt: 1 }}
          />
        </Box>
        <Box>
          <IconButton onClick={() => handleDialogOpen(strategy)} size="small">
            <EditIcon />
          </IconButton>
          <IconButton onClick={() => handleDeleteStrategy(strategy.id)} size="small">
            <DeleteIcon />
          </IconButton>
        </Box>
      </Box>
      <Typography variant="body1" sx={{ mt: 2 }}>
        {strategy.description}
      </Typography>
      <Box sx={{ mt: 2 }}>
        {strategy.talkingPoints.map((point, index) => (
          <Chip
            key={index}
            label={point}
            variant="outlined"
            size="small"
            sx={{ mr: 1, mb: 1 }}
          />
        ))}
      </Box>
    </Paper>
  );

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5">
          Interview Strategy
          <Tooltip title="Develop a comprehensive interview strategy aligned with executive expectations">
            <IconButton size="small">
              <HelpIcon />
            </IconButton>
          </Tooltip>
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleDialogOpen()}
        >
          Add Strategy Point
        </Button>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Strategy Points
              </Typography>
              {STRATEGY_CATEGORIES.map((category) => {
                const categoryStrategies = strategies.filter(s => s.category === category);
                if (categoryStrategies.length === 0) return null;

                return (
                  <Accordion key={category} defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography>{category}</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      {categoryStrategies.map((strategy) => renderStrategyCard(strategy))}
                    </AccordionDetails>
                  </Accordion>
                );
              })}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Strategy Guidelines
              </Typography>
              <List dense>
                <ListItem>
                  <ListItemText
                    primary="Opening (2-3 minutes)"
                    secondary="Executive summary of career progression"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Value Proposition (5 minutes)"
                    secondary="Key achievements and leadership impact"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Strategic Vision (5 minutes)"
                    secondary="Industry insights and growth opportunities"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Cultural Alignment (3-4 minutes)"
                    secondary="Leadership style and team development"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Closing (2-3 minutes)"
                    secondary="Next steps and follow-up plan"
                  />
                </ListItem>
              </List>
            </CardContent>
          </Card>

          <Card elevation={2} sx={{ mt: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Quick Tips
              </Typography>
              <List dense>
                <ListItem>
                  <ListItemText
                    primary="Use the STAR Method"
                    secondary="Situation, Task, Action, Result"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Quantify Impact"
                    secondary="Include specific metrics and KPIs"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Show Strategic Thinking"
                    secondary="Connect actions to business outcomes"
                  />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Dialog open={openDialog} onClose={handleDialogClose} maxWidth="md" fullWidth>
        <DialogTitle>
          {currentStrategy?.id ? 'Edit Strategy Point' : 'Add Strategy Point'}
        </DialogTitle>
        <DialogContent>
          {renderStrategyForm()}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose}>Cancel</Button>
          <Button
            variant="contained"
            startIcon={<SaveIcon />}
            onClick={handleSaveStrategy}
            disabled={!currentStrategy?.category || !currentStrategy?.description}
          >
            Save Strategy
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
