import React, { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  Chip,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Paper,
  Divider,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';
import api from '../../../api/config';

interface PositionAnalysisProps {
  onUpdate: (data: any) => void;
}

interface Requirement {
  id: string;
  type: string;
  description: string;
  importance: 'critical' | 'important' | 'preferred';
}

interface Responsibility {
  id: string;
  description: string;
  impact: string;
  stakeholders: string[];
}

export const PositionAnalysis: React.FC<PositionAnalysisProps> = ({ onUpdate }) => {
  const [loading, setLoading] = useState(false);
  const [position, setPosition] = useState({
    title: '',
    level: '',
    department: '',
    reportingTo: ''
  });
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [responsibilities, setResponsibilities] = useState<Responsibility[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogType, setDialogType] = useState<'requirement' | 'responsibility'>('requirement');
  const [currentItem, setCurrentItem] = useState<any>(null);

  const handlePositionChange = (field: string) => (event: React.ChangeEvent<HTMLInputElement>) => {
    setPosition(prev => ({
      ...prev,
      [field]: event.target.value
    }));
  };

  const handleDialogOpen = (type: 'requirement' | 'responsibility', item?: any) => {
    setDialogType(type);
    setCurrentItem(item || null);
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
    setCurrentItem(null);
  };

  const handleSaveItem = () => {
    if (dialogType === 'requirement') {
      if (currentItem?.id) {
        setRequirements(prev =>
          prev.map(req => (req.id === currentItem.id ? currentItem : req))
        );
      } else {
        setRequirements(prev => [
          ...prev,
          { ...currentItem, id: Math.random().toString() }
        ]);
      }
    } else {
      if (currentItem?.id) {
        setResponsibilities(prev =>
          prev.map(resp => (resp.id === currentItem.id ? currentItem : resp))
        );
      } else {
        setResponsibilities(prev => [
          ...prev,
          { ...currentItem, id: Math.random().toString() }
        ]);
      }
    }
    handleDialogClose();
  };

  const handleDelete = (type: 'requirement' | 'responsibility', id: string) => {
    if (type === 'requirement') {
      setRequirements(prev => prev.filter(req => req.id !== id));
    } else {
      setResponsibilities(prev => prev.filter(resp => resp.id !== id));
    }
  };

  const analyzePosition = async () => {
    setLoading(true);
    try {
      const response = await api.post('/interview/analyze-position', {
        position,
        requirements,
        responsibilities
      });
      onUpdate(response.data);
    } catch (error) {
      console.error('Error analyzing position:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Position Analysis
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Position Details
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Position Title"
                    value={position.title}
                    onChange={handlePositionChange('title')}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Level"
                    value={position.level}
                    onChange={handlePositionChange('level')}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Department"
                    value={position.department}
                    onChange={handlePositionChange('department')}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Reporting To"
                    value={position.reportingTo}
                    onChange={handlePositionChange('reportingTo')}
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Key Requirements
                </Typography>
                <Button
                  startIcon={<AddIcon />}
                  onClick={() => handleDialogOpen('requirement')}
                >
                  Add Requirement
                </Button>
              </Box>
              <List>
                {requirements.map((req) => (
                  <Paper key={req.id} elevation={1} sx={{ mb: 1, p: 1 }}>
                    <ListItem
                      secondaryAction={
                        <Box>
                          <IconButton onClick={() => handleDialogOpen('requirement', req)}>
                            <EditIcon />
                          </IconButton>
                          <IconButton onClick={() => handleDelete('requirement', req.id)}>
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      }
                    >
                      <ListItemText
                        primary={req.description}
                        secondary={
                          <Chip
                            label={req.importance}
                            size="small"
                            color={
                              req.importance === 'critical'
                                ? 'error'
                                : req.importance === 'important'
                                ? 'warning'
                                : 'default'
                            }
                          />
                        }
                      />
                    </ListItem>
                  </Paper>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card elevation={2}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Key Responsibilities
                </Typography>
                <Button
                  startIcon={<AddIcon />}
                  onClick={() => handleDialogOpen('responsibility')}
                >
                  Add Responsibility
                </Button>
              </Box>
              <List>
                {responsibilities.map((resp) => (
                  <Paper key={resp.id} elevation={1} sx={{ mb: 1, p: 1 }}>
                    <ListItem
                      secondaryAction={
                        <Box>
                          <IconButton onClick={() => handleDialogOpen('responsibility', resp)}>
                            <EditIcon />
                          </IconButton>
                          <IconButton onClick={() => handleDelete('responsibility', resp.id)}>
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      }
                    >
                      <ListItemText
                        primary={resp.description}
                        secondary={
                          <>
                            <Typography variant="body2" color="text.secondary">
                              Impact: {resp.impact}
                            </Typography>
                            <Box sx={{ mt: 1 }}>
                              {resp.stakeholders.map((stakeholder, index) => (
                                <Chip
                                  key={index}
                                  label={stakeholder}
                                  size="small"
                                  sx={{ mr: 0.5, mb: 0.5 }}
                                />
                              ))}
                            </Box>
                          </>
                        }
                      />
                    </ListItem>
                  </Paper>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={analyzePosition}
              disabled={loading || !position.title}
              size="large"
            >
              {loading ? <CircularProgress size={24} /> : 'Analyze Position'}
            </Button>
          </Box>
        </Grid>
      </Grid>

      <Dialog open={openDialog} onClose={handleDialogClose} maxWidth="md" fullWidth>
        <DialogTitle>
          {dialogType === 'requirement' ? 'Requirement Details' : 'Responsibility Details'}
        </DialogTitle>
        <DialogContent>
          {dialogType === 'requirement' ? (
            <Box sx={{ pt: 2 }}>
              <TextField
                fullWidth
                label="Description"
                value={currentItem?.description || ''}
                onChange={(e) =>
                  setCurrentItem({ ...currentItem, description: e.target.value })
                }
                multiline
                rows={2}
                sx={{ mb: 2 }}
              />
              <TextField
                fullWidth
                select
                label="Importance"
                value={currentItem?.importance || 'important'}
                onChange={(e) =>
                  setCurrentItem({ ...currentItem, importance: e.target.value })
                }
                SelectProps={{
                  native: true
                }}
              >
                <option value="critical">Critical</option>
                <option value="important">Important</option>
                <option value="preferred">Preferred</option>
              </TextField>
            </Box>
          ) : (
            <Box sx={{ pt: 2 }}>
              <TextField
                fullWidth
                label="Description"
                value={currentItem?.description || ''}
                onChange={(e) =>
                  setCurrentItem({ ...currentItem, description: e.target.value })
                }
                multiline
                rows={2}
                sx={{ mb: 2 }}
              />
              <TextField
                fullWidth
                label="Impact"
                value={currentItem?.impact || ''}
                onChange={(e) =>
                  setCurrentItem({ ...currentItem, impact: e.target.value })
                }
                multiline
                rows={2}
                sx={{ mb: 2 }}
              />
              <TextField
                fullWidth
                label="Stakeholders (comma-separated)"
                value={currentItem?.stakeholders?.join(', ') || ''}
                onChange={(e) =>
                  setCurrentItem({
                    ...currentItem,
                    stakeholders: e.target.value.split(',').map((s) => s.trim())
                  })
                }
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose}>Cancel</Button>
          <Button onClick={handleSaveItem} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
