import React, { useState, useRef, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Chip,
  Tooltip,
  Paper,
  Slider,
  Divider
} from '@mui/material';
import {
  Mic as MicIcon,
  Stop as StopIcon,
  PlayArrow as PlayIcon,
  Pause as PauseIcon,
  Save as SaveIcon,
  Videocam as VideoIcon,
  VideocamOff as VideoOffIcon,
  Help as HelpIcon
} from '@mui/icons-material';

interface PracticeSessionProps {
  onResult: (result: any) => void;
}

interface Question {
  id: string;
  text: string;
  category: string;
  difficulty: number;
  expectedDuration: number;
  keyPoints: string[];
}

const PRACTICE_CATEGORIES = [
  'Leadership Style',
  'Strategic Vision',
  'Change Management',
  'Team Building',
  'Crisis Management',
  'Innovation',
  'Financial Performance',
  'Market Understanding',
  'Stakeholder Management',
  'Personal Development'
];

const SAMPLE_QUESTIONS: Question[] = [
  {
    id: '1',
    text: 'How do you approach leading organizational transformation?',
    category: 'Change Management',
    difficulty: 4,
    expectedDuration: 180,
    keyPoints: [
      'Vision communication',
      'Stakeholder engagement',
      'Change resistance handling',
      'Success metrics'
    ]
  },
  {
    id: '2',
    text: 'Describe a situation where you had to make a difficult strategic decision with limited information.',
    category: 'Strategic Vision',
    difficulty: 5,
    expectedDuration: 240,
    keyPoints: [
      'Decision framework',
      'Risk assessment',
      'Stakeholder impact',
      'Outcome measurement'
    ]
  }
  // Add more sample questions as needed
];

export const PracticeSession: React.FC<PracticeSessionProps> = ({ onResult }) => {
  const [recording, setRecording] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [responseTime, setResponseTime] = useState(0);
  const [feedback, setFeedback] = useState<any>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [customQuestion, setCustomQuestion] = useState('');
  const [practiceHistory, setPracticeHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const timerRef = useRef<NodeJS.Timeout>();
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      stopMediaStream();
    };
  }, []);

  const stopMediaStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const startRecording = async () => {
    try {
      const constraints = {
        audio: true,
        video: videoEnabled
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        chunksRef.current = [];
        analyzePractice(blob);
      };

      mediaRecorder.start();
      setRecording(true);
      
      // Start timer
      let time = 0;
      timerRef.current = setInterval(() => {
        time += 1;
        setResponseTime(time);
      }, 1000);

    } catch (error) {
      console.error('Error accessing media devices:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      stopMediaStream();
    }
    
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    setRecording(false);
  };

  const analyzePractice = async (recordingBlob: Blob) => {
    setLoading(true);
    try {
      // Simulate API call for analysis
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockFeedback = {
        clarity: 4,
        structure: 4.5,
        relevance: 5,
        confidence: 4,
        timing: responseTime > currentQuestion?.expectedDuration ? 3 : 5,
        keyPointsCovered: 4,
        improvements: [
          'Consider providing more specific metrics',
          'Add more context about stakeholder impact',
          'Strengthen conclusion with future implications'
        ],
        strengths: [
          'Clear problem statement',
          'Logical solution approach',
          'Strong results focus'
        ]
      };

      setFeedback(mockFeedback);
      setPracticeHistory(prev => [...prev, {
        question: currentQuestion,
        feedback: mockFeedback,
        timestamp: new Date().toISOString()
      }]);
      
      onResult({
        question: currentQuestion,
        feedback: mockFeedback,
        duration: responseTime
      });
    } catch (error) {
      console.error('Error analyzing practice:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuestionSelect = (question: Question) => {
    setCurrentQuestion(question);
    setFeedback(null);
    setResponseTime(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Box>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card elevation={2}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h6">
                  Practice Session
                  <Tooltip title="Practice answering interview questions with real-time feedback">
                    <IconButton size="small">
                      <HelpIcon />
                    </IconButton>
                  </Tooltip>
                </Typography>
                <Box>
                  <IconButton
                    onClick={() => setVideoEnabled(!videoEnabled)}
                    color={videoEnabled ? 'primary' : 'default'}
                  >
                    {videoEnabled ? <VideoIcon /> : <VideoOffIcon />}
                  </IconButton>
                  <Button
                    variant="contained"
                    color={recording ? 'error' : 'primary'}
                    startIcon={recording ? <StopIcon /> : <MicIcon />}
                    onClick={recording ? stopRecording : startRecording}
                    disabled={!currentQuestion}
                  >
                    {recording ? 'Stop Recording' : 'Start Recording'}
                  </Button>
                </Box>
              </Box>

              {currentQuestion ? (
                <Box>
                  <Typography variant="h6" gutterBottom>
                    {currentQuestion.text}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Chip
                      label={currentQuestion.category}
                      color="primary"
                      size="small"
                      sx={{ mr: 1 }}
                    />
                    <Chip
                      label={`Difficulty: ${currentQuestion.difficulty}/5`}
                      size="small"
                      sx={{ mr: 1 }}
                    />
                    <Chip
                      label={`Expected: ${formatTime(currentQuestion.expectedDuration)}`}
                      size="small"
                    />
                  </Box>
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Key Points to Cover:
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                      {currentQuestion.keyPoints.map((point, index) => (
                        <Chip
                          key={index}
                          label={point}
                          variant="outlined"
                          size="small"
                        />
                      ))}
                    </Box>
                  </Box>
                  {recording && (
                    <Typography variant="h4" align="center" color="error">
                      {formatTime(responseTime)}
                    </Typography>
                  )}
                </Box>
              ) : (
                <Typography align="center" color="text.secondary">
                  Select a question to begin practice
                </Typography>
              )}

              {loading && (
                <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
                  <CircularProgress />
                </Box>
              )}

              {feedback && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Feedback Analysis
                  </Typography>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Paper sx={{ p: 2 }}>
                        <Typography variant="subtitle2" gutterBottom>
                          Strengths
                        </Typography>
                        <List dense>
                          {feedback.strengths.map((strength: string, index: number) => (
                            <ListItem key={index}>
                              <ListItemText primary={strength} />
                            </ListItem>
                          ))}
                        </List>
                      </Paper>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Paper sx={{ p: 2 }}>
                        <Typography variant="subtitle2" gutterBottom>
                          Areas for Improvement
                        </Typography>
                        <List dense>
                          {feedback.improvements.map((improvement: string, index: number) => (
                            <ListItem key={index}>
                              <ListItemText primary={improvement} />
                            </ListItem>
                          ))}
                        </List>
                      </Paper>
                    </Grid>
                    <Grid item xs={12}>
                      <Paper sx={{ p: 2 }}>
                        <Typography variant="subtitle2" gutterBottom>
                          Performance Metrics
                        </Typography>
                        <Grid container spacing={2}>
                          {Object.entries(feedback).filter(([key]) => typeof feedback[key] === 'number').map(([key, value]) => (
                            <Grid item xs={6} sm={4} key={key}>
                              <Typography variant="body2" color="text.secondary">
                                {key.charAt(0).toUpperCase() + key.slice(1)}
                              </Typography>
                              <Slider
                                value={value as number}
                                max={5}
                                step={0.5}
                                marks
                                disabled
                                sx={{ color: (value as number) >= 4 ? 'success.main' : 'warning.main' }}
                              />
                            </Grid>
                          ))}
                        </Grid>
                      </Paper>
                    </Grid>
                  </Grid>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card elevation={2}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Question Bank
                </Typography>
                <Button
                  variant="outlined"
                  size="small"
                  onClick={() => setOpenDialog(true)}
                >
                  Add Question
                </Button>
              </Box>
              <List>
                {SAMPLE_QUESTIONS.map((question) => (
                  <ListItem
                    key={question.id}
                    button
                    selected={currentQuestion?.id === question.id}
                    onClick={() => handleQuestionSelect(question)}
                  >
                    <ListItemText
                      primary={question.text}
                      secondary={
                        <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                          <Chip
                            label={question.category}
                            size="small"
                            variant="outlined"
                          />
                          <Chip
                            label={`${question.difficulty}/5`}
                            size="small"
                            variant="outlined"
                          />
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>

          {practiceHistory.length > 0 && (
            <Card elevation={2} sx={{ mt: 2 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Practice History
                </Typography>
                <List dense>
                  {practiceHistory.map((practice, index) => (
                    <ListItem key={index}>
                      <ListItemText
                        primary={practice.question.text}
                        secondary={new Date(practice.timestamp).toLocaleString()}
                      />
                    </ListItem>
                  ))}
                </List>
              </CardContent>
            </Card>
          )}
        </Grid>
      </Grid>

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Custom Question</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            multiline
            rows={4}
            value={customQuestion}
            onChange={(e) => setCustomQuestion(e.target.value)}
            placeholder="Enter your custom interview question..."
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={() => {
              // Add custom question logic here
              setOpenDialog(false);
            }}
            disabled={!customQuestion.trim()}
          >
            Add Question
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
