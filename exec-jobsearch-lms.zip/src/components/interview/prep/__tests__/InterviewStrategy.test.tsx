import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { InterviewStrategy } from '../InterviewStrategy';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

const server = setupServer(
  rest.post('/api/strategy/generate', (req, res, ctx) => {
    return res(
      ctx.json({
        strategies: [
          {
            category: 'preparation',
            points: [
              'Research company culture',
              'Review recent news and developments',
              'Prepare relevant project examples'
            ]
          },
          {
            category: 'communication',
            points: [
              'Use STAR method for behavioral questions',
              'Practice active listening',
              'Prepare concise answers'
            ]
          }
        ],
        timeline: {
          'day_before': ['Review company information', 'Prepare questions'],
          'day_of': ['Arrive 15 minutes early', 'Bring extra copies of resume'],
          'follow_up': ['Send thank you email', 'Connect on LinkedIn']
        }
      })
    );
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('InterviewStrategy', () => {
  const mockOnUpdate = jest.fn();
  const mockAnalysis = {
    strengths: ['Technical knowledge', 'Communication'],
    improvements: ['Add more metrics', 'Be more concise'],
    score: { overall: 85 }
  };

  const renderComponent = () => {
    return render(
      <InterviewStrategy
        analysis={mockAnalysis}
        onUpdate={mockOnUpdate}
      />
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders initial state correctly', () => {
    renderComponent();
    expect(screen.getByText('Interview Strategy')).toBeInTheDocument();
    expect(screen.getByText('Add Strategy Point')).toBeInTheDocument();
    expect(screen.getByText('Strategy Guidelines')).toBeInTheDocument();
  });

  it('adds a new strategy point', async () => {
    renderComponent();

    // Click add strategy button
    fireEvent.click(screen.getByText('Add Strategy Point'));

    // Fill out the strategy form
    const categorySelect = screen.getByLabelText('Category');
    fireEvent.change(categorySelect, { target: { value: 'Opening Approach' } });

    const descriptionInput = screen.getByLabelText('Strategy Description');
    fireEvent.change(descriptionInput, { target: { value: 'Start with a strong executive summary' } });

    // Save the strategy
    fireEvent.click(screen.getByText('Save Strategy'));

    // Verify the strategy was added
    await waitFor(() => {
      expect(screen.getByText('Opening Approach')).toBeInTheDocument();
      expect(screen.getByText('Start with a strong executive summary')).toBeInTheDocument();
    });
  });

  it('displays timeline recommendations', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Day Before')).toBeInTheDocument();
      expect(screen.getByText('Review company information')).toBeInTheDocument();
      expect(screen.getByText('Day Of')).toBeInTheDocument();
      expect(screen.getByText('Arrive 15 minutes early')).toBeInTheDocument();
    });
  });

  it('allows customizing strategy points', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Add Point'));
    const input = screen.getByPlaceholderText('Enter strategy point');
    await userEvent.type(input, 'Practice technical presentations');
    fireEvent.click(screen.getByText('Save'));

    expect(screen.getByText('Practice technical presentations')).toBeInTheDocument();
  });

  it('supports strategy prioritization', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    const dragHandle = screen.getAllByTestId('drag-handle')[0];
    fireEvent.mouseDown(dragHandle);
    fireEvent.mouseMove(dragHandle, { clientY: 100 });
    fireEvent.mouseUp(dragHandle);

    const points = screen.getAllByTestId('strategy-point');
    expect(points[0]).toHaveTextContent('Use STAR method for behavioral questions');
  });

  it('generates personalized tips', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Generate Tips'));

    expect(screen.getByText('Leverage your technical knowledge')).toBeInTheDocument();
    expect(screen.getByText('Focus on adding specific metrics')).toBeInTheDocument();
  });

  it('updates parent component on completion', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Complete Strategy'));

    expect(mockOnUpdate).toHaveBeenCalledWith({
      strategies: expect.arrayContaining([
        expect.objectContaining({
          category: 'preparation',
          points: expect.arrayContaining(['Research company culture'])
        })
      ]),
      timeline: expect.objectContaining({
        day_before: expect.arrayContaining(['Review company information'])
      })
    });
  });

  it('handles API errors gracefully', async () => {
    server.use(
      rest.post('/api/strategy/generate', (req, res, ctx) => {
        return res(ctx.status(500));
      })
    );

    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Failed to generate strategy')).toBeInTheDocument();
    });
  });

  it('exports strategy plan', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Export Plan'));

    expect(screen.getByText('Plan exported')).toBeInTheDocument();
  });

  it('saves strategy progress', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    // Add custom point
    fireEvent.click(screen.getByText('Add Point'));
    const input = screen.getByPlaceholderText('Enter strategy point');
    await userEvent.type(input, 'Custom strategy');
    fireEvent.click(screen.getByText('Save'));

    fireEvent.click(screen.getByText('Save Progress'));

    expect(screen.getByText('Progress saved')).toBeInTheDocument();
  });

  it('filters strategies by category', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Generate Strategy'));

    await waitFor(() => {
      expect(screen.getByText('Research company culture')).toBeInTheDocument();
    });

    // Filter by communication
    fireEvent.click(screen.getByText('Communication'));

    expect(screen.getByText('Use STAR method for behavioral questions')).toBeInTheDocument();
    expect(screen.queryByText('Research company culture')).not.toBeInTheDocument();
  });
});
