import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { TechnicalPrep } from '../TechnicalPrep';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

// Mock Monaco Editor
jest.mock('@monaco-editor/react', () => {
  return function MockMonacoEditor(props: any) {
    return <div data-testid="monaco-editor">{props.value}</div>;
  };
});

// Mock API endpoints
const server = setupServer(
  rest.get('/api/interview-prep/:id/technical-prep', (req, res, ctx) => {
    return res(
      ctx.json({
        technologies: [
          {
            technology: 'React',
            proficiency: 4.5,
            keyFeatures: ['Hooks', 'Context', 'Redux'],
            examples: ['Built a dashboard', 'Implemented auth flow']
          }
        ],
        systemDesign: [
          {
            topic: 'URL Shortener',
            requirements: ['High availability', 'Low latency'],
            components: ['Load balancer', 'Cache'],
            considerations: ['Database sharding', 'Rate limiting']
          }
        ],
        codeExercises: [
          {
            id: '1',
            title: 'Two Sum',
            description: 'Find two numbers that add up to target',
            difficulty: 'medium',
            starterCode: 'function twoSum(nums, target) {\n  // Your code here\n}',
            testCases: ['[2,7,11,15], 9', '[3,2,4], 6']
          }
        ],
        conceptReviews: [
          {
            topic: 'Data Structures',
            subtopics: ['Arrays', 'Linked Lists', 'Trees'],
            resources: ['leetcode.com', 'geeksforgeeks.org']
          }
        ]
      })
    );
  }),
  rest.post('/api/interview-prep/run-code', (req, res, ctx) => {
    return res(
      ctx.json({
        output: 'Test cases passed: 2/2'
      })
    );
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('TechnicalPrep', () => {
  const mockInterviewPrep = {
    id: '123',
    jobDescription: 'Senior Frontend Developer',
    experiences: []
  };

  const mockData = {
    technologies: [
      {
        technology: 'React',
        proficiency: 4.5,
        keyFeatures: ['Hooks', 'Context', 'Redux'],
        examples: ['Built a dashboard', 'Implemented auth flow']
      }
    ],
    systemDesign: [
      {
        topic: 'URL Shortener',
        requirements: ['High availability', 'Low latency'],
        components: ['Load balancer', 'Cache'],
        considerations: ['Database sharding', 'Rate limiting']
      }
    ],
    codeExercises: [
      {
        id: '1',
        title: 'Two Sum',
        description: 'Find two numbers that add up to target',
        difficulty: 'medium',
        starterCode: 'function twoSum(nums, target) {\n  // Your code here\n}',
        testCases: ['[2,7,11,15], 9', '[3,2,4], 6']
      }
    ],
    conceptReviews: [
      {
        topic: 'Data Structures',
        subtopics: ['Arrays', 'Linked Lists', 'Trees'],
        resources: ['leetcode.com', 'geeksforgeeks.org']
      }
    ]
  };

  const mockOnUpdate = jest.fn();

  const renderComponent = (props = {}) => {
    return render(
      <TechnicalPrep
        interviewPrep={mockInterviewPrep}
        data={null}
        onUpdate={mockOnUpdate}
        {...props}
      />
    );
  };

  it('renders loading state initially', () => {
    renderComponent();
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('displays technology cards', async () => {
    renderComponent({ data: mockData });
    expect(screen.getByText('React')).toBeInTheDocument();
    expect(screen.getByText('Hooks')).toBeInTheDocument();
  });

  it('displays system design cards', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByText('System Design'));
    expect(screen.getByText('URL Shortener')).toBeInTheDocument();
    expect(screen.getByText('High availability')).toBeInTheDocument();
  });

  it('displays code exercises', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByText('Code Exercises'));
    expect(screen.getByText('Two Sum')).toBeInTheDocument();
    expect(screen.getByText('medium')).toBeInTheDocument();
  });

  it('displays concept reviews', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByText('Concept Review'));
    expect(screen.getByText('Data Structures')).toBeInTheDocument();
    expect(screen.getByText('Arrays')).toBeInTheDocument();
  });

  it('runs code exercise', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByText('Code Exercises'));
    fireEvent.click(screen.getByText('Two Sum'));
    
    const runButton = screen.getByText('Run Code');
    fireEvent.click(runButton);

    await waitFor(() => {
      expect(screen.getByText('Test cases passed: 2/2')).toBeInTheDocument();
    });
  });

  it('fetches technical prep data when no initial data provided', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByText('React')).toBeInTheDocument();
    });
    expect(mockOnUpdate).toHaveBeenCalledWith(expect.any(Object));
  });

  it('handles API error gracefully', async () => {
    server.use(
      rest.get('/api/interview-prep/:id/technical-prep', (req, res, ctx) => {
        return res(ctx.status(500));
      })
    );

    renderComponent();
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });
  });
});
