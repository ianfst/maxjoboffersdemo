import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ExperienceMapping } from '../ExperienceMapping';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

// Mock API endpoints
const server = setupServer(
  rest.get('/api/interview-prep/:id/experience-mappings', (req, res, ctx) => {
    return res(
      ctx.json([
        {
          id: '1',
          jobRequirement: 'Frontend Development',
          strengthLevel: 'strong',
          relevantExperiences: [
            {
              role: 'Senior Frontend Developer',
              company: 'Tech Corp',
              duration: '2020-2023',
              description: 'Led frontend development team',
              achievements: ['Improved performance by 50%'],
              skills: ['React', 'TypeScript'],
              impact: 'High'
            }
          ],
          improvementSuggestions: ['Focus on system design']
        }
      ])
    );
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('ExperienceMapping', () => {
  const mockInterviewPrep = {
    id: '123',
    jobDescription: 'Senior Frontend Developer',
    experiences: []
  };

  const mockData = [
    {
      id: '1',
      jobRequirement: 'Frontend Development',
      strengthLevel: 'strong',
      relevantExperiences: [
        {
          role: 'Senior Frontend Developer',
          company: 'Tech Corp',
          duration: '2020-2023',
          description: 'Led frontend development team',
          achievements: ['Improved performance by 50%'],
          skills: ['React', 'TypeScript'],
          impact: 'High'
        }
      ],
      improvementSuggestions: ['Focus on system design']
    }
  ];

  const mockOnUpdate = jest.fn();

  const renderComponent = (props = {}) => {
    return render(
      <ExperienceMapping
        interviewPrep={mockInterviewPrep}
        data={null}
        onUpdate={mockOnUpdate}
        {...props}
      />
    );
  };

  it('renders loading state initially', () => {
    renderComponent();
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('displays experience mappings', async () => {
    renderComponent({ data: mockData });
    expect(screen.getByText('Frontend Development')).toBeInTheDocument();
    expect(screen.getByText('Strong')).toBeInTheDocument();
  });

  it('shows experience details when expanded', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByTestId('ExpandMoreIcon'));
    expect(screen.getByText('Senior Frontend Developer')).toBeInTheDocument();
    expect(screen.getByText('Tech Corp')).toBeInTheDocument();
  });

  it('shows improvement suggestions', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByTestId('ExpandMoreIcon'));
    expect(screen.getByText('Focus on system design')).toBeInTheDocument();
  });

  it('fetches mappings data when no initial data provided', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByText('Frontend Development')).toBeInTheDocument();
    });
    expect(mockOnUpdate).toHaveBeenCalledWith(expect.any(Array));
  });

  it('handles API error gracefully', async () => {
    server.use(
      rest.get('/api/interview-prep/:id/experience-mappings', (req, res, ctx) => {
        return res(ctx.status(500));
      })
    );

    renderComponent();
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });
  });
});
