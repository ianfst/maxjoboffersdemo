import React from 'react';
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react';
import { BehavioralPrep } from '../BehavioralPrep';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

// Mock API endpoints
const server = setupServer(
  rest.get('/api/interview-prep/:id/behavioral-prep', (req, res, ctx) => {
    return res(
      ctx.json({
        examples: [
          {
            id: '1',
            situation: 'Led a team project',
            task: 'Deliver new feature',
            action: 'Coordinated team efforts',
            result: 'Delivered on time',
            competencyArea: 'Leadership',
            keywords: ['Team Lead', 'Project Management']
          }
        ],
        competencyAreas: [
          {
            area: 'Leadership',
            description: 'Ability to guide and motivate teams',
            keyAttributes: ['Vision', 'Communication'],
            commonQuestions: ['Tell me about a time you led a project'],
            tips: ['Focus on results', 'Highlight team success']
          }
        ]
      })
    );
  }),
  rest.put('/api/interview-prep/:id/behavioral-examples/:exampleId', (req, res, ctx) => {
    return res(
      ctx.json({
        id: '1',
        situation: 'Updated situation',
        task: 'Updated task',
        action: 'Updated action',
        result: 'Updated result',
        competencyArea: 'Leadership',
        keywords: ['Updated', 'Keywords']
      })
    );
  })
);

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' });
  jest.spyOn(console, 'error').mockImplementation(() => {});
});

beforeEach(() => {
  // Clear any persisted state
  localStorage.clear();
  sessionStorage.clear();
});

afterEach(() => {
  server.resetHandlers();
  jest.clearAllMocks();
  // Clean up any remaining dialogs
  const dialogs = document.querySelectorAll('[role="dialog"]');
  dialogs.forEach(dialog => dialog.remove());
});

afterAll(() => {
  server.close();
  jest.restoreAllMocks();
});

describe('BehavioralPrep', () => {
  const mockInterviewPrep = {
    id: '123',
    jobDescription: 'Senior Frontend Developer',
    experiences: []
  };

  const mockData = {
    examples: [
      {
        id: '1',
        situation: 'Led a team project',
        task: 'Deliver new feature',
        action: 'Coordinated team efforts',
        result: 'Delivered on time',
        competencyArea: 'Leadership',
        keywords: ['Team Lead', 'Project Management']
      }
    ],
    competencyAreas: [
      {
        area: 'Leadership',
        description: 'Ability to guide and motivate teams',
        keyAttributes: ['Vision', 'Communication'],
        commonQuestions: ['Tell me about a time you led a project'],
        tips: ['Focus on results', 'Highlight team success']
      }
    ]
  };

  const mockOnUpdate = jest.fn();

  const renderComponent = (props = {}) => {
    return render(
      <BehavioralPrep
        interviewPrep={mockInterviewPrep}
        data={null}
        onUpdate={mockOnUpdate}
        {...props}
      />
    );
  };

  it('renders loading state when no initial data', () => {
    renderComponent();
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('renders content when data is provided', () => {
    renderComponent({ data: mockData });
    expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    expect(screen.getByText('STAR Examples')).toBeInTheDocument();
    expect(screen.getByText('Key Competencies')).toBeInTheDocument();
  });

  it('displays STAR examples', async () => {
    renderComponent({ data: mockData });
    expect(screen.getByText('Led a team project')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Leadership' })).toBeInTheDocument();
  });

  it('displays competency areas', async () => {
    renderComponent({ data: mockData });
    expect(screen.getByText('Ability to guide and motivate teams')).toBeInTheDocument();
    expect(screen.getByText('Vision')).toBeInTheDocument();
  });

  it('shows example details when clicked', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByText('Led a team project'));
    expect(screen.getByText('Coordinated team efforts')).toBeInTheDocument();
    expect(screen.getByText('Delivered on time')).toBeInTheDocument();
  });

  it('shows competency details when clicked', async () => {
    renderComponent({ data: mockData });
    fireEvent.click(screen.getByText('Ability to guide and motivate teams'));
    expect(screen.getByText('Tell me about a time you led a project')).toBeInTheDocument();
    expect(screen.getByText('Focus on results')).toBeInTheDocument();
  });

  it('handles example editing with validation and state management', async () => {
    jest.useFakeTimers({ advanceTimers: true });
    renderComponent({ data: mockData });

    // Open example details
    fireEvent.click(screen.getByText('Led a team project'));
    await waitFor(() => {
      const dialog = screen.getByRole('dialog');
      expect(dialog).toBeInTheDocument();
    });

    // Enter edit mode
    fireEvent.click(screen.getByTestId('EditIcon'));
    await waitFor(() => {
      expect(screen.getByText('Edit Example')).toBeInTheDocument();
    });

    // Verify initial form state
    const situationInput = screen.getByLabelText('Situation');
    const taskInput = screen.getByLabelText('Task');
    const actionInput = screen.getByLabelText('Action');
    const resultInput = screen.getByLabelText('Result');
    const keywordsInput = screen.getByLabelText('Keywords (comma-separated)');
    const saveButton = screen.getByText('Save Changes');

    expect(situationInput).toHaveValue('Led a team project');
    expect(taskInput).toHaveValue('Deliver new feature');
    expect(actionInput).toHaveValue('Coordinated team efforts');
    expect(resultInput).toHaveValue('Delivered on time');
    expect(keywordsInput).toHaveValue('Team Lead, Project Management');

    // Test form validation
    fireEvent.change(situationInput, { target: { value: '' } });
    await waitFor(() => {
      expect(saveButton).toBeDisabled();
      expect(screen.getByText('Situation is required')).toBeInTheDocument();
    });

    // Fix validation error
    fireEvent.change(situationInput, { target: { value: 'Updated situation' } });
    await waitFor(() => {
      expect(saveButton).not.toBeDisabled();
      expect(screen.queryByText('Situation is required')).not.toBeInTheDocument();
    });

    // Update all fields
    fireEvent.change(taskInput, { target: { value: 'Updated task' } });
    fireEvent.change(actionInput, { target: { value: 'Updated action' } });
    fireEvent.change(resultInput, { target: { value: 'Updated result' } });
    fireEvent.change(keywordsInput, { target: { value: 'Updated, Keywords' } });

    // Save changes
    fireEvent.click(saveButton);
    jest.advanceTimersByTime(100); // Allow time for state updates

    // Verify API call
    await waitFor(() => {
      expect(mockOnUpdate).toHaveBeenCalledWith(expect.objectContaining({
        examples: expect.arrayContaining([
          expect.objectContaining({
            id: '1',
            situation: 'Updated situation',
            task: 'Updated task',
            action: 'Updated action',
            result: 'Updated result',
            keywords: ['Updated', 'Keywords']
          })
        ])
      }));
    });

    // Dialog should close after save
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });

    // Verify updated content is displayed
    expect(screen.getByText('Updated situation')).toBeInTheDocument();

    // Cleanup
    jest.useRealTimers();
  });

  it('handles form cancellation and state reset', async () => {
    jest.useFakeTimers({ advanceTimers: true });
    renderComponent({ data: mockData });

    // Open example details and enter edit mode
    fireEvent.click(screen.getByText('Led a team project'));
    await waitFor(() => {
      expect(screen.getByRole('dialog')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByTestId('EditIcon'));
    await waitFor(() => {
      expect(screen.getByText('Edit Example')).toBeInTheDocument();
    });

    // Make some changes
    const situationInput = screen.getByLabelText('Situation');
    fireEvent.change(situationInput, { target: { value: 'Changed but not saved' } });
    jest.advanceTimersByTime(100); // Allow time for state updates

    // Cancel edit
    fireEvent.click(screen.getByText('Cancel'));
    jest.advanceTimersByTime(100); // Allow time for state updates

    // Dialog should close
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });

    // Reopen dialog and verify original content
    fireEvent.click(screen.getByText('Led a team project'));
    expect(screen.getByText('Led a team project')).toBeInTheDocument();
    expect(screen.queryByText('Changed but not saved')).not.toBeInTheDocument();
  });

  it('prevents concurrent edit operations', async () => {
    jest.useFakeTimers(); // Use fake timers for better async control
    let saveCount = 0;
    server.use(
      rest.put('/api/interview-prep/:id/behavioral-examples/:exampleId', async (req, res, ctx) => {
        saveCount++;
        await new Promise(resolve => setTimeout(resolve, 100)); // Add delay
        return res(
          ctx.json({
            id: '1',
            ...req.body
          })
        );
      })
    );

    renderComponent({ data: mockData });

    // Open example and enter edit mode
    fireEvent.click(screen.getByText('Led a team project'));
    fireEvent.click(screen.getByTestId('EditIcon'));

    // Update and try to save multiple times
    const situationInput = screen.getByLabelText('Situation');
    fireEvent.change(situationInput, { target: { value: 'Updated situation' } });

    const saveButton = screen.getByText('Save Changes');
    fireEvent.click(saveButton);
    fireEvent.click(saveButton);
    fireEvent.click(saveButton);

    // Advance timers to complete the request
    jest.advanceTimersByTime(100);

    // Wait for save to complete
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });

    expect(saveCount).toBe(1); // Should only save once

    // Cleanup
    jest.useRealTimers();
  });

  it('fetches behavioral prep data when no initial data provided', async () => {
    jest.useFakeTimers();
    const { container } = renderComponent();

    // Verify loading state
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Advance timers
    jest.advanceTimersByTime(100);

    await waitFor(() => {
      expect(screen.getByText('Led a team project')).toBeInTheDocument();
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    expect(mockOnUpdate).toHaveBeenCalledWith(expect.objectContaining({
      examples: expect.arrayContaining([expect.objectContaining({
        id: '1',
        situation: 'Led a team project'
      })])
    }));

    // Cleanup
    jest.useRealTimers();
    container.remove();
  });

  it('maintains state during component updates', async () => {
    jest.useFakeTimers();
    const { rerender } = renderComponent();

    // Should start with loading state
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Rerender with same props during loading
    rerender(
      <BehavioralPrep
        interviewPrep={mockInterviewPrep}
        data={null}
        onUpdate={mockOnUpdate}
      />
    );

    // Loading state should persist
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Advance timers to complete loading
    jest.advanceTimersByTime(100);

    await waitFor(() => {
      expect(screen.getByText('Led a team project')).toBeInTheDocument();
    });

    // Rerender with new data
    const updatedPrep = {
      ...mockInterviewPrep,
      id: '456'
    };

    rerender(
      <BehavioralPrep
        interviewPrep={updatedPrep}
        data={null}
        onUpdate={mockOnUpdate}
      />
    );

    // Should reset to loading for new data
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
    expect(screen.queryByText('Led a team project')).not.toBeInTheDocument();

    // Cleanup
    jest.useRealTimers();
  });

  it('handles various API errors gracefully', async () => {
    jest.useFakeTimers({ advanceTimers: true });
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    const errorScenarios = [
      {
        status: 500,
        error: 'Internal server error',
        expected: 'Failed to fetch behavioral data: Internal server error'
      },
      {
        status: 404,
        error: 'Interview prep not found',
        expected: 'Failed to fetch behavioral data: Interview prep not found'
      },
      {
        status: 400,
        error: 'Invalid request',
        expected: 'Failed to fetch behavioral data: Invalid request'
      }
    ];

    for (const scenario of errorScenarios) {
      server.use(
        rest.get('/api/interview-prep/:id/behavioral-prep', (req, res, ctx) => {
          return res(
            ctx.status(scenario.status),
            ctx.json({ error: scenario.error })
          );
        })
      );

      const { container } = renderComponent();

      // Advance timers
      jest.advanceTimersByTime(100);

      await waitFor(() => {
        expect(screen.getByText(scenario.expected)).toBeInTheDocument();
        expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
        expect(screen.getByText('Retry')).toBeEnabled();
      });

      // Test retry functionality
      server.use(
        rest.get('/api/interview-prep/:id/behavioral-prep', (req, res, ctx) => {
          return res(ctx.json(mockData));
        })
      );

      fireEvent.click(screen.getByText('Retry'));
      jest.advanceTimersByTime(100);

      await waitFor(() => {
        expect(screen.getByText('Led a team project')).toBeInTheDocument();
        expect(screen.queryByText(scenario.expected)).not.toBeInTheDocument();
      });

      container.remove();
    }

    // Cleanup
    jest.useRealTimers();
    consoleSpy.mockRestore();
  });

  it('handles network errors gracefully', async () => {
    jest.useFakeTimers();
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    server.use(
      rest.get('/api/interview-prep/:id/behavioral-prep', (req, res) => {
        return res.networkError('Failed to connect');
      })
    );

    const { container } = renderComponent();

    // Advance timers
    jest.advanceTimersByTime(100);

    await waitFor(() => {
      expect(screen.getByText('Network error: Failed to connect')).toBeInTheDocument();
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByText('Retry')).toBeEnabled();
    });

    // Test auto-retry on network recovery
    server.use(
      rest.get('/api/interview-prep/:id/behavioral-prep', (req, res, ctx) => {
        return res(ctx.json(mockData));
      })
    );

    fireEvent.click(screen.getByText('Retry'));
    jest.advanceTimersByTime(100);

    await waitFor(() => {
      expect(screen.getByText('Led a team project')).toBeInTheDocument();
      expect(screen.queryByText('Network error: Failed to connect')).not.toBeInTheDocument();
    });

    // Cleanup
    jest.useRealTimers();
    consoleSpy.mockRestore();
    container.remove();
  });
    server.use(
      rest.get('/api/interview-prep/:id/behavioral-prep', (req, res, ctx) => {
        return res(
          ctx.status(500),
          ctx.json({ error: 'Internal server error' })
        );
      })
    );

    renderComponent();

    // Initially there should be a loading state
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Wait for loading state to be removed and verify error state
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(console.error).toHaveBeenCalledWith(
        'Failed to fetch behavioral preparation:',
        expect.any(Error)
      );
    }, { timeout: 3000 });
  });

  it('handles example update error gracefully', async () => {
    jest.useFakeTimers({ advanceTimers: true });
    server.use(
      rest.put('/api/interview-prep/:id/behavioral-examples/:exampleId', (req, res, ctx) => {
        return res(
          ctx.status(500),
          ctx.json({ error: 'Internal server error' })
        );
      })
    );

    renderComponent({ data: mockData });

    // Open example edit form
    fireEvent.click(screen.getByText('Led a team project'));
    fireEvent.click(screen.getByTestId('EditIcon'));

    // Try to save changes
    const situationInput = screen.getByLabelText('Situation');
    fireEvent.change(situationInput, { target: { value: 'Updated situation' } });
    fireEvent.click(screen.getByText('Save Changes'));

    // Wait for error to be logged and verify form state
    await waitFor(() => {
      expect(console.error).toHaveBeenCalledWith(
        'Failed to save example:',
        expect.any(Error)
      );
      // Form should still be open with user's input preserved
      expect(screen.getByLabelText('Situation')).toHaveValue('Updated situation');
    });
  });
});
