import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { FeedbackAnalysis } from '../FeedbackAnalysis';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

const server = setupServer(
  rest.get('/api/interview-prep/:id/feedback/analyze', (req, res, ctx) => {
    return res(
      ctx.json({
        strengths: ['Clear articulation', 'Strong system design'],
        improvements: ['Add more metrics', 'Consider edge cases'],
        overallScore: 83,
        totalInterviews: 5,
        categoryScores: [
          { name: 'Communication', score: 85 },
          { name: 'Technical', score: 90 },
          { name: 'Behavioral', score: 75 }
        ],
        scoreTrend: [
          { date: '2025-01-01', score: 75 },
          { date: '2025-02-01', score: 80 },
          { date: '2025-03-01', score: 83 }
        ]
      })
    );
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('FeedbackAnalysis', () => {
  const mockOnUpdate = jest.fn();
  const mockInterviewPrep = {
    id: 'test-interview-123',
    responses: [
      {
        question: 'Describe a challenging project',
        response: 'Led a team of 5 developers...',
        score: 85,
        feedback: ['Good structure', 'Need more metrics']
      },
      {
        question: 'Design a cache system',
        response: "First, let's discuss requirements...",
        score: 90,
        feedback: ['Strong technical depth', 'Consider edge cases']
      }
    ]
  };

  const renderComponent = () => {
    return render(
      <FeedbackAnalysis
        interviewPrep={mockInterviewPrep}
        onUpdate={mockOnUpdate}
      />
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders initial state correctly', () => {
    renderComponent();
    expect(screen.getByRole('heading', { name: 'Feedback Analysis' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Analyze Feedback' })).toBeInTheDocument();
  });

  it('analyzes interview feedback with loading state and UI updates', async () => {
    renderComponent();

    // Button should be enabled initially
    const analyzeButton = screen.getByRole('button', { name: 'Analyze Feedback' });
    expect(analyzeButton).toBeEnabled();

    // Start analysis
    fireEvent.click(analyzeButton);

    // Verify loading state
    await waitFor(() => {
      expect(screen.getByRole('progressbar')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Analyzing feedback...' })).toBeDisabled();
    });

    // Wait for results
    await waitFor(() => {
      expect(screen.getByText('83%')).toBeInTheDocument();
      expect(screen.getByText('Based on 5 interviews')).toBeInTheDocument();
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Verify all UI sections are visible
    expect(screen.getByText('Strengths')).toBeInTheDocument();
    expect(screen.getByText('Areas for Improvement')).toBeInTheDocument();
    expect(screen.getByText('Score Trends')).toBeInTheDocument();
  });

  it('handles empty or incomplete feedback data', async () => {
    server.use(
      rest.get('/api/interview-prep/:id/feedback/analyze', (req, res, ctx) => {
        return res(
          ctx.json({
            strengths: [],
            improvements: [],
            overallScore: 0,
            totalInterviews: 0,
            categoryScores: [],
            scoreTrend: []
          })
        );
      })
    );

    renderComponent();
    fireEvent.click(screen.getByText('Analyze Feedback'));

    await waitFor(() => {
      expect(screen.getByText('No interviews completed yet')).toBeInTheDocument();
      expect(screen.getByText('Complete more interviews to see analysis')).toBeInTheDocument();
    });
  });



  it('shows category scores', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Analyze Feedback'));

    await waitFor(() => {
      expect(screen.getByText('Communication')).toBeInTheDocument();
      expect(screen.getByText('85%')).toBeInTheDocument();
      expect(screen.getByText('Technical')).toBeInTheDocument();
      expect(screen.getByText('90%')).toBeInTheDocument();
      expect(screen.getByText('Behavioral')).toBeInTheDocument();
      expect(screen.getByText('75%')).toBeInTheDocument();
    });
  });





  it('updates parent component on completion', async () => {
    renderComponent();

    fireEvent.click(screen.getByText('Analyze Feedback'));

    await waitFor(() => {
      expect(screen.getByText('83%')).toBeInTheDocument();
    });

    expect(mockOnUpdate).toHaveBeenCalledWith({
      strengths: ['Clear articulation', 'Strong system design'],
      improvements: ['Add more metrics', 'Consider edge cases'],
      overallScore: 83,
      totalInterviews: 5,
      categoryScores: [
        { name: 'Communication', score: 85 },
        { name: 'Technical', score: 90 },
        { name: 'Behavioral', score: 75 }
      ],
      scoreTrend: [
        { date: '2025-01-01', score: 75 },
        { date: '2025-02-01', score: 80 },
        { date: '2025-03-01', score: 83 }
      ]
    });
  });

  it('handles various API errors gracefully', async () => {
    const errorScenarios = [
      {
        status: 500,
        error: 'Internal server error',
        expected: 'Failed to fetch feedback: Internal server error'
      },
      {
        status: 404,
        error: 'Interview prep not found',
        expected: 'Failed to fetch feedback: Interview prep not found'
      },
      {
        status: 400,
        error: 'Invalid interview ID',
        expected: 'Failed to fetch feedback: Invalid interview ID'
      }
    ];

    for (const scenario of errorScenarios) {
      server.use(
        rest.get('/api/interview-prep/:id/feedback/analyze', (req, res, ctx) => {
          return res(
            ctx.status(scenario.status),
            ctx.json({ error: scenario.error })
          );
        })
      );

      renderComponent();
      const analyzeButton = screen.getByText('Analyze Feedback');
      fireEvent.click(analyzeButton);

      await waitFor(() => {
        expect(screen.getByText(scenario.expected)).toBeInTheDocument();
        expect(analyzeButton).toBeEnabled();
      });
    }
  });

  it('prevents concurrent analysis requests', async () => {
    let requestCount = 0;
    server.use(
      rest.get('/api/interview-prep/:id/feedback/analyze', async (req, res, ctx) => {
        requestCount++;
        await new Promise(resolve => setTimeout(resolve, 100)); // Add delay
        return res(
          ctx.json({
            strengths: ['Clear articulation'],
            improvements: ['Add more metrics'],
            overallScore: 83,
            totalInterviews: 5,
            categoryScores: [{ name: 'Communication', score: 85 }],
            scoreTrend: [{ date: '2025-03-01', score: 83 }]
          })
        );
      })
    );

    renderComponent();
    const analyzeButton = screen.getByText('Analyze Feedback');

    // Click multiple times rapidly
    fireEvent.click(analyzeButton);
    fireEvent.click(analyzeButton);
    fireEvent.click(analyzeButton);

    await waitFor(() => {
      expect(screen.getByText('83%')).toBeInTheDocument();
    });

    expect(requestCount).toBe(1); // Should only make one request
  });

  it('maintains state during component updates', async () => {
    const { rerender } = renderComponent();

    // Start analysis
    fireEvent.click(screen.getByText('Analyze Feedback'));

    // Rerender with same props during loading
    rerender(
      <FeedbackAnalysis
        interviewPrep={mockInterviewPrep}
        onUpdate={mockOnUpdate}
      />
    );

    // Verify loading state maintained
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Wait for completion
    await waitFor(() => {
      expect(screen.getByText('83%')).toBeInTheDocument();
      expect(mockOnUpdate).toHaveBeenCalledTimes(1);
    });

    // Rerender with new interview data
    const updatedPrep = {
      ...mockInterviewPrep,
      responses: [
        ...mockInterviewPrep.responses,
        {
          question: 'New question',
          response: 'New response',
          score: 95,
          feedback: ['Excellent']
        }
      ]
    };

    rerender(
      <FeedbackAnalysis
        interviewPrep={updatedPrep}
        onUpdate={mockOnUpdate}
      />
    );

    // Verify state reset for new data
    expect(screen.getByText('Analyze Feedback')).toBeEnabled();
    expect(screen.queryByText('83%')).not.toBeInTheDocument();
  });
});
