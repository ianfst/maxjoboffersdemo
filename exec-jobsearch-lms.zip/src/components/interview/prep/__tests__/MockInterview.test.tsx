import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MockInterview } from '../MockInterview';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

const mockData = [
  {
    id: '1',
    type: 'behavioral',
    date: new Date().toISOString(),
    duration: 1800,
    overallScore: 85,
    questions: [
      {
        id: '1',
        text: 'Describe a challenging project you led',
        type: 'behavioral',
        category: 'leadership'
      }
    ]
  }
];

const baseUrl = window.location.origin;

const server = setupServer(
  rest.get(`${baseUrl}/api/interview-prep/:id/mock-interviews`, (req, res, ctx) => {
    return res(ctx.json(mockData));
  }),
  rest.post(`${baseUrl}/api/interview-prep/:id/mock-interviews`, (req, res, ctx) => {
    return res(
      ctx.json({
        id: '2',
        type: req.body.type,
        date: new Date().toISOString(),
        duration: 1800,
        overallScore: 85,
        questions: [
          {
            id: '1',
            text: 'Describe a challenging project you led',
            type: 'behavioral',
            category: 'leadership'
          }
        ],
        currentQuestionIndex: 0,
        status: 'in_progress'
      })
    );
  }),
  rest.post(`${baseUrl}/api/interview-prep/:id/feedback`, (req, res, ctx) => {
    return res(
      ctx.json({
        score: 85,
        feedback: 'Good structure and clear examples',
        strengths: ['Clear communication', 'Good examples'],
        improvements: ['Add quantitative results', 'Be more concise'],
        status: 'completed'
      })
    );
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('MockInterview', () => {
  const mockOnUpdate = jest.fn();
  const mockRequirements = [
    { id: '1', text: 'Leadership experience', category: 'soft_skills' },
    { id: '2', text: 'System design expertise', category: 'technical' }
  ];

  const renderComponent = (props = {}) => {
    return render(
      <MockInterview
        interviewPrep={{ id: '123' }}
        data={null}
        onUpdate={mockOnUpdate}
        {...props}
      />
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders initial state correctly', async () => {
    renderComponent();
    
    // Should show loading state initially
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
    
    // Wait for loading to complete and verify interview options
    await waitFor(() => {
      // Loading should be complete
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();

      // Interview type buttons should be present
      expect(screen.getByRole('button', { name: 'Technical Interview' })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Mixed Interview' })).toBeInTheDocument();

      // Headers should be present
      expect(screen.getByText(/Mock Interviews/i)).toBeInTheDocument();
      expect(screen.getByText(/Previous Interviews/i)).toBeInTheDocument();
      expect(screen.getByText(/Interview Stats/i)).toBeInTheDocument();
    });
  });

  it('handles API errors gracefully', async () => {
    server.use(
      rest.get(`${baseUrl}/api/interview-prep/:id/mock-interviews`, (req, res, ctx) => {
        return res(ctx.status(500), ctx.text('Internal server error'));
      })
    );

    renderComponent();

    // Should show loading state initially
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Wait for error message to appear
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByText(/Failed to load mock interviews/i)).toBeInTheDocument();
    });

    // Verify error state - buttons should not be present
    expect(screen.queryByRole('button', { name: 'Behavioral Interview' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Technical Interview' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Mixed Interview' })).not.toBeInTheDocument();
  });

  it('handles feedback API errors gracefully', async () => {
    renderComponent();

    // Wait for loading to complete and verify interview options
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
    });

    // Start a behavioral interview
    fireEvent.click(screen.getByRole('button', { name: 'Behavioral Interview' }));

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Verify question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Mock feedback API error
    server.use(
      rest.post(`${baseUrl}/api/interview-prep/:id/feedback`, (req, res, ctx) => {
        return res(ctx.status(500), ctx.text('Failed to analyze response'));
      })
    );

    // Try to get feedback
    const responseInput = screen.getByRole('textbox');
    await userEvent.type(responseInput, 'Test response');
    fireEvent.click(screen.getByRole('button', { name: 'Get AI Feedback' }));

    // Wait for loading to complete and verify error message
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByText(/Failed to analyze response/i)).toBeInTheDocument();
    });

    // Verify error state - feedback elements should not be present
    expect(screen.queryByText(/Score:/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/Good structure/i)).not.toBeInTheDocument();
  });

  it('shows question suggestions', async () => {
    renderComponent();

    // Wait for loading to complete and buttons to appear
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
    });

    // Start a behavioral interview
    fireEvent.click(screen.getByRole('button', { name: 'Behavioral Interview' }));

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Check if question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Get AI feedback
    const responseInput = screen.getByRole('textbox');
    await userEvent.type(responseInput, 'I led a team of 5 developers');
    
    fireEvent.click(screen.getByRole('button', { name: 'Get AI Feedback' }));

    await waitFor(() => {
      expect(screen.getByText('Good structure and clear examples')).toBeInTheDocument();
      expect(screen.getByText('Clear communication')).toBeInTheDocument();
    });
  });

  it('records and analyzes responses', async () => {
    renderComponent();

    // Wait for loading to complete and verify interview options
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Technical Interview' })).toBeInTheDocument();
    });

    // Start a technical interview
    fireEvent.click(screen.getByRole('button', { name: 'Technical Interview' }));

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Verify question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Type response and get feedback
    const responseInput = screen.getByRole('textbox');
    await userEvent.type(responseInput, 'First, we need to consider the system requirements');

    fireEvent.click(screen.getByRole('button', { name: /get ai feedback/i }));

    // Wait for loading to complete and verify feedback
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByText(/Score: 85/i)).toBeInTheDocument();
      expect(screen.getByText('Good structure')).toBeInTheDocument();
    });
  });

  it('provides feedback and improvements', async () => {
    renderComponent();

    // Wait for loading to complete and verify interview options
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: /mixed interview/i })).toBeInTheDocument();
    });

    // Start a mixed interview
    fireEvent.click(screen.getByRole('button', { name: /mixed interview/i }));

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Verify question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Type response and get feedback
    const responseInput = screen.getByRole('textbox', { name: /response/i });
    await userEvent.type(responseInput, 'I led a team of 5 developers');

    fireEvent.click(screen.getByRole('button', { name: /get ai feedback/i }));

    // Wait for loading to complete and verify feedback
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByText('Add quantitative results')).toBeInTheDocument();
      expect(screen.getByText('Be more concise')).toBeInTheDocument();
    });
  });

  it('allows recording video responses', async () => {
    renderComponent();

    // Wait for loading to complete and verify interview options
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: /behavioral interview/i })).toBeInTheDocument();
    });

    // Start a behavioral interview
    fireEvent.click(screen.getByRole('button', { name: /behavioral interview/i }));

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Verify question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Toggle video recording
    const recordButton = screen.getByRole('button', { name: /record video/i });
    fireEvent.click(recordButton);

    // Wait for recording UI to update
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /stop recording/i })).toBeInTheDocument();
    });

    const stopButton = screen.getByRole('button', { name: /stop recording/i });
    fireEvent.click(stopButton);

    // Submit response and check feedback
    const submitButton = screen.getByRole('button', { name: /get ai feedback/i });
    fireEvent.click(submitButton);

    // Wait for loading to complete and verify feedback
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByText(/good structure/i)).toBeInTheDocument();
    });
  });

  it('supports timed responses', async () => {
    renderComponent();

    // Wait for loading to complete and verify interview options
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
    });

    // Start a behavioral interview
    const behavioralButton = screen.getByRole('button', { name: 'Behavioral Interview' });
    fireEvent.click(behavioralButton);

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Verify question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Type response and get feedback
    const responseInput = screen.getByRole('textbox');
    await userEvent.type(responseInput, 'I led a team of 5 developers');

    // Submit response and wait for feedback
    const submitButton = screen.getByRole('button', { name: 'Get AI Feedback' });
    fireEvent.click(submitButton);

    // Wait for feedback to load
    await waitFor(() => {
      expect(screen.getByText('Good structure and clear examples')).toBeInTheDocument();
      expect(screen.getByText(/Score:/i)).toBeInTheDocument();
    });
  });

  it('updates parent component on completion', async () => {
    renderComponent();

    // Wait for loading to complete and buttons to appear
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
    });

    // Start a behavioral interview
    fireEvent.click(screen.getByRole('button', { name: 'Behavioral Interview' }));

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Check if question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Type response and get feedback
    const responseInput = screen.getByRole('textbox');
    await userEvent.type(responseInput, 'I led a team of 5 developers');

    fireEvent.click(screen.getByRole('button', { name: 'Get AI Feedback' }));
    
    await waitFor(() => {
      expect(screen.getByText('Good structure and clear examples')).toBeInTheDocument();
    });

    // Move to next question and complete
    fireEvent.click(screen.getByRole('button', { name: 'Next Question' }));

    await waitFor(() => {
      expect(mockOnUpdate).toHaveBeenCalledWith(expect.arrayContaining([{
        id: '2',
        type: 'behavioral',
        date: expect.any(String),
        duration: 1800,
        overallScore: 85,
        questions: expect.arrayContaining([{
          id: '1',
          text: 'Describe a challenging project you led',
          type: 'behavioral',
          category: 'leadership'
        }])
      }]));
    });
  });

  it('handles API errors gracefully', async () => {
    server.use(
      rest.post(`${baseUrl}/api/interview-prep/:id/mock-interviews`, (req, res, ctx) => {
        return res(ctx.status(500), ctx.json({ error: 'Failed to create interview' }));
      })
    );

    renderComponent();

    // Wait for loading to complete and buttons to appear
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
    });

    // Start a behavioral interview
    const behavioralButton = screen.getByRole('button', { name: 'Behavioral Interview' });
    fireEvent.click(behavioralButton);

    // Wait for error message
    await waitFor(() => {
      expect(screen.getByText(/Failed to create interview/i)).toBeInTheDocument();
    });
  });

  it('saves interview progress', async () => {
    renderComponent();

    // Wait for loading to complete and buttons to appear
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Behavioral Interview' })).toBeInTheDocument();
    });

    // Start a behavioral interview
    const behavioralButton = screen.getByRole('button', { name: 'Behavioral Interview' });
    fireEvent.click(behavioralButton);

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Check if question is displayed
    expect(screen.getByText('Describe a challenging project you led')).toBeInTheDocument();

    // Type response and get feedback
    const responseInput = screen.getByRole('textbox');
    await userEvent.type(responseInput, 'I led a team of 5 developers');

    // Submit response and wait for feedback
    const submitButton = screen.getByRole('button', { name: 'Get AI Feedback' });
    fireEvent.click(submitButton);
    
    // Wait for feedback to load
    await waitFor(() => {
      expect(screen.getByText('Good structure and clear examples')).toBeInTheDocument();
    });

    // Move to next question and complete
    const nextButton = screen.getByRole('button', { name: 'Next Question' });
    fireEvent.click(nextButton);

    // Verify update was called with correct data
    await waitFor(() => {
      expect(mockOnUpdate).toHaveBeenCalledWith(expect.arrayContaining([{
        id: '2',
        type: 'behavioral',
        date: expect.any(String),
        duration: 1800,
        overallScore: 85,
        questions: expect.arrayContaining([{
          id: '1',
          text: 'Describe a challenging project you led',
          type: 'behavioral',
          category: 'leadership'
        }]),
        status: 'completed'
      }]));
    });
  });
});
