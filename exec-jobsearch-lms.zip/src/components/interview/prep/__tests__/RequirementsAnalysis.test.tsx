import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { RequirementsAnalysis } from '../RequirementsAnalysis';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

// Mock API endpoints
const server = setupServer(
  rest.get('/api/interview-prep/:id/requirements-analysis', (req, res, ctx) => {
    return res(
      ctx.json({
        skillMatches: [
          {
            skill: 'React',
            matched: true,
            proficiencyLevel: 4,
            yearsOfExperience: 3,
            lastUsed: '2025-01-01',
            relevantExperience: ['Built complex web applications', 'Led team of developers']
          }
        ],
        experienceRequirements: [
          {
            area: 'Frontend Development',
            matched: true,
            yearsRequired: 3,
            relevantExperience: ['5 years of web development', 'Expert in React']
          }
        ],
        overallMatch: 0.85,
        recommendations: ['Focus on system design', 'Practice coding challenges']
      })
    );
  })
);

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'error' });
});

beforeEach(() => {
  // Clear any persisted state
  localStorage.clear();
  sessionStorage.clear();
});

afterEach(() => {
  server.resetHandlers();
  jest.clearAllMocks();
});

afterAll(() => {
  server.close();
  jest.restoreAllMocks();
});

describe('RequirementsAnalysis', () => {
  const mockInterviewPrep = {
    id: '123',
    jobDescription: 'Senior Frontend Developer',
    experiences: []
  };

  const mockData = {
    skillMatches: [
      {
        skill: 'React',
        matched: true,
        proficiencyLevel: 4,
        yearsOfExperience: 3,
        lastUsed: '2025-01-01',
        relevantExperience: ['Built complex web applications', 'Led team of developers']
      }
    ],
    experienceRequirements: [
      {
        area: 'Frontend Development',
        matched: true,
        yearsRequired: 3,
        relevantExperience: ['5 years of web development', 'Expert in React']
      }
    ],
    overallMatch: 0.85,
    recommendations: ['Focus on system design', 'Practice coding challenges']
  };

  const mockOnUpdate = jest.fn();

  const renderComponent = (props = {}) => {
    return render(
      <RequirementsAnalysis
        interviewPrep={mockInterviewPrep}
        data={null}
        onUpdate={mockOnUpdate}
        {...props}
      />
    );
  };

  it('renders loading state initially', () => {
    renderComponent();
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('displays skill matches', async () => {
    renderComponent({ data: mockData });
    expect(screen.getByText('React')).toBeInTheDocument();
    expect(screen.getByText('3 years of experience')).toBeInTheDocument();
  });

  it('displays experience requirements', async () => {
    renderComponent({ data: mockData });
    expect(screen.getByText('Frontend Development')).toBeInTheDocument();
    expect(screen.getByText('3 years required')).toBeInTheDocument();
  });

  it('shows and interacts with skill details dialog', async () => {
    renderComponent({ data: mockData });
    
    // Open dialog
    fireEvent.click(screen.getByText('React'));
    const dialog = screen.getByRole('dialog');
    expect(dialog).toBeInTheDocument();
    
    // Verify all skill details
    expect(screen.getByText('Skill Analysis: React')).toBeInTheDocument();
    expect(screen.getByText('Proficiency Level: 4/5')).toBeInTheDocument();
    expect(screen.getByText('Years of Experience: 3')).toBeInTheDocument();
    expect(screen.getByText('Last Used: January 2025')).toBeInTheDocument();
    
    // Check relevant experience section
    const experienceList = screen.getByTestId('relevant-experience-list');
    expect(within(experienceList).getByText('Built complex web applications')).toBeInTheDocument();
    expect(within(experienceList).getByText('Led team of developers')).toBeInTheDocument();
    
    // Close dialog
    fireEvent.click(screen.getByLabelText('Close dialog'));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('handles skill match status correctly', async () => {
    const mixedMatchData = {
      ...mockData,
      skillMatches: [
        {
          skill: 'React',
          matched: true,
          proficiencyLevel: 4,
          yearsOfExperience: 3,
          lastUsed: '2025-01-01',
          relevantExperience: ['Built complex web applications']
        },
        {
          skill: 'Python',
          matched: false,
          proficiencyLevel: 2,
          yearsOfExperience: 1,
          lastUsed: '2024-01-01',
          relevantExperience: ['Basic scripting']
        }
      ]
    };

    renderComponent({ data: mixedMatchData });

    // Check matched skill
    const reactSkill = screen.getByText('React').closest('[data-testid="skill-item"]');
    expect(reactSkill).toHaveClass('matched');
    expect(within(reactSkill).getByTestId('match-icon')).toHaveStyle({ color: 'green' });

    // Check unmatched skill
    const pythonSkill = screen.getByText('Python').closest('[data-testid="skill-item"]');
    expect(pythonSkill).toHaveClass('unmatched');
    expect(within(pythonSkill).getByTestId('warning-icon')).toHaveStyle({ color: 'orange' });
  });

  it('fetches analysis data when no initial data provided', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByText('React')).toBeInTheDocument();
    });
    expect(mockOnUpdate).toHaveBeenCalledWith(expect.any(Object));
  });

  it('handles various API errors gracefully', async () => {
    jest.spyOn(console, 'error').mockImplementation(() => {}); // Suppress expected error logs
    const errorScenarios = [
      {
        status: 500,
        error: 'Internal server error',
        expected: 'Failed to analyze requirements: Internal server error'
      },
      {
        status: 404,
        error: 'Interview prep not found',
        expected: 'Failed to analyze requirements: Interview prep not found'
      },
      {
        status: 400,
        error: 'Invalid job description',
        expected: 'Failed to analyze requirements: Invalid job description'
      }
    ];

    for (const scenario of errorScenarios) {
      server.use(
        rest.get('/api/interview-prep/:id/requirements-analysis', (req, res, ctx) => {
          return res(
            ctx.status(scenario.status),
            ctx.json({ error: scenario.error })
          );
        })
      );

      renderComponent();
      
      await waitFor(() => {
        expect(screen.getByText(scenario.expected)).toBeInTheDocument();
        expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
        expect(screen.getByText('Retry Analysis')).toBeEnabled();
      });

      // Test retry functionality
      server.use(
        rest.get('/api/interview-prep/:id/requirements-analysis', (req, res, ctx) => {
          return res(ctx.json(mockData));
        })
      );

      fireEvent.click(screen.getByText('Retry Analysis'));
      
      await waitFor(() => {
        expect(screen.getByText('React')).toBeInTheDocument();
        expect(screen.queryByText(scenario.expected)).not.toBeInTheDocument();
      });
    }
  });

  it('handles network errors during analysis', async () => {
    server.use(
      rest.get('/api/interview-prep/:id/requirements-analysis', (req, res) => {
        return res.networkError('Failed to connect');
      })
    );

    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Network error: Failed to connect')).toBeInTheDocument();
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Test auto-retry on network recovery
    server.use(
      rest.get('/api/interview-prep/:id/requirements-analysis', (req, res, ctx) => {
        return res(ctx.json(mockData));
      })
    );

    fireEvent.click(screen.getByText('Retry Analysis'));

    await waitFor(() => {
      expect(screen.getByText('React')).toBeInTheDocument();
      expect(screen.queryByText('Network error: Failed to connect')).not.toBeInTheDocument();
    });
  });

  it('prevents concurrent analysis requests', async () => {
    jest.useFakeTimers(); // Use fake timers for better async control
    let requestCount = 0;
    server.use(
      rest.get('/api/interview-prep/:id/requirements-analysis', async (req, res, ctx) => {
        requestCount++;
        await new Promise(resolve => setTimeout(resolve, 100)); // Add delay
        return res(ctx.json(mockData));
      })
    );

    const { container } = renderComponent();
    
    // Try to trigger multiple analyses
    const analyzeButton = screen.getByText('Analyze Requirements');
    fireEvent.click(analyzeButton);
    expect(analyzeButton).toBeDisabled(); // Button should be disabled during analysis
    
    // Attempt more clicks while disabled
    fireEvent.click(analyzeButton);
    fireEvent.click(analyzeButton);

    // Advance timers to complete the request
    jest.advanceTimersByTime(100);

    await waitFor(() => {
      expect(screen.getByText('React')).toBeInTheDocument();
      expect(analyzeButton).toBeEnabled(); // Button should be re-enabled
    });

    expect(requestCount).toBe(1); // Should only make one request

    // Cleanup
    jest.useRealTimers();
    container.remove();
  });

  it('maintains state during component updates', async () => {
    const { rerender } = renderComponent();

    // Start analysis
    fireEvent.click(screen.getByText('Analyze Requirements'));
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Rerender with same props during loading
    rerender(
      <RequirementsAnalysis
        interviewPrep={mockInterviewPrep}
        data={null}
        onUpdate={mockOnUpdate}
      />
    );

    // Verify loading state maintained
    expect(screen.getByRole('progressbar')).toBeInTheDocument();

    // Wait for completion
    await waitFor(() => {
      expect(screen.getByText('React')).toBeInTheDocument();
      expect(mockOnUpdate).toHaveBeenCalledTimes(1);
    });

    // Rerender with new data
    const updatedPrep = {
      ...mockInterviewPrep,
      jobDescription: 'Updated Job Description'
    };

    rerender(
      <RequirementsAnalysis
        interviewPrep={updatedPrep}
        data={null}
        onUpdate={mockOnUpdate}
      />
    );

    // Verify state reset for new data
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
    expect(screen.queryByText('React')).not.toBeInTheDocument();
  });
});
