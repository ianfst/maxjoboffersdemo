import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  Chip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  CircularProgress
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { useTheme } from '@mui/material/styles';
import api from '../../../api/config';

interface CompanyResearchProps {
  onUpdate: (data: any) => void;
}

export const CompanyResearch: React.FC<CompanyResearchProps> = ({ onUpdate }) => {
  const theme = useTheme();
  const [loading, setLoading] = useState(false);
  const [companyData, setCompanyData] = useState({
    name: '',
    industry: '',
    competitors: '',
    recentNews: ''
  });
  const [analysis, setAnalysis] = useState<any>(null);

  const researchCategories = [
    {
      title: 'Market Position',
      fields: ['Market Share', 'Growth Trajectory', 'Competitive Advantages']
    },
    {
      title: 'Financial Health',
      fields: ['Revenue Trends', 'Profitability', 'Investment Areas']
    },
    {
      title: 'Corporate Culture',
      fields: ['Values', 'Leadership Style', 'Employee Reviews']
    },
    {
      title: 'Strategic Initiatives',
      fields: ['Current Projects', 'Future Plans', 'Innovation Focus']
    }
  ];

  const handleInputChange = (field: string) => (event: React.ChangeEvent<HTMLInputElement>) => {
    setCompanyData(prev => ({
      ...prev,
      [field]: event.target.value
    }));
  };

  const analyzeCompany = async () => {
    setLoading(true);
    try {
      const response = await api.post('/interview/analyze-company', companyData);
      setAnalysis(response.data);
      onUpdate({
        ...companyData,
        analysis: response.data
      });
    } catch (error) {
      console.error('Error analyzing company:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderAnalysisSection = (title: string, data: any) => (
    <Accordion defaultExpanded>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Typography variant="h6">{title}</Typography>
      </AccordionSummary>
      <AccordionDetails>
        <List>
          {data.map((item: any, index: number) => (
            <ListItem key={index}>
              <ListItemText
                primary={item.title}
                secondary={item.description}
                secondaryTypographyProps={{ style: { whiteSpace: 'pre-wrap' } }}
              />
            </ListItem>
          ))}
        </List>
      </AccordionDetails>
    </Accordion>
  );

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Company Research
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Basic Information
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Company Name"
                    value={companyData.name}
                    onChange={handleInputChange('name')}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Industry"
                    value={companyData.industry}
                    onChange={handleInputChange('industry')}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Key Competitors"
                    value={companyData.competitors}
                    onChange={handleInputChange('competitors')}
                    multiline
                    rows={2}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Recent News & Developments"
                    value={companyData.recentNews}
                    onChange={handleInputChange('recentNews')}
                    multiline
                    rows={3}
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Research Categories
              </Typography>
              {researchCategories.map((category, index) => (
                <Box key={index} sx={{ mb: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    {category.title}
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {category.fields.map((field, fieldIndex) => (
                      <Chip
                        key={fieldIndex}
                        label={field}
                        variant="outlined"
                        color="primary"
                      />
                    ))}
                  </Box>
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={analyzeCompany}
              disabled={loading || !companyData.name}
              size="large"
            >
              {loading ? <CircularProgress size={24} /> : 'Analyze Company'}
            </Button>
          </Box>
        </Grid>

        {analysis && (
          <Grid item xs={12}>
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Analysis Results
                </Typography>
                {renderAnalysisSection('Market Position', analysis.marketPosition)}
                {renderAnalysisSection('Financial Health', analysis.financialHealth)}
                {renderAnalysisSection('Corporate Culture', analysis.culture)}
                {renderAnalysisSection('Strategic Initiatives', analysis.strategies)}
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>
    </Box>
  );
};
