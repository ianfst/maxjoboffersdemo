import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
  Rating,
  IconButton,
  TextField,
  LinearProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Tooltip
} from '@mui/material';
import {
  Star as StarIcon,
  Assignment as AssignmentIcon,
  ExpandMore as ExpandMoreIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Psychology as PsychologyIcon,
  Business as BusinessIcon,
  Group as TeamIcon,
  Lightbulb as ImpactIcon
} from '@mui/icons-material';
import { BehavioralPrep as IBehavioralPrep, BehavioralExample, CompetencyArea } from '../../../types/interview';

interface BehavioralPrepProps {
  interviewPrep: any;
  data: IBehavioralPrep | null;
  onUpdate: (data: IBehavioralPrep) => void;
}

export const BehavioralPrep: React.FC<BehavioralPrepProps> = ({
  interviewPrep,
  data,
  onUpdate
}) => {
  const [loading, setLoading] = useState(!data);
  const [behavioralPrep, setBehavioralPrep] = useState<IBehavioralPrep | null>(data);
  const [selectedExample, setSelectedExample] = useState<BehavioralExample | null>(null);
  const [selectedCompetency, setSelectedCompetency] = useState<CompetencyArea | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [editedExample, setEditedExample] = useState<BehavioralExample | null>(null);

  useEffect(() => {
    if (!data) {
      fetchBehavioralPrep();
    }
  }, [data]);

  const fetchBehavioralPrep = async () => {
    try {
      const response = await fetch(`/api/interview-prep/${interviewPrep.id}/behavioral-prep`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Server error (${response.status}): ${errorData.error}`);
      }
      
      const prepData = await response.json();
      setBehavioralPrep(prepData);
      onUpdate(prepData);
    } catch (err) {
      console.error('Failed to fetch behavioral preparation:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveExample = async () => {
    if (!editedExample) return;

    try {
      const response = await fetch(`/api/interview-prep/${interviewPrep.id}/behavioral-examples/${editedExample.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedExample),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Server error (${response.status}): ${errorData.error}`);
      }

      const updatedExample = await response.json();
      if (behavioralPrep) {
        const updatedPrep = {
          ...behavioralPrep,
          examples: behavioralPrep.examples.map(ex => 
            ex.id === updatedExample.id ? updatedExample : ex
          )
        };
        setBehavioralPrep(updatedPrep);
        onUpdate(updatedPrep);
      }
      setEditMode(false);
      setSelectedExample(null);
      setEditedExample(null);
    } catch (err) {
      console.error('Failed to save example:', err);
    }
  };

  const getCompetencyIcon = (area: string) => {
    switch (area.toLowerCase()) {
      case 'leadership':
        return <BusinessIcon />;
      case 'teamwork':
        return <TeamIcon />;
      case 'impact':
        return <ImpactIcon />;
      case 'problem solving':
        return <PsychologyIcon />;
      default:
        return <StarIcon />;
    }
  };

  const renderExampleCard = (example: BehavioralExample) => (
    <Card
      key={example.id}
      sx={{ mb: 2, cursor: 'pointer' }}
      onClick={() => setSelectedExample(example)}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{example.situation}</Typography>
          <Chip
            icon={getCompetencyIcon(example.competencyArea)}
            label={example.competencyArea}
            color="primary"
            variant="outlined"
            size="small"
          />
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {example.task}
        </Typography>
        <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
          {example.keywords.slice(0, 3).map((keyword, index) => (
            <Chip
              key={index}
              label={keyword}
              size="small"
              variant="outlined"
            />
          ))}
          {example.keywords.length > 3 && (
            <Chip
              label={`+${example.keywords.length - 3} more`}
              size="small"
              variant="outlined"
            />
          )}
        </Box>
      </CardContent>
    </Card>
  );

  const renderCompetencyCard = (competency: CompetencyArea) => (
    <Card
      key={competency.area}
      sx={{ mb: 2, cursor: 'pointer' }}
      onClick={() => setSelectedCompetency(competency)}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{competency.area}</Typography>
          <IconButton size="small">
            {getCompetencyIcon(competency.area)}
          </IconButton>
        </Box>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary">
            {competency.description}
          </Typography>
        </Box>
        <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
          {competency.keyAttributes.slice(0, 3).map((attr, index) => (
            <Chip
              key={index}
              label={attr}
              size="small"
              variant="outlined"
            />
          ))}
        </Box>
      </CardContent>
    </Card>
  );

  if (loading) {
    return <LinearProgress />;
  }

  if (!behavioralPrep) {
    return null;
  }

  return (
    <Box sx={{ width: '100%' }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Typography variant="h5" gutterBottom>
            STAR Examples
          </Typography>
          {behavioralPrep.examples.map(renderExampleCard)}
        </Grid>

        <Grid item xs={12} md={4}>
          <Typography variant="h5" gutterBottom>
            Key Competencies
          </Typography>
          {behavioralPrep.competencyAreas.map(renderCompetencyCard)}
        </Grid>
      </Grid>

      <Dialog
        open={!!selectedExample}
        onClose={() => {
          setSelectedExample(null);
          setEditMode(false);
          setEditedExample(null);
        }}
        maxWidth="md"
        fullWidth
      >
        {selectedExample && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                {editMode ? 'Edit Example' : 'STAR Example'}
                {!editMode && (
                  <IconButton onClick={() => {
                    setEditMode(true);
                    setEditedExample(selectedExample);
                  }}>
                    <EditIcon />
                  </IconButton>
                )}
              </Box>
            </DialogTitle>
            <DialogContent>
              {editMode && editedExample ? (
                <Box sx={{ mt: 2 }}>
                  <TextField
                    fullWidth
                    label="Situation"
                    value={editedExample.situation}
                    onChange={(e) => setEditedExample({
                      ...editedExample,
                      situation: e.target.value
                    })}
                    sx={{ mb: 2 }}
                  />
                  <TextField
                    fullWidth
                    label="Task"
                    value={editedExample.task}
                    onChange={(e) => setEditedExample({
                      ...editedExample,
                      task: e.target.value
                    })}
                    sx={{ mb: 2 }}
                  />
                  <TextField
                    fullWidth
                    label="Action"
                    value={editedExample.action}
                    onChange={(e) => setEditedExample({
                      ...editedExample,
                      action: e.target.value
                    })}
                    multiline
                    rows={3}
                    sx={{ mb: 2 }}
                  />
                  <TextField
                    fullWidth
                    label="Result"
                    value={editedExample.result}
                    onChange={(e) => setEditedExample({
                      ...editedExample,
                      result: e.target.value
                    })}
                    multiline
                    rows={2}
                    sx={{ mb: 2 }}
                  />
                  <TextField
                    fullWidth
                    label="Keywords (comma-separated)"
                    value={editedExample.keywords.join(', ')}
                    onChange={(e) => setEditedExample({
                      ...editedExample,
                      keywords: e.target.value.split(',').map(k => k.trim())
                    })}
                  />
                </Box>
              ) : (
                <>
                  <Paper sx={{ p: 2, mb: 2 }}>
                    <Typography variant="h6" gutterBottom>Situation</Typography>
                    <Typography>{selectedExample.situation}</Typography>
                  </Paper>

                  <Paper sx={{ p: 2, mb: 2 }}>
                    <Typography variant="h6" gutterBottom>Task</Typography>
                    <Typography>{selectedExample.task}</Typography>
                  </Paper>

                  <Paper sx={{ p: 2, mb: 2 }}>
                    <Typography variant="h6" gutterBottom>Action</Typography>
                    <Typography>{selectedExample.action}</Typography>
                  </Paper>

                  <Paper sx={{ p: 2, mb: 2 }}>
                    <Typography variant="h6" gutterBottom>Result</Typography>
                    <Typography>{selectedExample.result}</Typography>
                  </Paper>

                  <Box sx={{ mt: 3 }}>
                    <Typography variant="h6" gutterBottom>Keywords</Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                      {selectedExample.keywords.map((keyword, index) => (
                        <Chip
                          key={index}
                          label={keyword}
                          variant="outlined"
                        />
                      ))}
                    </Box>
                  </Box>
                </>
              )}
            </DialogContent>
            <DialogActions>
              {editMode ? (
                <>
                  <Button onClick={() => {
                    setEditMode(false);
                    setEditedExample(null);
                  }}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSaveExample}
                    variant="contained"
                    startIcon={<SaveIcon />}
                  >
                    Save Changes
                  </Button>
                </>
              ) : (
                <Button onClick={() => setSelectedExample(null)}>Close</Button>
              )}
            </DialogActions>
          </>
        )}
      </Dialog>

      <Dialog
        open={!!selectedCompetency}
        onClose={() => setSelectedCompetency(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedCompetency && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                {selectedCompetency.area}
                {getCompetencyIcon(selectedCompetency.area)}
              </Box>
            </DialogTitle>
            <DialogContent>
              <Typography variant="body1" paragraph>
                {selectedCompetency.description}
              </Typography>

              <Typography variant="h6" gutterBottom>Key Attributes</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {selectedCompetency.keyAttributes.map((attr, index) => (
                  <Chip
                    key={index}
                    label={attr}
                    variant="outlined"
                  />
                ))}
              </Box>

              <Typography variant="h6" gutterBottom>Common Questions</Typography>
              <List>
                {selectedCompetency.commonQuestions.map((question, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <AssignmentIcon />
                    </ListItemIcon>
                    <ListItemText primary={question} />
                  </ListItem>
                ))}
              </List>

              {selectedCompetency.tips && (
                <>
                  <Typography variant="h6" gutterBottom>Tips</Typography>
                  <List>
                    {selectedCompetency.tips.map((tip, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <StarIcon />
                        </ListItemIcon>
                        <ListItemText primary={tip} />
                      </ListItem>
                    ))}
                  </List>
                </>
              )}
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setSelectedCompetency(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};
