import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
  Divider,
  LinearProgress,
  IconButton,
  Tooltip,
  Collapse
} from '@mui/material';
import {
  Work as WorkIcon,
  Star as StarIcon,
  TrendingUp as TrendingUpIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Edit as EditIcon,
  Assessment as AssessmentIcon,
  CheckCircle as StrongIcon,
  RemoveCircle as WeakIcon,
  RadioButtonChecked as ModerateIcon
} from '@mui/icons-material';
import { ExperienceMapping as IExperienceMapping, StrengthLevel } from '../../../types/interview';

interface ExperienceMappingProps {
  interviewPrep: any;
  data: IExperienceMapping[] | null;
  onUpdate: (data: IExperienceMapping[]) => void;
}

export const ExperienceMapping: React.FC<ExperienceMappingProps> = ({
  interviewPrep,
  data,
  onUpdate
}) => {
  const [loading, setLoading] = useState(!data);
  const [mappings, setMappings] = useState<IExperienceMapping[] | null>(data);
  const [selectedMapping, setSelectedMapping] = useState<IExperienceMapping | null>(null);
  const [expandedMappings, setExpandedMappings] = useState<{ [key: string]: boolean }>({});

  useEffect(() => {
    if (!data) {
      fetchMappings();
    }
  }, [data]);

  const fetchMappings = async () => {
    try {
      const response = await fetch(`/api/interview-prep/${interviewPrep.id}/experience-mappings`);
      if (!response.ok) throw new Error('Failed to fetch mappings');
      
      const mappingsData = await response.json();
      setMappings(mappingsData);
      onUpdate(mappingsData);
    } catch (err) {
      console.error('Failed to fetch experience mappings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleExpand = (mappingId: string) => {
    setExpandedMappings(prev => ({
      ...prev,
      [mappingId]: !prev[mappingId]
    }));
  };

  const getStrengthIcon = (strength: StrengthLevel) => {
    switch (strength) {
      case 'strong':
        return <StrongIcon color="success" />;
      case 'moderate':
        return <ModerateIcon color="warning" />;
      case 'weak':
        return <WeakIcon color="error" />;
      default:
        return null;
    }
  };

  const getStrengthColor = (strength: StrengthLevel) => {
    switch (strength) {
      case 'strong':
        return 'success';
      case 'moderate':
        return 'warning';
      case 'weak':
        return 'error';
      default:
        return 'default';
    }
  };

  const renderExperience = (experience: any) => (
    <Card variant="outlined" sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{experience.role}</Typography>
          <Typography variant="body2" color="text.secondary">
            {experience.company}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {experience.duration}
        </Typography>
        <Typography variant="body1" sx={{ mt: 2 }}>
          {experience.description}
        </Typography>
        {experience.achievements && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle2">Key Achievements:</Typography>
            <List dense>
              {experience.achievements.map((achievement: string, index: number) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <StarIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary={achievement} />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
        {experience.skills && (
          <Box sx={{ mt: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {experience.skills.map((skill: string, index: number) => (
              <Chip
                key={index}
                label={skill}
                size="small"
                variant="outlined"
              />
            ))}
          </Box>
        )}
        <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
          Impact: {experience.impact}
        </Typography>
      </CardContent>
    </Card>
  );

  const renderMapping = (mapping: IExperienceMapping) => {
    const isExpanded = expandedMappings[mapping.id];

    return (
      <Card key={mapping.id} sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Typography variant="h6">{mapping.jobRequirement}</Typography>
              <Chip
                icon={getStrengthIcon(mapping.strengthLevel)}
                label={mapping.strengthLevel.charAt(0).toUpperCase() + mapping.strengthLevel.slice(1)}
                color={getStrengthColor(mapping.strengthLevel) as any}
                size="small"
              />
            </Box>
            <Box>
              <IconButton
                onClick={() => setSelectedMapping(mapping)}
                size="small"
              >
                <AssessmentIcon />
              </IconButton>
              <IconButton
                onClick={() => handleToggleExpand(mapping.id)}
                size="small"
              >
                {isExpanded ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Box>
          </Box>

          <Collapse in={isExpanded}>
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle1" gutterBottom>
                Relevant Experiences
              </Typography>
              {mapping.relevantExperiences.map((exp, index) => (
                <Box key={index} sx={{ mb: 2 }}>
                  {renderExperience(exp)}
                </Box>
              ))}

              {mapping.improvementSuggestions && mapping.improvementSuggestions.length > 0 && (
                <Box sx={{ mt: 2 }}>
                  <Typography variant="subtitle1" color="warning.main" gutterBottom>
                    Improvement Suggestions
                  </Typography>
                  <List dense>
                    {mapping.improvementSuggestions.map((suggestion, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <TrendingUpIcon color="warning" />
                        </ListItemIcon>
                        <ListItemText primary={suggestion} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </Box>
          </Collapse>
        </CardContent>
      </Card>
    );
  };

  const renderMappingDialog = () => (
    <Dialog
      open={!!selectedMapping}
      onClose={() => setSelectedMapping(null)}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>
        Requirement Analysis: {selectedMapping?.jobRequirement}
      </DialogTitle>
      <DialogContent>
        {selectedMapping && (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6">Strength Assessment</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 2 }}>
                  {getStrengthIcon(selectedMapping.strengthLevel)}
                  <Typography sx={{ ml: 1 }}>
                    {selectedMapping.strengthLevel.charAt(0).toUpperCase() + selectedMapping.strengthLevel.slice(1)} Match
                  </Typography>
                </Box>
              </Paper>
            </Grid>

            <Grid item xs={12}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6">Experience Coverage</Typography>
                <List>
                  {selectedMapping.relevantExperiences.map((exp, index) => (
                    <ListItem key={index}>
                      <ListItemIcon>
                        <WorkIcon />
                      </ListItemIcon>
                      <ListItemText
                        primary={`${exp.role} at ${exp.company}`}
                        secondary={exp.description}
                      />
                    </ListItem>
                  ))}
                </List>
              </Paper>
            </Grid>

            {selectedMapping.improvementSuggestions && (
              <Grid item xs={12}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="h6" color="warning.main">
                    Areas for Improvement
                  </Typography>
                  <List>
                    {selectedMapping.improvementSuggestions.map((suggestion, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <TrendingUpIcon color="warning" />
                        </ListItemIcon>
                        <ListItemText primary={suggestion} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              </Grid>
            )}
          </Grid>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={() => setSelectedMapping(null)}>Close</Button>
      </DialogActions>
    </Dialog>
  );

  if (loading) {
    return <LinearProgress />;
  }

  if (!mappings) {
    return (
      <Typography color="error">
        Failed to load experience mappings
      </Typography>
    );
  }

  return (
    <Box sx={{ mt: 3 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Typography variant="h5" gutterBottom>
            Experience Mapping Analysis
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            Analysis of how your experiences match the job requirements
          </Typography>
        </Grid>

        {/* Strong Matches */}
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom color="success.main">
            Strong Matches
          </Typography>
          {mappings
            .filter(m => m.strengthLevel === 'strong')
            .map(renderMapping)}
        </Grid>

        {/* Moderate Matches */}
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom color="warning.main">
            Moderate Matches
          </Typography>
          {mappings
            .filter(m => m.strengthLevel === 'moderate')
            .map(renderMapping)}
        </Grid>

        {/* Weak Matches */}
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom color="error.main">
            Areas Needing Improvement
          </Typography>
          {mappings
            .filter(m => m.strengthLevel === 'weak')
            .map(renderMapping)}
        </Grid>
      </Grid>

      {renderMappingDialog()}
    </Box>
  );
};
