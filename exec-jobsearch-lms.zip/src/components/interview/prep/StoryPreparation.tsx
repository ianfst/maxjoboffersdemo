import React, { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Rating,
  Tooltip,
  Paper
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Star as StarIcon,
  Help as HelpIcon
} from '@mui/icons-material';

interface StoryPreparationProps {
  onUpdate: (stories: any[]) => void;
}

interface Story {
  id: string;
  title: string;
  situation: string;
  task: string;
  action: string;
  result: string;
  metrics: string;
  category: string;
  competencies: string[];
  impact: number;
}

const COMPETENCIES = [
  'Strategic Leadership',
  'Change Management',
  'Team Building',
  'Innovation',
  'Financial Acumen',
  'Stakeholder Management',
  'Crisis Management',
  'Digital Transformation',
  'Global Operations',
  'Business Development'
];

const STORY_CATEGORIES = [
  'Leadership',
  'Innovation',
  'Crisis Management',
  'Growth & Scale',
  'Team Development',
  'Strategic Planning',
  'Change Management',
  'Technical Achievement',
  'Client Success',
  'Business Transformation'
];

export const StoryPreparation: React.FC<StoryPreparationProps> = ({ onUpdate }) => {
  const [stories, setStories] = useState<Story[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [currentStory, setCurrentStory] = useState<Partial<Story> | null>(null);
  const [selectedCompetencies, setSelectedCompetencies] = useState<string[]>([]);

  const handleDialogOpen = (story?: Story) => {
    if (story) {
      setCurrentStory(story);
      setSelectedCompetencies(story.competencies);
    } else {
      setCurrentStory({
        id: Math.random().toString(),
        impact: 3,
        competencies: []
      });
      setSelectedCompetencies([]);
    }
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
    setCurrentStory(null);
    setSelectedCompetencies([]);
  };

  const handleStoryChange = (field: keyof Story) => (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setCurrentStory(prev => ({
      ...prev,
      [field]: event.target.value
    }));
  };

  const handleCompetencyChange = (event: any) => {
    const value = event.target.value;
    setSelectedCompetencies(value);
    setCurrentStory(prev => ({
      ...prev,
      competencies: value
    }));
  };

  const handleSaveStory = () => {
    if (currentStory) {
      if (stories.find(s => s.id === currentStory.id)) {
        setStories(prev =>
          prev.map(story => (story.id === currentStory.id ? currentStory as Story : story))
        );
      } else {
        setStories(prev => [...prev, currentStory as Story]);
      }
      onUpdate([...stories, currentStory as Story]);
      handleDialogClose();
    }
  };

  const handleDeleteStory = (id: string) => {
    setStories(prev => prev.filter(story => story.id !== id));
    onUpdate(stories.filter(story => story.id !== id));
  };

  const renderStoryCard = (story: Story) => (
    <Card elevation={2} sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Typography variant="h6" gutterBottom>
            {story.title}
          </Typography>
          <Box>
            <IconButton onClick={() => handleDialogOpen(story)} size="small">
              <EditIcon />
            </IconButton>
            <IconButton onClick={() => handleDeleteStory(story.id)} size="small">
              <DeleteIcon />
            </IconButton>
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Chip
            label={story.category}
            color="primary"
            size="small"
            sx={{ mr: 1 }}
          />
          <Rating
            value={story.impact}
            readOnly
            size="small"
            icon={<StarIcon fontSize="inherit" />}
          />
        </Box>

        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" color="text.secondary">
              Situation
            </Typography>
            <Typography variant="body2" paragraph>
              {story.situation}
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" color="text.secondary">
              Task
            </Typography>
            <Typography variant="body2" paragraph>
              {story.task}
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" color="text.secondary">
              Action
            </Typography>
            <Typography variant="body2" paragraph>
              {story.action}
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" color="text.secondary">
              Result
            </Typography>
            <Typography variant="body2" paragraph>
              {story.result}
            </Typography>
          </Grid>
        </Grid>

        <Box sx={{ mt: 2 }}>
          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
            Key Metrics
          </Typography>
          <Typography variant="body2" color="success.main">
            {story.metrics}
          </Typography>
        </Box>

        <Box sx={{ mt: 2 }}>
          {story.competencies.map((comp, index) => (
            <Chip
              key={index}
              label={comp}
              size="small"
              variant="outlined"
              sx={{ mr: 0.5, mb: 0.5 }}
            />
          ))}
        </Box>
      </CardContent>
    </Card>
  );

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5">
          Story Preparation
          <Tooltip title="Prepare compelling STAR stories that demonstrate your executive capabilities">
            <IconButton size="small">
              <HelpIcon />
            </IconButton>
          </Tooltip>
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleDialogOpen()}
        >
          Add Story
        </Button>
      </Box>

      <Grid container spacing={3}>
        {stories.map((story) => (
          <Grid item xs={12} key={story.id}>
            {renderStoryCard(story)}
          </Grid>
        ))}
      </Grid>

      <Dialog open={openDialog} onClose={handleDialogClose} maxWidth="md" fullWidth>
        <DialogTitle>
          {currentStory?.id ? 'Edit Story' : 'Add New Story'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={8}>
                <TextField
                  fullWidth
                  label="Story Title"
                  value={currentStory?.title || ''}
                  onChange={handleStoryChange('title')}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
                  <InputLabel>Category</InputLabel>
                  <Select
                    value={currentStory?.category || ''}
                    onChange={handleStoryChange('category')}
                    label="Category"
                  >
                    {STORY_CATEGORIES.map((category) => (
                      <MenuItem key={category} value={category}>
                        {category}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Situation"
                  multiline
                  rows={2}
                  value={currentStory?.situation || ''}
                  onChange={handleStoryChange('situation')}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Task"
                  multiline
                  rows={2}
                  value={currentStory?.task || ''}
                  onChange={handleStoryChange('task')}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Action"
                  multiline
                  rows={2}
                  value={currentStory?.action || ''}
                  onChange={handleStoryChange('action')}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Result"
                  multiline
                  rows={2}
                  value={currentStory?.result || ''}
                  onChange={handleStoryChange('result')}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Key Metrics"
                  value={currentStory?.metrics || ''}
                  onChange={handleStoryChange('metrics')}
                  placeholder="e.g., Increased revenue by 25%, Reduced costs by $2M"
                />
              </Grid>

              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Competencies</InputLabel>
                  <Select
                    multiple
                    value={selectedCompetencies}
                    onChange={handleCompetencyChange}
                    renderValue={(selected) => (
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {selected.map((value) => (
                          <Chip key={value} label={value} size="small" />
                        ))}
                      </Box>
                    )}
                  >
                    {COMPETENCIES.map((competency) => (
                      <MenuItem key={competency} value={competency}>
                        {competency}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <Typography component="legend">Impact Level</Typography>
                <Rating
                  value={currentStory?.impact || 3}
                  onChange={(event, newValue) => {
                    setCurrentStory(prev => ({
                      ...prev,
                      impact: newValue || 3
                    }));
                  }}
                />
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose}>Cancel</Button>
          <Button
            onClick={handleSaveStory}
            variant="contained"
            disabled={!currentStory?.title || !currentStory?.situation}
          >
            Save Story
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
