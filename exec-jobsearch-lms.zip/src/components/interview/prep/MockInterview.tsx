import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
  LinearProgress,
  IconButton,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Rating,
  TextField,
  CircularProgress,
  Alert,
  Tooltip,
  Divider,
  Stack
} from '@mui/material';
import {
  Mic as MicIcon,
  Stop as StopIcon,
  PlayArrow as PlayIcon,
  Pause as PauseIcon,
  Save as SaveIcon,
  Assessment as AssessmentIcon,
  CheckCircle as CheckIcon,
  Warning as WarningIcon,
  Timer as TimerIcon,
  Videocam as VideoIcon,
  VideocamOff as VideoOffIcon,
  Psychology as AIIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import { MockInterview as IMockInterview, PracticeQuestion, InterviewFeedback } from '../../../types/interview';

interface MockInterviewProps {
  interviewPrep: any;
  data: IMockInterview[] | null;
  onUpdate: (data: IMockInterview[]) => void;
}

export const MockInterview: React.FC<MockInterviewProps> = ({
  interviewPrep,
  data,
  onUpdate
}) => {
  const [loading, setLoading] = useState(!data);
  const [interviews, setInterviews] = useState<IMockInterview[] | null>(data);
  const [activeInterview, setActiveInterview] = useState<IMockInterview | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<PracticeQuestion | null>(null);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState<InterviewFeedback | null>(null);
  const [timer, setTimer] = useState<number>(0);
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [processingAnswer, setProcessingAnswer] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!data && interviewPrep?.id) {
      fetchInterviews();
    }
  }, [data, interviewPrep]);

  useEffect(() => {
    return () => {
      stopRecording();
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const fetchInterviews = async () => {
    try {
      if (!interviewPrep?.id) {
        throw new Error('Interview prep ID is required');
      }
      const baseUrl = window.location.origin;
      const response = await fetch(`${baseUrl}/api/interview-prep/${interviewPrep.id}/mock-interviews`);
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to fetch interviews: ${errorText}`);
      }
      
      const interviewsData = await response.json();
      setInterviews(interviewsData);
      onUpdate(interviewsData);
    } catch (err) {
      console.error('Failed to fetch mock interviews:', err);
      setError(err instanceof Error ? err.message : 'Failed to load mock interviews');
    } finally {
      setLoading(false);
    }
  };

  const startNewInterview = async (type: 'technical' | 'behavioral' | 'mixed') => {
    try {
      const baseUrl = window.location.origin;
      const response = await fetch(`${baseUrl}/api/interview-prep/${interviewPrep.id}/mock-interviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ type }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to create interview: ${errorText}`);
      }

      const newInterview = await response.json();
      setActiveInterview(newInterview);
      setCurrentQuestion(newInterview.questions[0]);
    } catch (err) {
      console.error('Failed to start new interview:', err);
      setError(err instanceof Error ? err.message : 'Failed to start interview');
    }
  };

  const startRecording = async () => {
    try {
      const constraints = {
        audio: true,
        video: videoEnabled
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoEnabled && videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        await saveRecording(blob);
      };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);

      // Start timer
      timerRef.current = setInterval(() => {
        setTimer(t => t + 1);
      }, 1000);
    } catch (err) {
      console.error('Failed to start recording:', err);
      setError('Failed to start recording');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    setIsRecording(false);
    setTimer(0);
  };

  const saveRecording = async (blob: Blob) => {
    if (!activeInterview || !currentQuestion) return;

    try {
      const formData = new FormData();
      formData.append('recording', blob);
      formData.append('interviewId', activeInterview.id);
      formData.append('questionId', currentQuestion.id);

      const response = await fetch('/api/interview-prep/save-recording', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) throw new Error('Failed to save recording');
    } catch (err) {
      console.error('Failed to save recording:', err);
      setError('Failed to save recording');
    }
  };

  const submitAnswer = async () => {
    if (!activeInterview || !currentQuestion) return;

    setProcessingAnswer(true);
    try {
      const baseUrl = window.location.origin;
      const response = await fetch(`${baseUrl}/api/interview-prep/${activeInterview.id}/feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          questionId: currentQuestion.id,
          answer
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to submit answer: ${errorText}`);
      }

      const feedbackData = await response.json();
      setFeedback(feedbackData);
    } catch (err) {
      console.error('Failed to submit answer:', err);
      setError(err instanceof Error ? err.message : 'Failed to get feedback');
    } finally {
      setProcessingAnswer(false);
    }
  };

  const nextQuestion = () => {
    if (!activeInterview || !currentQuestion) return;

    const currentIndex = activeInterview.questions.findIndex(q => q.id === currentQuestion.id);
    if (currentIndex < activeInterview.questions.length - 1) {
      setCurrentQuestion(activeInterview.questions[currentIndex + 1]);
      setAnswer('');
      setFeedback(null);
    } else {
      finishInterview();
    }
  };

  const finishInterview = async () => {
    if (!activeInterview) return;

    try {
      const baseUrl = window.location.origin;
      const response = await fetch(`${baseUrl}/api/interview-prep/${activeInterview.id}/complete`, {
        method: 'POST'
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to complete interview: ${errorText}`);
      }

      const updatedInterview = await response.json();
      setInterviews(prev => prev ? [...prev, updatedInterview] : [updatedInterview]);
      setActiveInterview(null);
      setCurrentQuestion(null);
    } catch (err) {
      console.error('Failed to complete interview:', err);
      setError(err instanceof Error ? err.message : 'Failed to complete interview');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const renderInterviewCard = (interview: IMockInterview) => (
    <Card key={interview.id} sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">
            {new Date(interview.date).toLocaleDateString()} Interview
          </Typography>
          <Chip
            label={interview.type}
            color={
              interview.type === 'technical' ? 'primary' :
              interview.type === 'behavioral' ? 'secondary' : 'default'
            }
          />
        </Box>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary">
            Duration: {Math.floor(interview.duration / 60)} minutes
          </Typography>
          {interview.overallScore && (
            <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
              <Typography variant="body2" sx={{ mr: 1 }}>Score:</Typography>
              <Rating value={interview.overallScore / 20} readOnly precision={0.5} />
            </Box>
          )}
        </Box>
      </CardContent>
    </Card>
  );

  const renderActiveInterview = () => (
    <Box>
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h5">
            Current Question ({currentQuestion?.category})
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Chip
              icon={<TimerIcon />}
              label={formatTime(timer)}
              color="primary"
            />
            <IconButton
              onClick={() => setVideoEnabled(!videoEnabled)}
              color={videoEnabled ? 'primary' : 'default'}
            >
              {videoEnabled ? <VideoIcon /> : <VideoOffIcon />}
            </IconButton>
          </Box>
        </Box>

        <Typography variant="h6" gutterBottom>
          {currentQuestion?.question}
        </Typography>

        {videoEnabled && (
          <Box sx={{ width: '100%', maxWidth: 640, mx: 'auto', my: 3 }}>
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              style={{ width: '100%', borderRadius: 8 }}
            />
          </Box>
        )}

        <TextField
          fullWidth
          multiline
          rows={6}
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Type your answer here..."
          disabled={isRecording || processingAnswer}
          aria-label="response"
          sx={{ mt: 2 }}
        />

        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
          <Box>
            <Button
              variant="contained"
              color={isRecording ? 'error' : 'primary'}
              startIcon={isRecording ? <StopIcon /> : <MicIcon />}
              onClick={isRecording ? stopRecording : startRecording}
              aria-label={isRecording ? 'Stop Recording' : 'Record Video'}
              sx={{ mr: 1 }}
            >
              {isRecording ? 'Stop Recording' : 'Start Recording'}
            </Button>
          </Box>
          <Box>
            <Button
              variant="contained"
              onClick={submitAnswer}
              disabled={!answer || isRecording || processingAnswer}
              startIcon={processingAnswer ? <CircularProgress size={20} /> : <AIIcon />}
              aria-label="Submit Response"
              sx={{ mr: 1 }}
            >
              Get AI Feedback
            </Button>
            <Button
              variant="contained"
              onClick={nextQuestion}
              disabled={!feedback}
              aria-label="Next Question"
            >
              Next Question
            </Button>
          </Box>
        </Box>
      </Paper>

      {feedback && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Feedback
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Typography variant="body1">
                {feedback.feedback}
              </Typography>
            </Grid>

            <Grid item xs={12} md={6}>
              <List>
                <Typography variant="subtitle1" color="success.main" gutterBottom>
                  Strengths
                </Typography>
                {feedback.strengths.map((strength, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <CheckIcon color="success" />
                    </ListItemIcon>
                    <ListItemText primary={strength} />
                  </ListItem>
                ))}
              </List>
            </Grid>

            <Grid item xs={12} md={6}>
              <List>
                <Typography variant="subtitle1" color="warning.main" gutterBottom>
                  Areas for Improvement
                </Typography>
                {feedback.improvements.map((improvement, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <WarningIcon color="warning" />
                    </ListItemIcon>
                    <ListItemText primary={improvement} />
                  </ListItem>
                ))}
              </List>
            </Grid>

            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Typography>Score:</Typography>
                <Rating value={feedback.score / 20} readOnly precision={0.5} />
                <Typography>({feedback.score}/100)</Typography>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      )}
    </Box>
  );

  if (loading) {
    return <LinearProgress />;
  }

  return (
    <Box sx={{ mt: 3 }}>
      {!activeInterview ? (
        <>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h5">Mock Interviews</Typography>
            <Box>
              <Button
                variant="contained"
                onClick={() => startNewInterview('technical')}
                aria-label="Technical Interview"
                sx={{ mr: 1 }}
              >
                Technical Interview
              </Button>
              <Button
                variant="contained"
                onClick={() => startNewInterview('behavioral')}
                aria-label="Behavioral Interview"
                sx={{ mr: 1 }}
              >
                Behavioral Interview
              </Button>
              <Button
                variant="contained"
                onClick={() => startNewInterview('mixed')}
                aria-label="Mixed Interview"
              >
                Mixed Interview
              </Button>
            </Box>
          </Box>

          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Typography variant="h6" gutterBottom>
                Previous Interviews
              </Typography>
              {interviews && interviews.length > 0 ? (
                interviews.map(renderInterviewCard)
              ) : (
                <Typography color="text.secondary">
                  No previous interviews found. Start a new interview to practice!
                </Typography>
              )}
            </Grid>

            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Interview Stats
                </Typography>
                {interviews && interviews.length > 0 ? (
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Total Interviews
                      </Typography>
                      <Typography variant="h4">
                        {interviews.length}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Average Score
                      </Typography>
                      <Typography variant="h4">
                        {Math.round(
                          interviews.reduce((acc, int) => acc + (int.overallScore || 0), 0) / 
                          interviews.length
                        )}%
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Total Practice Time
                      </Typography>
                      <Typography variant="h4">
                        {Math.round(
                          interviews.reduce((acc, int) => acc + int.duration, 0) / 60
                        )} mins
                      </Typography>
                    </Box>
                  </Stack>
                ) : (
                  <Typography color="text.secondary">
                    No statistics available yet
                  </Typography>
                )}
              </Paper>
            </Grid>
          </Grid>
        </>
      ) : (
        renderActiveInterview()
      )}

      {error && (
        <Alert
          severity="error"
          onClose={() => setError(null)}
          sx={{ mt: 2 }}
        >
          {error}
        </Alert>
      )}
    </Box>
  );
};
