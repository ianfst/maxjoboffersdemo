import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  LinearProgress,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Paper,
  Tab,
  Tabs,
  Chip,
  Button
} from '@mui/material';
import {
  TrendingUp as TrendingUpIcon,
  CheckCircle as CheckIcon,
  Warning as WarningIcon,
  Assessment as AssessmentIcon,
  Timeline as TimelineIcon
} from '@mui/icons-material';

import { FeedbackAnalysis as IFeedbackAnalysis } from '../../../types/interview';

interface FeedbackAnalysisProps {
  interviewPrep: any;
  data: IFeedbackAnalysis | null;
  onUpdate: (data: IFeedbackAnalysis) => void;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`feedback-tabpanel-${index}`}
      aria-labelledby={`feedback-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

export const FeedbackAnalysis: React.FC<FeedbackAnalysisProps> = ({
  interviewPrep,
  data,
  onUpdate
}) => {
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<IFeedbackAnalysis | null>(data);
  const [tabValue, setTabValue] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (data) {
      setFeedback(data);
      setLoading(false);
    }
  }, [data]);

  const fetchFeedback = async () => {
    try {
      const response = await fetch(`/api/interview-prep/${interviewPrep.id}/feedback/analyze`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Failed to fetch feedback: ${errorData.error || response.statusText}`);
      }
      
      const feedbackData = await response.json();
      setFeedback(feedbackData);
      onUpdate(feedbackData);
    } catch (err) {
      console.error('Failed to fetch feedback analysis:', err);
      setError(err instanceof Error ? err.message : 'Failed to analyze feedback');
      setFeedback(null);
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError(null);
    await fetchFeedback();
  };

  if (!feedback) {
    return (
      <Box sx={{ mt: 2 }}>
        <Typography variant="h5" gutterBottom>
          Feedback Analysis
        </Typography>
        <Box sx={{ mt: 2 }}>
          <Button
            variant="contained"
            onClick={handleAnalyze}
            disabled={loading}
            startIcon={<AssessmentIcon />}
          >
            {loading ? 'Analyzing feedback...' : 'Analyze Feedback'}
          </Button>
          {loading && (
            <Box sx={{ mt: 2 }}>
              <LinearProgress />
            </Box>
          )}
          {error && (
            <Typography color="error" sx={{ mt: 2 }}>
              {error}
            </Typography>
          )}
        </Box>
      </Box>
    );
  }



  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const renderPerformanceMetrics = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={4}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Overall Score
            </Typography>
            <Typography variant="h3" color="primary">
              {feedback?.overallScore}%
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Based on {feedback?.totalInterviews} interviews
            </Typography>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Category Performance
            </Typography>
            <Grid container spacing={2}>
              {feedback?.categoryScores.map((category) => (
                <Grid item xs={12} sm={6} md={4} key={category.name}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1">
                      {category.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                      <Box sx={{ flexGrow: 1, mr: 1 }}>
                        <LinearProgress
                          variant="determinate"
                          value={category.score}
                          sx={{ height: 8, borderRadius: 4 }}
                        />
                      </Box>
                      <Typography variant="body2">
                        {category.score}%
                      </Typography>
                    </Box>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderImprovementSuggestions = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom color="success.main">
              Strengths
            </Typography>
            <List>
              {feedback?.strengths.map((strength, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <CheckIcon color="success" />
                  </ListItemIcon>
                  <ListItemText primary={strength} />
                </ListItem>
              ))}
            </List>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom color="warning.main">
              Areas for Improvement
            </Typography>
            <List>
              {feedback?.improvements.map((improvement, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <WarningIcon color="warning" />
                  </ListItemIcon>
                  <ListItemText primary={improvement} />
                </ListItem>
              ))}
            </List>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  return (
    <Box sx={{ width: '100%' }}>
      <Tabs
        value={tabValue}
        onChange={handleTabChange}
        aria-label="feedback analysis tabs"
        sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}
      >
        <Tab
          icon={<AssessmentIcon />}
          label="Performance"
          id="feedback-tab-0"
        />
        <Tab
          icon={<TimelineIcon />}
          label="Improvements"
          id="feedback-tab-1"
        />
      </Tabs>

      <TabPanel value={tabValue} index={0}>
        {renderPerformanceMetrics()}
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        {renderImprovementSuggestions()}
      </TabPanel>
    </Box>
  );
};
