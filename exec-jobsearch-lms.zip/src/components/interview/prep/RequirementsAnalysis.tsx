import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Rating,
  LinearProgress,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
  Divider
} from '@mui/material';
import {
  Check as CheckIcon,
  Close as CloseIcon,
  Warning as WarningIcon,
  TrendingUp as TrendingUpIcon,
  School as SchoolIcon,
  WorkHistory as WorkIcon,
  Star as StarIcon
} from '@mui/icons-material';
import { RequirementsAnalysis as IRequirementsAnalysis, SkillMatch, ExperienceRequirement } from '../../../types/interview';

interface RequirementsAnalysisProps {
  interviewPrep: any;
  data: IRequirementsAnalysis | null;
  onUpdate: (data: IRequirementsAnalysis) => void;
}

export const RequirementsAnalysis: React.FC<RequirementsAnalysisProps> = ({
  interviewPrep,
  data,
  onUpdate
}) => {
  const [loading, setLoading] = useState(!data);
  const [analysis, setAnalysis] = useState<IRequirementsAnalysis | null>(data);
  const [selectedSkill, setSelectedSkill] = useState<SkillMatch | null>(null);
  const [selectedExperience, setSelectedExperience] = useState<ExperienceRequirement | null>(null);

  useEffect(() => {
    if (!data) {
      fetchAnalysis();
    }
  }, [data]);

  const fetchAnalysis = async () => {
    try {
      const response = await fetch(`/api/interview-prep/${interviewPrep.id}/requirements-analysis`);
      if (!response.ok) throw new Error('Failed to fetch analysis');
      
      const analysisData = await response.json();
      setAnalysis(analysisData);
      onUpdate(analysisData);
    } catch (err) {
      console.error('Failed to fetch requirements analysis:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderSkillMatch = (skill: SkillMatch) => (
    <Card
      key={skill.skill}
      variant="outlined"
      sx={{
        mb: 2,
        cursor: 'pointer',
        '&:hover': { bgcolor: 'action.hover' }
      }}
      onClick={() => setSelectedSkill(skill)}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{skill.skill}</Typography>
          <Chip
            icon={skill.matched ? <CheckIcon /> : <CloseIcon />}
            label={skill.matched ? 'Matched' : 'Not Matched'}
            color={skill.matched ? 'success' : 'error'}
            size="small"
          />
        </Box>
        {skill.proficiencyLevel && (
          <Box sx={{ mt: 1 }}>
            <Typography component="legend" variant="body2">Proficiency</Typography>
            <Rating value={skill.proficiencyLevel} readOnly precision={0.5} />
          </Box>
        )}
        {skill.yearsOfExperience && (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            {skill.yearsOfExperience} years of experience
          </Typography>
        )}
      </CardContent>
    </Card>
  );

  const renderExperienceRequirement = (exp: ExperienceRequirement) => (
    <Card
      key={exp.area}
      variant="outlined"
      sx={{
        mb: 2,
        cursor: 'pointer',
        '&:hover': { bgcolor: 'action.hover' }
      }}
      onClick={() => setSelectedExperience(exp)}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">{exp.area}</Typography>
          <Chip
            icon={exp.matched ? <CheckIcon /> : <CloseIcon />}
            label={exp.matched ? 'Matched' : 'Not Matched'}
            color={exp.matched ? 'success' : 'error'}
            size="small"
          />
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {exp.yearsRequired} years required
        </Typography>
        {exp.relevantExperience && (
          <List dense>
            {exp.relevantExperience.map((experience, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <WorkIcon fontSize="small" />
                </ListItemIcon>
                <ListItemText primary={experience} />
              </ListItem>
            ))}
          </List>
        )}
      </CardContent>
    </Card>
  );

  const renderSkillDialog = () => (
    <Dialog
      open={!!selectedSkill}
      onClose={() => setSelectedSkill(null)}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>Skill Analysis: {selectedSkill?.skill}</DialogTitle>
      <DialogContent>
        {selectedSkill && (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6">Proficiency Details</Typography>
                <Box sx={{ mt: 2 }}>
                  <Typography component="legend">Current Level</Typography>
                  <Rating value={selectedSkill.proficiencyLevel || 0} readOnly precision={0.5} />
                </Box>
                {selectedSkill.yearsOfExperience && (
                  <Typography sx={{ mt: 2 }}>
                    Years of Experience: {selectedSkill.yearsOfExperience}
                  </Typography>
                )}
                {selectedSkill.lastUsed && (
                  <Typography sx={{ mt: 1 }}>
                    Last Used: {new Date(selectedSkill.lastUsed).toLocaleDateString()}
                  </Typography>
                )}
              </Paper>
            </Grid>
            
            {selectedSkill.relevantExperience && (
              <Grid item xs={12}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="h6">Relevant Experience</Typography>
                  <List>
                    {selectedSkill.relevantExperience.map((exp, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <WorkIcon />
                        </ListItemIcon>
                        <ListItemText primary={exp} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              </Grid>
            )}
          </Grid>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={() => setSelectedSkill(null)}>Close</Button>
      </DialogActions>
    </Dialog>
  );

  if (loading) {
    return <LinearProgress />;
  }

  if (!analysis) {
    return (
      <Typography variant="body1" color="error">
        Failed to load requirements analysis
      </Typography>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Overall Match Score */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Requirements Analysis
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6" sx={{ mr: 2 }}>
            Overall Match:
          </Typography>
          <Typography variant="h6" color={analysis.overallMatch >= 0.7 ? 'success.main' : 'warning.main'}>
            {Math.round(analysis.overallMatch * 100)}%
          </Typography>
        </Box>
      </Box>

      <Grid container spacing={4}>
        {/* Skill Matches */}
        <Grid item xs={12} md={6}>
          <Typography variant="h5" gutterBottom>
            Skills
          </Typography>
          {analysis.skillMatches.map(renderSkillMatch)}
        </Grid>

        {/* Experience Requirements */}
        <Grid item xs={12} md={6}>
          <Typography variant="h5" gutterBottom>
            Experience
          </Typography>
          {analysis.experienceRequirements.map(renderExperienceRequirement)}
        </Grid>

        {/* Recommendations */}
        <Grid item xs={12}>
          <Typography variant="h5" gutterBottom>
            Recommendations
          </Typography>
          <Paper sx={{ p: 2 }}>
            <List>
              {analysis.recommendations.map((recommendation, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <TrendingUpIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText primary={recommendation} />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
      </Grid>

      {/* Skill Details Dialog */}
      {renderSkillDialog()}
    </Box>
  );
};
