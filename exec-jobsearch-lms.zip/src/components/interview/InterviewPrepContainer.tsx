import React, { useState, useEffect } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Typography,
  Card,
  CardContent,
  LinearProgress,
  Grid,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  Rating,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import {
  Save as SaveIcon,
  Help as HelpIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Check as CheckIcon,
  Warning as WarningIcon,
  Psychology as ToneIcon,
  Assessment as AssessmentIcon,
  Style as StyleIcon,
  Person as BehavioralIcon
} from '@mui/icons-material';
import { CompanyResearch } from './prep/CompanyResearch';
import { PositionAnalysis } from './prep/PositionAnalysis';
import { StoryPreparation } from './prep/StoryPreparation';
import { PracticeSession } from './prep/PracticeSession';
import { FeedbackAnalysis } from './prep/FeedbackAnalysis';
import { InterviewStrategy } from './prep/InterviewStrategy';
import { RequirementsAnalysis } from './prep/RequirementsAnalysis';
import { ExperienceMapping } from './prep/ExperienceMapping';
import { MockInterview } from './prep/MockInterview';
import { TechnicalPrep } from './prep/TechnicalPrep';
import { BehavioralPrep } from './prep/BehavioralPrep';
import { InterviewPrep, RequirementsAnalysis as IRequirementsAnalysis, BehavioralPrep as IBehavioralPrep } from '../../types/interview';
import { validateResponse, validateInterviewPrep, handleApiError } from '../../utils/api';

const API_BASE_URL = 'http://localhost:3000/api';

interface PrepStep {
  label: string;
  description: string;
  component: React.ComponentType<any>;
  completed: boolean;
  data: any;
  disabled?: boolean;
}

type Props = {
  jobId: string;
  resumeId: string;
};

export default function InterviewPrepContainer({ jobId, resumeId }: Props) {
  const [activeStep, setActiveStep] = useState(0);
  const [interviewPrep, setInterviewPrep] = useState<InterviewPrep | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [steps, setSteps] = useState<PrepStep[]>([
    {
      label: 'Requirements Analysis',
      description: 'Analyze job requirements and match with your profile',
      component: RequirementsAnalysis,
      completed: false,
      data: null
    },
    {
      label: 'Experience Mapping',
      description: 'Map your experiences to job requirements',
      component: ExperienceMapping,
      completed: false,
      data: null,
      disabled: true
    },
    {
      label: 'Behavioral Preparation',
      description: 'Prepare STAR examples and competency areas',
      component: BehavioralPrep,
      completed: false,
      data: null,
      disabled: true
    },
    {
      label: 'Technical Preparation',
      description: 'Prepare for technical questions and challenges',
      component: TechnicalPrep,
      completed: false,
      data: null,
      disabled: true
    },
    {
      label: 'Company Research',
      description: 'Analyze company background, culture, and market position',
      component: CompanyResearch,
      completed: false,
      data: null,
      disabled: true
    },
    {
      label: 'Practice Session',
      description: 'Practice with AI-powered mock interviews',
      component: MockInterview,
      completed: false,
      data: null,
      disabled: true
    },
    {
      label: 'Feedback Analysis',
      description: 'Review performance and get AI insights',
      component: FeedbackAnalysis,
      completed: false,
      data: null,
      disabled: true
    },
    {
      label: 'Interview Strategy',
      description: 'Finalize your interview approach',
      component: InterviewStrategy,
      completed: false,
      data: null,
      disabled: true
    }
  ]);

  const [overallProgress, setOverallProgress] = useState(0);
  const [openSummary, setOpenSummary] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    initializeInterviewPrep();
  }, [jobId, resumeId]);

  const initializeInterviewPrep = async () => {
    if (loading) return; // Prevent multiple initialization

    setLoading(true);
    setError(null);
    setInitialized(false);
    setOverallProgress(0);
    setActiveStep(0);
    setInterviewPrep(null);

    if (!jobId || !resumeId) {
      setError('Missing required job or resume ID');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/interview-prep/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ jobId, resumeId }),
      });

      const data = await validateResponse(response);
      
      if (!data.interviewPrep) {
        throw new Error('Invalid interview prep data received from server');
      }

      const { interviewPrep } = data;

      // Reset all steps to initial state
      setSteps(prevSteps => prevSteps.map(step => {
        const stepKey = getStepKey(step.label);
        const stepData = interviewPrep.steps[stepKey];
        return {
          ...step,
          completed: stepData?.status === 'completed',
          data: stepData?.data || null,
          disabled: !isStepAccessible(prevSteps.findIndex(s => s.label === step.label))
        };
      }));

      setInterviewPrep(interviewPrep);
      setInitialized(true);
      setLoading(false);
    } catch (err) {
      clearTimeout(timeoutId);
      abortController = null;

      let errorMessage = 'Failed to initialize interview preparation';
      let retryable = false;
      
      if (err instanceof Error) {
        if ('status' in err) {
          const status = (err as any).status;
          retryable = status >= 500 || status === 429 || status === 503;
          
          switch (status) {
            case 400:
              errorMessage = `Invalid request: ${err.message}`;
              break;
            case 401:
              errorMessage = 'Session expired, please refresh';
              break;
            case 403:
              errorMessage = 'Access denied';
              break;
            case 404:
              errorMessage = 'Resource not found';
              break;
            case 409:
              errorMessage = 'Conflict detected, please try again';
              break;
            case 429:
              errorMessage = 'Too many requests, please wait';
              break;
            default:
              if (status >= 500) {
                errorMessage = `Server error: ${err.message}`;
              }
          }
        } else if (err.name === 'AbortError') {
          errorMessage = 'Initialization timed out';
          retryable = true;
        } else {
          errorMessage = err.message;
        }
      }
      
      console.error('Failed to initialize interview prep:', errorMessage);
      setError(errorMessage);
      
      // Reset component state
      setSteps(prevSteps => prevSteps.map(step => ({
        ...step,
        completed: false,
        data: null,
        loading: false,
        error: null,
        disabled: true
      })));
      setInterviewPrep(null);
      setInitialized(false);

      // Auto-retry for server errors
      if (retryable) {
        setTimeout(() => {
          if (!initialized) { // Only retry if still not initialized
            initializeInterviewPrep();
          }
        }, 3000);
      }
    }
  };

  // Handle progress updates
  useEffect(() => {
    if (!initialized || loading) {
      setOverallProgress(0);
      return;
    }
    const completed = steps.filter(step => step.completed).length;
    setOverallProgress(Math.floor((completed / steps.length) * 100));
  }, [steps, loading, initialized]);

  const handleNext = () => {
    if (!initialized || loading) return;
    const nextStep = activeStep + 1;
    if (nextStep < steps.length && isStepCompleted(activeStep)) {
      setActiveStep(nextStep);
    }
  };

  const handleBack = () => {
    if (activeStep > 0 && initialized) {
      setActiveStep(activeStep - 1);
    }
  };

  const getStepKey = (label: string) => {
    switch (label) {
      case 'Requirements Analysis': return 'requirements-analysis';
      case 'Experience Mapping': return 'experience-mapping';
      case 'Behavioral Preparation': return 'behavioral-prep';
      case 'Technical Preparation': return 'technical-prep';
      case 'Company Research': return 'company-research';
      case 'Practice Session': return 'mock-interview';
      case 'Feedback Analysis': return 'feedback-analysis';
      case 'Interview Strategy': return 'interview-strategy';
      default: return label.toLowerCase().replace(/\s+/g, '-');
    }
  };

  const handleStepComplete = async (stepIndex: number, stepData: any) => {
    if (!interviewPrep?.id || !initialized) {
      setError('Cannot update step: interview prep not initialized');
      return;
    }

    // Prevent concurrent operations on the same step
    if (steps[stepIndex].loading) {
      console.warn('Step operation already in progress');
      return;
    }

    // Update loading state for this step
    setSteps(prevSteps => {
      const newSteps = [...prevSteps];
      newSteps[stepIndex] = { ...newSteps[stepIndex], loading: true, error: null };
      return newSteps;
    });

    let abortController: AbortController | null = new AbortController();
    const timeoutId = setTimeout(() => {
      if (abortController) {
        abortController.abort();
        abortController = null;
      }
    }, 30000); // 30s timeout

    try {
      const stepLabel = steps[stepIndex].label;
      const stepKey = getStepKey(stepLabel);

      // Validate step data
      if (!stepData || typeof stepData !== 'object') {
        throw new ApiError('Invalid step data', 400, { error: 'VALIDATION_ERROR' });
      }

      const response = await fetch(`${API_BASE_URL}/interview-prep/${interviewPrep.id}/steps/${stepKey}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ data: stepData }),
        signal: abortController?.signal
      });

      clearTimeout(timeoutId);
      const updatedData = await validateResponse(response);
      
      if (!updatedData.interviewPrep) {
        throw new Error('Invalid response: missing interview prep data');
      }

      // Update interview prep state
      setInterviewPrep(updatedData.interviewPrep);

      // Update step states
      setSteps(prevSteps => {
        const updatedSteps = prevSteps.map((step, idx) => {
          const stepKey = getStepKey(step.label);
          const stepData = updatedData.interviewPrep.steps[stepKey];
          return {
            ...step,
            completed: stepData?.status === 'completed',
            data: stepData?.data || null,
            loading: false,
            error: null,
            disabled: !isStepAccessible(idx)
          };
        });

        // Enable next step if available
        if (stepIndex < updatedSteps.length - 1) {
          updatedSteps[stepIndex + 1].disabled = false;
        }

        return updatedSteps;
      });

      // Update progress
      const completedCount = steps.filter(s => s.completed).length;
      setOverallProgress((completedCount / steps.length) * 100);

      // Move to next step if available
      if (stepIndex < steps.length - 1) {
        setActiveStep(stepIndex + 1);
      }
    } catch (err) {
      clearTimeout(timeoutId);
      abortController = null;

      let errorMessage = 'Failed to save step progress';
      let retryable = false;

      if (err instanceof Error) {
        if ('status' in err) {
          const status = (err as any).status;
          retryable = status >= 500 || status === 429 || status === 503;

          switch (status) {
            case 400:
              errorMessage = `Invalid data: ${err.message}`;
              break;
            case 401:
              errorMessage = 'Session expired, please refresh';
              break;
            case 403:
              errorMessage = 'Access denied';
              break;
            case 404:
              errorMessage = 'Step not found';
              break;
            case 409:
              errorMessage = 'Step was modified elsewhere';
              break;
            case 429:
              errorMessage = 'Too many requests, please wait';
              break;
            default:
              if (status >= 500) {
                errorMessage = `Server error: ${err.message}`;
              }
          }
        } else if (err.name === 'AbortError') {
          errorMessage = 'Operation timed out';
          retryable = true;
        } else {
          errorMessage = err.message;
        }
      }

      console.error('Step completion failed:', errorMessage);
      
      // Update step error state
      setSteps(prevSteps => {
        const newSteps = [...prevSteps];
        newSteps[stepIndex] = {
          ...newSteps[stepIndex],
          loading: false,
          error: errorMessage
        };
        return newSteps;
      });

      setError(errorMessage);

      // Auto-retry for server errors
      if (retryable) {
        setTimeout(() => {
          if (steps[stepIndex].error === errorMessage) { // Only retry if error hasn't changed
            handleStepComplete(stepIndex, stepData);
          }
        }, 3000);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleStepClick = (step: number) => {
    if (!initialized || loading) return;
    if (canNavigateToStep(step)) {
      setActiveStep(step);
    }
  };

  const handleSaveProgress = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/interview-prep/${interviewPrep?.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ steps: steps.map(s => ({ label: s.label, data: s.data })) }),
      });

      await validateResponse(response);
    } catch (err) {
      const errorMessage = await handleApiError(err);
      console.error('Failed to save progress:', errorMessage);
      setError(`Failed to save progress: ${errorMessage}`);
    }
  };

  const generatePreparationReport = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/interview-prep/${interviewPrep?.id}/report`, {
        method: 'GET',
      });

      await validateResponse(response);

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = 'interview-prep-report.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      const errorMessage = await handleApiError(err);
      console.error('Failed to generate report:', errorMessage);
      setError(`Failed to generate report: ${errorMessage}`);
    }
  };

  const isStepAccessible = (stepIndex: number) => {
    return stepIndex === 0 || (stepIndex > 0 && steps[stepIndex - 1].completed);
  };

  const renderStepContent = (step: number) => {
    const currentStep = steps[step];
    if (!currentStep || !initialized) {
      return null;
    }

    const stepId = getStepKey(currentStep.label);
    const StepComponent = currentStep.component;
    const isCurrentStepAccessible = step === 0 || (step > 0 && steps[step - 1].completed);

    return (
      <Box data-testid={stepId}>
        <StepComponent
          onComplete={(data: any) => handleStepComplete(step, data)}
          data={currentStep.data}
          interviewPrep={interviewPrep}
          disabled={!isCurrentStepAccessible || !initialized}
        />
      </Box>
    );
  };

  const renderProgressSummary = () => {
    return (
      <Dialog
        open={openSummary}
        onClose={() => setOpenSummary(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Interview Preparation Summary</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            {steps.map((step, index) => (
              <Grid item xs={12} key={index}>
                <Card variant="outlined">
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="h6">{step.label}</Typography>
                      <Chip
                        label={step.completed ? 'Completed' : 'In Progress'}
                        color={step.completed ? 'success' : 'default'}
                        size="small"
                      />
                    </Box>
                    {step.completed && step.data && (
                      <Box sx={{ mt: 1 }}>
                        <Typography variant="body2" color="text.secondary">
                          {renderStepSummary(step)}
                        </Typography>
                      </Box>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenSummary(false)}>Close</Button>
          <Button onClick={generatePreparationReport} startIcon={<DownloadIcon />}>
            Download Report
          </Button>
        </DialogActions>
      </Dialog>
    );
  };

  const renderStepSummary = (step: PrepStep) => {
    if (!step.data) return step.description;

    try {
      switch (step.label) {
        case 'Requirements Analysis': {
          const analysis = step.data as IRequirementsAnalysis;
          if (!analysis.mustHaveSkills || !analysis.overallMatch) {
            return 'Requirements analysis completed';
          }
          const matchScore = Math.round(analysis.overallMatch * 100);
          const matchedSkills = analysis.mustHaveSkills.filter(s => s?.matched).length;
          const totalSkills = analysis.mustHaveSkills.length;
          return (
            <>
              <Typography>Match Score: {matchScore}%</Typography>
              <Typography>
                Skills Matched: {matchedSkills}/{totalSkills}
              </Typography>
            </>
          );
        }
        case 'Experience Mapping': {
          const mappings = Array.isArray(step.data) ? step.data : [];
          return `${mappings.length} experiences mapped to requirements`;
        }
        case 'Behavioral Preparation': {
          const behavioralPrep = step.data as IBehavioralPrep;
          if (!behavioralPrep.starExamples || !behavioralPrep.competencyAreas) {
            return 'Behavioral preparation completed';
          }
          return (
            <>
              <Typography>STAR Examples: {behavioralPrep.starExamples.length}</Typography>
              <Typography>Competency Areas: {behavioralPrep.competencyAreas.length}</Typography>
            </>
          );
        }
        case 'Technical Preparation': {
          const techPrep = step.data;
          if (!techPrep.requiredTechnologies || !Array.isArray(techPrep.requiredTechnologies)) {
            return 'Technical preparation completed';
          }
          return `${techPrep.requiredTechnologies.length} technologies prepared`;
        }
        case 'Company Research':
          return 'Company background, culture, and market position analyzed';
        case 'Practice Session': {
          const sessions = Array.isArray(step.data) ? step.data : [];
          return `${sessions.length} mock interviews completed`;
        }
        case 'Feedback Analysis':
          return 'Performance reviewed and AI insights received';
        case 'Interview Strategy':
          return 'Interview approach finalized';
        default:
          return step.description;
      }
    } catch (err) {
      console.error('Error rendering step summary:', err);
      return step.description;
    }
  };

  // Handle step completion and navigation
  const isStepCompleted = (stepIndex: number) => {
    return steps[stepIndex].completed;
  };

  const canNavigateToStep = (stepIndex: number) => {
    return stepIndex === 0 || (stepIndex > 0 && isStepCompleted(stepIndex - 1));
  };

  const renderMainContent = () => {
    if (loading) {
      return <LinearProgress data-testid="loading-progress" />;
    }

    return (
      <>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 4 }}>
          <Typography variant="h4">Interview Preparation</Typography>
          <Box>
            <Tooltip title="Save Progress">
              <IconButton onClick={handleSaveProgress} color="primary">
                <SaveIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="View Summary">
              <IconButton onClick={() => setOpenSummary(true)} color="primary">
                <AssessmentIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Download Report">
              <IconButton onClick={generatePreparationReport} color="primary">
                <DownloadIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        <LinearProgress
          variant="determinate"
          value={overallProgress}
          sx={{ mb: 4 }}
          data-testid="progress-bar"
        />

        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((step, index) => (
            <Step
              key={step.label}
              completed={step.completed}
              onClick={() => handleStepClick(index)}
              sx={{ cursor: 'pointer' }}
            >
              <StepLabel>{step.label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <Box sx={{ mt: 4 }}>
          {renderStepContent(activeStep)}
        </Box>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button
            onClick={handleBack}
            disabled={activeStep === 0}
          >
            Back
          </Button>
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={activeStep === steps.length - 1 || !steps[activeStep].completed}
          >
            {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
          </Button>
        </Box>

        {renderProgressSummary()}
      </>
    );
  };

  const renderError = () => {
    if (!error) return null;
    return (
      <Box sx={{ mb: 2 }}>
        <Typography color="error" data-testid="error-message">
          {error}
        </Typography>
        <Button 
          onClick={() => setError(null)} 
          variant="outlined" 
          color="primary" 
          size="small"
          sx={{ mt: 1 }}
        >
          Dismiss
        </Button>
      </Box>
    );
  };

  // Render component
  return (
    <Box sx={{ width: '100%', p: 3 }}>
      {renderError()}
      {renderMainContent()}
    </Box>
  );
}


