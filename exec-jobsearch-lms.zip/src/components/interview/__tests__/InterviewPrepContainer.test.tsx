import React from 'react';
import { screen, waitFor } from '@testing-library/react';
import { rest } from 'msw';
import InterviewPrepContainer from '../InterviewPrepContainer';
import { renderWithProviders } from '../../../test-utils/renderWithProviders';
import { server } from '../../../test-utils/server';
import { ApiError } from '../../../utils/api';
import { createMockUser } from '../../../test-utils/mockProviders';
import { prepComponentsList } from '../__mocks__/testUtils';
import './mocks/iconMocks';

// Test utilities
const testUtils = {
  verifyStepState: async (stepId: string, state: 'active' | 'completed' | 'pending' | 'error' | 'loading') => {
    const step = screen.getByTestId(`step-${stepId}`);
    expect(step).toHaveAttribute('data-state', state);
  },

  verifyLoadingState: async (isLoading: boolean) => {
    if (isLoading) {
      expect(screen.getByTestId(TEST_IDS.loadingSpinner)).toBeInTheDocument();
    } else {
      expect(screen.queryByTestId(TEST_IDS.loadingSpinner)).not.toBeInTheDocument();
    }
  },

  verifyErrorState: async (error: string | null) => {
    if (error) {
      const alert = screen.getByRole('alert');
      expect(alert).toHaveTextContent(error);
      expect(alert).toHaveAttribute('aria-live', 'assertive');
    } else {
      expect(screen.queryByRole('alert')).not.toBeInTheDocument();
    }
  },

  verifyProgressState: async (progress: number) => {
    const progressBar = screen.getByRole('progressbar');
    expect(progressBar).toHaveAttribute('aria-valuenow', String(progress));
  },

  navigateAndVerify: async (direction: 'Next' | 'Back', expectedStepId: string) => {
    const button = screen.getByRole('button', { name: direction });
    await userEvent.click(button);
    await testUtils.verifyStepState(expectedStepId, 'active');
  },

  completeStepAndVerify: async (stepId: string, data?: any) => {
    const button = screen.getByRole('button', { name: /complete/i });
    await userEvent.click(button);
    await testUtils.verifyStepState(stepId, 'completed');
    if (data) {
      await testUtils.verifyStepData(stepId, data);
    }
  },

  verifyStepData: async (stepId: string, expectedData: any) => {
    const step = screen.getByTestId(`step-${stepId}`);
    const dataDisplay = within(step).getByTestId('step-data');
    expect(dataDisplay).toHaveTextContent(JSON.stringify(expectedData));
  },

  mockApiResponse: (success: boolean, data?: any, error?: { status: number; message: string }) => {
    if (success) {
      return rest.post('*/api/interview-prep/*', (req, res, ctx) => {
        return res(ctx.status(200), ctx.json({ success: true, data }));
      });
    } else {
      return rest.post('*/api/interview-prep/*', (req, res, ctx) => {
        return res(
          ctx.status(error?.status || 500),
          ctx.json({ success: false, error: error?.message || 'Server error' })
        );
      });
    }
  }
};

// Constants and configurations
const TEST_CONFIG = {
  defaultProps: {
    jobId: 'test-job-123',
    resumeId: 'test-resume-123'
  },
  mockUser: createMockUser(),
  steps: {
    initial: 'requirements-analysis',
    second: 'experience-mapping',
    final: 'mock-interview'
  },
  timeouts: {
    api: 30000,
    retry: 3000,
    animation: 300
  },
  testIds: {
    loadingSpinner: 'loading-spinner',
    stepContainer: 'step-container',
    progressBar: 'progress-bar',
    errorAlert: 'error-alert'
  }
} as const;

// Mock external dependencies
const mockDependencies = {
  setupMocks: () => {
    // Mock API utilities
    jest.mock('../utils/interviewPrep');
    jest.mock('../../../utils/api');

    // Mock prep components
    prepComponentsList.forEach(component => {
      jest.mock(`../prep/${component}`, () => {
        const { [component]: MockComponent } = require('../__mocks__/prepComponents');
        return { [component]: MockComponent };
      });
    });

    // Import mocked modules
    const mockedInterviewPrepUtils = jest.requireMock('../utils/interviewPrep');
    const mockedApiUtils = jest.requireMock('../../../utils/api');

    return { mockedInterviewPrepUtils, mockedApiUtils };
  },

  setupApiMocks: () => {
    // Setup MSW handlers
    server.use(
      rest.post('*/api/interview-prep/create', (req, res, ctx) => {
        return res(
          ctx.status(200),
          ctx.json({
            success: true,
            interviewPrep: {
              id: 'test-prep-id',
              steps: {},
              progress: 0
            }
          })
        );
      }),

      rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
        return res(
          ctx.status(200),
          ctx.json({
            success: true,
            step: {
              id: req.params.stepId,
              status: 'completed',
              data: req.body.data
            }
          })
        );
      })
    );
  }
};

// Test setup utilities
const setupTest = async (options: {
  mockPrep?: any;
  props?: typeof TEST_CONFIG.defaultProps;
  user?: typeof TEST_CONFIG.mockUser;
  mockResponses?: {
    success?: boolean;
    data?: any;
    error?: { status: number; message: string };
  };
  skipInitMock?: boolean;
} = {}) => {
  // Setup mocks
  const { mockedInterviewPrepUtils, mockedApiUtils } = mockDependencies.setupMocks();
  
  // Setup default mock prep if not provided
  const mockPrep = options.mockPrep || {
    id: 'test-prep-id',
    steps: {},
    progress: 0,
    ...options.mockPrep
  };

  // Setup API responses
  if (!options.skipInitMock) {
    mockedInterviewPrepUtils.initializeInterviewPrep.mockResolvedValueOnce(mockPrep);
  }

  if (options.mockResponses) {
    server.use(
      testUtils.mockApiResponse(
        options.mockResponses.success ?? true,
        options.mockResponses.data,
        options.mockResponses.error
      )
    );
  }

  // Render component
  const result = renderWithProviders(
    <InterviewPrepContainer {...(options.props || TEST_CONFIG.defaultProps)} />,
    {
      user: options.user || TEST_CONFIG.mockUser,
      route: '/interview-prep'
    }
  );

  // Wait for initial loading
  await waitFor(() => {
    expect(screen.queryByTestId(TEST_CONFIG.testIds.loadingSpinner)).not.toBeInTheDocument();
  });

  // Return enhanced utilities
  return {
    ...result,
    mockPrep,
    utils: {
      ...testUtils,
      // Additional test-specific utilities
      async completeStep(stepId: string, data?: any) {
        await testUtils.completeStepAndVerify(stepId, data);
        return mockPrep;
      },

      async retryStep(stepId: string) {
        const retryButton = screen.getByRole('button', { name: /retry/i });
        await result.user.click(retryButton);
        await testUtils.verifyStepState(stepId, 'active');
      },

      async openSummary() {
        const summaryButton = screen.getByRole('button', { name: /view summary/i });
        await result.user.click(summaryButton);
        expect(screen.getByRole('dialog')).toBeInTheDocument();
      },

      async closeSummary() {
        const closeButton = screen.getByRole('button', { name: /close/i });
        await result.user.click(closeButton);
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      },

      rerender() {
        result.rerender(
          <InterviewPrepContainer {...(options.props || TEST_CONFIG.defaultProps)} />
        );
      }
    }
  };
};

// Server mocks
server.use(
  rest.post('*/api/interview-prep/step/complete', async (req, res, ctx) => {
    const { stepId, data } = await req.json();
    return res(
      ctx.status(200),
      ctx.json(mockApiSuccess({
        step: { id: stepId, status: 'completed', data }
      }))
    );
  })
);
describe('InterviewPrepContainer', () => {
  // Global test lifecycle
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
    mockDependencies.setupMocks();
    mockDependencies.setupApiMocks();
  });

  afterAll(() => {
    server.close();
  });

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    server.resetHandlers();
    jest.useRealTimers();
    cleanup();
  });

  describe('Initialization and Loading', () => {
    it('initializes successfully with valid props', async () => {
      const { utils } = await setupTest();

      // Verify initial states
      await utils.verifyLoadingState(false);
      await utils.verifyStepState(TEST_CONFIG.steps.initial, 'active');
      await utils.verifyProgressState(0);
      await utils.verifyErrorState(null);
    });

    it('handles initialization errors with retry mechanism', async () => {
      // Setup error response
      const error = { status: 500, message: 'Internal server error' };
      const { utils } = await setupTest({
        skipInitMock: true,
        mockResponses: { success: false, error }
      });

      // Verify error state
      await utils.verifyErrorState(error.message);
      await utils.verifyLoadingState(false);

      // Setup success response for retry
      server.use(testUtils.mockApiResponse(true, { interviewPrep: TEST_CONFIG.mockPrep }));

      // Retry initialization
      await utils.retryStep(TEST_CONFIG.steps.initial);

      // Verify recovery
      await utils.verifyErrorState(null);
      await utils.verifyStepState(TEST_CONFIG.steps.initial, 'active');
    });

    it.each([
      { status: 400, message: 'Invalid request format' },
      { status: 401, message: 'Session expired' },
      { status: 403, message: 'Access denied' },
      { status: 404, message: 'Resource not found' },
      { status: 429, message: 'Rate limit exceeded' }
    ])('handles $status error with appropriate message', async ({ status, message }) => {
      const { utils } = await setupTest({
        skipInitMock: true,
        mockResponses: { success: false, error: { status, message } }
      });

      await utils.verifyErrorState(message);
      await utils.verifyLoadingState(false);
    });

    it('handles network timeout with retry', async () => {
      const { utils } = await setupTest({
        skipInitMock: true,
        mockResponses: { success: false, error: { status: 503, message: 'Network timeout' } }
      });

      // Verify timeout handling
      await utils.verifyErrorState('Network timeout');
      
      // Advance timers to trigger auto-retry
      await testUtils.advanceTimers(TEST_CONFIG.timeouts.retry);

      // Setup success for retry
      server.use(testUtils.mockApiResponse(true, { interviewPrep: TEST_CONFIG.mockPrep }));

      // Verify recovery
      await utils.verifyErrorState(null);
      await utils.verifyStepState(TEST_CONFIG.steps.initial, 'active');
    });

    it.each([
      { props: { jobId: '', resumeId: TEST_CONFIG.defaultProps.resumeId } },
      { props: { jobId: TEST_CONFIG.defaultProps.jobId, resumeId: '' } },
      { props: { jobId: '', resumeId: '' } }
    ])('validates required props: $props', async ({ props }) => {
      const { utils } = await setupTest({ props, skipInitMock: true });

      await utils.verifyErrorState('Missing required job or resume ID');
      await utils.verifyLoadingState(false);
      
      // Verify component state
      expect(screen.queryByTestId(TEST_CONFIG.testIds.stepContainer)).not.toBeInTheDocument();
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    it('prevents concurrent initialization attempts', async () => {
      // Start first initialization
      const { utils } = await setupTest({
        skipInitMock: true,
        mockResponses: {
          success: false,
          error: { status: 500, message: 'First attempt failed' }
        }
      });

      // Attempt second initialization before first completes
      await utils.retryStep(TEST_CONFIG.steps.initial);

      // Verify only one initialization attempt
      expect(mockedInterviewPrepUtils.initializeInterviewPrep).toHaveBeenCalledTimes(1);
    });

    it('maintains accessibility during loading and error states', async () => {
      const { utils } = await setupTest({
        skipInitMock: true,
        mockResponses: {
          success: false,
          error: { status: 500, message: 'Test error' }
        }
      });

      // Verify loading indicator accessibility
      const loadingSpinner = screen.getByTestId(TEST_CONFIG.testIds.loadingSpinner);
      expect(loadingSpinner).toHaveAttribute('aria-busy', 'true');
      expect(loadingSpinner).toHaveAttribute('role', 'progressbar');

      // Verify error message accessibility
      const errorAlert = screen.getByRole('alert');
      expect(errorAlert).toHaveAttribute('aria-live', 'assertive');
      
      // Verify keyboard navigation
      const retryButton = screen.getByRole('button', { name: /retry/i });
      await utils.user.tab();
      expect(retryButton).toHaveFocus();
    });

    it('restores state with previously completed steps', async () => {
      // Setup mock with completed steps
      const mockPrep = mockedInterviewPrepUtils.createMockInterviewPrep(
        TEST_CONFIG.defaultProps.jobId,
        TEST_CONFIG.defaultProps.resumeId
      );
      mockPrep.completedSteps = [TEST_CONFIG.steps.initial, TEST_CONFIG.steps.second];

      const { utils } = await setupTest({ mockPrep });

      // Verify completed steps
      await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
      await utils.verifyStep(TEST_CONFIG.steps.second, 'completed');
      
      // Verify progress
      const progressBar = screen.getByRole('progressbar');
      expect(progressBar).toHaveAttribute('aria-valuenow', '25'); // 2/8 steps
    });
  });

  describe('Error Handling', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    describe('API Errors', () => {
      it('handles initialization errors with retry mechanism', async () => {
        const error = new ApiError('Failed to initialize', 500, { error: 'INTERNAL_ERROR' });
        mockedInterviewPrepUtils.initializeInterviewPrep.mockRejectedValueOnce(error);

        const { utils } = await setupTest();

        // Verify error state
        const errorAlert = await screen.findByRole('alert');
        expect(errorAlert).toHaveTextContent('Failed to initialize');

        // Test retry mechanism
        mockedInterviewPrepUtils.initializeInterviewPrep.mockResolvedValueOnce(TEST_CONFIG.mockPrep);
        await utils.user.click(screen.getByRole('button', { name: /retry/i }));
        await utils.verifyStep(TEST_CONFIG.steps.initial, 'active');
      });

      it('handles step completion errors with retry', async () => {
        const { utils } = await setupTest();

        // Setup error scenario
        const error = new ApiError('Failed to complete step', 500, { error: 'INTERNAL_ERROR' });
        mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);

        // Attempt step completion
        await utils.completeStep(TEST_CONFIG.steps.initial);

        // Verify error handling
        const errorAlert = await screen.findByRole('alert');
        expect(errorAlert).toHaveTextContent('Failed to complete step');
        await utils.verifyStep(TEST_CONFIG.steps.initial, 'active');

        // Test retry success
        mockedInterviewPrepUtils.completeInterviewStep.mockResolvedValueOnce({ success: true });
        await utils.user.click(screen.getByRole('button', { name: /retry/i }));
        await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
      });
    });

    describe('Validation Errors', () => {
      it('handles invalid step data with clear feedback', async () => {
        const { utils } = await setupTest();

        // Setup validation error
        const error = new ApiError('Invalid step data', 400, { error: 'VALIDATION_ERROR' });
        mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);

        // Attempt step completion
        await utils.completeStep(TEST_CONFIG.steps.initial);

        // Verify error feedback
        const errorAlert = await screen.findByRole('alert');
        expect(errorAlert).toHaveTextContent('Invalid step data');
        await utils.verifyStep(TEST_CONFIG.steps.initial, 'active');
      });

      it('preserves step state during validation errors', async () => {
        const { utils } = await setupTest();

        // Complete first step successfully
        await utils.completeStep(TEST_CONFIG.steps.initial);
        await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');

        // Trigger validation error on second step
        const error = new ApiError('Invalid data', 400, { error: 'VALIDATION_ERROR' });
        mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);
        await utils.completeStep(TEST_CONFIG.steps.second);

        // Verify states preserved
        await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
        await utils.verifyStep(TEST_CONFIG.steps.second, 'active');
      });
    });
  });

  describe('Navigation and Progress', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    it('tracks step completion progress accurately', async () => {
      const { utils } = await setupTest();

      // Complete first step
      await utils.completeStep(TEST_CONFIG.steps.initial);
      await utils.verifyProgress(12.5); // 1/8 steps

      // Complete second step
      await utils.navigate('Next', TEST_CONFIG.steps.second);
      await utils.completeStep(TEST_CONFIG.steps.second);
      await utils.verifyProgress(25); // 2/8 steps
    });

    it('maintains step state through navigation', async () => {
      const { utils } = await setupTest();

      // Verify initial navigation state
      await utils.verifyNavigationControls({ back: false, next: true });

      // Complete steps and navigate
      for (const stepId of [TEST_CONFIG.steps.initial, TEST_CONFIG.steps.second]) {
        await utils.completeStep(stepId);
        if (stepId !== TEST_CONFIG.steps.second) {
          await utils.navigate('Next', TEST_CONFIG.steps.second);
        }
      }

      // Verify final navigation state
      await utils.verifyNavigationControls({ back: true, next: true });

      // Verify state persistence through navigation
      await utils.navigate('Back', TEST_CONFIG.steps.initial);
      await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
      await utils.verifyStep(TEST_CONFIG.steps.second, 'completed');
    });

    it('enforces step completion requirements', async () => {
      const { utils } = await setupTest();

      // Verify initial step requirements
      await utils.verifyStep(TEST_CONFIG.steps.initial, 'active');
      await utils.verifyStep(TEST_CONFIG.steps.second, 'disabled');

      // Complete first step and verify second step enabled
      await utils.completeStep(TEST_CONFIG.steps.initial);
      await utils.verifyStep(TEST_CONFIG.steps.second, 'active');
    });
          expectedMessage: 'Invalid step data'
        }
      ];

      for (const { error, expectedMessage } of testCases) {
        mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);
        const completeButton = screen.getByRole('button', { name: /complete requirements analysis/i });
        fireEvent.click(completeButton);

        await waitFor(() => {
          const errorMessage = screen.getByText(expectedMessage);
          expect(errorMessage).toBeInTheDocument();
          expect(errorMessage).toHaveAttribute('role', 'alert');
        });

        // Verify step remains incomplete
        expect(getStepElement('requirements-analysis')).not.toHaveAttribute('data-completed');
        cleanup();
      }
    });

    it('should prevent navigation to incomplete steps', async () => {
      const { navigate } = await setupTest();

      // Try to navigate forward without completing current step
      navigate('Next');
      await verifyStepState('requirements-analysis', { enabled: true });
      expect(screen.getByText('Complete the current step before proceeding')).toBeInTheDocument();

      // Complete step and verify navigation is allowed
      await completeStep('requirements-analysis');
      navigate('Next');
      await verifyStepState('experience-mapping', { enabled: true });
    });
  });

  describe('Progress Tracking', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
      jest.clearAllMocks();
    });

    const verifyProgressState = async ({
      completedSteps,
      currentStep,
      expectedProgress
    }: {
      completedSteps?: string[];
      currentStep?: string;
      expectedProgress: number;
    }) => {
      const progressBar = screen.getByTestId('progress-bar');
      expect(progressBar).toHaveAttribute('aria-valuenow', expectedProgress.toString());

      if (completedSteps) {
        for (const stepId of completedSteps) {
          const step = screen.getByTestId(stepId);
          expect(step).toHaveAttribute('data-completed', 'true');
        }
      }

      if (currentStep) {
        const step = screen.getByTestId(currentStep);
        expect(step).toHaveAttribute('data-current', 'true');
      }
    };

    it('should track progress accurately', async () => {
      const { completeStep, navigate } = await setupTest();

      // Initial state - no progress
      await verifyProgressState({ expectedProgress: 0, currentStep: 'requirements-analysis' });

      // Complete first step
      await completeStep('requirements-analysis');
      await verifyProgressState({
        completedSteps: ['requirements-analysis'],
        expectedProgress: 12.5 // 1/8 steps
      });

      // Complete second step
      navigate('Next');
      await completeStep('experience-mapping');
      await verifyProgressState({
        completedSteps: ['requirements-analysis', 'experience-mapping'],
        expectedProgress: 25 // 2/8 steps
      });
    });

    it('should maintain progress during navigation and state changes', async () => {
      const { completeStep, navigate } = await setupTest();

      // Complete first two steps
      await completeStep('requirements-analysis');
      navigate('Next');
      await completeStep('experience-mapping');

      // Navigate through all steps and verify progress persists
      const steps = ['behavioral-prep', 'technical-prep', 'company-research', 'mock-interview', 'feedback-analysis', 'interview-strategy'];
      for (const step of steps) {
        navigate('Next');
        await verifyProgressState({
          completedSteps: ['requirements-analysis', 'experience-mapping'],
          currentStep: step,
          expectedProgress: 25
        });
      }

      // Navigate back and verify progress remains
      for (const step of [...steps].reverse()) {
        navigate('Back');
        await verifyProgressState({
          completedSteps: ['requirements-analysis', 'experience-mapping'],
          currentStep: step === steps[0] ? 'experience-mapping' : step,
          expectedProgress: 25
        });
      }
    });

    it('should handle rapid progress updates', async () => {
      const { completeStep, navigate } = await setupTest();
      const stepsToComplete = ['requirements-analysis', 'experience-mapping', 'behavioral-prep'];

      // Rapidly complete multiple steps
      for (const step of stepsToComplete) {
        await completeStep(step);
        navigate('Next');
        jest.advanceTimersByTime(50); // Shorter delay for rapid updates
      }

      // Verify final progress
      await verifyProgressState({
        completedSteps: stepsToComplete,
        currentStep: 'technical-prep',
        expectedProgress: 37.5 // 3/8 steps
      });
    });
  });

  describe('Error Handling', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
      jest.clearAllMocks();
    });

    const verifyErrorState = async ({
      error,
      expectedMessage,
      action
    }: {
      error: Error | ApiError;
      expectedMessage: string;
      action: () => Promise<void>;
    }) => {
      if (error instanceof ApiError) {
        expect(error.details?.error).toBeDefined();
      }

      await action();

      await waitFor(() => {
        const errorMessage = screen.getByTestId('error-message');
        expect(errorMessage).toBeInTheDocument();
        expect(errorMessage).toHaveTextContent(expectedMessage);
        expect(errorMessage).toHaveAttribute('role', 'alert');
      });

      // Loading indicator should be removed
      expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();

      // Error should be displayed in a user-friendly way
      const errorAlert = screen.getByRole('alert');
      expect(errorAlert).toBeInTheDocument();
      expect(errorAlert).toHaveTextContent(expectedMessage);
    };

    describe('Initialization Errors', () => {
      const testCases = [
        {
          error: new ApiError('Invalid response format', 400, { error: 'INVALID_FORMAT' }),
          expectedMessage: 'Invalid response format'
        },
        {
          error: new ApiError('Server error', 500, { error: 'INTERNAL_ERROR' }),
          expectedMessage: 'Server error'
        },
        {
          error: new Error('Network error'),
          expectedMessage: 'An unexpected error occurred'
        }
      ];

      test.each(testCases)('should handle $error.message during initialization', async ({ error, expectedMessage }) => {
        mockedInterviewPrepUtils.initializeInterviewPrep.mockRejectedValueOnce(error);
        await verifyErrorState({
          error,
          expectedMessage,
          action: async () => {
            renderComponent();
          }
        });
      });
    });

    describe('Step Completion Errors', () => {
      const testCases = [
        {
          error: new ApiError('Invalid step data', 400, { error: 'VALIDATION_ERROR' }),
          expectedMessage: 'Invalid step data'
        },
        {
          error: new ApiError('Server error', 500, { error: 'INTERNAL_ERROR' }),
          expectedMessage: 'Server error'
        },
        {
          error: new Error('Network error'),
          expectedMessage: 'An unexpected error occurred'
        }
      ];

      test.each(testCases)('should handle $error.message during step completion', async ({ error, expectedMessage }) => {
        const { getStepElement } = await setupTest();
        mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);

        await verifyErrorState({
          error,
          expectedMessage,
          action: async () => {
            const completeButton = screen.getByRole('button', { name: /complete requirements analysis/i });
            fireEvent.click(completeButton);
          }
        });

        // Verify step remains incomplete
        expect(getStepElement('requirements-analysis')).not.toHaveAttribute('data-completed');
      });
    });

    it('should handle multiple consecutive errors', async () => {
      const { getStepElement } = await setupTest();
      const errors = [
        new ApiError('First error', 400, { error: 'ERROR_1' }),
        new ApiError('Second error', 500, { error: 'ERROR_2' }),
        new ApiError('Third error', 400, { error: 'ERROR_3' })
      ];

      for (const error of errors) {
        mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);
        await verifyErrorState({
          error,
          expectedMessage: error.message,
          action: async () => {
            const completeButton = screen.getByRole('button', { name: /complete requirements analysis/i });
            fireEvent.click(completeButton);
          }
        });

        // Verify step remains incomplete after each error
        expect(getStepElement('requirements-analysis')).not.toHaveAttribute('data-completed');
        cleanup();
      }
    });
  });

  describe('Navigation and State Management', () => {
    beforeEach(() => {
      jest.useFakeTimers();
      const mockPrep = createMockInterviewPrep(defaultProps.jobId, defaultProps.resumeId);
      mockedInterviewPrepUtils.initializeInterviewPrep.mockResolvedValueOnce(mockPrep);
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    const verifyCurrentStep = async (stepId: string) => {
      await waitFor(() => {
        const step = screen.getByTestId(stepId);
        expect(step).toBeInTheDocument();
        expect(step).toHaveAttribute('role', 'step');
      });
    };

    const navigateAndVerify = async (direction: 'Next' | 'Back', expectedStepId: string) => {
      fireEvent.click(screen.getByText(direction));
      jest.advanceTimersByTime(100);
      await verifyCurrentStep(expectedStepId);
    };

    it('should handle navigation between steps', async () => {
      renderComponent();
      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      });

      // Initial step
      await verifyCurrentStep('requirements-analysis');

      // Navigate forward through steps
      await navigateAndVerify('Next', 'experience-mapping');
      await navigateAndVerify('Next', 'behavioral-prep');
      await navigateAndVerify('Next', 'technical-prep');

      // Navigate backward
      await navigateAndVerify('Back', 'behavioral-prep');
      await navigateAndVerify('Back', 'experience-mapping');
      await navigateAndVerify('Back', 'requirements-analysis');
    });

    it('should maintain state during rapid navigation', async () => {
      renderComponent();
      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      });

      // Complete first step
      const completeButton = screen.getByRole('button', { name: /complete requirements analysis/i });
      fireEvent.click(completeButton);
      await waitFor(() => {
        expect(mockedInterviewPrepUtils.completeInterviewStep).toHaveBeenCalled();
      });

      // Rapid forward navigation
      for (let i = 0; i < 3; i++) {
        fireEvent.click(screen.getByText('Next'));
        jest.advanceTimersByTime(50);
      }
      await verifyCurrentStep('technical-prep');

      // Rapid backward navigation
      for (let i = 0; i < 3; i++) {
        fireEvent.click(screen.getByText('Back'));
        jest.advanceTimersByTime(50);
      }
      await verifyCurrentStep('requirements-analysis');

      // Verify completed step remains completed
      const reqAnalysis = screen.getByTestId('requirements-analysis');
      expect(reqAnalysis).toHaveAttribute('data-completed', 'true');
    });

    it('should handle dialog interactions', async () => {
      renderComponent();
      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      });

      // Open summary dialog
      const summaryButton = screen.getByRole('button', { name: /view summary/i });
      fireEvent.click(summaryButton);
      expect(screen.getByRole('dialog')).toBeInTheDocument();

      // Close dialog
      const closeButton = screen.getByRole('button', { name: /close/i });
      fireEvent.click(closeButton);
      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      });
    });
  });
});
    }
    
    // Create and store initial state
    const initialState = createMockInterviewPrep(jobId, resumeId);
    (global as any).testState = { mockInterviewPrep: initialState };
    
    return res(ctx.status(200), ctx.json({
      interviewPrep: initialState
    }));
  }),
  rest.post('*/api/interview-prep/:prepId/update', async (req, res, ctx) => {
    const { stepName, data } = await req.json();
    if (!stepName || !data) {
      return res(ctx.status(400), ctx.json({
        error: 'VALIDATION_ERROR',
        message: 'Missing required fields',
        fields: ['stepName', 'data']
      }));
    }
    
    const currentState = (global as any).testState?.mockInterviewPrep;
    if (!currentState) {
      return res(ctx.status(500), ctx.json({
        error: 'INTERNAL_ERROR',
        message: 'Test state not found'
      }));
    }
    
    // Update step data
    currentState.steps[stepName] = {
      status: 'completed',
      data: data
    };
    currentState.completedSteps.push(stepName);
    
    return res(ctx.status(200), ctx.json({
      interviewPrep: currentState
    }));
  })
    // Initialize test state before each test
    beforeEach(() => {
      (global as any).testState = { mockInterviewPrep: null };
    });

    // Clean up test state after each test
    afterEach(() => {
      (global as any).testState = null;
    });

    // Clean up after all tests
    afterAll(() => {
      server.close();
      jest.useRealTimers();
    });
  }),

  rest.post('*/api/interview-prep/:id/update', async (req, res, ctx) => {
    const { stepName, data } = await req.json();
    if (!stepName || !data) {
      return res(
        ctx.status(400),
        ctx.json({
          error: 'VALIDATION_ERROR',
          message: 'Missing required fields',
          fields: ['stepName', 'data']
        })
      );
    }

    // Get the current state from the test scope
    const currentState = (global as any).testState?.mockInterviewPrep;
    if (!currentState) {
      return res(
        ctx.status(500),
        ctx.json({
          error: 'INTERNAL_ERROR',
          message: 'Test state not initialized'
        })
      );
    }

    // Update the step status and data
    currentState.steps[stepName] = {
      status: 'completed',
      data
    };
    currentState.completedSteps = [...new Set([...currentState.completedSteps, stepName])];

    // Store updated state
    (global as any).testState.mockInterviewPrep = currentState;
    return res(ctx.json(currentState));
  })
);

describe('InterviewPrepContainer', () => {
  // Helper function to render component with default props
  const renderComponent = () => {
    return render(
      <InterviewPrepContainer
        jobId="job123"
        resumeId="resume123"
      />
    );
  };

  // Start server before tests
  beforeAll(() => server.listen());

  // Reset handlers and state after each test
  afterEach(() => {
    server.resetHandlers();
    jest.clearAllMocks();
    (global as any).testState = undefined;
  });

  // Clean up after all tests
  afterAll(() => server.close());

  // Initialize test state
  beforeEach(() => {
    // Reset global test state before each test
    (global as any).testState = undefined;

    // Set up initial test state for MSW handlers
    const initialState = createMockInterviewPrep('job123', 'resume123');
    (global as any).testState = {
      mockInterviewPrep: initialState
    };

  });

  it('initializes with API call and validates data', async () => {
    const mockPrep = createMockInterviewPrep(defaultProps.jobId, defaultProps.resumeId);
    mockedInterviewPrepUtils.initializeInterviewPrep.mockResolvedValueOnce(mockPrep);
    renderComponent();

    // Initially should show loading
    expect(screen.getByTestId('loading-progress')).toBeInTheDocument();

    // Wait for initialization to complete
    await waitFor(() => {
      expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
    });

    // Verify initialization was called with correct params
    expect(mockedInterviewPrepUtils.initializeInterviewPrep).toHaveBeenCalledWith(
      defaultProps.jobId,
      defaultProps.resumeId
    );

    // Verify first step is rendered and enabled
    const firstStep = screen.getByTestId('requirements-analysis');
    expect(firstStep).toBeInTheDocument();
    expect(firstStep).not.toHaveAttribute('aria-disabled');
  });

  it('handles initialization error', async () => {
    // Mock initialization failure
    const error = new ApiError('Server error', 500, { error: 'INTERNAL_ERROR' });
    mockedInterviewPrepUtils.initializeInterviewPrep.mockRejectedValueOnce(error);

    renderComponent();

    // Wait for error to be displayed
    await waitFor(() => {
      expect(screen.getByText('Server error')).toBeInTheDocument();
    });

    // Verify loading state is cleared
    expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
  });

    // Mock initialization with delay to test concurrency
    mockedInterviewPrepUtils.initializeInterviewPrep.mockImplementation(async (jobId, resumeId) => {
      requestCount++;
      await new Promise(resolve => setTimeout(resolve, 100));
      return mockInterviewPrep;
    });

    const { rerender } = renderComponent();
    rerender(<InterviewPrepContainer jobId="job123" resumeId="resume123" />);

    // Wait for loading to finish and component to initialize
    await waitFor(() => {
      expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      expect(screen.getByTestId('requirements-analysis')).toBeInTheDocument();
      
      const progressBar = screen.getByTestId('progress-bar');
      expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
      expect(progressBar).toHaveAttribute('aria-valuenow', '0');
      expect(progressBar).toHaveAttribute('aria-valuemin', '0');
      expect(progressBar).toHaveAttribute('aria-valuemax', '100');
      const progressText = screen.getByText('0%');
      expect(progressText).toBeInTheDocument();
      expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });

      const nextButton = screen.getByText('Next');
      const backButton = screen.getByText('Back');
      expect(nextButton).toBeDisabled();
      expect(backButton).toBeDisabled();
    }, { timeout: 3000 });

    expect(requestCount).toBe(1); // Should only make one request despite two renders
  });

  it('handles API initialization error and resets state', async () => {
    // Mock initialization failure
    mockedInterviewPrepUtils.initializeInterviewPrep.mockRejectedValueOnce(
      new mockedApiUtils.ApiError('Internal server error', 500, {
        error: 'INTERNAL_ERROR',
        message: 'An unexpected error occurred'
      })
    );

    renderComponent();

    // Initially should show loading
    expect(screen.getByTestId('loading-progress')).toBeInTheDocument();

    // Wait for loading to finish and error to appear
    await waitFor(() => {
      expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      const errorMessage = screen.getByTestId('error-message');
      expect(errorMessage).toBeInTheDocument();
      expect(errorMessage).toHaveTextContent(/Failed to initialize interview preparation: Internal server error/);
      expect(errorMessage).toHaveAttribute('role', 'alert');
      expect(errorMessage).toHaveStyle({ color: '#d32f2f' });

      // Verify state is reset
      const progressBar = screen.getByTestId('progress-bar');
      expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
      expect(progressBar).toHaveAttribute('aria-valuenow', '0');
      expect(progressBar).toHaveAttribute('aria-valuemin', '0');
      expect(progressBar).toHaveAttribute('aria-valuemax', '100');
      const progressText = screen.getByText('0%');
      expect(progressText).toBeInTheDocument();
      expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });
      const nextButton = screen.queryByText('Next');
      const backButton = screen.queryByText('Back');
      expect(nextButton).toBeDisabled();
      expect(backButton).toBeDisabled();
    }, { timeout: 3000 });
  });

  describe('Step Completion and Progress', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
      jest.clearAllMocks();
    });

    const verifyProgressBarState = async (expectedProgress: number) => {
      await waitFor(() => {
        const progressBar = screen.getByTestId('progress-bar');
        expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
        expect(progressBar).toHaveAttribute('aria-valuenow', expectedProgress.toString());
        expect(progressBar).toHaveAttribute('aria-valuemin', '0');
        expect(progressBar).toHaveAttribute('aria-valuemax', '100');
        const progressText = screen.getByText(`${expectedProgress}%`);
        expect(progressText).toBeInTheDocument();
        expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });
      });
    };

    const completeStepAndVerify = async (stepId: string, expectedProgress: number) => {
      const stepElement = screen.getByTestId(stepId);
      const completeButton = within(stepElement).getByRole('button');
      expect(completeButton).not.toBeDisabled();
      fireEvent.click(completeButton);

      await waitFor(() => {
        const currentState = (global as any).testState.mockInterviewPrep;
        expect(currentState.steps[stepId].status).toBe('completed');
      });

      await verifyProgressBarState(expectedProgress);
    };

    it('completes steps in sequence with accurate progress tracking', async () => {
      const { container } = renderComponent();

      // Initial state verification
      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
        expect(screen.getByTestId('requirements-analysis')).toBeInTheDocument();
      });
      await verifyProgressBarState(0);

      // Complete steps in sequence
      const steps = [
        { id: 'requirements-analysis', progress: 12.5 },
        { id: 'experience-mapping', progress: 25 },
        { id: 'behavioral-prep', progress: 37.5 },
        { id: 'technical-prep', progress: 50 },
        { id: 'company-research', progress: 62.5 },
        { id: 'mock-interview', progress: 75 },
        { id: 'feedback-analysis', progress: 87.5 },
        { id: 'interview-strategy', progress: 100 }
      ];

      for (const { id, progress } of steps) {
        await completeStepAndVerify(id, progress);

        // Navigate to next step if not last
        if (id !== 'interview-strategy') {
          fireEvent.click(screen.getByText('Next'));
          jest.advanceTimersByTime(100);

          // Verify navigation
          await waitFor(() => {
            const nextStep = screen.getByTestId(steps[steps.findIndex(s => s.id === id) + 1].id);
            expect(nextStep).toBeInTheDocument();
            expect(nextStep).toHaveAttribute('role', 'step');
          });
        }
      }

      // Final verification
      const completedSteps = steps.map(s => s.id);
      for (const stepId of completedSteps) {
        expect(screen.getByTestId(stepId)).toHaveAttribute('data-completed', 'true');
      }
    });

    it('maintains navigation state during rapid transitions', async () => {
      const { container } = renderComponent();

      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      });

      // Complete first three steps
      const initialSteps = [
        { id: 'requirements-analysis', progress: 12.5 },
        { id: 'experience-mapping', progress: 25 },
        { id: 'behavioral-prep', progress: 37.5 }
      ];

      for (const { id, progress } of initialSteps) {
        await completeStepAndVerify(id, progress);
        fireEvent.click(screen.getByText('Next'));
        jest.advanceTimersByTime(100);
      }

      // Rapid forward navigation
      const remainingSteps = ['technical-prep', 'company-research', 'mock-interview'];
      for (const stepId of remainingSteps) {
        fireEvent.click(screen.getByText('Next'));
        jest.advanceTimersByTime(50);

        await waitFor(() => {
          const currentStep = screen.getByTestId(stepId);
          expect(currentStep).toBeInTheDocument();
          expect(currentStep).toHaveAttribute('role', 'step');
        });
      }

      // Rapid backward navigation
      for (const stepId of [...remainingSteps].reverse()) {
        fireEvent.click(screen.getByText('Back'));
        jest.advanceTimersByTime(50);

        await waitFor(() => {
          const currentStep = screen.getByTestId(stepId);
          expect(currentStep).toBeInTheDocument();
          expect(currentStep).toHaveAttribute('role', 'step');
        });
      }

      // Verify completed steps remain completed
      for (const { id } of initialSteps) {
        expect(screen.getByTestId(id)).toHaveAttribute('data-completed', 'true');
      }
    });
  });

    // Complete second step
    fireEvent.click(screen.getByText('Complete Experience Mapping'));
    await waitFor(() => {
      const nextButton = screen.getByText('Next');
      const backButton = screen.getByText('Back');
      expect(nextButton).not.toBeDisabled();
      expect(backButton).not.toBeDisabled();
      const progressBar = screen.getByTestId('progress-bar');
      expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
      expect(progressBar).toHaveAttribute('aria-valuenow', '25');
      expect(progressBar).toHaveAttribute('aria-valuemin', '0');
      expect(progressBar).toHaveAttribute('aria-valuemax', '100');
      const progressText = screen.getByText('25%');
      expect(progressText).toBeInTheDocument();
      expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });
    });

    // Navigate to next step
    fireEvent.click(screen.getByText('Next'));
    await waitFor(() => {
      expect(screen.getByTestId('behavioral-prep')).toBeInTheDocument();
      const nextButton = screen.getByText('Next');
      const backButton = screen.getByText('Back');
      expect(nextButton).toBeDisabled();
      expect(backButton).not.toBeDisabled();
      const progressBar = screen.getByTestId('progress-bar');
      expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
      expect(progressBar).toHaveAttribute('aria-valuenow', '25');
      expect(progressBar).toHaveAttribute('aria-valuemin', '0');
      expect(progressBar).toHaveAttribute('aria-valuemax', '100');
      const progressText = screen.getByText('25%');
      expect(progressText).toBeInTheDocument();
      expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });
    });

    // Complete third step
    fireEvent.click(screen.getByText('Complete Behavioral Prep'));
    await waitFor(() => {
      const nextButton = screen.getByText('Next');
      const backButton = screen.getByText('Back');
      expect(nextButton).not.toBeDisabled();
      expect(backButton).not.toBeDisabled();
      const progressBar = screen.getByTestId('progress-bar');
      expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
      expect(progressBar).toHaveAttribute('aria-valuenow', '37');
      expect(progressBar).toHaveAttribute('aria-valuemin', '0');
      expect(progressBar).toHaveAttribute('aria-valuemax', '100');
      const progressText = screen.getByText('37.5%');
      expect(progressText).toBeInTheDocument();
      expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });
    });

    // Navigate to next step
    fireEvent.click(screen.getByText('Next'));
    await waitFor(() => {
      await verifyStepState('technical-prep', {
        completed: false,
        enabled: true,
        isCurrent: true,
        buttonText: 'Complete Technical Prep'
      });
      await verifyNavigationState({
        nextEnabled: false,
        backEnabled: true,
        progress: 37.5
      });

      // Complete technical prep step
      fireEvent.click(screen.getByText('Complete Technical Prep'));
      await verifyStepState('technical-prep', {
        completed: true,
        enabled: false,
        isCurrent: true
      });
      await verifyNavigationState({
        nextEnabled: true,
        backEnabled: true,
        progress: 50
      });

      // Verify previous steps maintain their state
      const completedSteps = ['requirements-analysis', 'experience-mapping', 'behavioral-prep', 'technical-prep'];
      for (const stepId of completedSteps) {
        await verifyStepState(stepId, {
          completed: true,
          enabled: false,
          isCurrent: stepId === 'technical-prep'
        });
      }
  });

  describe('Error Handling', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
      jest.clearAllMocks();
    });

    const verifyErrorState = async ({
      error,
      expectedMessage,
      action
    }: {
      error: ApiError;
      expectedMessage: string;
      action: () => Promise<void>;
    }) => {
      // Setup error mock
      mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(error);

      // Initialize component
      renderComponent();
      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      });

      // Verify initial state
      await verifyStepState('requirements-analysis', {
        completed: false,
        enabled: true,
        isCurrent: true,
        buttonText: 'Complete Requirements Analysis'
      });
      await verifyNavigationState({
        nextEnabled: false,
        backEnabled: false,
        progress: 0
      });

      // Execute action that triggers error
      await action();

      // Verify error state
      await waitFor(() => {
        const errorMessage = screen.getByTestId('error-message');
        expect(errorMessage).toBeInTheDocument();
        expect(errorMessage).toHaveTextContent(`Failed to complete step: ${expectedMessage}`);
        expect(errorMessage).toHaveAttribute('role', 'alert');
        expect(errorMessage).toHaveStyle({ color: '#d32f2f' });
      });

      // Verify navigation is disabled during error
      await verifyNavigationState({
        nextEnabled: false,
        backEnabled: false,
        progress: 0
      });

      // Verify loading state is cleared
      expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
    };

    it('handles server errors during step completion', async () => {
      const error = new ApiError('Internal server error', 500, {
        error: 'INTERNAL_ERROR',
        message: 'Internal server error'
      });

      await verifyErrorState({
        error,
        expectedMessage: error.message,
        action: async () => {
          fireEvent.click(screen.getByText('Complete Requirements Analysis'));
        }
      });

      // Verify error can be dismissed and step retried
      fireEvent.click(screen.getByText('Dismiss'));
      fireEvent.click(screen.getByText('Complete Requirements Analysis'));

      // Verify successful completion after retry
      await verifyStepState('requirements-analysis', {
        completed: true,
        enabled: false,
        isCurrent: true
      });
      await verifyNavigationState({
        nextEnabled: true,
        backEnabled: false,
        progress: 12.5
      });
      expect(screen.queryByTestId('error-message')).not.toBeInTheDocument();
    });

    it('handles validation errors during step completion', async () => {
      const error = new ApiError('Invalid step data', 400, {
        error: 'VALIDATION_ERROR',
        field: 'data',
        message: 'Step data must be an object'
      });

      await verifyErrorState({
        error,
        expectedMessage: error.message,
        action: async () => {
          fireEvent.click(screen.getByText('Complete Requirements Analysis'));
        }
      });

      // Verify step states remain unchanged
      await verifyStepState('requirements-analysis', {
        completed: false,
        enabled: true,
        isCurrent: true
      });
      Object.entries(mockPrepComponents).forEach(([name, _]) => {
        const stepId = name.toLowerCase();
        if (stepId !== 'requirements-analysis') {
          verifyStepState(stepId, {
            completed: false,
            enabled: false,
            isCurrent: false
          });
        }
      });
    });

    it('handles multiple consecutive errors', async () => {
      const errors = [
        new ApiError('First error', 400, { error: 'ERROR_1' }),
        new ApiError('Second error', 500, { error: 'ERROR_2' }),
        new ApiError('Network error', 503, { error: 'ERROR_3' })
      ];

      for (const error of errors) {
        await verifyErrorState({
          error,
          expectedMessage: error.message,
          action: async () => {
            fireEvent.click(screen.getByText('Complete Requirements Analysis'));
          }
        });

        // Verify step remains incomplete
        await verifyStepState('requirements-analysis', {
          completed: false,
          enabled: true,
          isCurrent: true
        });

        // Dismiss error before next iteration
        fireEvent.click(screen.getByText('Dismiss'));
      }
    });
  });

  it('tracks progress accurately through all steps', async () => {
    jest.useFakeTimers();
    const { container } = renderComponent();

    // Wait for initialization
    await waitFor(() => {
      expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
    });

    // Define all steps with their expected progress
    const allSteps = [
      { id: 'requirements-analysis', label: 'Requirements Analysis', progress: 12.5 },
      { id: 'experience-mapping', label: 'Experience Mapping', progress: 25 },
      { id: 'behavioral-prep', label: 'Behavioral Preparation', progress: 37.5 },
      { id: 'technical-prep', label: 'Technical Prep', progress: 50 },
      { id: 'company-research', label: 'Company Research', progress: 62.5 },
      { id: 'mock-interview', label: 'Mock Interview', progress: 75 },
      { id: 'feedback-analysis', label: 'Feedback Analysis', progress: 87.5 },
      { id: 'interview-strategy', label: 'Interview Strategy', progress: 100 }
    ];

    // Verify initial state
    await verifyStepState('requirements-analysis', {
      completed: false,
      enabled: true,
      isCurrent: true,
      buttonText: 'Complete Requirements Analysis'
    });
    await verifyNavigationState({
      nextEnabled: false,
      backEnabled: false,
      progress: 0
    });

    // Complete all steps in sequence
    for (let i = 0; i < allSteps.length; i++) {
      const currentStep = allSteps[i];
      const isFirstStep = i === 0;
      const isLastStep = i === allSteps.length - 1;
      const previousStep = i > 0 ? allSteps[i - 1] : null;

      // Navigate to step if not first
      if (!isFirstStep) {
        await navigateAndVerify('Next', currentStep.id);
      }

      // Verify current step state before completion
      await verifyStepState(currentStep.id, {
        completed: false,
        enabled: true,
        isCurrent: true,
        buttonText: `Complete ${currentStep.label}`
      });
      await verifyNavigationState({
        nextEnabled: false,
        backEnabled: !isFirstStep,
        progress: previousStep?.progress || 0
      });

      // Complete current step
      fireEvent.click(screen.getByText(`Complete ${currentStep.label}`));
      await verifyStepState(currentStep.id, {
        completed: true,
        enabled: false,
        isCurrent: true
      });
      await verifyNavigationState({
        nextEnabled: !isLastStep,
        backEnabled: !isFirstStep,
        progress: currentStep.progress
      });

      // Verify previous steps maintain completed state
      for (let j = 0; j < i; j++) {
        await verifyStepState(allSteps[j].id, {
          completed: true,
          enabled: false,
          isCurrent: false
        });
      }

      // Verify upcoming steps remain disabled
      for (let j = i + 1; j < allSteps.length; j++) {
        await verifyStepState(allSteps[j].id, {
          completed: false,
          enabled: false,
          isCurrent: false
        });
      }
    }

    // Navigate back through all steps and verify state preservation
    for (let i = allSteps.length - 1; i >= 0; i--) {
      const currentStep = allSteps[i];
      const isFirstStep = i === 0;

      if (!isFirstStep) {
        await navigateAndVerify('Back', allSteps[i - 1].id);
      }

      // Verify all steps maintain their state
      for (let j = 0; j < allSteps.length; j++) {
        await verifyStepState(allSteps[j].id, {
          completed: true,
          enabled: false,
          isCurrent: j === i - 1
        });
      }

      // Verify navigation state
      await verifyNavigationState({
        nextEnabled: true,
        backEnabled: !isFirstStep,
        progress: currentStep.progress
      });
    }

    // Cleanup
    jest.useRealTimers();
    container.remove();
  });



  describe('Navigation and Step Controls', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
      jest.clearAllMocks();
    });

    it('validates initial state and step progression', async () => {
      const { container } = renderComponent();

      // Wait for initialization
      await waitFor(() => {
        expect(screen.queryByTestId('loading-progress')).not.toBeInTheDocument();
      });

      // Verify initial state
      await verifyStepState('requirements-analysis', { 
        completed: false, 
        enabled: true,
        isCurrent: true,
        buttonText: 'Complete Requirements Analysis'
      });
      await verifyNavigationState({ 
        nextEnabled: false, 
        backEnabled: false, 
        progress: 0 
      });

      // Verify other steps are disabled
      const otherSteps = Object.entries(mockPrepComponents)
        .map(([name, _]) => name.toLowerCase())
        .filter(id => id !== 'requirements-analysis');

      for (const stepId of otherSteps) {
        await verifyStepState(stepId, { 
          completed: false, 
          enabled: false,
          isCurrent: false 
        });
      }

      // Complete first step and verify state changes
      fireEvent.click(screen.getByText('Complete Requirements Analysis'));
      await verifyStepState('requirements-analysis', { 
        completed: true, 
        enabled: false,
        isCurrent: true 
      });
      await verifyNavigationState({ 
        nextEnabled: true, 
        backEnabled: false, 
        progress: 12.5 
      });

      // Navigate to next step and verify state
      await navigateAndVerify('Next', 'experience-mapping');
      await verifyStepState('experience-mapping', { 
        completed: false, 
        enabled: true,
        isCurrent: true,
        buttonText: 'Complete Experience Mapping'
      });
      await verifyNavigationState({ 
        nextEnabled: false, 
        backEnabled: true, 
        progress: 12.5 
      });
    });

    // Go back and verify first step state is preserved
    fireEvent.click(screen.getByText('Back'));
    jest.advanceTimersByTime(100);

    await waitFor(() => {
      expect(screen.getByTestId('requirements-analysis')).toBeInTheDocument();
      const nextButton = screen.getByText('Next');
      expect(nextButton).not.toBeDisabled(); // Step already completed
      const progressText = screen.getByText('12.5%');
      expect(progressText).toBeInTheDocument();
      expect(progressText).toHaveStyle({ color: 'rgba(0, 0, 0, 0.6)' });
      const progressBar = screen.getByTestId('progress-bar');
    expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
      expect(progressBar).toHaveAttribute('aria-valuenow', '12');
    });

    // Cleanup
    jest.useRealTimers();
    container.remove();
  });

    describe('Edge Cases and Performance', () => {
      beforeEach(() => {
        jest.useFakeTimers();
      });

      afterEach(() => {
        jest.useRealTimers();
        jest.clearAllMocks();
      });

      describe('Navigation Edge Cases', () => {
        it('handles rapid navigation without state corruption', async () => {
          const { utils } = await setupTest();

          // Complete first step
          await utils.completeStep(TEST_CONFIG.steps.initial, { requirements: ['test'] });
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');

          // Rapid navigation sequence
          await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
          jest.advanceTimersByTime(TEST_CONFIG.timeouts.animation / 2);

          await utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial);
          jest.advanceTimersByTime(TEST_CONFIG.timeouts.animation / 2);

          // Verify state consistency
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
          await utils.verifyProgressState(33);
          await utils.verifyStepData(TEST_CONFIG.steps.initial, { requirements: ['test'] });
        });

        it('prevents navigation during step transitions', async () => {
          const { utils } = await setupTest();

          // Start navigation
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

          // Attempt navigation during transition
          jest.advanceTimersByTime(TEST_CONFIG.timeouts.animation / 2);
          const backButton = screen.getByRole('button', { name: 'Back' });
          await utils.user.click(backButton);

          // Verify navigation was prevented
          await utils.verifyStepState(TEST_CONFIG.steps.second, 'active');
        });

        it('handles browser back/forward navigation', async () => {
          const { utils } = await setupTest();

          // Complete steps and navigate
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

          // Simulate browser back
          window.history.back();
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');

          // Simulate browser forward
          window.history.forward();
          await utils.verifyStepState(TEST_CONFIG.steps.second, 'active');
        });
      });

      describe('Network and Loading States', () => {
        it('maintains state during network latency', async () => {
          const { utils } = await setupTest({
            mockResponses: {
              success: true,
              data: { step: { id: TEST_CONFIG.steps.initial, status: 'completed' } }
            }
          });

          // Simulate slow network
          server.use(
            rest.post('*/api/interview-prep/step/complete', async (req, res, ctx) => {
              await new Promise(resolve => setTimeout(resolve, TEST_CONFIG.timeouts.api));
              return res(ctx.json({
                success: true,
                step: {
                  id: TEST_CONFIG.steps.initial,
                  status: 'completed',
                  data: { requirements: ['test'] }
                }
              }));
            })
          );

          // Start step completion
          const completePromise = utils.completeStep(TEST_CONFIG.steps.initial, { requirements: ['test'] });

          // Verify loading state
          await utils.verifyLoadingState(true);
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'loading');

          // Verify navigation is disabled during loading
          expect(screen.getByRole('button', { name: 'Next' })).toBeDisabled();
          expect(screen.getByRole('button', { name: 'Back' })).toBeDisabled();

          // Fast-forward and verify completion
          jest.advanceTimersByTime(TEST_CONFIG.timeouts.api);
          await completePromise;

          await utils.verifyLoadingState(false);
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
          await utils.verifyStepData(TEST_CONFIG.steps.initial, { requirements: ['test'] });
        });

        it('handles network timeouts gracefully', async () => {
          const { utils } = await setupTest();

          // Setup timeout response
          server.use(
            rest.post('*/api/interview-prep/step/complete', async (req, res, ctx) => {
              await new Promise(resolve => setTimeout(resolve, TEST_CONFIG.timeouts.api * 2));
              return res(ctx.status(504), ctx.json({
                success: false,
                error: { message: 'Request timeout' }
              }));
            })
          );

          // Attempt step completion
          await utils.completeStep(TEST_CONFIG.steps.initial, { requirements: ['test'] });

          // Verify error state
          await utils.verifyErrorState('Request timeout');
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'error');

          // Setup success for retry
          server.use(testUtils.mockApiResponse(true, {
            step: {
              id: TEST_CONFIG.steps.initial,
              status: 'completed',
              data: { requirements: ['test'] }
            }
          }));

          // Retry and verify
          await utils.retryStep(TEST_CONFIG.steps.initial);
          await utils.verifyErrorState(null);
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
        });

        it('handles concurrent API requests', async () => {
          const { utils } = await setupTest();

          // Setup conflict response for first request
          server.use(
            rest.post('*/api/interview-prep/step/complete', async (req, res, ctx) => {
              const requestCount = parseInt(req.headers.get('x-request-count') || '0');
              if (requestCount === 0) {
                return res(ctx.status(409), ctx.json({
                  success: false,
                  error: { message: 'Concurrent modification' }
                }));
              }
              return res(ctx.json({
                success: true,
                step: {
                  id: TEST_CONFIG.steps.initial,
                  status: 'completed',
                  data: { requirements: ['test'] }
                }
              }));
            })
          );

          // Start multiple step completions
          const promises = [
            utils.completeStep(TEST_CONFIG.steps.initial, { requirements: ['test1'] }),
            utils.completeStep(TEST_CONFIG.steps.initial, { requirements: ['test2'] })
          ];

          // Wait for both requests
          await Promise.allSettled(promises);

          // Verify final state
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
          await utils.verifyStepData(TEST_CONFIG.steps.initial, { requirements: ['test1'] });
        });
    });

    describe('Accessibility and UX', () => {
      beforeEach(() => {
        jest.useFakeTimers();
      });

      afterEach(() => {
        jest.useRealTimers();
        jest.clearAllMocks();
      });

      describe('Focus Management', () => {
        it('maintains focus during step navigation', async () => {
          const { utils } = await setupTest();

          // Complete first step
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

          // Verify focus moves to active step
          const activeStep = screen.getByTestId(TEST_CONFIG.steps.second);
          expect(activeStep).toHaveAttribute('aria-current', 'true');
          expect(document.activeElement).toBe(
            within(activeStep).getByRole('button', { name: 'Complete Experience Mapping' })
          );
        });

        it('restores focus after error dismissal', async () => {
          const { utils } = await setupTest();

          // Trigger error
          server.use(
            rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
              return res(ctx.status(500), ctx.json({
                success: false,
                error: { message: 'Server error' }
              }));
            })
          );

          await utils.completeStep(TEST_CONFIG.steps.initial);
          
          // Dismiss error and verify focus returns
          const dismissButton = screen.getByRole('button', { name: 'Dismiss' });
          await utils.user.click(dismissButton);
          
          const stepButton = within(screen.getByTestId(TEST_CONFIG.steps.initial))
            .getByRole('button');
          expect(document.activeElement).toBe(stepButton);
        });
      });

      describe('ARIA Attributes', () => {
        it('provides appropriate step status feedback', async () => {
          const { utils } = await setupTest();

          // Complete step and verify ARIA
          await utils.completeStep(TEST_CONFIG.steps.initial);

          const completedStep = screen.getByTestId(TEST_CONFIG.steps.initial);
          expect(completedStep).toHaveAttribute('aria-completed', 'true');
          expect(completedStep).toHaveAttribute('aria-label', 'Requirements Analysis - Completed');

          const currentStep = screen.getByTestId(TEST_CONFIG.steps.second);
          expect(currentStep).toHaveAttribute('aria-current', 'true');
          expect(currentStep).toHaveAttribute('aria-label', 'Experience Mapping - Current step');
        });

        it('announces progress updates', async () => {
          const { utils } = await setupTest();

          // Complete step and verify progress announcements
          await utils.completeStep(TEST_CONFIG.steps.initial);

          const progressBar = screen.getByRole('progressbar');
          expect(progressBar).toHaveAttribute('aria-valuenow', '12.5');
          expect(progressBar).toHaveAttribute('aria-valuemin', '0');
          expect(progressBar).toHaveAttribute('aria-valuemax', '100');
          expect(progressBar).toHaveAttribute('aria-valuetext', '1 of 8 steps completed');
          expect(progressBar).toHaveAttribute('aria-label', 'Interview preparation progress');
        });
      });

      describe('Keyboard Navigation', () => {
        it('supports complete keyboard interaction flow', async () => {
          const { utils } = await setupTest();

          // Navigate to first step
          await utils.user.tab(); // Focus first step
          expect(document.activeElement).toHaveAttribute('aria-label', 'Requirements Analysis - Current step');

          // Complete step
          await utils.user.keyboard('{Enter}');
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');

          // Navigate to next step
          await utils.user.tab(); // Focus next button
          await utils.user.keyboard('{Enter}');
          await utils.verifyStepState(TEST_CONFIG.steps.second, 'active');

          // Return to previous step
          await utils.user.tab(); // Focus back button
          await utils.user.keyboard('{Enter}');
          await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
        });

        it('traps focus within active modal dialogs', async () => {
          const { utils } = await setupTest();

          // Trigger error dialog
          server.use(
            rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
              return res(ctx.status(500), ctx.json({
                success: false,
                error: { message: 'Server error' }
              }));
            })
          );

          await utils.completeStep(TEST_CONFIG.steps.initial);

          // Verify focus trap
          const dialog = screen.getByRole('dialog');
          const dismissButton = within(dialog).getByRole('button', { name: 'Dismiss' });

          await utils.user.tab();
          expect(document.activeElement).toBe(dismissButton);

          await utils.user.keyboard('{Tab}');
          expect(document.activeElement).toBe(dismissButton); // Focus should stay in dialog
        });
      });
    });
    });

      describe('Step Dependencies and State Management', () => {
        beforeEach(() => {
          jest.useFakeTimers();
        });

        afterEach(() => {
          jest.useRealTimers();
          jest.clearAllMocks();
        });

        describe('Step Dependencies', () => {
          it('enforces step completion order', async () => {
            const { utils } = await setupTest();

            // Attempt to complete second step before first
            await utils.completeStep(TEST_CONFIG.steps.second);
            await utils.verifyStepState(TEST_CONFIG.steps.second, 'error');
            await utils.verifyErrorState('Previous step must be completed first');

            // Complete first step and verify second becomes available
            await utils.completeStep(TEST_CONFIG.steps.initial);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
            await utils.verifyStepState(TEST_CONFIG.steps.second, 'active');
          });

          it('preserves step data during navigation', async () => {
            const { utils } = await setupTest();

            // Complete first step with data
            const stepData = { requirements: ['test1', 'test2'] };
            await utils.completeStep(TEST_CONFIG.steps.initial, stepData);

            // Navigate away and back
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
            await utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial);

            // Verify data is preserved
            await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);
          });

          it('maintains step dependencies during async operations', async () => {
            const { utils } = await setupTest();

            // Start multiple step completions
            const firstStep = utils.completeStep(TEST_CONFIG.steps.initial);
            const secondStep = utils.completeStep(TEST_CONFIG.steps.second);

            // Complete first step
            await firstStep;
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');

            // Verify second step failed due to dependency
            await secondStep;
            await utils.verifyStepState(TEST_CONFIG.steps.second, 'error');
          });
        });

        describe('State Management', () => {
          it('handles step state transitions correctly', async () => {
            const { utils } = await setupTest();

          // Verify initial step states
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'active');
          await utils.verifyStep(TEST_CONFIG.steps.second, 'disabled');
          await utils.verifyNavigationControls({ back: false, next: false });

          // Complete first step and verify dependencies
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
          await utils.verifyStep(TEST_CONFIG.steps.second, 'active');
          await utils.verifyNavigationControls({ back: false, next: true });

          // Verify later steps remain locked
          const laterSteps = ['mock-interview', 'feedback-analysis', 'interview-strategy'];
          for (const stepId of laterSteps) {
            await utils.verifyStep(stepId, 'disabled');
          }
        });

        it('maintains state during full navigation cycle', async () => {
          const { utils } = await setupTest();

          // Complete initial steps
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.navigate('Next', TEST_CONFIG.steps.second);
          await utils.completeStep(TEST_CONFIG.steps.second);

          // Navigate through all steps forward
          const allSteps = Object.values(TEST_CONFIG.steps);
          for (const [index, stepId] of allSteps.entries()) {
            await utils.navigate('Next', stepId);
            await utils.verifyStep(stepId, stepId === TEST_CONFIG.steps.second ? 'completed' : 'active');
            await utils.verifyNavigationControls({
              back: index > 0,
              next: index < allSteps.length - 1 || stepId === TEST_CONFIG.steps.second
            });
          }

          // Navigate backward and verify state preservation
          for (const [index, stepId] of [...allSteps].reverse().entries()) {
            await utils.navigate('Back', stepId);
            await utils.verifyStep(stepId, stepId === TEST_CONFIG.steps.second ? 'completed' : 'active');
            await utils.verifyNavigationControls({
              back: index > 0,
              next: stepId === TEST_CONFIG.steps.second
            });
          }
        });
      });

      describe('Initialization and Data Loading', () => {
        it('handles missing job or resume IDs', async () => {
          const { utils } = await setupTest({
            props: { jobId: '', resumeId: TEST_CONFIG.defaultProps.resumeId }
          });

          await utils.verifyError('Missing required job or resume ID');
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'disabled');
        });

        it('retries initialization on network failure', async () => {
          // First attempt fails
          mockedInterviewPrepUtils.initializeInterviewPrep.mockRejectedValueOnce(
            new ApiError('Network error', 503, { error: 'SERVICE_UNAVAILABLE' })
          );

          const { utils } = await setupTest();

          // Verify error state
          await utils.verifyError('Service temporarily unavailable');

          // Retry succeeds
          await utils.retryInitialization();
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'active');
          expect(mockedInterviewPrepUtils.initializeInterviewPrep).toHaveBeenCalledTimes(2);
        });

        it('preserves step data during navigation', async () => {
          const { utils } = await setupTest();

          // Complete first step with data
          const stepData = { key: 'test-data' };
          await utils.completeStep(TEST_CONFIG.steps.initial, stepData);

          // Navigate away and back
          await utils.navigate('Next', TEST_CONFIG.steps.second);
          await utils.navigate('Back', TEST_CONFIG.steps.initial);

          // Verify data persistence
          await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);
        });
      });

      describe('Component State Management', () => {
        it('prevents concurrent step operations', async () => {
          const { utils } = await setupTest();

          // Start completion
          const completion = utils.completeStep(TEST_CONFIG.steps.initial);

          // Verify UI locked
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'loading');
          await utils.verifyNavigationControls({ back: false, next: false });

          // Complete operation
          await completion;
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
        });

        it('handles step component unmounting during operations', async () => {
          const { utils } = await setupTest();

          // Start completion but unmount before it finishes
          const completion = utils.completeStep(TEST_CONFIG.steps.initial);
          utils.unmount();

          // Operation should complete without errors
          await completion;
          expect(console.error).not.toHaveBeenCalled();
        });

        it('maintains consistent progress calculation', async () => {
          const { utils } = await setupTest();

          // Complete multiple steps rapidly
          await Promise.all([
            utils.completeStep(TEST_CONFIG.steps.initial),
            utils.completeStep(TEST_CONFIG.steps.second)
          ]);

          // Verify final progress is accurate
          await utils.verifyProgress(25); // 2/8 steps
        });
      });

      describe('Error Handling and Recovery', () => {
        beforeEach(() => {
          jest.useFakeTimers();
        });

        afterEach(() => {
          jest.useRealTimers();
          jest.clearAllMocks();
        });

        describe('Error States', () => {
          it('handles API validation errors', async () => {
            const { utils } = await setupTest();

            // Setup validation error
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                return res(ctx.status(400), ctx.json({
                  success: false,
                  error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid step data',
                    details: ['requirements field is required']
                  }
                }));
              })
            );

            // Attempt step completion
            await utils.completeStep(TEST_CONFIG.steps.initial, {});

            // Verify error state
            await utils.verifyErrorState('Invalid step data');
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'error');

            // Verify error details are displayed
            const errorMessage = screen.getByText('requirements field is required');
            expect(errorMessage).toBeInTheDocument();
          });

          it('handles network connectivity errors', async () => {
            const { utils } = await setupTest();

            // Setup network error
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                return res.networkError('Failed to connect');
              })
            );

            // Attempt step completion
            await utils.completeStep(TEST_CONFIG.steps.initial);

            // Verify error state
            await utils.verifyErrorState('Network error: Failed to connect');
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'error');

            // Verify retry button is available
            const retryButton = screen.getByRole('button', { name: /retry/i });
            expect(retryButton).toBeInTheDocument();
          });

          it('handles server errors with fallback UI', async () => {
            const { utils } = await setupTest();

            // Setup server error
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                return res(ctx.status(500), ctx.json({
                  success: false,
                  error: { message: 'Internal server error' }
                }));
              })
            );

            // Attempt step completion
            await utils.completeStep(TEST_CONFIG.steps.initial);

            // Verify error state and fallback UI
            await utils.verifyErrorState('Internal server error');
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'error');

            const fallbackMessage = screen.getByText(/please try again later/i);
            expect(fallbackMessage).toBeInTheDocument();
          });
        });

        describe('Error Recovery', () => {
          it('recovers from transient errors with retry', async () => {
            const { utils } = await setupTest();

            // Setup initial error then success
            let attemptCount = 0;
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                attemptCount++;
                if (attemptCount === 1) {
                  return res(ctx.status(503), ctx.json({
                    success: false,
                    error: { message: 'Service temporarily unavailable' }
                  }));
                }
                return res(ctx.json({
                  success: true,
                  step: {
                    id: TEST_CONFIG.steps.initial,
                    status: 'completed',
                    data: { requirements: ['test'] }
                  }
                }));
              })
            );

            // First attempt fails
            await utils.completeStep(TEST_CONFIG.steps.initial, { requirements: ['test'] });
            await utils.verifyErrorState('Service temporarily unavailable');

            // Retry succeeds
            await utils.retryStep(TEST_CONFIG.steps.initial);
            await utils.verifyErrorState(null);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
          });

          it('preserves form data during error recovery', async () => {
            const { utils } = await setupTest();

            // Setup error response
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                return res(ctx.status(500), ctx.json({
                  success: false,
                  error: { message: 'Server error' }
                }));
              })
            );

            const stepData = { requirements: ['test1', 'test2'] };
            await utils.completeStep(TEST_CONFIG.steps.initial, stepData);

            // Verify error state preserves data
            await utils.verifyErrorState('Server error');
            await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);

            // Setup success for retry
            server.use(testUtils.mockApiResponse(true, {
              step: {
                id: TEST_CONFIG.steps.initial,
                status: 'completed',
                data: stepData
              }
            }));

            // Retry and verify data persists
            await utils.retryStep(TEST_CONFIG.steps.initial);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
            await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);
          });

          it('handles multiple error states gracefully', async () => {
            const { utils } = await setupTest();

            // Setup sequence of errors
            const errors = [
              { status: 400, message: 'Validation error' },
              { status: 503, message: 'Service unavailable' },
              { status: 500, message: 'Server error' }
            ];

            let errorIndex = 0;
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                const error = errors[errorIndex++ % errors.length];
                return res(ctx.status(error.status), ctx.json({
                  success: false,
                  error: { message: error.message }
                }));
              })
            );

            // Attempt multiple operations
            for (const error of errors) {
              await utils.completeStep(TEST_CONFIG.steps.initial);
              await utils.verifyErrorState(error.message);
              await utils.verifyStepState(TEST_CONFIG.steps.initial, 'error');
            }

            // Setup success for final retry
            server.use(testUtils.mockApiResponse(true));

            // Verify recovery
            await utils.retryStep(TEST_CONFIG.steps.initial);
            await utils.verifyErrorState(null);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
          });
        });
      });
          mockedInterviewPrepUtils.completeInterviewStep.mockImplementationOnce(
            () => new Promise(resolve => setTimeout(resolve, 1000))
          );

          // Start step completion
          const completion = utils.completeStep(TEST_CONFIG.steps.initial);

          // Verify loading indicators
          await utils.verifyLoadingState(true);
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'loading');

          // Complete operation
          jest.advanceTimersByTime(1000);
          await completion;

          // Verify loading cleared
          await utils.verifyLoadingState(false);
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
        });

        it('handles validation errors with clear feedback', async () => {
          const { utils } = await setupTest();

          // Trigger validation error
          mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(
            new ApiError('Invalid step data', 400, {
              error: 'VALIDATION_ERROR',
              details: ['Required field missing']
            })
          );

          // Attempt step completion
          await utils.completeStep(TEST_CONFIG.steps.initial).catch(() => {});

          // Verify error display
          await utils.verifyError('Invalid step data: Required field missing');
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'error');
        });

        it('recovers gracefully from server errors', async () => {
          const { utils } = await setupTest();

          // Setup server error
          mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(
            new ApiError('Internal server error', 500, { error: 'INTERNAL_ERROR' })
          );

          // Attempt step completion
          await utils.completeStep(TEST_CONFIG.steps.initial).catch(() => {});

          // Verify error state
          await utils.verifyError('Internal server error');
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'error');

          // Retry successfully
          mockedInterviewPrepUtils.completeInterviewStep.mockResolvedValueOnce({ success: true });
          await utils.retryStep(TEST_CONFIG.steps.initial);

          // Verify recovery
          await utils.verifyStep(TEST_CONFIG.steps.initial, 'completed');
          await utils.verifyError(null);
        });

        it('provides accessible error notifications', async () => {
          const { utils } = await setupTest();

          // Trigger error
          mockedInterviewPrepUtils.completeInterviewStep.mockRejectedValueOnce(
            new ApiError('Connection error', 503, { error: 'SERVICE_UNAVAILABLE' })
          );

          // Attempt step completion
          await utils.completeStep(TEST_CONFIG.steps.initial).catch(() => {});

          // Verify error accessibility
          const errorAlert = screen.getByRole('alert');
          expect(errorAlert).toHaveTextContent('Connection error');
          expect(errorAlert).toHaveAttribute('aria-live', 'assertive');

          // Verify error can be dismissed via keyboard
          await utils.user.tab();
          expect(screen.getByRole('button', { name: /dismiss/i })).toHaveFocus();
          await utils.user.keyboard('{Enter}');
          expect(screen.queryByRole('alert')).not.toBeInTheDocument();
        });
      });

      describe('Performance and Optimization', () => {
        beforeEach(() => {
          jest.useFakeTimers();
        });

        afterEach(() => {
          jest.useRealTimers();
          jest.clearAllMocks();
        });

        describe('Debouncing and Throttling', () => {
          it('debounces rapid step completion attempts', async () => {
            const { utils } = await setupTest();

            // Track API calls
            let apiCallCount = 0;
            server.use(
              rest.post('*/api/interview-prep/step/complete', (req, res, ctx) => {
                apiCallCount++;
                return res(ctx.json({
                  success: true,
                  step: {
                    id: TEST_CONFIG.steps.initial,
                    status: 'completed'
                  }
                }));
              })
            );

            // Rapid completion attempts
            for (let i = 0; i < 5; i++) {
              utils.completeStep(TEST_CONFIG.steps.initial);
              jest.advanceTimersByTime(50); // Less than debounce delay
            }

            // Wait for debounce
            jest.advanceTimersByTime(TEST_CONFIG.timeouts.debounce);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');

            // Verify only one API call made
            expect(apiCallCount).toBe(1);
          });

          it('throttles navigation between steps', async () => {
            const { utils } = await setupTest();

            // Complete first step
            await utils.completeStep(TEST_CONFIG.steps.initial);

            // Attempt rapid navigation
            const navigationAttempts = [
              utils.navigateAndVerify('Next', TEST_CONFIG.steps.second),
              utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial),
              utils.navigateAndVerify('Next', TEST_CONFIG.steps.second)
            ];

            // Wait for throttle
            jest.advanceTimersByTime(TEST_CONFIG.timeouts.throttle);
            await Promise.all(navigationAttempts);

            // Verify final state
            await utils.verifyStepState(TEST_CONFIG.steps.second, 'active');
          });
        });

        describe('Caching and Memoization', () => {
          it('caches step data between navigations', async () => {
            const { utils } = await setupTest();

            // Track API calls
            let apiCallCount = 0;
            server.use(
              rest.get('*/api/interview-prep/step/:id', (req, res, ctx) => {
                apiCallCount++;
                return res(ctx.json({
                  success: true,
                  step: {
                    id: req.params.id,
                    status: 'completed',
                    data: { cached: true }
                  }
                }));
              })
            );

            // Navigate between steps
            await utils.completeStep(TEST_CONFIG.steps.initial);
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
            await utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial);
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

            // Verify cached data used
            expect(apiCallCount).toBe(1); // Only one API call for initial data
          });

          it('invalidates cache on step updates', async () => {
            const { utils } = await setupTest();

            // Complete step with initial data
            await utils.completeStep(TEST_CONFIG.steps.initial, { version: 1 });
            await utils.verifyStepData(TEST_CONFIG.steps.initial, { version: 1 });

            // Update step data
            await utils.completeStep(TEST_CONFIG.steps.initial, { version: 2 });
            await utils.verifyStepData(TEST_CONFIG.steps.initial, { version: 2 });

            // Navigate and verify updated data persists
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
            await utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial);
            await utils.verifyStepData(TEST_CONFIG.steps.initial, { version: 2 });
          });
        });

        describe('Resource Management', () => {
          it('cleans up resources on unmount', async () => {
            const { utils, container } = await setupTest();

            // Setup API subscriptions
            await utils.completeStep(TEST_CONFIG.steps.initial);
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

            // Unmount and verify cleanup
            container.unmount();
            expect(mockedInterviewPrepUtils.cleanup).toHaveBeenCalled();
          });

          it('handles interrupted operations on navigation', async () => {
            const { utils } = await setupTest();

            // Start long operation
            const completion = utils.completeStep(TEST_CONFIG.steps.initial);
            await utils.verifyLoadingState(true);

            // Navigate away before completion
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

            // Verify operation cancelled
            await completion;
            await utils.verifyLoadingState(false);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'active');
          });
        });
      });

      describe('Step Data Management', () => {
        beforeEach(() => {
          jest.useFakeTimers();
        });

        afterEach(() => {
          jest.useRealTimers();
          jest.clearAllMocks();
        });

        describe('Data Persistence', () => {
          it('saves and retrieves step data correctly', async () => {
            const { utils } = await setupTest();

            // Complete step with data
            const stepData = {
              requirements: ['React', 'TypeScript'],
              experience: ['3+ years', 'Team lead'],
              notes: 'Important technical requirements'
            };

            await utils.completeStep(TEST_CONFIG.steps.initial, stepData);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
            await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);

            // Navigate away and back
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
            await utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial);

            // Verify data persists
            await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);
          });

          it('handles data updates for completed steps', async () => {
            const { utils } = await setupTest();

            // Complete step with initial data
            const initialData = { requirements: ['React'] };
            await utils.completeStep(TEST_CONFIG.steps.initial, initialData);

            // Update step data
            const updatedData = { requirements: ['React', 'TypeScript'] };
            await utils.completeStep(TEST_CONFIG.steps.initial, updatedData);

            // Verify update
            await utils.verifyStepData(TEST_CONFIG.steps.initial, updatedData);
          });
        });

        describe('Data Validation', () => {
          it('validates required fields', async () => {
            const { utils } = await setupTest();

            // Attempt completion without required data
            await utils.completeStep(TEST_CONFIG.steps.initial, {});
            await utils.verifyErrorState('Required field missing: requirements');

            // Complete with valid data
            const validData = { requirements: ['React'] };
            await utils.completeStep(TEST_CONFIG.steps.initial, validData);
            await utils.verifyStepState(TEST_CONFIG.steps.initial, 'completed');
          });

          it('sanitizes step data before saving', async () => {
            const { utils } = await setupTest();

            // Complete with data needing sanitization
            const dirtyData = {
              requirements: ['  React  ', '', 'TypeScript  '],
              notes: '  Clean this text  '
            };

            const expectedData = {
              requirements: ['React', 'TypeScript'],
              notes: 'Clean this text'
            };

            await utils.completeStep(TEST_CONFIG.steps.initial, dirtyData);
            await utils.verifyStepData(TEST_CONFIG.steps.initial, expectedData);
          });
        });

        describe('Data Dependencies', () => {
          it('propagates data between dependent steps', async () => {
            const { utils } = await setupTest();

            // Complete first step with requirements
            const firstStepData = { requirements: ['React', 'TypeScript'] };
            await utils.completeStep(TEST_CONFIG.steps.initial, firstStepData);

            // Navigate to second step
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);

            // Verify second step pre-filled with relevant data
            await utils.verifyStepData(TEST_CONFIG.steps.second, {
              technologies: firstStepData.requirements
            });
          });

          it('updates dependent steps on data changes', async () => {
            const { utils } = await setupTest();

            // Complete first step
            await utils.completeStep(TEST_CONFIG.steps.initial, {
              requirements: ['React']
            });

            // Complete second step
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
            await utils.completeStep(TEST_CONFIG.steps.second, {
              technologies: ['React'],
              experience: '3+ years'
            });

            // Update first step data
            await utils.navigateAndVerify('Back', TEST_CONFIG.steps.initial);
            await utils.completeStep(TEST_CONFIG.steps.initial, {
              requirements: ['React', 'TypeScript']
            });

            // Verify second step updated
            await utils.navigateAndVerify('Next', TEST_CONFIG.steps.second);
            await utils.verifyStepData(TEST_CONFIG.steps.second, {
              technologies: ['React', 'TypeScript'],
              experience: '3+ years'
            });
          });
        });
      });
          await utils.completeStep(TEST_CONFIG.steps.initial, stepData);

          // Open summary dialog
          await utils.openSummary();

          // Verify summary content
          const dialog = screen.getByRole('dialog');
          expect(dialog).toHaveAttribute('aria-labelledby', expect.any(String));
          
          const title = screen.getByText('Interview Preparation Summary');
          expect(title.id).toBe(dialog.getAttribute('aria-labelledby'));

          // Verify step data display
          expect(screen.getByText('React')).toBeInTheDocument();
          expect(screen.getByText('TypeScript')).toBeInTheDocument();
          expect(screen.getByText('Important technical requirements')).toBeInTheDocument();
        });

        it('handles step data updates correctly', async () => {
          const { utils } = await setupTest();

          // Initial step completion
          const initialData = { requirements: ['React'] };
          await utils.completeStep(TEST_CONFIG.steps.initial, initialData);

          // Update step data
          const updatedData = { requirements: ['React', 'Node.js'] };
          await utils.updateStepData(TEST_CONFIG.steps.initial, updatedData);

          // Verify data update
          await utils.verifyStepData(TEST_CONFIG.steps.initial, updatedData);
        });

        it('preserves step data during component remounts', async () => {
          const { utils } = await setupTest();

          // Complete step with data
          const stepData = { requirements: ['React'] };
          await utils.completeStep(TEST_CONFIG.steps.initial, stepData);

          // Remount component
          utils.rerender();

          // Verify data persistence
          await utils.verifyStepData(TEST_CONFIG.steps.initial, stepData);
        });

        it('handles summary dialog accessibility', async () => {
          const { utils } = await setupTest();

          // Open dialog
          await utils.openSummary();

          // Verify dialog accessibility
          const dialog = screen.getByRole('dialog');
          expect(dialog).toHaveAttribute('aria-modal', 'true');

          // Verify focus trap
          const closeButton = screen.getByRole('button', { name: /close/i });
          await utils.user.tab();
          expect(closeButton).toHaveFocus();

          // Close with keyboard
          await utils.user.keyboard('{Escape}');
          expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
        });

        it('updates summary when steps are modified', async () => {
          const { utils } = await setupTest();

          // Complete first step
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.openSummary();

          // Verify initial summary
          expect(screen.getByText('1/8 Steps Completed')).toBeInTheDocument();

          // Complete another step
          await utils.closeSummary();
          await utils.navigate('Next', TEST_CONFIG.steps.second);
          await utils.completeStep(TEST_CONFIG.steps.second);
          await utils.openSummary();

          // Verify updated summary
          expect(screen.getByText('2/8 Steps Completed')).toBeInTheDocument();
        });
      });

      describe('Progress Tracking', () => {
        it('calculates progress accurately', async () => {
          const { utils } = await setupTest();

          // Initial state
          await utils.verifyProgress(0);
          await utils.verifyNavigationControls({ back: false, next: false });

          // Complete steps and verify progress
          const steps = [TEST_CONFIG.steps.initial, TEST_CONFIG.steps.second];
          for (const [index, stepId] of steps.entries()) {
            await utils.completeStep(stepId);
            await utils.verifyProgress(
              ((index + 1) / TEST_CONFIG.totalSteps) * 100
            );
            await utils.verifyNavigationControls({
              back: index > 0,
              next: true
            });
          }
        });

        it('persists progress during navigation', async () => {
          const { utils } = await setupTest();

          // Complete steps
          await utils.completeStep(TEST_CONFIG.steps.initial);
          await utils.navigate('Next', TEST_CONFIG.steps.second);
          await utils.completeStep(TEST_CONFIG.steps.second);

          // Navigate and verify progress persistence
          await utils.navigate('Back', TEST_CONFIG.steps.initial);
          await utils.verifyProgress(25); // 2/8 steps
          await utils.verifyNavigationControls({ back: false, next: true });

          await utils.navigate('Next', TEST_CONFIG.steps.second);
          await utils.verifyProgress(25);
          await utils.verifyNavigationControls({ back: true, next: true });

          // Navigate through remaining steps
          const remainingSteps = Object.values(TEST_CONFIG.steps).slice(2);
          for (const [index, stepId] of remainingSteps.entries()) {
            await utils.navigate('Next', stepId);
            await utils.verifyProgress(25);
            await utils.verifyNavigationControls({
              back: true,
              next: index < remainingSteps.length - 1
            });
          }
        });
      });        backEnabled: step !== stepsToComplete[0], 
        progress: 37.5 
      });
    }

    // Cleanup
    jest.useRealTimers();
    container.remove();
  });
});
