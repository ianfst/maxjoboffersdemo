import React from 'react';

const mockIcon = () => <div data-testid="mock-icon" />;

// Mock all Material-UI icons
jest.mock('@mui/icons-material/Save', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Help', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Download', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Print', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Check', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Warning', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Psychology', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Assessment', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Style', () => ({ __esModule: true, default: mockIcon }));
jest.mock('@mui/icons-material/Person', () => ({ __esModule: true, default: mockIcon }));
