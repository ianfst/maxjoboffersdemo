import { InterviewPrep } from '../../../types/interview';

export type InterviewPrepStep = {
  status: 'pending' | 'completed';
  data: any;
};

export type InterviewPrepData = {
  id: string;
  jobId: string;
  resumeId: string;
  status: 'in_progress' | 'completed';
  completedSteps: string[];
  steps: Record<string, InterviewPrepStep>;
};

export const createMockInterviewPrep = (jobId: string, resumeId: string): InterviewPrepData => ({
  id: '123',
  jobId,
  resumeId,
  status: 'in_progress',
  completedSteps: [],
  steps: {
    'requirements-analysis': { status: 'pending', data: null },
    'experience-mapping': { status: 'pending', data: null },
    'behavioral-prep': { status: 'pending', data: null },
    'technical-prep': { status: 'pending', data: null },
    'company-research': { status: 'pending', data: null },
    'mock-interview': { status: 'pending', data: null },
    'feedback-analysis': { status: 'pending', data: null },
    'interview-strategy': { status: 'pending', data: null },
  }
});

export const mockApiResponses = {
  success: (data: any) => ({
    status: 200,
    json: () => Promise.resolve(data),
    ok: true,
  }),
  error: (status: number, message: string) => ({
    status,
    json: () => Promise.resolve({ error: message }),
    ok: false,
  }),
};

export const prepComponentsList = [
  'RequirementsAnalysis',
  'ExperienceMapping',
  'BehavioralPrep',
  'TechnicalPrep',
  'CompanyResearch',
  'MockInterview',
  'FeedbackAnalysis',
  'InterviewStrategy'
];
