import React from 'react';

type PrepComponentProps = {
  onComplete: (data: any) => void;
  disabled?: boolean;
  data?: any;
  interviewPrep?: any;
};

export const RequirementsAnalysis = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="requirements-analysis" role="step">
    <button 
      onClick={() => onComplete({
        overallMatch: 0.85,
        mustHaveSkills: [
          { skill: 'JavaScript', matched: true },
          { skill: 'React', matched: true },
          { skill: 'Node.js', matched: false }
        ],
        niceToHaveSkills: [
          { skill: 'TypeScript', matched: true },
          { skill: 'GraphQL', matched: false }
        ]
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Requirements Analysis
    </button>
  </div>
);

export const ExperienceMapping = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="experience-mapping" role="step">
    <button 
      onClick={() => onComplete({
        mappings: [
          { requirement: 'Leadership', experience: 'Team Lead', strength: 4 },
          { requirement: 'Technical Skills', experience: 'Project X', strength: 5 }
        ]
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Experience Mapping
    </button>
  </div>
);

export const BehavioralPrep = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="behavioral-prep" role="step">
    <button 
      onClick={() => onComplete({
        scenarios: ['Leadership', 'Conflict Resolution'],
        responses: ['Example 1', 'Example 2'],
        confidence: 4
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Behavioral Prep
    </button>
  </div>
);

export const TechnicalPrep = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="technical-prep" role="step">
    <button 
      onClick={() => onComplete({
        topics: ['System Design', 'Algorithms'],
        practiceProblems: ['Problem 1', 'Problem 2'],
        confidence: 4
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Technical Prep
    </button>
  </div>
);

export const CompanyResearch = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="company-research" role="step">
    <button 
      onClick={() => onComplete({
        companyName: 'Test Corp',
        industry: 'Technology',
        culture: ['Innovation', 'Collaboration'],
        market: 'Growing'
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Research
    </button>
  </div>
);

export const MockInterview = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="mock-interview" role="step">
    <button 
      onClick={() => onComplete({
        questions: ['Q1', 'Q2'],
        answers: ['A1', 'A2'],
        feedback: { technical: 4, communication: 5, overall: 4.5 }
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Mock Interview
    </button>
  </div>
);

export const FeedbackAnalysis = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="feedback-analysis" role="step">
    <button 
      onClick={() => onComplete({
        strengths: ['Communication', 'Technical Knowledge'],
        improvements: ['Body Language', 'Conciseness'],
        score: 4.2
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Feedback
    </button>
  </div>
);

export const InterviewStrategy = ({ onComplete, disabled }: PrepComponentProps) => (
  <div data-testid="interview-strategy" role="step">
    <button 
      onClick={() => onComplete({
        strategies: ['STAR Method', 'Active Listening'],
        timeline: ['Pre-Interview', 'During', 'Post'],
        confidence: 4
      })} 
      disabled={disabled} 
      role="button"
    >
      Complete Strategy
    </button>
  </div>
);
