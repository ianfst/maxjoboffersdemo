import React, { useState } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Container,
  Paper,
  TextField,
  Typography,
  List,
  ListItem,
  ListItemText,
  Divider,
  Grid
} from '@mui/material';
import { useDropzone } from 'react-dropzone';
import api from '../../api/config';

export const InterviewPrep: React.FC = () => {
  const [resume, setResume] = useState<string>('');
  const [jobDescription, setJobDescription] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('');
  const [industry, setIndustry] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [report, setReport] = useState<any>(null);
  const [error, setError] = useState<string>('');

  const onDrop = (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    const reader = new FileReader();
    
    reader.onload = () => {
      setResume(reader.result as string);
    };
    
    reader.readAsText(file);
  };

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc', '.docx']
    },
    multiple: false
  });

  const handleSubmit = async () => {
    try {
      setLoading(true);
      setError('');
      
      const response = await api.post('/interview-prep/analyze', {
        resume,
        job_description: jobDescription,
        company_name: companyName,
        industry
      });
      
      if (response.data.success) {
        setReport(response.data);
        // Trigger download of Word document
        window.location.href = `/download/${response.data.report_path}`;
      } else {
        setError(response.data.error || 'Failed to generate report');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Interview Preparation Assistant
        </Typography>
        
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              variant="outlined"
              label="Company Name"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              sx={{ mb: 2 }}
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              variant="outlined"
              label="Industry"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              sx={{ mb: 2 }}
            />
          </Grid>
        </Grid>
        
        <Paper {...getRootProps()} sx={{ p: 2, mb: 2, cursor: 'pointer' }}>
          <input {...getInputProps()} />
          <Typography align="center">
            Drop your resume here or click to select
          </Typography>
        </Paper>
        
        <TextField
          fullWidth
          multiline
          rows={6}
          variant="outlined"
          label="Job Description"
          value={jobDescription}
          onChange={(e) => setJobDescription(e.target.value)}
          sx={{ mb: 2 }}
        />
        
        <Button
          fullWidth
          variant="contained"
          color="primary"
          onClick={handleSubmit}
          disabled={loading || !resume || !jobDescription || !companyName || !industry}
        >
          {loading ? <CircularProgress size={24} /> : 'Generate Report'}
        </Button>
        
        {error && (
          <Typography color="error" sx={{ mt: 2 }}>
            {error}
          </Typography>
        )}
        
        {report && (
          <Box sx={{ mt: 4 }}>
            <Typography variant="h5" gutterBottom>
              Company Analysis
            </Typography>
            
            <Typography variant="h6" gutterBottom>
              Growth Areas
            </Typography>
            <List>
              {report.company_research.growth_areas.map((area: any, index: number) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={area.area}
                    secondary={area.description}
                  />
                </ListItem>
              ))}
            </List>
            
            <Typography variant="h6" gutterBottom>
              Risks & Challenges
            </Typography>
            <List>
              {report.company_research.risks_challenges.map((risk: any, index: number) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={risk.category}
                    secondary={risk.description}
                  />
                </ListItem>
              ))}
            </List>
            
            <Typography variant="h6" gutterBottom>
              Role Impact
            </Typography>
            <List>
              {Object.entries(report.company_research.role_impact).map(([key, value]: [string, any]) => (
                <ListItem key={key}>
                  <ListItemText
                    primary={key.replace('_', ' ').toUpperCase()}
                    secondary={value.description}
                  />
                </ListItem>
              ))}
            </List>
            
            <Typography variant="h5" gutterBottom sx={{ mt: 2 }}>
              Power Statements
            </Typography>
            <List>
              {report.power_statements.map((statement: any, index: number) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={statement.requirement}
                    secondary={statement.statement}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </Box>
    </Container>
  );
};
