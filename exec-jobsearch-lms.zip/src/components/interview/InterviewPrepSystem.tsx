import React, { useState } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Typography,
  Container,
  Paper,
  Grid,
  Tabs,
  Tab,
  CircularProgress,
  Divider
} from '@mui/material';
import { CompanyResearch } from './prep/CompanyResearch';
import { PositionAnalysis } from './prep/PositionAnalysis';
import { StoryPreparation } from './prep/StoryPreparation';
import { PracticeSession } from './prep/PracticeSession';
import { FeedbackAnalysis } from './prep/FeedbackAnalysis';
import { InterviewStrategy } from './prep/InterviewStrategy';

const steps = [
  'Company Research',
  'Position Analysis',
  'Story Preparation',
  'Practice Session',
  'Feedback Analysis',
  'Interview Strategy'
];

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`prep-tabpanel-${index}`}
      aria-labelledby={`prep-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

export const InterviewPrepSystem: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [tabValue, setTabValue] = useState(0);
  const [loading, setLoading] = useState(false);
  const [prepData, setPrepData] = useState({
    company: {
      research: {},
      culture: {},
      challenges: {},
      opportunities: {}
    },
    position: {
      requirements: [],
      responsibilities: [],
      objectives: [],
      stakeholders: []
    },
    stories: [],
    practiceResults: [],
    feedback: {},
    strategy: {}
  });

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleCompanyDataUpdate = (data: any) => {
    setPrepData(prev => ({
      ...prev,
      company: { ...prev.company, ...data }
    }));
  };

  const handlePositionDataUpdate = (data: any) => {
    setPrepData(prev => ({
      ...prev,
      position: { ...prev.position, ...data }
    }));
  };

  const handleStoryUpdate = (stories: any[]) => {
    setPrepData(prev => ({
      ...prev,
      stories
    }));
  };

  const handlePracticeResult = (result: any) => {
    setPrepData(prev => ({
      ...prev,
      practiceResults: [...prev.practiceResults, result]
    }));
  };

  const handleFeedbackUpdate = (feedback: any) => {
    setPrepData(prev => ({
      ...prev,
      feedback
    }));
  };

  const handleStrategyUpdate = (strategy: any) => {
    setPrepData(prev => ({
      ...prev,
      strategy
    }));
  };

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return <CompanyResearch onUpdate={handleCompanyDataUpdate} />;
      case 1:
        return <PositionAnalysis onUpdate={handlePositionDataUpdate} />;
      case 2:
        return <StoryPreparation onUpdate={handleStoryUpdate} />;
      case 3:
        return <PracticeSession onResult={handlePracticeResult} />;
      case 4:
        return <FeedbackAnalysis onUpdate={handleFeedbackUpdate} practiceResults={prepData.practiceResults} />;
      case 5:
        return <InterviewStrategy onUpdate={handleStrategyUpdate} prepData={prepData} />;
      default:
        return 'Unknown step';
    }
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ width: '100%', mb: 4 }}>
        <Typography variant="h4" gutterBottom align="center">
          Executive Interview Preparation System
        </Typography>
        
        <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
          <Stepper activeStep={activeStep} alternativeLabel>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        </Paper>

        <Grid container spacing={3}>
          <Grid item xs={12} md={9}>
            <Paper elevation={3} sx={{ p: 3, minHeight: '60vh' }}>
              {loading ? (
                <Box display="flex" justifyContent="center" alignItems="center" height="100%">
                  <CircularProgress />
                </Box>
              ) : (
                getStepContent(activeStep)
              )}
            </Paper>
          </Grid>

          <Grid item xs={12} md={3}>
            <Paper elevation={3} sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Progress Overview
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Tabs
                orientation="vertical"
                value={tabValue}
                onChange={handleTabChange}
                sx={{ borderRight: 1, borderColor: 'divider' }}
              >
                <Tab label="Research" />
                <Tab label="Analysis" />
                <Tab label="Stories" />
                <Tab label="Practice" />
                <Tab label="Feedback" />
                <Tab label="Strategy" />
              </Tabs>
            </Paper>
          </Grid>
        </Grid>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
          <Button
            variant="outlined"
            onClick={handleBack}
            disabled={activeStep === 0}
          >
            Back
          </Button>
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={activeStep === steps.length - 1}
          >
            {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
          </Button>
        </Box>
      </Box>
    </Container>
  );
};
