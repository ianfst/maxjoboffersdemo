import React from 'react';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  Avatar,
  LinearProgress,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  Chip,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { mockDashboardData } from '../../mocks/dashboardData';
import { useAuth } from '../../hooks/useAuth';
import { ResourcesAndEventsContainer } from './ResourcesAndEventsContainer';

const DashboardContainer = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const { user } = useAuth();
  const { careerProgress, resumeProgress, coaching } = mockDashboardData;

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      {/* Header Section */}
      <Paper elevation={2} sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Grid container alignItems="center" spacing={2}>
          <Grid item>
            <Avatar
              src={user?.avatar || `https://ui-avatars.com/api/?name=${user?.first_name}+${user?.last_name}`}
              alt={`${user?.first_name} ${user?.last_name}`}
              sx={{ width: 64, height: 64 }}
            />
          </Grid>
          <Grid item xs>
            <Typography variant="h4">{`${user?.first_name} ${user?.last_name}`}</Typography>
            <Typography color="textSecondary">Executive Job Seeker</Typography>
            <Chip
              label={user?.membership_tier || 'standard'}
              color="primary"
              size="small"
              sx={{ mt: 1 }}
            />
          </Grid>
        </Grid>
      </Paper>

      <Grid container spacing={3}>
        {/* Career Progress */}
        <Grid item xs={12} md={8}>
          <Paper elevation={2} sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>Career Progress</Typography>
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="textSecondary">
                Goals Progress ({careerProgress.goalsCompleted}/{careerProgress.totalGoals})
              </Typography>
              <LinearProgress
                variant="determinate"
                value={(careerProgress.goalsCompleted / careerProgress.totalGoals) * 100}
                sx={{ mt: 1 }}
              />
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={4}>
                <Typography variant="h4">{careerProgress.metrics.resumesCreated}</Typography>
                <Typography variant="body2" color="textSecondary">Resumes</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography variant="h4">{careerProgress.metrics.connectionsBuilt}</Typography>
                <Typography variant="body2" color="textSecondary">Connections</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography variant="h4">{careerProgress.metrics.interviewsPracticed}</Typography>
                <Typography variant="body2" color="textSecondary">Interviews</Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* Resume Progress */}
        <Grid item xs={12} md={4}>
          <Paper elevation={2} sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>Resume Status</Typography>
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="textSecondary">ATS Score</Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography variant="h4" sx={{ mr: 1 }}>{resumeProgress.atsScore}</Typography>
                <Typography variant="body2" color="textSecondary">/100</Typography>
              </Box>
            </Box>
            <Typography variant="body2" color="textSecondary">
              Last optimized: {formatDate(resumeProgress.lastOptimized)}
            </Typography>
          </Paper>
        </Grid>

        {/* Coaching Section */}
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>Coaching</Typography>
            {coaching.upcomingSessions.map((session, index) => (
              <Card key={index} sx={{ mb: 2 }}>
                <CardContent>
                  <Typography variant="subtitle1">{session.focus}</Typography>
                  <Typography variant="body2" color="textSecondary">
                    with {session.coachName}
                  </Typography>
                  <Typography variant="body2">
                    {formatDate(session.date)} • {session.duration} minutes
                  </Typography>
                </CardContent>
              </Card>
            ))}
          </Paper>
        </Grid>

        {/* Resources and Events Section */}
        <Grid item xs={12}>
          <ResourcesAndEventsContainer />
        </Grid>
      </Grid>
    </Container>
  );
};

export default DashboardContainer;
