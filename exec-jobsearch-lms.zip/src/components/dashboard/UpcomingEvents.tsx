import {
  Box,
  Paper,
  Typography,
  Button,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Chip,
  Divider,
} from '@mui/material';
import {
  Event as EventIcon,
  VideoCall as VideoCallIcon,
  Group as GroupIcon,
  Person as PersonIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';

interface Event {
  id: string;
  title: string;
  type: 'coaching' | 'networking' | 'workshop';
  startTime: string;
  duration: number;
  host: string;
  meetingUrl?: string;
}

interface UpcomingEventsProps {
  events: Event[];
  loading: boolean;
}

const UpcomingEvents = ({ events, loading }: UpcomingEventsProps) => {
  const getEventIcon = (type: string) => {
    switch (type) {
      case 'coaching':
        return <PersonIcon />;
      case 'networking':
        return <GroupIcon />;
      case 'workshop':
        return <EventIcon />;
      default:
        return <EventIcon />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'coaching':
        return 'primary';
      case 'networking':
        return 'success';
      case 'workshop':
        return 'secondary';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Paper sx={{ p: 3, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" component="h2">
          Upcoming Events
        </Typography>
        <Button
          variant="outlined"
          size="small"
          startIcon={<EventIcon />}
          onClick={() => window.location.href = '/calendar'}
        >
          View Calendar
        </Button>
      </Box>

      {events.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <Typography variant="body1" color="text.secondary" gutterBottom>
            No upcoming events
          </Typography>
          <Button
            variant="contained"
            onClick={() => window.location.href = '/schedule'}
          >
            Schedule a Session
          </Button>
        </Box>
      ) : (
        <List disablePadding>
          {events.map((event, index) => (
            <Box key={event.id}>
              {index > 0 && <Divider sx={{ my: 1 }} />}
              <ListItem
                disablePadding
                sx={{ py: 1 }}
                secondaryAction={
                  event.meetingUrl && (
                    <Button
                      variant="outlined"
                      size="small"
                      startIcon={<VideoCallIcon />}
                      href={event.meetingUrl}
                      target="_blank"
                    >
                      Join
                    </Button>
                  )
                }
              >
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: `${getEventColor(event.type)}.light` }}>
                    {getEventIcon(event.type)}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body1" component="span">
                        {event.title}
                      </Typography>
                      <Chip
                        label={event.type}
                        size="small"
                        color={getEventColor(event.type) as any}
                      />
                    </Box>
                  }
                  secondary={
                    <>
                      <Typography variant="body2" component="span" display="block">
                        {format(new Date(event.startTime), 'MMM d, h:mm a')}
                      </Typography>
                      <Typography variant="body2" component="span" color="text.secondary">
                        with {event.host} • {event.duration} min
                      </Typography>
                    </>
                  }
                />
              </ListItem>
            </Box>
          ))}
        </List>
      )}
    </Paper>
  );
};

export default UpcomingEvents;
