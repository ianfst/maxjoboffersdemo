import {
  Box,
  Paper,
  Typography,
  Button,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  AvatarGroup,
  Chip,
  Divider,
} from '@mui/material';
import {
  Group as GroupIcon,
  Event as EventIcon,
  LocationOn as LocationIcon,
  People as PeopleIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';

interface NetworkingEvent {
  id: string;
  title: string;
  type: 'virtual' | 'in-person';
  date: string;
  location: string;
  description: string;
  attendees: {
    id: string;
    name: string;
    avatar: string;
    role: string;
  }[];
  maxAttendees: number;
  registered: boolean;
}

interface NetworkingSectionProps {
  events: NetworkingEvent[];
  loading: boolean;
}

const NetworkingSection = ({ events, loading }: NetworkingSectionProps) => {
  const handleRegister = async (eventId: string) => {
    try {
      await fetch(`/api/events/${eventId}/register`, {
        method: 'POST',
        credentials: 'include',
      });
      // Refresh events or update UI
    } catch (error) {
      console.error('Error registering for event:', error);
    }
  };

  if (loading) {
    return (
      <Paper sx={{ p: 3, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" component="h2">
          Networking Events
        </Typography>
        <Button
          variant="outlined"
          startIcon={<EventIcon />}
          onClick={() => window.location.href = '/networking'}
        >
          View All Events
        </Button>
      </Box>

      {events.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <GroupIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
          <Typography variant="body1" color="text.secondary" gutterBottom>
            No upcoming networking events
          </Typography>
          <Button
            variant="contained"
            onClick={() => window.location.href = '/networking/browse'}
          >
            Browse Events
          </Button>
        </Box>
      ) : (
        <List disablePadding>
          {events.map((event, index) => (
            <Box key={event.id}>
              {index > 0 && <Divider sx={{ my: 1 }} />}
              <ListItem
                disablePadding
                sx={{ py: 1 }}
                secondaryAction={
                  event.registered ? (
                    <Chip
                      label="Registered"
                      color="success"
                      size="small"
                    />
                  ) : (
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => handleRegister(event.id)}
                    >
                      Register
                    </Button>
                  )
                }
              >
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: 'primary.light' }}>
                    {event.type === 'virtual' ? <GroupIcon /> : <LocationIcon />}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body1" component="span">
                        {event.title}
                      </Typography>
                      <Chip
                        label={event.type}
                        size="small"
                        color={event.type === 'virtual' ? 'info' : 'success'}
                      />
                    </Box>
                  }
                  secondary={
                    <Box>
                      <Typography variant="body2" component="div">
                        {format(new Date(event.date), 'MMM d, h:mm a')}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        component="div"
                        sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}
                      >
                        <LocationIcon fontSize="small" />
                        {event.location}
                      </Typography>
                      <Box sx={{ mt: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                        <AvatarGroup max={3} sx={{ '& .MuiAvatar-root': { width: 24, height: 24 } }}>
                          {event.attendees.map((attendee) => (
                            <Avatar
                              key={attendee.id}
                              alt={attendee.name}
                              src={attendee.avatar}
                              sx={{ width: 24, height: 24 }}
                            />
                          ))}
                        </AvatarGroup>
                        <Typography variant="body2" color="text.secondary">
                          <PeopleIcon fontSize="small" sx={{ verticalAlign: 'middle', mr: 0.5 }} />
                          {event.attendees.length}/{event.maxAttendees} attending
                        </Typography>
                      </Box>
                    </Box>
                  }
                />
              </ListItem>
            </Box>
          ))}
        </List>
      )}
    </Paper>
  );
};

export default NetworkingSection;
