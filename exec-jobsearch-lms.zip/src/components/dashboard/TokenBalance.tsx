import {
  Box,
  Paper,
  Typography,
  Button,
  CircularProgress,
  useTheme,
  Tooltip,
  IconButton,
} from '@mui/material';
import {
  Token as TokenIcon,
  Info as InfoIcon,
  Add as AddIcon,
} from '@mui/icons-material';

interface TokenBalanceProps {
  balance: number;
  loading: boolean;
}

const TokenBalance = ({ balance, loading }: TokenBalanceProps) => {
  const theme = useTheme();

  const getTokenStatus = () => {
    if (balance < 10) return 'low';
    if (balance < 50) return 'medium';
    return 'good';
  };

  const getStatusColor = () => {
    const status = getTokenStatus();
    switch (status) {
      case 'low':
        return theme.palette.error.main;
      case 'medium':
        return theme.palette.warning.main;
      case 'good':
        return theme.palette.success.main;
      default:
        return theme.palette.primary.main;
    }
  };

  if (loading) {
    return (
      <Paper sx={{ p: 3, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" component="h2">
          Token Balance
        </Typography>
        <Tooltip title="Tokens are used for AI interactions, coaching sessions, and accessing premium resources">
          <IconButton size="small">
            <InfoIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>

      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <TokenIcon
          sx={{
            fontSize: 48,
            color: getStatusColor(),
            mr: 2,
          }}
        />
        <Box>
          <Typography variant="h3" component="div" sx={{ fontWeight: 'bold' }}>
            {balance}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Available Tokens
          </Typography>
        </Box>
      </Box>

      <Box sx={{ mb: 2 }}>
        <Typography variant="body2" color="text.secondary" gutterBottom>
          Token Usage
        </Typography>
        <Typography variant="body1">
          • AI Chat: 1 token per message
        </Typography>
        <Typography variant="body1">
          • Coaching: 5 tokens per session
        </Typography>
        <Typography variant="body1">
          • Resources: 2 tokens per premium resource
        </Typography>
      </Box>

      <Button
        variant="contained"
        startIcon={<AddIcon />}
        fullWidth
        onClick={() => window.location.href = '/tokens/purchase'}
      >
        Get More Tokens
      </Button>
    </Paper>
  );
};

export default TokenBalance;
