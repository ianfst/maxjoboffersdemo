import {
  Box,
  Paper,
  Typography,
  LinearProgress,
  Button,
  CircularProgress,
  Grid,
  Chip,
} from '@mui/material';
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
} from '@mui/lab';
import {
  CheckCircle as CheckCircleIcon,
  Flag as FlagIcon,
  EmojiEvents as EmojiEventsIcon,
} from '@mui/icons-material';

interface CareerProgressProps {
  progress: {
    goalsCompleted: number;
    totalGoals: number;
    nextMilestone: string;
  };
  loading: boolean;
}

const CareerProgress = ({ progress, loading }: CareerProgressProps) => {
  const progressPercentage = (progress.goalsCompleted / progress.totalGoals) * 100;

  if (loading) {
    return (
      <Paper sx={{ p: 3, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h6" component="h2">
          Career Progress
        </Typography>
        <Button
          variant="outlined"
          size="small"
          startIcon={<FlagIcon />}
          onClick={() => window.location.href = '/goals'}
        >
          Update Goals
        </Button>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
              <Typography variant="body2" color="text.secondary">
                Goals Progress
              </Typography>
              <Typography variant="body2" color="text.primary">
                {progress.goalsCompleted}/{progress.totalGoals} Complete
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={progressPercentage}
              sx={{ height: 10, borderRadius: 5 }}
            />
          </Box>

          <Box>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Next Milestone
            </Typography>
            <Chip
              icon={<EmojiEventsIcon />}
              label={progress.nextMilestone}
              color="primary"
              variant="outlined"
            />
          </Box>
        </Grid>

        <Grid item xs={12} md={6}>
          <Timeline>
            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="success">
                  <CheckCircleIcon />
                </TimelineDot>
                <TimelineConnector />
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="body1">
                  Complete Profile
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Completed on {new Date().toLocaleDateString()}
                </Typography>
              </TimelineContent>
            </TimelineItem>

            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="success">
                  <CheckCircleIcon />
                </TimelineDot>
                <TimelineConnector />
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="body1">
                  Set Career Goals
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Updated 2 days ago
                </Typography>
              </TimelineContent>
            </TimelineItem>

            <TimelineItem>
              <TimelineSeparator>
                <TimelineDot color="primary">
                  <FlagIcon />
                </TimelineDot>
              </TimelineSeparator>
              <TimelineContent>
                <Typography variant="body1">
                  {progress.nextMilestone}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  In Progress
                </Typography>
              </TimelineContent>
            </TimelineItem>
          </Timeline>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CareerProgress;
