import {
  Box,
  Paper,
  Typography,
  Button,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Rating,
  Chip,
  Divider,
} from '@mui/material';
import {
  Person as PersonIcon,
  Schedule as ScheduleIcon,
  Star as StarIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';

interface CoachingSession {
  id: string;
  coachName: string;
  coachAvatar: string;
  coachSpecialty: string;
  rating: number;
  sessionDate: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  notes?: string;
}

interface CoachingSectionProps {
  sessions: CoachingSession[];
  loading: boolean;
}

const CoachingSection = ({ sessions, loading }: CoachingSectionProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming':
        return 'primary';
      case 'completed':
        return 'success';
      case 'cancelled':
        return 'error';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Paper sx={{ p: 3, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" component="h2">
          Coaching Sessions
        </Typography>
        <Button
          variant="outlined"
          startIcon={<ScheduleIcon />}
          onClick={() => window.location.href = '/coaching/schedule'}
        >
          Schedule Session
        </Button>
      </Box>

      {sessions.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <PersonIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
          <Typography variant="body1" color="text.secondary" gutterBottom>
            No coaching sessions yet
          </Typography>
          <Button
            variant="contained"
            onClick={() => window.location.href = '/coaching/browse'}
          >
            Find a Coach
          </Button>
        </Box>
      ) : (
        <List disablePadding>
          {sessions.map((session, index) => (
            <Box key={session.id}>
              {index > 0 && <Divider sx={{ my: 1 }} />}
              <ListItem disablePadding sx={{ py: 1 }}>
                <ListItemAvatar>
                  <Avatar
                    src={session.coachAvatar}
                    alt={session.coachName}
                  >
                    <PersonIcon />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body1" component="span">
                        {session.coachName}
                      </Typography>
                      <Chip
                        label={session.status}
                        size="small"
                        color={getStatusColor(session.status) as any}
                      />
                    </Box>
                  }
                  secondary={
                    <Box>
                      <Typography variant="body2" component="span" display="block">
                        {format(new Date(session.sessionDate), 'MMM d, h:mm a')}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" component="span">
                        {session.coachSpecialty}
                      </Typography>
                      {session.status === 'completed' && (
                        <Rating
                          value={session.rating}
                          readOnly
                          size="small"
                          icon={<StarIcon fontSize="inherit" />}
                          emptyIcon={<StarIcon fontSize="inherit" />}
                          sx={{ ml: 1 }}
                        />
                      )}
                    </Box>
                  }
                />
              </ListItem>
              {session.notes && session.status === 'completed' && (
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{
                    ml: 7,
                    mt: 1,
                    fontStyle: 'italic',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                  }}
                >
                  "{session.notes}"
                </Typography>
              )}
            </Box>
          ))}
        </List>
      )}
    </Paper>
  );
};

export default CoachingSection;
