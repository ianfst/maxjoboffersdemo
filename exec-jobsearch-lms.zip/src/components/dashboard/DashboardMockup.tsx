import React from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  LinearProgress,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Avatar,
  Stack,
} from '@mui/material';
import {
  Assignment as AssignmentIcon,
  People as PeopleIcon,
  Event as EventIcon,
  CheckCircle as CheckCircleIcon,
  Timeline as TimelineIcon,
} from '@mui/icons-material';

const DashboardMockup: React.FC = () => {
  return (
    <Box sx={{ p: 3 }}>
      {/* Header Section */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Welcome back, John!
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Your job search progress at a glance
        </Typography>
      </Box>

      {/* Career Progress Section */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Career Progress
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <Card>
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Applications Submitted
                    </Typography>
                    <Typography variant="h4">12</Typography>
                    <LinearProgress value={60} variant="determinate" sx={{ mt: 1 }} />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Card>
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Interviews Scheduled
                    </Typography>
                    <Typography variant="h4">3</Typography>
                    <LinearProgress value={40} variant="determinate" sx={{ mt: 1 }} />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Card>
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Network Connections
                    </Typography>
                    <Typography variant="h4">28</Typography>
                    <LinearProgress value={75} variant="determinate" sx={{ mt: 1 }} />
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Paper>

          {/* Resume Status */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">Resume Status</Typography>
              <Button variant="outlined" startIcon={<AssignmentIcon />}>
                Update Resume
              </Button>
            </Box>
            <List>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="success" />
                </ListItemIcon>
                <ListItemText 
                  primary="Executive Summary" 
                  secondary="Last updated 2 days ago"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="success" />
                </ListItemIcon>
                <ListItemText 
                  primary="Work Experience" 
                  secondary="Last updated 1 week ago"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <TimelineIcon color="warning" />
                </ListItemIcon>
                <ListItemText 
                  primary="Skills Section" 
                  secondary="Needs optimization for target roles"
                />
              </ListItem>
            </List>
          </Paper>
        </Grid>

        {/* Right Sidebar */}
        <Grid item xs={12} md={4}>
          {/* Upcoming Events */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Upcoming Events
            </Typography>
            <List>
              <ListItem>
                <ListItemIcon>
                  <EventIcon />
                </ListItemIcon>
                <ListItemText 
                  primary="Technical Interview - Google"
                  secondary="Tomorrow, 2:00 PM"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <PeopleIcon />
                </ListItemIcon>
                <ListItemText 
                  primary="Networking Event - Tech Leaders"
                  secondary="March 25, 6:00 PM"
                />
              </ListItem>
            </List>
            <Button variant="text" fullWidth>
              View All Events
            </Button>
          </Paper>

          {/* Coaching Sessions */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Coaching Sessions
            </Typography>
            <List>
              <ListItem>
                <ListItemIcon>
                  <Avatar>MC</Avatar>
                </ListItemIcon>
                <ListItemText 
                  primary="Mock Interview Practice"
                  secondary="With Mark Chen • March 24, 3:00 PM"
                />
              </ListItem>
            </List>
            <Button variant="contained" fullWidth>
              Schedule Session
            </Button>
          </Paper>

          {/* Recommended Resources */}
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Recommended Resources
            </Typography>
            <Stack spacing={2}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="subtitle2" gutterBottom>
                    Leadership Interview Questions
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Prepare for executive-level interviews
                  </Typography>
                  <Chip 
                    size="small" 
                    label="High Priority" 
                    color="error" 
                    sx={{ mt: 1 }} 
                  />
                </CardContent>
              </Card>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="subtitle2" gutterBottom>
                    Salary Negotiation Guide
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Expert tips for negotiating compensation
                  </Typography>
                  <Chip 
                    size="small" 
                    label="Recommended" 
                    color="primary" 
                    sx={{ mt: 1 }} 
                  />
                </CardContent>
              </Card>
            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardMockup;
