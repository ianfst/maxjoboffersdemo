import React from 'react';
import {
  Box,
  Typography,
  Button,
  Avatar,
  Chip,
  Stack,
  useTheme,
} from '@mui/material';
import { CalendarToday as CalendarIcon } from '@mui/icons-material';
import { User } from '../../contexts/AuthContext';

interface DashboardHeaderProps {
  user: User | null;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({ user }) => {
  const theme = useTheme();

  const getTierChipColor = (tier: string): 'primary' | 'secondary' | 'default' => {
    switch (tier) {
      case 'platinum':
        return 'primary';
      case 'standard':
        return 'secondary';
      default:
        return 'default';
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const isPlatinum = user?.membership_tier === 'platinum';

  return (
    <Box
      sx={{
        mb: 4,
        display: 'flex',
        flexDirection: { xs: 'column', md: 'row' },
        alignItems: { xs: 'flex-start', md: 'center' },
        justifyContent: 'space-between',
        gap: 2,
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        <Avatar
          src={user?.avatar}
          alt={user?.first_name}
          sx={{ width: 64, height: 64 }}
        />
        <Box>
          <Typography variant="h4" gutterBottom>
            {getGreeting()}, {user?.first_name}
          </Typography>
          <Stack direction="row" spacing={1} alignItems="center">
            <Chip
              label={`${user?.membership_tier?.toUpperCase()} Member`}
              sx={{
                bgcolor: isPlatinum ? 'linear-gradient(45deg, #1a237e 30%, #283593 90%)' : undefined,
                color: isPlatinum ? 'white' : undefined
              }}
            />
            {user?.created_at && (
              <Typography variant="body2" color="text.secondary">
                Member since {new Date(user.created_at).toLocaleDateString()}
              </Typography>
            )}
          </Stack>
        </Box>
      </Box>

      <Stack direction="row" spacing={2}>
        <Button
          variant="outlined"
          startIcon={<CalendarIcon />}
          onClick={() => window.location.href = '/schedule'}
        >
          Schedule Session
        </Button>
        <Button
          variant="contained"
          onClick={() => window.location.href = '/goals'}
        >
          Update Goals
        </Button>
      </Stack>
    </Box>
  );
};

export default DashboardHeader;
