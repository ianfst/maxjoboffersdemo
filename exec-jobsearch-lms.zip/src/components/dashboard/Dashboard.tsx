import { useUser } from '../../hooks/useUser';
import DashboardMockup from './DashboardMockup';
import { CircularProgress, Box, Alert } from '@mui/material';

const Dashboard = () => {
  const { user, isLoading, error } = useUser();

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">
          {error.message || 'An error occurred while loading your dashboard'}
        </Alert>
      </Box>
    );
  }

  return <DashboardMockup />;
};

export default Dashboard;
