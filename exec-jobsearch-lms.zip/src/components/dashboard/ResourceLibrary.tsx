import {
  Box,
  Paper,
  Typography,
  Button,
  CircularProgress,
  Grid,
  Card,
  CardContent,
  CardMedia,
  CardActionArea,
  Chip,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Bookmark as BookmarkIcon,
  BookmarkBorder as BookmarkBorderIcon,
  LocalLibrary as LibraryIcon,
  Lock as LockIcon,
} from '@mui/icons-material';
import { useState } from 'react';
import api from '../../api/config';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'article' | 'video' | 'template' | 'guide';
  imageUrl: string;
  premium: boolean;
  bookmarked: boolean;
  tokenCost: number;
  url: string;
}

interface ResourceLibraryProps {
  resources: Resource[];
  loading: boolean;
}

const ResourceLibrary = ({ resources, loading }: ResourceLibraryProps) => {
  const [bookmarkedResources, setBookmarkedResources] = useState<Set<string>>(
    new Set(resources.filter(r => r.bookmarked).map(r => r.id))
  );

  const handleBookmark = async (resourceId: string) => {
    try {
      const isBookmarked = bookmarkedResources.has(resourceId);
      const endpoint = `/api/resources/${resourceId}/${isBookmarked ? 'unbookmark' : 'bookmark'}`;
      await api.post(endpoint);

      setBookmarkedResources(prev => {
        const next = new Set(prev);
        if (isBookmarked) {
          next.delete(resourceId);
        } else {
          next.add(resourceId);
        }
        return next;
      });
    } catch (error) {
      console.error('Error toggling bookmark:', error);
    }
  };

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'article':
        return '📄';
      case 'video':
        return '🎥';
      case 'template':
        return '📑';
      case 'guide':
        return '📚';
      default:
        return '📄';
    }
  };

  if (loading) {
    return (
      <Paper sx={{ p: 3, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h6" component="h2">
          Resource Library
        </Typography>
        <Button
          variant="outlined"
          startIcon={<LibraryIcon />}
          onClick={() => window.location.href = '/resources'}
        >
          View All Resources
        </Button>
      </Box>

      <Grid container spacing={2}>
        {resources.map((resource) => (
          <Grid item xs={12} sm={6} md={4} key={resource.id}>
            <Card>
              <CardActionArea onClick={() => window.location.href = resource.url}>
                <CardMedia
                  component="img"
                  height="140"
                  image={resource.imageUrl}
                  alt={resource.title}
                />
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                    <Typography gutterBottom variant="h6" component="div" noWrap>
                      {resource.title}
                    </Typography>
                    <Tooltip title={bookmarkedResources.has(resource.id) ? 'Remove Bookmark' : 'Bookmark'}>
                      <IconButton
                        size="small"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          handleBookmark(resource.id);
                        }}
                      >
                        {bookmarkedResources.has(resource.id) ? (
                          <BookmarkIcon color="primary" />
                        ) : (
                          <BookmarkBorderIcon />
                        )}
                      </IconButton>
                    </Tooltip>
                  </Box>

                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      mb: 1,
                    }}
                  >
                    {resource.description}
                  </Typography>

                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Chip
                      size="small"
                      label={`${getResourceIcon(resource.type)} ${resource.type}`}
                    />
                    {resource.premium && (
                      <Chip
                        size="small"
                        icon={<LockIcon />}
                        label={`${resource.tokenCost} tokens`}
                        color="primary"
                        variant="outlined"
                      />
                    )}
                  </Box>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Paper>
  );
};

export default ResourceLibrary;
