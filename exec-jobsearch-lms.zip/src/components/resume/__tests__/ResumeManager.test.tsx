import React from 'react';
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ResumeManager } from '../ResumeManager';
import '@testing-library/jest-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

// Mock Material-UI components
jest.mock('@mui/material', () => ({
  Box: ({ children }) => <div className="MuiBox-root">{children}</div>,
  Paper: ({ children }) => <div className="MuiPaper-root">{children}</div>,
  Card: ({ children }) => <div className="MuiCard-root">{children}</div>,
  CardContent: ({ children }) => <div className="MuiCardContent-root">{children}</div>,
  Typography: ({ children, variant }) => <div data-variant={variant}>{children}</div>,
  TextField: ({ label, value, onChange, multiline, rows }) => (
    <div>
      <label>{label}</label>
      <textarea
        data-testid={`textarea-${label}`}
        value={value}
        onChange={onChange}
        rows={rows}
        aria-label={label}
      />
    </div>
  ),
  Dialog: ({ open, onClose, children }) => open ? <div role="dialog">{children}</div> : null,
  DialogTitle: ({ children }) => <div>{children}</div>,
  DialogContent: ({ children }) => <div>{children}</div>,
  DialogActions: ({ children }) => <div>{children}</div>,
  Button: ({ children, onClick, disabled, variant }) => (
    <button onClick={onClick} disabled={disabled} data-variant={variant}>
      {children}
    </button>
  ),
  IconButton: ({ children, onClick, title }) => (
    <button onClick={onClick} title={title}>
      {children}
    </button>
  ),
  CircularProgress: () => <div>Loading...</div>,
  Alert: ({ children, severity }) => <div data-severity={severity}>{children}</div>,
  List: ({ children }) => <div>{children}</div>,
  ListItem: ({ children }) => <div>{children}</div>,
  ListItemText: ({ primary, secondary }) => (
    <div>
      <div>{primary}</div>
      {secondary && <div>{secondary}</div>}
    </div>
  ),
}));

// Mock Material Icons
jest.mock('@mui/icons-material', () => ({
  Upload: () => 'UploadIcon',
  Edit: () => 'EditIcon',
  Download: () => 'DownloadIcon',
  Close: () => 'CloseIcon',
  Delete: () => 'DeleteIcon',
  Add: () => 'AddIcon',
  Refresh: () => 'RefreshIcon',
  Save: () => 'SaveIcon',
}));

// Mock API responses
const mockResumes = [
  {
    id: 'resume1',
    version: 1,
    content: 'Senior Software Engineer with 5 years experience',
    format: 'standard',
    lastModified: '2025-03-06T12:00:00Z',
    score: 85,
  },
  {
    id: 'resume2',
    version: 2,
    content: 'Senior Software Engineer with extensive experience',
    format: 'modern',
    lastModified: '2025-03-06T13:00:00Z',
    score: 90,
  },
];

const mockJobAnalysis = {
  requirements: ['React', 'TypeScript', 'Node.js'],
  skills: ['Frontend Development', 'Backend Development'],
  experience: '5+ years',
  score: 85,
};

// Set up MSW server
const server = setupServer(
  rest.get('/api/resumes/:userId', (req, res, ctx) => {
    return res(ctx.json(mockResumes));
  }),
  rest.post('/api/resume/analyze-job', (req, res, ctx) => {
    return res(ctx.json(mockJobAnalysis));
  }),
  rest.post('/api/resume/:resumeId/rewrite', (req, res, ctx) => {
    const newResume = {
      ...mockResumes[0],
      id: 'resume3',
      version: 3,
      lastModified: new Date().toISOString(),
    };
    return res(ctx.json(newResume));
  }),
  rest.delete('/api/resume/:resumeId', (req, res, ctx) => {
    return res(ctx.json({ success: true }));
  })
);

describe('ResumeManager', () => {
  const defaultProps = {
    userId: 'user123',
    jobData: {
      description: 'Looking for a Senior Software Engineer...',
      requirements: ['React', 'TypeScript'],
    },
  };

  beforeAll(() => server.listen());
  afterEach(() => server.resetHandlers());
  afterAll(() => server.close());

  it('loads and displays resume versions', async () => {
    render(<ResumeManager {...defaultProps} />);

    // Wait for resumes to load
    await waitFor(() => {
      expect(screen.getByText('Version 1')).toBeInTheDocument();
      expect(screen.getByText('Version 2')).toBeInTheDocument();
    });

    // Verify resume details are displayed
    expect(screen.getByText(/Senior Software Engineer with 5 years/)).toBeInTheDocument();
    expect(screen.getByText(/extensive experience/)).toBeInTheDocument();
  });

  it('analyzes job requirements on load', async () => {
    render(<ResumeManager {...defaultProps} />);

    await waitFor(() => {
      expect(screen.getByText('React')).toBeInTheDocument();
      expect(screen.getByText('TypeScript')).toBeInTheDocument();
      expect(screen.getByText('Node.js')).toBeInTheDocument();
    });

    expect(screen.getByText('Job Match Score: 85%')).toBeInTheDocument();
  });

  it('handles resume deletion', async () => {
    render(<ResumeManager {...defaultProps} />);

    // Wait for resumes to load
    await waitFor(() => {
      expect(screen.getByText('Version 1')).toBeInTheDocument();
    });

    // Click delete button for first resume
    const deleteButtons = screen.getAllByTitle('Delete Resume');
    fireEvent.click(deleteButtons[0]);

    // Confirm deletion
    const confirmButton = screen.getByText('Confirm Delete');
    fireEvent.click(confirmButton);

    // Verify success message
    await waitFor(() => {
      expect(screen.getByText(/Resume deleted successfully/)).toBeInTheDocument();
    });
  });

  it('handles resume rewrite', async () => {
    render(<ResumeManager {...defaultProps} />);

    // Wait for resumes to load
    await waitFor(() => {
      expect(screen.getByText('Version 1')).toBeInTheDocument();
    });

    // Click rewrite button
    const rewriteButton = screen.getByText('Rewrite Resume');
    fireEvent.click(rewriteButton);

    // Verify success message and new version
    await waitFor(() => {
      expect(screen.getByText(/Resume rewritten successfully/)).toBeInTheDocument();
      expect(screen.getByText('Version 3')).toBeInTheDocument();
    });
  });

  it('handles errors gracefully', async () => {
    // Mock error response
    server.use(
      rest.get('/api/resumes/:userId', (req, res, ctx) => {
        return res(ctx.status(500), ctx.json({ error: 'Internal server error' }));
      })
    );

    render(<ResumeManager {...defaultProps} />);

    // Verify error message
    await waitFor(() => {
      expect(screen.getByText(/Error loading resumes/)).toBeInTheDocument();
    });
  });

  it('updates resume format', async () => {
    render(<ResumeManager {...defaultProps} />);

    // Wait for resumes to load
    await waitFor(() => {
      expect(screen.getByText('Version 1')).toBeInTheDocument();
    });

    // Open format selector
    const formatButton = screen.getByText('Change Format');
    fireEvent.click(formatButton);

    // Select new format
    const modernFormat = screen.getByText('Modern');
    fireEvent.click(modernFormat);

    // Verify success message
    await waitFor(() => {
      expect(screen.getByText(/Format updated successfully/)).toBeInTheDocument();
    });
  });

  it('preserves state during navigation', async () => {
    const { rerender } = render(<ResumeManager {...defaultProps} />);

    // Wait for initial load
    await waitFor(() => {
      expect(screen.getByText('Version 1')).toBeInTheDocument();
    });

    // Simulate component remount
    rerender(<ResumeManager {...defaultProps} />);

    // Verify state is preserved
    expect(screen.getByText('Version 1')).toBeInTheDocument();
    expect(screen.getByText('Version 2')).toBeInTheDocument();
  });

  it('tracks progress during operations', async () => {
    render(<ResumeManager {...defaultProps} />);

    // Click rewrite button
    const rewriteButton = screen.getByText('Rewrite Resume');
    fireEvent.click(rewriteButton);

    // Verify loading state
    expect(screen.getByText('Loading...')).toBeInTheDocument();

    // Verify completion
    await waitFor(() => {
      expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      expect(screen.getByText(/Resume rewritten successfully/)).toBeInTheDocument();
    });
  });
});
