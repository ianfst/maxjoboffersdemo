import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  LinearProgress,
  Fade,
  Collapse,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  Paper,
  Grid,
  Avatar,
  Tooltip
} from '@mui/material';
import {
  Psychology as AIIcon,
  Person as PersonIcon,
  Search as SearchIcon,
  Assignment as AssignmentIcon,
  CheckCircle as CheckIcon,
  Pending as PendingIcon,
  WorkOutline as WorkIcon,
  TrendingUp as TrendingIcon,
  Analytics as AnalyticsIcon
} from '@mui/icons-material';
import { keyframes } from '@mui/system';

const pulse = keyframes`
  0% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.1);
    opacity: 0.8;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
`;

interface ProcessStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  subSteps: string[];
  insights?: string[];
}

interface ProcessVisualizationProps {
  currentStage: string;
  progress: number;
  insights: Record<string, string[]>;
  onStageComplete: (stage: string) => void;
}

export const ResumeProcessVisualization: React.FC<ProcessVisualizationProps> = ({
  currentStage,
  progress,
  insights,
  onStageComplete
}) => {
  const [activeStep, setActiveStep] = useState<string>(currentStage);
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set());
  const [showInsights, setShowInsights] = useState<boolean>(false);

  const processSteps: ProcessStep[] = [
    {
      id: 'expert_review',
      title: 'Expert Resume Writer Analysis',
      description: 'Our AI is channeling decades of executive resume writing expertise',
      icon: <PersonIcon />,
      subSteps: [
        'Analyzing current resume structure and content',
        'Identifying achievement highlights and metrics',
        'Evaluating executive presence in language',
        'Checking industry best practices alignment',
        'Optimizing professional narrative flow'
      ]
    },
    {
      id: 'keyword_analysis',
      title: 'Advanced Keyword Analysis',
      description: 'Performing deep semantic analysis and optimization',
      icon: <SearchIcon />,
      subSteps: [
        'Extracting key phrases from job description',
        'Analyzing semantic relevance scores',
        'Identifying missing critical keywords',
        'Optimizing keyword placement and density',
        'Verifying ATS compatibility'
      ]
    },
    {
      id: 'ai_enhancement',
      title: 'AI-Powered Enhancement',
      description: 'Applying advanced AI algorithms for optimization',
      icon: <AIIcon />,
      subSteps: [
        'Running natural language processing',
        'Applying industry-specific improvements',
        'Enhancing achievement descriptions',
        'Optimizing professional terminology',
        'Implementing success patterns'
      ]
    },
    {
      id: 'hiring_manager',
      title: 'Hiring Manager Perspective Review',
      description: 'Evaluating through the eyes of a hiring manager',
      icon: <WorkIcon />,
      subSteps: [
        'Assessing qualification alignment',
        'Evaluating experience relevance',
        'Checking leadership demonstration',
        'Verifying impact metrics',
        'Analyzing cultural fit indicators'
      ]
    }
  ];

  useEffect(() => {
    setActiveStep(currentStage);
  }, [currentStage]);

  const ProcessStepCard: React.FC<{
    step: ProcessStep;
    isActive: boolean;
    isCompleted: boolean;
  }> = ({ step, isActive, isCompleted }) => (
    <Card
      sx={{
        mb: 2,
        border: isActive ? '2px solid #1976d2' : 'none',
        bgcolor: isCompleted ? 'action.hover' : 'background.paper',
        position: 'relative',
        overflow: 'visible'
      }}
    >
      <CardContent>
        <Grid container spacing={2} alignItems="center">
          <Grid item>
            <Avatar
              sx={{
                bgcolor: isActive ? 'primary.main' : 'grey.400',
                animation: isActive ? `${pulse} 2s infinite` : 'none'
              }}
            >
              {step.icon}
            </Avatar>
          </Grid>
          <Grid item xs>
            <Typography variant="h6" component="div">
              {step.title}
              {isCompleted && (
                <CheckIcon
                  color="success"
                  sx={{ ml: 1, verticalAlign: 'middle' }}
                />
              )}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {step.description}
            </Typography>
          </Grid>
        </Grid>

        <Collapse in={isActive}>
          <Box mt={2}>
            <List dense>
              {step.subSteps.map((subStep, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    {isCompleted ? (
                      <CheckIcon color="success" fontSize="small" />
                    ) : (
                      <PendingIcon
                        sx={{
                          animation: `${pulse} 1s infinite`,
                          color: 'primary.main'
                        }}
                      />
                    )}
                  </ListItemIcon>
                  <ListItemText primary={subStep} />
                </ListItem>
              ))}
            </List>

            {isActive && insights[step.id] && (
              <Box mt={2}>
                <Typography variant="subtitle2" color="primary" gutterBottom>
                  Live Insights
                </Typography>
                <Box display="flex" flexWrap="wrap" gap={1}>
                  {insights[step.id].map((insight, index) => (
                    <Chip
                      key={index}
                      label={insight}
                      size="small"
                      icon={<TrendingIcon />}
                      variant="outlined"
                    />
                  ))}
                </Box>
              </Box>
            )}
          </Box>
        </Collapse>
      </CardContent>

      {isActive && (
        <LinearProgress
          variant="determinate"
          value={progress}
          sx={{
            position: 'absolute',
            bottom: 0,
            width: '100%',
            height: 4
          }}
        />
      )}
    </Card>
  );

  return (
    <Box>
      <Paper sx={{ p: 3, mb: 3, bgcolor: 'primary.light' }}>
        <Typography variant="h5" color="white" gutterBottom>
          Advanced AI Resume Optimization in Progress
        </Typography>
        <Typography variant="body1" color="white">
          Our AI system is applying multiple layers of expert analysis to perfect your resume
        </Typography>
      </Paper>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          {processSteps.map((step) => (
            <ProcessStepCard
              key={step.id}
              step={step}
              isActive={step.id === activeStep}
              isCompleted={completedSteps.has(step.id)}
            />
          ))}
        </Grid>

        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Process Statistics
              </Typography>
              
              <List dense>
                <ListItem>
                  <ListItemIcon>
                    <AnalyticsIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Keywords Analyzed"
                    secondary={`${Math.floor(progress * 1.5)} keywords processed`}
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <TrendingIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Improvement Opportunities"
                    secondary={`${Math.floor(progress * 0.3)} identified`}
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <AssignmentIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Overall Progress"
                    secondary={`${Math.floor(progress)}% complete`}
                  />
                </ListItem>
              </List>

              <Box mt={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Current Focus
                </Typography>
                <Chip
                  icon={<AIIcon />}
                  label={processSteps.find(s => s.id === activeStep)?.title}
                  color="primary"
                  variant="outlined"
                  sx={{ animation: `${pulse} 2s infinite` }}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};
