import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Grid,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Radio,
  RadioGroup,
  FormControlLabel,
  Tooltip,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  Description as TemplateIcon,
  Download as DownloadIcon,
  Preview as PreviewIcon
} from '@mui/icons-material';
import { downloadResume, ResumeSection, ResumeTemplate } from '../../utils/wordExport';
import { ATSCompatibility } from './ATSCompatibility';

interface ResumeFormatSelectorProps {
  resumeContent: ResumeSection[];
  onExportComplete: () => void;
}

export const ResumeFormatSelector: React.FC<ResumeFormatSelectorProps> = ({
  resumeContent,
  onExportComplete
}) => {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('executive-modern');
  const [isExporting, setIsExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [selectedPreview, setSelectedPreview] = useState<string>('');

  const templates = [
    {
      id: 'executive-modern',
      name: 'Executive Modern',
      description: 'Clean, professional layout with modern typography. Perfect for senior roles.',
      preview: '/templates/executive-modern.png',
      recommended: true
    },
    {
      id: 'traditional-elegant',
      name: 'Traditional Elegant',
      description: 'Classic format preferred by established industries and conservative sectors.',
      preview: '/templates/traditional-elegant.png'
    },
    {
      id: 'tech-forward',
      name: 'Tech Forward',
      description: 'Modern design with emphasis on skills and achievements. Ideal for tech roles.',
      preview: '/templates/tech-forward.png'
    }
  ];

  const handleExport = async () => {
    setIsExporting(true);
    setError(null);

    try {
      await downloadResume(
        resumeContent,
        selectedTemplate,
        'Enhanced_Resume'
      );
      onExportComplete();
    } catch (err) {
      setError('Failed to export resume. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handlePreview = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setSelectedPreview(template.preview);
      setPreviewOpen(true);
    }
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Select Resume Format
      </Typography>

      <Grid container spacing={3}>
        {templates.map((template) => (
          <Grid item xs={12} md={4} key={template.id}>
            <Card
              sx={{
                border: selectedTemplate === template.id
                  ? '2px solid #2196f3'
                  : '1px solid #e0e0e0',
                cursor: 'pointer',
                transition: 'all 0.2s',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: 3
                }
              }}
              onClick={() => setSelectedTemplate(template.id)}
            >
              <CardMedia
                component="img"
                height="200"
                image={template.preview}
                alt={template.name}
                sx={{ objectFit: 'cover' }}
              />
              <CardContent>
                <Box display="flex" alignItems="center" mb={1}>
                  <Typography variant="h6" component="div">
                    {template.name}
                  </Typography>
                  {template.recommended && (
                    <Tooltip title="Recommended for your industry">
                      <Box
                        sx={{
                          ml: 1,
                          px: 1,
                          py: 0.5,
                          bgcolor: 'primary.main',
                          color: 'white',
                          borderRadius: 1,
                          fontSize: '0.75rem'
                        }}
                      >
                        Recommended
                      </Box>
                    </Tooltip>
                  )}
                </Box>

                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mb: 2 }}
                >
                  {template.description}
                </Typography>

                <Box display="flex" gap={1}>
                  <Button
                    size="small"
                    startIcon={<PreviewIcon />}
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePreview(template.id);
                    }}
                  >
                    Preview
                  </Button>
                  <Button
                    size="small"
                    variant={selectedTemplate === template.id ? 'contained' : 'outlined'}
                    startIcon={<TemplateIcon />}
                    onClick={() => setSelectedTemplate(template.id)}
                  >
                    Select
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <ATSCompatibility />

      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}

      <Box
        sx={{
          mt: 4,
          display: 'flex',
          justifyContent: 'center'
        }}
      >
        <Button
          variant="contained"
          size="large"
          startIcon={isExporting ? <CircularProgress size={20} /> : <DownloadIcon />}
          onClick={handleExport}
          disabled={isExporting}
        >
          {isExporting ? 'Exporting...' : 'Export to Word'}
        </Button>
      </Box>

      <Dialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Template Preview</DialogTitle>
        <DialogContent>
          <Box
            component="img"
            src={selectedPreview}
            alt="Template Preview"
            sx={{
              width: '100%',
              height: 'auto',
              objectFit: 'contain'
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
