import React, { useState, useCallback, useRef } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  IconButton,
  CircularProgress,
  Alert,
  Collapse,
  Tooltip,
  Chip
} from '@mui/material';
import {
  CloudUpload as UploadIcon,
  Link as LinkIcon,
  Description as FileIcon,
  Close as CloseIcon,
  DragHandle as DragIcon
} from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';

interface DocumentUploaderProps {
  type: 'resume' | 'jobDescription';
  onFileLoaded: (content: string) => void;
  onUrlLoaded: (url: string) => void;
}

export const DocumentUploader: React.FC<DocumentUploaderProps> = ({
  type,
  onFileLoaded,
  onUrlLoaded
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [url, setUrl] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const acceptedFileTypes = {
    resume: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt']
    },
    jobDescription: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
      'text/html': ['.html']
    }
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      try {
        setIsLoading(true);
        setError(null);
        const content = await readFile(file);
        setUploadedFile(file);
        onFileLoaded(content);
      } catch (err) {
        setError('Failed to read file. Please try again.');
      } finally {
        setIsLoading(false);
      }
    }
  }, [onFileLoaded]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: acceptedFileTypes[type],
    multiple: false
  });

  const readFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  };

  const handleUrlSubmit = async () => {
    if (!url) return;

    try {
      setIsLoading(true);
      setError(null);

      // For job description URLs, fetch the content
      if (type === 'jobDescription') {
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch job description');
        const content = await response.text();
        onUrlLoaded(content);
      } else {
        onUrlLoaded(url);
      }

      setShowUrlInput(false);
    } catch (err) {
      setError('Failed to load content from URL. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Box sx={{ mb: 3 }}>
      <Paper
        {...getRootProps()}
        sx={{
          p: 3,
          border: '2px dashed',
          borderColor: isDragActive ? 'primary.main' : 'grey.300',
          bgcolor: isDragActive ? 'action.hover' : 'background.paper',
          cursor: 'pointer',
          transition: 'all 0.2s',
          '&:hover': {
            borderColor: 'primary.main',
            bgcolor: 'action.hover'
          }
        }}
      >
        <input {...getInputProps()} ref={fileInputRef} />
        
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
        >
          {isLoading ? (
            <CircularProgress size={40} sx={{ mb: 2 }} />
          ) : (
            <UploadIcon sx={{ fontSize: 40, mb: 2, color: 'primary.main' }} />
          )}

          <Typography variant="h6" gutterBottom>
            {type === 'resume' ? 'Upload Your Resume' : 'Upload Job Description'}
          </Typography>
          
          <Typography variant="body2" color="text.secondary" align="center">
            Drag and drop your file here, or click to select
            <br />
            Supported formats: PDF, DOC, DOCX, TXT
            {type === 'jobDescription' && ', HTML'}
          </Typography>

          {uploadedFile && (
            <Chip
              icon={<FileIcon />}
              label={uploadedFile.name}
              onDelete={removeFile}
              sx={{ mt: 2 }}
            />
          )}
        </Box>
      </Paper>

      {type === 'jobDescription' && (
        <Box mt={2}>
          <Button
            startIcon={<LinkIcon />}
            onClick={() => setShowUrlInput(!showUrlInput)}
            variant="outlined"
            size="small"
          >
            {showUrlInput ? 'Hide URL Input' : 'Add Job Description URL'}
          </Button>

          <Collapse in={showUrlInput}>
            <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
              <TextField
                fullWidth
                size="small"
                placeholder="Paste job description URL here"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                InputProps={{
                  startAdornment: <LinkIcon sx={{ mr: 1, color: 'action.active' }} />
                }}
              />
              <Button
                variant="contained"
                onClick={handleUrlSubmit}
                disabled={!url || isLoading}
              >
                Load
              </Button>
            </Box>
          </Collapse>
        </Box>
      )}

      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}
    </Box>
  );
};
