import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Tooltip,
  Avatar,
  Chip,
  Paper,
  Alert
} from '@mui/material';
import {
  CheckCircle as CheckIcon,
  Info as InfoIcon,
  Security as SecurityIcon
} from '@mui/icons-material';

const atsSystemsData = [
  {
    name: 'Workday',
    logo: '/ats-logos/workday.png',
    description: 'Enterprise-grade ATS used by Fortune 500 companies'
  },
  {
    name: 'Greenhouse',
    logo: '/ats-logos/greenhouse.png',
    description: 'Popular among tech companies and startups'
  },
  {
    name: 'iCIMS',
    logo: '/ats-logos/icims.png',
    description: 'Comprehensive talent acquisition platform'
  },
  {
    name: 'Lever',
    logo: '/ats-logos/lever.png',
    description: 'Modern recruiting software'
  },
  {
    name: 'Jobvite',
    logo: '/ats-logos/jobvite.png',
    description: 'Full-service talent acquisition suite'
  },
  {
    name: 'Taleo',
    logo: '/ats-logos/taleo.png',
    description: 'Oracle\'s enterprise recruiting solution'
  },
  {
    name: 'BambooHR',
    logo: '/ats-logos/bamboohr.png',
    description: 'HR software for growing companies'
  },
  {
    name: 'JazzHR',
    logo: '/ats-logos/jazzhr.png',
    description: 'Recruiting solution for SMBs'
  },
  {
    name: 'Cornerstone',
    logo: '/ats-logos/cornerstone.png',
    description: 'Talent management suite'
  },
  {
    name: 'SAP SuccessFactors',
    logo: '/ats-logos/successfactors.png',
    description: 'Enterprise HR and recruiting platform'
  },
  {
    name: 'ADP Recruiting',
    logo: '/ats-logos/adp.png',
    description: 'Integrated hiring and HR platform'
  },
  {
    name: 'Zoho Recruit',
    logo: '/ats-logos/zoho.png',
    description: 'End-to-end recruiting solution'
  }
];

const compatibilityFeatures = [
  'Clean, parseable text formatting',
  'Standard font selection',
  'Proper heading hierarchy',
  'Consistent section breaks',
  'No tables or complex formatting',
  'Unicode text compliance',
  'Proper bullet point handling',
  'Standardized margins and spacing',
  'No headers or footers',
  'No text boxes or floating elements'
];

export const ATSCompatibility: React.FC = () => {
  return (
    <Box sx={{ mt: 4 }}>
      <Paper
        sx={{
          p: 3,
          bgcolor: 'primary.light',
          color: 'white',
          mb: 3
        }}
      >
        <Box display="flex" alignItems="center" mb={2}>
          <SecurityIcon sx={{ fontSize: 40, mr: 2 }} />
          <Typography variant="h5">
            ATS-Optimized Resume Format
          </Typography>
        </Box>
        <Typography variant="body1">
          Your resume will be perfectly readable by all major Applicant Tracking Systems (ATS).
          Our format has been specifically tested and optimized for the following systems, but
          works seamlessly with virtually all ATS platforms in use today.
        </Typography>
      </Paper>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {atsSystemsData.map((system) => (
          <Grid item xs={6} sm={4} md={3} key={system.name}>
            <Tooltip title={system.description} arrow>
              <Card
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  p: 2,
                  cursor: 'pointer',
                  '&:hover': {
                    boxShadow: 3,
                    transform: 'translateY(-2px)'
                  }
                }}
              >
                <Avatar
                  src={system.logo}
                  alt={system.name}
                  sx={{ width: 48, height: 48, mb: 1 }}
                >
                  {system.name[0]}
                </Avatar>
                <Typography
                  variant="subtitle2"
                  align="center"
                  sx={{ fontWeight: 500 }}
                >
                  {system.name}
                </Typography>
                <CheckIcon
                  color="success"
                  sx={{ mt: 1, fontSize: 20 }}
                />
              </Card>
            </Tooltip>
          </Grid>
        ))}
      </Grid>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Key Compatibility Features
          </Typography>
          <Grid container spacing={2}>
            {compatibilityFeatures.map((feature, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Chip
                  icon={<CheckIcon />}
                  label={feature}
                  color="success"
                  variant="outlined"
                  sx={{ width: '100%' }}
                />
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      <Alert
        severity="info"
        icon={<InfoIcon />}
        sx={{
          '& .MuiAlert-message': {
            width: '100%'
          }
        }}
      >
        <Typography variant="subtitle2" gutterBottom>
          Universal Compatibility
        </Typography>
        <Typography variant="body2">
          While we've specifically tested and optimized for the systems shown above,
          our resume format follows universal ATS compatibility standards. This ensures
          your resume will be properly parsed by virtually any ATS system you encounter
          in your job search.
        </Typography>
      </Alert>
    </Box>
  );
};
