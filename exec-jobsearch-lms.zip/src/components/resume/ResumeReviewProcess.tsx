import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Alert,
  Grid,
  Rating,
  Divider
} from '@mui/material';
import { ResumeProcessVisualization } from './ResumeProcessVisualization';
import { ResumeAccuracyReview } from './ResumeAccuracyReview';
import { resumeReview } from '../../utils/resumeReviewSystem';

export const ResumeReviewProcess: React.FC<{
  resume: string;
  jobDescription: string;
  industry: string;
  onComplete: (finalResume: string) => void;
}> = ({ resume, jobDescription, industry, onComplete }) => {
  const [currentStage, setCurrentStage] = useState('expert_review');
  const [progress, setProgress] = useState(0);
  const [insights, setInsights] = useState<Record<string, string[]>>({});
  const [results, setResults] = useState<any[]>([]);
  const [isReviewing, setIsReviewing] = useState(false);
  const [finalResume, setFinalResume] = useState(resume);
  const [error, setError] = useState<string | null>(null);
  const [showAccuracyReview, setShowAccuracyReview] = useState(false);

  useEffect(() => {
    startReviewProcess();
  }, []);

  const startReviewProcess = async () => {
    setIsReviewing(true);
    setError(null);
    setProgress(0);
    setInsights({});
    setShowAccuracyReview(false);

    try {
      // Expert Review Stage
      setCurrentStage('expert_review');
      await simulateProgress(0, 25);
      setInsights(prev => ({
        ...prev,
        expert_review: [
          'Analyzing executive experience',
          'Evaluating achievement metrics',
          'Optimizing professional language'
        ]
      }));

      // Keyword Analysis Stage
      setCurrentStage('keyword_analysis');
      await simulateProgress(25, 50);
      setInsights(prev => ({
        ...prev,
        keyword_analysis: [
          'Identified 15 key industry terms',
          'Analyzing semantic relevance',
          'Optimizing keyword placement'
        ]
      }));

      // AI Enhancement Stage
      setCurrentStage('ai_enhancement');
      await simulateProgress(50, 75);
      setInsights(prev => ({
        ...prev,
        ai_enhancement: [
          'Applying industry best practices',
          'Enhancing impact statements',
          'Implementing success patterns'
        ]
      }));

      // Hiring Manager Review Stage
      setCurrentStage('hiring_manager');
      await simulateProgress(75, 100);
      setInsights(prev => ({
        ...prev,
        hiring_manager: [
          'Evaluating job fit alignment',
          'Assessing leadership impact',
          'Verifying qualification match'
        ]
      }));

      const reviewResults = await resumeReview.performComprehensiveReview(
        resume,
        jobDescription,
        industry
      );

      setResults(reviewResults);
      
      // Get the final version of the resume
      const finalVersion = await applyAllImprovements(resume, reviewResults);
      setFinalResume(finalVersion);
      setShowAccuracyReview(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsReviewing(false);
    }
  };

  const simulateProgress = async (start: number, end: number) => {
    const duration = 3000; // 3 seconds per stage
    const steps = 20;
    const increment = (end - start) / steps;
    const stepDuration = duration / steps;

    for (let i = 0; i <= steps; i++) {
      await new Promise(resolve => setTimeout(resolve, stepDuration));
      setProgress(start + (i * increment));
    }
  };

  const applyAllImprovements = async (
    originalResume: string,
    reviewResults: any[]
  ): Promise<string> => {
    let improved = originalResume;
    
    for (const result of reviewResults) {
      for (const improvement of result.improvements) {
        improved = improved.replace(
          improvement.current,
          improvement.suggested
        );
      }
    }
    
    return improved;
  };

  if (error) {
    return (
      <Alert severity="error" sx={{ mt: 2 }}>
        {error}
        <Button
          onClick={startReviewProcess}
          variant="outlined"
          size="small"
          sx={{ ml: 2 }}
        >
          Retry
        </Button>
      </Alert>
    );
  }

  return (
    <Box>
      {!showAccuracyReview ? (
        <>
          <ResumeProcessVisualization
            currentStage={currentStage}
            progress={progress}
            insights={insights}
            onStageComplete={(stage) => {
              console.log('Stage completed:', stage);
            }}
          />

          {!isReviewing && results.length > 0 && (
            <Card sx={{ mt: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Initial Assessment Complete
                </Typography>
                <Typography variant="body1" color="text.secondary" gutterBottom>
                  We've enhanced your resume. Now let's review the changes to ensure everything is accurate.
                </Typography>
                
                <Button
                  variant="contained"
                  fullWidth
                  onClick={() => setShowAccuracyReview(true)}
                  sx={{ mt: 2 }}
                >
                  Review Changes
                </Button>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <ResumeAccuracyReview
          originalResume={resume}
          enhancedResume={finalResume}
          jobDescription={jobDescription}
          onComplete={(verifiedResume) => {
            onComplete(verifiedResume);
          }}
        />
      )}
    </Box>
  );
};
