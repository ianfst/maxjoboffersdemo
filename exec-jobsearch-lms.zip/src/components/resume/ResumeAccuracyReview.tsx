import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Chip,
  Paper,
  Grid,
  Tooltip,
  Menu,
  MenuItem,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Alert,
  Divider
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  ExpandMore as ExpandMoreIcon,
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
  Lightbulb as SuggestionIcon,
  Save as SaveIcon,
  History as HistoryIcon
} from '@mui/icons-material';

interface ResumeSection {
  id: string;
  title: string;
  content: string;
  newAdditions: string[];
  suggestions: {
    text: string;
    reason: string;
    alternativeApproaches: string[];
  }[];
  requiresReview: boolean;
}

interface ChangeHighlight {
  original: string;
  new: string;
  reason: string;
  alternatives: string[];
}

export const ResumeAccuracyReview: React.FC<{
  originalResume: string;
  enhancedResume: string;
  jobDescription: string;
  onComplete: (finalResume: string) => void;
}> = ({ originalResume, enhancedResume, jobDescription, onComplete }) => {
  const [sections, setSections] = useState<ResumeSection[]>([]);
  const [currentSection, setCurrentSection] = useState<string | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editContent, setEditContent] = useState('');
  const [suggestionMenuAnchor, setSuggestionMenuAnchor] = useState<null | HTMLElement>(null);
  const [selectedSuggestion, setSelectedSuggestion] = useState<any>(null);

  useEffect(() => {
    // Parse resume into sections and identify changes
    const parsedSections = parseResumeSections(originalResume, enhancedResume);
    setSections(parsedSections);
  }, [originalResume, enhancedResume]);

  const parseResumeSections = (original: string, enhanced: string): ResumeSection[] => {
    // This is a placeholder implementation
    // In reality, you'd need a more sophisticated parsing logic
    return [
      {
        id: 'summary',
        title: 'Professional Summary',
        content: 'Enhanced professional summary...',
        newAdditions: ['Six Sigma expertise mentioned'],
        suggestions: [{
          text: 'Consider highlighting your practical Six Sigma experience',
          reason: 'Job requires Six Sigma certification',
          alternativeApproaches: [
            'Emphasize hands-on process improvement experience',
            'Highlight team leadership of certified professionals',
            'Showcase equivalent methodologies used'
          ]
        }],
        requiresReview: true
      },
      // Add other sections...
    ];
  };

  const handleSectionEdit = (sectionId: string) => {
    const section = sections.find(s => s.id === sectionId);
    if (section) {
      setEditContent(section.content);
      setCurrentSection(sectionId);
      setEditDialogOpen(true);
    }
  };

  const handleSaveEdit = () => {
    setSections(sections.map(section => 
      section.id === currentSection
        ? { ...section, content: editContent }
        : section
    ));
    setEditDialogOpen(false);
  };

  const SectionReviewCard: React.FC<{
    section: ResumeSection;
    onEdit: () => void;
  }> = ({ section, onEdit }) => (
    <Card sx={{ mb: 2 }}>
      <CardContent>
        <Box display="flex" alignItems="center" mb={2}>
          <Typography variant="h6">
            {section.title}
          </Typography>
          {section.requiresReview && (
            <Tooltip title="Requires review">
              <WarningIcon color="warning" sx={{ ml: 1 }} />
            </Tooltip>
          )}
          <IconButton
            size="small"
            onClick={onEdit}
            sx={{ ml: 'auto' }}
          >
            <EditIcon />
          </IconButton>
        </Box>

        <Paper
          variant="outlined"
          sx={{
            p: 2,
            mb: 2,
            bgcolor: 'background.default',
            position: 'relative'
          }}
        >
          <Typography
            component="div"
            sx={{
              '& mark': {
                bgcolor: 'warning.light',
                padding: '0 4px',
                borderRadius: 1
              }
            }}
            dangerouslySetInnerHTML={{
              __html: highlightNewContent(section.content, section.newAdditions)
            }}
          />
        </Paper>

        {section.newAdditions.length > 0 && (
          <Box mb={2}>
            <Typography variant="subtitle2" color="warning.main" gutterBottom>
              New Additions to Review:
            </Typography>
            <Box display="flex" flexWrap="wrap" gap={1}>
              {section.newAdditions.map((addition, index) => (
                <Chip
                  key={index}
                  label={addition}
                  color="warning"
                  variant="outlined"
                  onDelete={() => handleRemoveAddition(section.id, index)}
                />
              ))}
            </Box>
          </Box>
        )}

        {section.suggestions.length > 0 && (
          <Box>
            <Typography variant="subtitle2" color="primary" gutterBottom>
              Suggestions for Improvement:
            </Typography>
            <List dense>
              {section.suggestions.map((suggestion, index) => (
                <ListItem
                  key={index}
                  secondaryAction={
                    <IconButton
                      edge="end"
                      onClick={(event) => {
                        setSuggestionMenuAnchor(event.currentTarget);
                        setSelectedSuggestion(suggestion);
                      }}
                    >
                      <SuggestionIcon color="primary" />
                    </IconButton>
                  }
                >
                  <ListItemText
                    primary={suggestion.text}
                    secondary={suggestion.reason}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </CardContent>
    </Card>
  );

  const highlightNewContent = (content: string, additions: string[]): string => {
    let highlightedContent = content;
    additions.forEach(addition => {
      highlightedContent = highlightedContent.replace(
        new RegExp(addition, 'gi'),
        `<mark>$&</mark>`
      );
    });
    return highlightedContent;
  };

  const handleRemoveAddition = (sectionId: string, additionIndex: number) => {
    setSections(sections.map(section => {
      if (section.id === sectionId) {
        const newAdditions = [...section.newAdditions];
        newAdditions.splice(additionIndex, 1);
        return { ...section, newAdditions };
      }
      return section;
    }));
  };

  return (
    <Box>
      <Paper sx={{ p: 3, mb: 3, bgcolor: 'primary.light' }}>
        <Typography variant="h5" color="white" gutterBottom>
          Accuracy Review
        </Typography>
        <Typography variant="body1" color="white">
          Review and verify the enhanced content. Pay special attention to highlighted additions and suggestions.
        </Typography>
      </Paper>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          {sections.map(section => (
            <SectionReviewCard
              key={section.id}
              section={section}
              onEdit={() => handleSectionEdit(section.id)}
            />
          ))}
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{ position: 'sticky', top: 16 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Review Progress
              </Typography>
              
              <Box mb={3}>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Sections requiring review
                </Typography>
                <Typography variant="h3" color="warning.main">
                  {sections.filter(s => s.requiresReview).length}
                </Typography>
              </Box>

              <Alert severity="info" sx={{ mb: 2 }}>
                Highlighted text indicates new content added by AI. Please verify its accuracy.
              </Alert>

              <Button
                variant="contained"
                fullWidth
                startIcon={<SaveIcon />}
                onClick={() => {
                  const finalResume = sections.map(s => s.content).join('\n\n');
                  onComplete(finalResume);
                }}
                disabled={sections.some(s => s.requiresReview)}
              >
                Save and Export
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Edit Dialog */}
      <Dialog
        open={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Edit Section Content
        </DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            multiline
            rows={10}
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            variant="outlined"
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleSaveEdit}
            variant="contained"
            startIcon={<SaveIcon />}
          >
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Suggestion Menu */}
      <Menu
        anchorEl={suggestionMenuAnchor}
        open={Boolean(suggestionMenuAnchor)}
        onClose={() => setSuggestionMenuAnchor(null)}
      >
        <MenuItem disabled>
          <Typography variant="subtitle2">
            Alternative Approaches:
          </Typography>
        </MenuItem>
        {selectedSuggestion?.alternativeApproaches.map((approach: string, index: number) => (
          <MenuItem
            key={index}
            onClick={() => {
              // Apply the selected approach
              setSuggestionMenuAnchor(null);
            }}
          >
            {approach}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
};
