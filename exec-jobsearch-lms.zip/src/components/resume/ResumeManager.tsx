import React, { useState, useCallback, useEffect } from 'react';
import {
  Box,
  Button,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  CircularProgress,
  Tabs,
  Tab,
  Grid,
  Card,
  CardContent,
  Chip,
  Divider
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileCopy as CopyIcon,
  Visibility as ViewIcon,
  CloudUpload as UploadIcon,
  Compare as CompareIcon,
  Check as CheckIcon,
  Psychology as AIIcon,
  Assignment as RequirementsIcon
} from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';
import { ResumeVersion } from '../../types/resume';
import { ResumeRewriter } from './ResumeRewriter';
import { ResumeAccuracyReview } from './ResumeAccuracyReview';
import { ResumeFormatSelector } from './ResumeFormatSelector';

interface ResumeManagerProps {
  userId: string;
  jobData?: any; // Optional job data for tailoring
  onComplete?: (resumeId: string) => void; // Optional callback for job application flow
}

export const ResumeManager: React.FC<ResumeManagerProps> = ({ 
  userId, 
  jobData,
  onComplete
}) => {
  const [resumes, setResumes] = useState<ResumeVersion[]>([]);
  const [selectedResume, setSelectedResume] = useState<ResumeVersion | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [jobAnalysis, setJobAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    if (jobData) {
      analyzeJobRequirements();
    }
  }, [jobData]);

  const analyzeJobRequirements = async () => {
    if (!jobData) return;
    
    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/resume/analyze-job', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ jobData }),
      });

      if (!response.ok) throw new Error('Failed to analyze job requirements');

      const analysis = await response.json();
      setJobAnalysis(analysis);
    } catch (err) {
      setError('Failed to analyze job requirements');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle file upload
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setIsUploading(true);
    setError(null);

    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', userId);

    try {
      const response = await fetch('/api/resume/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Failed to upload resume');

      const newResume = await response.json();
      setResumes(prev => [...prev, newResume]);
      setSuccess('Resume uploaded successfully!');
    } catch (err) {
      setError('Failed to upload resume. Please try again.');
    } finally {
      setIsUploading(false);
    }
  }, [userId]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    multiple: false
  });

  // Handle resume deletion
  const handleDelete = async (resumeId: string) => {
    try {
      await fetch(`/api/resume/${resumeId}`, {
        method: 'DELETE',
      });
      setResumes(prev => prev.filter(r => r.id !== resumeId));
      setSuccess('Resume deleted successfully!');
    } catch (err) {
      setError('Failed to delete resume. Please try again.');
    }
  };

  // Handle resume view
  const handleView = (resume: ResumeVersion) => {
    setSelectedResume(resume);
    setIsViewOpen(true);
  };

  const handleRewrite = async (resumeId: string) => {
    try {
      const response = await fetch(`/api/resume/${resumeId}/rewrite`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobRequirements: jobData ? jobAnalysis : null
        }),
      });

      if (!response.ok) throw new Error('Failed to rewrite resume');

      const newVersion = await response.json();
      setResumes(prev => [...prev, newVersion]);
      setSuccess('Resume rewritten successfully!');
      
      if (onComplete) {
        onComplete(newVersion.id);
      }
    } catch (err) {
      setError('Failed to rewrite resume. Please try again.');
    }
  };

  const handleFormatChange = async (resumeId: string, format: string) => {
    try {
      const response = await fetch(`/api/resume/${resumeId}/format`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ format }),
      });

      if (!response.ok) throw new Error('Failed to change resume format');

      const newVersion = await response.json();
      setResumes(prev => [...prev, newVersion]);
      setSuccess('Resume format updated successfully!');
    } catch (err) {
      setError('Failed to update resume format. Please try again.');
    }
  };

  const renderJobRequirements = () => {
    if (!jobData) return null;

    return (
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Job Requirements Analysis
          </Typography>
          {isAnalyzing ? (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <CircularProgress size={20} />
              <Typography>Analyzing job requirements...</Typography>
            </Box>
          ) : jobAnalysis && (
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Key Skills Required:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {jobAnalysis.requiredSkills.map((skill: string, index: number) => (
                    <Chip
                      key={index}
                      label={skill}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Experience Level:
                </Typography>
                <Typography>{jobAnalysis.experienceLevel}</Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Key Responsibilities:
                </Typography>
                <List dense>
                  {jobAnalysis.responsibilities.map((resp: string, index: number) => (
                    <ListItem key={index}>
                      <ListItemText primary={resp} />
                    </ListItem>
                  ))}
                </List>
              </Grid>
            </Grid>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <Box sx={{ maxWidth: 1200, margin: '0 auto', p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Resume Management
      </Typography>

      {renderJobRequirements()}

      <Tabs
        value={activeTab}
        onChange={(e, newValue) => setActiveTab(newValue)}
        sx={{ mb: 3 }}
      >
        <Tab icon={<UploadIcon />} label="Upload" />
        <Tab icon={<EditIcon />} label="Edit & Rewrite" />
        <Tab icon={<CompareIcon />} label="Compare Versions" />
        <Tab icon={<RequirementsIcon />} label="Format" />
      </Tabs>

      {activeTab === 0 && (
        <Paper
          {...getRootProps()}
          sx={{
            p: 3,
            textAlign: 'center',
            backgroundColor: isDragActive ? '#f0f7ff' : 'white',
            cursor: 'pointer'
          }}
        >
          <input {...getInputProps()} />
          <UploadIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
          <Typography variant="h6" gutterBottom>
            {isDragActive ? 'Drop your resume here' : 'Drag & drop your resume here'}
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Supported formats: PDF, DOCX
          </Typography>
          {isUploading && <CircularProgress sx={{ mt: 2 }} />}
        </Paper>
      )}

      {activeTab === 1 && (
        <ResumeRewriter
          resumes={resumes}
          jobAnalysis={jobAnalysis}
          onRewrite={handleRewrite}
        />
      )}

      {activeTab === 2 && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <ResumeAccuracyReview
              resume={selectedResume}
              jobRequirements={jobAnalysis}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Version History
              </Typography>
              <List>
                {resumes.map((resume) => (
                  <ListItem key={resume.id}>
                    <ListItemText
                      primary={`Version ${resume.version}`}
                      secondary={`Created: ${new Date(resume.createdAt).toLocaleDateString()}`}
                    />
                    <ListItemSecondaryAction>
                      <IconButton onClick={() => handleView(resume)}>
                        <ViewIcon />
                      </IconButton>
                      <IconButton onClick={() => setSelectedResume(resume)}>
                        <CompareIcon />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
            </Paper>
          </Grid>
        </Grid>
      )}

      {activeTab === 3 && (
        <ResumeFormatSelector
          resume={selectedResume}
          onFormatChange={handleFormatChange}
        />
      )}

      {/* View Dialog */}
      <Dialog
        open={isViewOpen}
        onClose={() => setIsViewOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Resume Version {selectedResume?.version}
        </DialogTitle>
        <DialogContent>
          <Typography
            component="pre"
            sx={{
              whiteSpace: 'pre-wrap',
              fontFamily: 'monospace',
              fontSize: '0.875rem'
            }}
          >
            {selectedResume?.content}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsViewOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Notifications */}
      <Snackbar
        open={!!error}
        autoHideDuration={6000}
        onClose={() => setError(null)}
      >
        <Alert severity="error" onClose={() => setError(null)}>
          {error}
        </Alert>
      </Snackbar>

      <Snackbar
        open={!!success}
        autoHideDuration={6000}
        onClose={() => setSuccess(null)}
      >
        <Alert severity="success" onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      </Snackbar>
    </Box>
  );
};
