import React from 'react';
import { Box, Card, CardContent, Typography, Grid, Button, useTheme } from '@mui/material';
import { ResumeFormat } from '../../types/resume';

interface FormatOption {
  id: ResumeFormat;
  title: string;
  description: string;
  bestFor: string[];
  preview: string; // URL to preview image
}

const formatOptions: FormatOption[] = [
  {
    id: 'chronological',
    title: 'Chronological',
    description: 'Traditional format highlighting work history in reverse chronological order',
    bestFor: [
      'Consistent work history',
      'Career progression',
      'Traditional industries'
    ],
    preview: '/assets/resume-previews/chronological.png'
  },
  {
    id: 'functional',
    title: 'Functional',
    description: 'Skills-based format emphasizing capabilities over work history',
    bestFor: [
      'Career changers',
      'Employment gaps',
      'Diverse experience'
    ],
    preview: '/assets/resume-previews/functional.png'
  },
  {
    id: 'hybrid',
    title: 'Hybrid',
    description: 'Combines chronological and functional formats for maximum impact',
    bestFor: [
      'Experienced professionals',
      'Complex skill sets',
      'Technical roles'
    ],
    preview: '/assets/resume-previews/hybrid.png'
  },
  {
    id: 'executive',
    title: 'Executive',
    description: 'Leadership-focused format highlighting achievements and vision',
    bestFor: [
      'Senior positions',
      'Leadership roles',
      'Board positions'
    ],
    preview: '/assets/resume-previews/executive.png'
  },
  {
    id: 'technical',
    title: 'Technical',
    description: 'Specialized format for technical roles with detailed skills section',
    bestFor: [
      'Technical positions',
      'IT professionals',
      'Specialized roles'
    ],
    preview: '/assets/resume-previews/technical.png'
  }
];

interface FormatSelectorProps {
  currentFormat?: ResumeFormat;
  onFormatSelect: (format: ResumeFormat) => void;
  jobRecommendation?: ResumeFormat;
  atsScore?: Record<ResumeFormat, number>;
}

export const FormatSelector: React.FC<FormatSelectorProps> = ({
  currentFormat,
  onFormatSelect,
  jobRecommendation,
  atsScore
}) => {
  const theme = useTheme();

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Choose Resume Format
      </Typography>
      
      {jobRecommendation && (
        <Typography 
          variant="subtitle1" 
          sx={{ mb: 2, color: theme.palette.primary.main }}
        >
          Recommended format for this job: {formatOptions.find(f => f.id === jobRecommendation)?.title}
        </Typography>
      )}

      <Grid container spacing={3}>
        {formatOptions.map((format) => (
          <Grid item xs={12} sm={6} md={4} key={format.id}>
            <Card 
              sx={{
                cursor: 'pointer',
                border: currentFormat === format.id ? `2px solid ${theme.palette.primary.main}` : 'none',
                '&:hover': {
                  boxShadow: 4
                }
              }}
              onClick={() => onFormatSelect(format.id)}
            >
              <CardContent>
                <Box 
                  component="img"
                  src={format.preview}
                  alt={`${format.title} format preview`}
                  sx={{ 
                    width: '100%',
                    height: 200,
                    objectFit: 'cover',
                    mb: 2
                  }}
                />
                
                <Typography variant="h6" gutterBottom>
                  {format.title}
                </Typography>
                
                <Typography variant="body2" color="text.secondary" paragraph>
                  {format.description}
                </Typography>

                {atsScore && (
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      color: atsScore[format.id] > 0.7 ? 'success.main' : 'warning.main',
                      mb: 1
                    }}
                  >
                    ATS Compatibility: {Math.round(atsScore[format.id] * 100)}%
                  </Typography>
                )}

                <Typography variant="subtitle2" gutterBottom>
                  Best for:
                </Typography>
                <Box component="ul" sx={{ pl: 2, mt: 0 }}>
                  {format.bestFor.map((point, idx) => (
                    <Typography 
                      component="li" 
                      variant="body2" 
                      key={idx}
                      color="text.secondary"
                    >
                      {point}
                    </Typography>
                  ))}
                </Box>

                <Button 
                  variant={currentFormat === format.id ? "contained" : "outlined"}
                  fullWidth
                  sx={{ mt: 2 }}
                  onClick={() => onFormatSelect(format.id)}
                >
                  {currentFormat === format.id ? 'Selected' : 'Select'}
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};
