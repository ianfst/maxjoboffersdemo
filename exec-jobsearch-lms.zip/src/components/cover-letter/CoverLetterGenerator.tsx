import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  Grid,
  CircularProgress,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  Rating,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import {
  Description as TemplateIcon,
  Style as StyleIcon,
  Psychology as ToneIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Assessment as AnalysisIcon,
  Check as CheckIcon,
  Warning as WarningIcon
} from '@mui/icons-material';
import { CoverLetter, CoverLetterTemplate, CoverLetterAnalysis, CoverLetterCustomization } from '../../types/cover_letter';

interface CoverLetterGeneratorProps {
  userId: string;
  jobId: string;
  resumeId: string;
}

export const CoverLetterGenerator: React.FC<CoverLetterGeneratorProps> = ({
  userId,
  jobId,
  resumeId
}) => {
  // State
  const [templates, setTemplates] = useState<CoverLetterTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [style, setStyle] = useState<'professional' | 'creative' | 'modern' | 'traditional'>('professional');
  const [tone, setTone] = useState<'formal' | 'casual' | 'balanced'>('balanced');
  const [keyPoints, setKeyPoints] = useState<string[]>([]);
  const [newKeyPoint, setNewKeyPoint] = useState('');
  const [customInstructions, setCustomInstructions] = useState('');
  const [coverLetter, setCoverLetter] = useState<CoverLetter | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<CoverLetterAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [customization, setCustomization] = useState<CoverLetterCustomization>({
    achievements: [],
    skills: [],
    experience: [],
    companyKnowledge: [],
    cultureFit: [],
    jobRequirements: []
  });

  // Load templates
  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      const response = await fetch('/api/cover-letters/templates');
      const data = await response.json();
      if (data.success) {
        setTemplates(data.templates);
      }
    } catch (err) {
      setError('Failed to load templates');
    }
  };

  // Generate cover letter
  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const response = await fetch('/api/cover-letters/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobId,
          resumeId,
          templateId: selectedTemplate || undefined,
          style,
          tone,
          keyPoints: keyPoints.length > 0 ? keyPoints : undefined,
          customInstructions: customInstructions || undefined
        }),
      });

      const data = await response.json();
      if (data.success) {
        setCoverLetter(data.coverLetter);
        setSuccess('Cover letter generated successfully!');
        // Automatically analyze the generated cover letter
        await analyzeCoverLetter(data.coverLetter.id);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Failed to generate cover letter');
    } finally {
      setIsGenerating(false);
    }
  };

  // Analyze cover letter
  const analyzeCoverLetter = async (coverId: string) => {
    setIsAnalyzing(true);
    try {
      const response = await fetch(`/api/cover-letters/${coverId}/analyze`);
      const data = await response.json();
      if (data.success) {
        setAnalysis(data.analysis);
      }
    } catch (err) {
      setError('Failed to analyze cover letter');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Customize cover letter
  const handleCustomize = async () => {
    if (!coverLetter) return;

    try {
      const response = await fetch(`/api/cover-letters/${coverLetter.id}/customize`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ customization }),
      });

      const data = await response.json();
      if (data.success) {
        setCoverLetter(data.coverLetter);
        setSuccess('Cover letter customized successfully!');
        setIsCustomizing(false);
        // Analyze the new version
        await analyzeCoverLetter(data.coverLetter.id);
      }
    } catch (err) {
      setError('Failed to customize cover letter');
    }
  };

  // Add key point
  const handleAddKeyPoint = () => {
    if (newKeyPoint.trim()) {
      setKeyPoints([...keyPoints, newKeyPoint.trim()]);
      setNewKeyPoint('');
    }
  };

  // Remove key point
  const handleRemoveKeyPoint = (point: string) => {
    setKeyPoints(keyPoints.filter(p => p !== point));
  };

  return (
    <Box sx={{ maxWidth: 1200, margin: '0 auto', p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Cover Letter Generator
      </Typography>

      {/* Generation Options */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={3}>
          {/* Template Selection */}
          <Grid item xs={12} md={6}>
            <FormControl fullWidth>
              <InputLabel>Template</InputLabel>
              <Select
                value={selectedTemplate}
                onChange={(e) => setSelectedTemplate(e.target.value)}
                startAdornment={<TemplateIcon sx={{ mr: 1 }} />}
              >
                <MenuItem value="">No Template</MenuItem>
                {templates.map((template) => (
                  <MenuItem key={template.id} value={template.id}>
                    {template.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          {/* Style Selection */}
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Style</InputLabel>
              <Select
                value={style}
                onChange={(e) => setStyle(e.target.value as any)}
                startAdornment={<StyleIcon sx={{ mr: 1 }} />}
              >
                <MenuItem value="professional">Professional</MenuItem>
                <MenuItem value="creative">Creative</MenuItem>
                <MenuItem value="modern">Modern</MenuItem>
                <MenuItem value="traditional">Traditional</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* Tone Selection */}
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Tone</InputLabel>
              <Select
                value={tone}
                onChange={(e) => setTone(e.target.value as any)}
                startAdornment={<ToneIcon sx={{ mr: 1 }} />}
              >
                <MenuItem value="formal">Formal</MenuItem>
                <MenuItem value="casual">Casual</MenuItem>
                <MenuItem value="balanced">Balanced</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* Key Points */}
          <Grid item xs={12}>
            <Box sx={{ mb: 2 }}>
              <TextField
                fullWidth
                label="Add Key Point"
                value={newKeyPoint}
                onChange={(e) => setNewKeyPoint(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddKeyPoint()}
              />
            </Box>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {keyPoints.map((point) => (
                <Chip
                  key={point}
                  label={point}
                  onDelete={() => handleRemoveKeyPoint(point)}
                />
              ))}
            </Box>
          </Grid>

          {/* Custom Instructions */}
          <Grid item xs={12}>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Custom Instructions"
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
            />
          </Grid>

          {/* Generate Button */}
          <Grid item xs={12}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleGenerate}
              disabled={isGenerating}
              startIcon={isGenerating ? <CircularProgress size={20} /> : null}
            >
              {isGenerating ? 'Generating...' : 'Generate Cover Letter'}
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Cover Letter Preview */}
      {coverLetter && (
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
            <Typography variant="h5">Cover Letter</Typography>
            <Box>
              <Button
                startIcon={<EditIcon />}
                onClick={() => setIsCustomizing(true)}
                sx={{ mr: 1 }}
              >
                Customize
              </Button>
              <Button
                startIcon={<SaveIcon />}
                variant="contained"
              >
                Save
              </Button>
            </Box>
          </Box>
          <Typography
            component="pre"
            sx={{
              whiteSpace: 'pre-wrap',
              fontFamily: 'inherit',
              fontSize: '1rem'
            }}
          >
            {coverLetter.content}
          </Typography>
        </Paper>
      )}

      {/* Analysis Results */}
      {analysis && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h5" gutterBottom>
            Analysis
          </Typography>

          <Grid container spacing={3}>
            {/* Scores */}
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Scores
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <Box>
                      <Typography component="legend">Clarity</Typography>
                      <Rating value={analysis.clarity * 5} readOnly precision={0.5} />
                    </Box>
                    <Box>
                      <Typography component="legend">Impact</Typography>
                      <Rating value={analysis.impact * 5} readOnly precision={0.5} />
                    </Box>
                    <Box>
                      <Typography component="legend">Relevance</Typography>
                      <Rating value={analysis.relevance * 5} readOnly precision={0.5} />
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            {/* Key Points and Suggestions */}
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Feedback
                  </Typography>
                  <List>
                    {analysis.keyPoints.map((point, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <CheckIcon color="success" />
                        </ListItemIcon>
                        <ListItemText primary={point} />
                      </ListItem>
                    ))}
                    {analysis.suggestions.map((suggestion, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <WarningIcon color="warning" />
                        </ListItemIcon>
                        <ListItemText primary={suggestion} />
                      </ListItem>
                    ))}
                  </List>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      )}

      {/* Customization Dialog */}
      <Dialog
        open={isCustomizing}
        onClose={() => setIsCustomizing(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Customize Cover Letter</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            {Object.entries(customization).map(([key, values]) => (
              <Grid item xs={12} key={key}>
                <TextField
                  fullWidth
                  multiline
                  rows={2}
                  label={key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                  value={values.join('\n')}
                  onChange={(e) => setCustomization({
                    ...customization,
                    [key]: e.target.value.split('\n').filter(v => v.trim())
                  })}
                />
              </Grid>
            ))}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsCustomizing(false)}>Cancel</Button>
          <Button onClick={handleCustomize} variant="contained">
            Apply Changes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Notifications */}
      <Snackbar
        open={!!error}
        autoHideDuration={6000}
        onClose={() => setError(null)}
      >
        <Alert severity="error" onClose={() => setError(null)}>
          {error}
        </Alert>
      </Snackbar>

      <Snackbar
        open={!!success}
        autoHideDuration={6000}
        onClose={() => setSuccess(null)}
      >
        <Alert severity="success" onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      </Snackbar>
    </Box>
  );
};
