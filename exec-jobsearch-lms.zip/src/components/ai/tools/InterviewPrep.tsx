import React, { useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Card,
  CardContent,
  Grid,
  Chip,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  Add as AddIcon,
  PlayArrow as PlayIcon,
  Stop as StopIcon,
  Save as SaveIcon,
} from '@mui/icons-material';

interface InterviewPrepProps {
  onSubmit: (data: any) => void;
}

const InterviewPrep: React.FC<InterviewPrepProps> = ({ onSubmit }) => {
  const [jobDetails, setJobDetails] = useState({
    title: '',
    company: '',
    level: '',
    keyResponsibilities: '',
  });

  const [practiceMode, setPracticeMode] = useState(false);
  const [recording, setRecording] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [savedResponses, setSavedResponses] = useState<Array<{
    question: string;
    response: string;
    feedback: string;
  }>>([]);

  const [openDialog, setOpenDialog] = useState(false);
  const [selectedResponse, setSelectedResponse] = useState<{
    question: string;
    response: string;
    feedback: string;
  } | null>(null);

  const commonQuestions = [
    'Describe a major transformation you led and its impact.',
    'How do you handle strategic disagreements with board members?',
    'What is your approach to building and developing high-performing teams?',
    'How do you stay ahead of industry trends and innovation?',
  ];

  const handleStartPrep = () => {
    onSubmit(jobDetails);
    setPracticeMode(true);
  };

  const handleRecordToggle = () => {
    if (recording) {
      // Stop recording and analyze response
      setRecording(false);
      // Simulate AI analysis
      setTimeout(() => {
        setSavedResponses([
          ...savedResponses,
          {
            question: currentQuestion,
            response: 'Your recorded response...',
            feedback:
              'Strong points on strategy, consider adding more specific metrics. Maintain consistent eye contact.',
          },
        ]);
      }, 1000);
    } else {
      setRecording(true);
    }
  };

  const handleResponseClick = (response: {
    question: string;
    response: string;
    feedback: string;
  }) => {
    setSelectedResponse(response);
    setOpenDialog(true);
  };

  return (
    <Box sx={{ p: 2 }}>
      {!practiceMode ? (
        <Box>
          <Typography variant="h6" gutterBottom>
            Job Details
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Job Title"
                value={jobDetails.title}
                onChange={(e) =>
                  setJobDetails({ ...jobDetails, title: e.target.value })
                }
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Company"
                value={jobDetails.company}
                onChange={(e) =>
                  setJobDetails({ ...jobDetails, company: e.target.value })
                }
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Key Responsibilities"
                multiline
                rows={4}
                value={jobDetails.keyResponsibilities}
                onChange={(e) =>
                  setJobDetails({
                    ...jobDetails,
                    keyResponsibilities: e.target.value,
                  })
                }
              />
            </Grid>
          </Grid>

          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" gutterBottom>
              Common Executive Interview Questions
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
              {commonQuestions.map((question, index) => (
                <Chip key={index} label={question} variant="outlined" />
              ))}
            </Box>
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
            <Button
              variant="contained"
              onClick={handleStartPrep}
              disabled={!jobDetails.title || !jobDetails.company}
            >
              Start Interview Prep
            </Button>
          </Box>
        </Box>
      ) : (
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Practice Session
                </Typography>
                <TextField
                  fullWidth
                  label="Current Question"
                  value={currentQuestion}
                  onChange={(e) => setCurrentQuestion(e.target.value)}
                  sx={{ mb: 2 }}
                />
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    gap: 2,
                    mb: 2,
                  }}
                >
                  <IconButton
                    color={recording ? 'error' : 'primary'}
                    onClick={handleRecordToggle}
                    sx={{ width: 56, height: 56 }}
                  >
                    {recording ? <StopIcon /> : <PlayIcon />}
                  </IconButton>
                  {recording && (
                    <Typography
                      variant="body2"
                      color="error"
                      sx={{ alignSelf: 'center' }}
                    >
                      Recording...
                    </Typography>
                  )}
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              Saved Responses
            </Typography>
            <List>
              {savedResponses.map((response, index) => (
                <ListItem
                  key={index}
                  button
                  onClick={() => handleResponseClick(response)}
                >
                  <ListItemText
                    primary={response.question}
                    secondary={`Response ${index + 1}`}
                  />
                  <ListItemSecondaryAction>
                    <IconButton edge="end">
                      <SaveIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </Grid>
        </Grid>
      )}

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>Response Analysis</DialogTitle>
        <DialogContent>
          {selectedResponse && (
            <Box>
              <Typography variant="subtitle1" gutterBottom>
                Question:
              </Typography>
              <Typography paragraph>{selectedResponse.question}</Typography>

              <Typography variant="subtitle1" gutterBottom>
                Your Response:
              </Typography>
              <Typography paragraph>{selectedResponse.response}</Typography>

              <Typography variant="subtitle1" gutterBottom>
                AI Feedback:
              </Typography>
              <Typography paragraph>{selectedResponse.feedback}</Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default InterviewPrep;
