import React, { useState } from 'react';
import {
  Box,
  Button,
  Typography,
  TextField,
  Stepper,
  Step,
  StepLabel,
  Paper,
  Autocomplete,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
} from '@mui/material';

interface CoverLetterGeneratorProps {
  onSubmit: (data: any) => void;
}

const CoverLetterGenerator: React.FC<CoverLetterGeneratorProps> = ({
  onSubmit,
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    jobTitle: '',
    company: '',
    industry: '',
    jobDescription: '',
    keyRequirements: '',
    tone: 'professional',
    emphasis: 'leadership',
  });

  const steps = ['Job Details', 'Requirements', 'Style Preferences'];

  const handleNext = () => {
    if (activeStep === steps.length - 1) {
      onSubmit(formData);
    } else {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const isStepValid = () => {
    switch (activeStep) {
      case 0:
        return (
          formData.jobTitle.trim() &&
          formData.company.trim() &&
          formData.industry.trim()
        );
      case 1:
        return formData.jobDescription.trim() && formData.keyRequirements.trim();
      case 2:
        return true;
      default:
        return false;
    }
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <Box sx={{ p: 2 }}>
            <TextField
              fullWidth
              label="Job Title"
              value={formData.jobTitle}
              onChange={(e) =>
                setFormData({ ...formData, jobTitle: e.target.value })
              }
              sx={{ mb: 3 }}
            />
            <TextField
              fullWidth
              label="Company Name"
              value={formData.company}
              onChange={(e) =>
                setFormData({ ...formData, company: e.target.value })
              }
              sx={{ mb: 3 }}
            />
            <Autocomplete
              options={[
                'Technology',
                'Finance',
                'Healthcare',
                'Manufacturing',
                'Consulting',
                'Retail',
                'Energy',
              ]}
              value={formData.industry}
              onChange={(_, newValue) =>
                setFormData({ ...formData, industry: newValue || '' })
              }
              renderInput={(params) => (
                <TextField {...params} label="Industry" fullWidth />
              )}
            />
          </Box>
        );
      case 1:
        return (
          <Box sx={{ p: 2 }}>
            <TextField
              fullWidth
              multiline
              rows={6}
              label="Job Description"
              value={formData.jobDescription}
              onChange={(e) =>
                setFormData({ ...formData, jobDescription: e.target.value })
              }
              sx={{ mb: 3 }}
              placeholder="Paste the full job description here..."
            />
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Key Requirements"
              value={formData.keyRequirements}
              onChange={(e) =>
                setFormData({ ...formData, keyRequirements: e.target.value })
              }
              placeholder="List the most important requirements and qualifications..."
            />
          </Box>
        );
      case 2:
        return (
          <Box sx={{ p: 2 }}>
            <FormControl component="fieldset" sx={{ mb: 3 }}>
              <FormLabel component="legend">Tone</FormLabel>
              <RadioGroup
                value={formData.tone}
                onChange={(e) =>
                  setFormData({ ...formData, tone: e.target.value })
                }
              >
                <FormControlLabel
                  value="professional"
                  control={<Radio />}
                  label="Professional & Traditional"
                />
                <FormControlLabel
                  value="modern"
                  control={<Radio />}
                  label="Modern & Dynamic"
                />
                <FormControlLabel
                  value="bold"
                  control={<Radio />}
                  label="Bold & Confident"
                />
              </RadioGroup>
            </FormControl>

            <FormControl component="fieldset">
              <FormLabel component="legend">Primary Emphasis</FormLabel>
              <RadioGroup
                value={formData.emphasis}
                onChange={(e) =>
                  setFormData({ ...formData, emphasis: e.target.value })
                }
              >
                <FormControlLabel
                  value="leadership"
                  control={<Radio />}
                  label="Leadership & Strategy"
                />
                <FormControlLabel
                  value="innovation"
                  control={<Radio />}
                  label="Innovation & Transformation"
                />
                <FormControlLabel
                  value="results"
                  control={<Radio />}
                  label="Results & Achievement"
                />
                <FormControlLabel
                  value="culture"
                  control={<Radio />}
                  label="Culture & Team Building"
                />
              </RadioGroup>
            </FormControl>
          </Box>
        );
      default:
        return null;
    }
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      <Paper sx={{ p: 2 }}>
        {renderStepContent()}

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3, gap: 2 }}>
          {activeStep > 0 && (
            <Button onClick={handleBack} variant="outlined">
              Back
            </Button>
          )}
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={!isStepValid()}
          >
            {activeStep === steps.length - 1 ? 'Generate' : 'Next'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
};

export default CoverLetterGenerator;
