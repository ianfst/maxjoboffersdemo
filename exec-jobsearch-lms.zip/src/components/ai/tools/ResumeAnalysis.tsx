import React, { useState } from 'react';
import {
  Box,
  Button,
  Typography,
  TextField,
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
} from '@mui/material';
import { Upload, CheckCircle, Error } from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';

interface ResumeAnalysisProps {
  onSubmit: (data: any) => void;
}

const ResumeAnalysis: React.FC<ResumeAnalysisProps> = ({ onSubmit }) => {
  const [resumeText, setResumeText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': [
        '.docx',
      ],
    },
    maxFiles: 1,
    onDrop: async (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setFile(acceptedFiles[0]);
        try {
          const formData = new FormData();
          formData.append('file', acceptedFiles[0]);
          const response = await fetch('/api/parse-resume', {
            method: 'POST',
            body: formData,
          });
          const data = await response.json();
          if (data.success) {
            setResumeText(data.content);
            setError('');
          } else {
            setError(data.error || 'Failed to parse resume');
          }
        } catch (err) {
          setError('Failed to parse resume. Please paste the content manually.');
        }
      }
    },
  });

  const handleSubmit = () => {
    if (!resumeText.trim()) {
      setError('Please provide resume content');
      return;
    }
    onSubmit({ content: resumeText });
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h6" gutterBottom>
        Upload Your Resume
      </Typography>

      <Paper
        {...getRootProps()}
        sx={{
          p: 3,
          mb: 3,
          textAlign: 'center',
          cursor: 'pointer',
          bgcolor: isDragActive ? 'action.hover' : 'background.paper',
          border: '2px dashed',
          borderColor: isDragActive ? 'primary.main' : 'divider',
        }}
      >
        <input {...getInputProps()} />
        <Upload sx={{ fontSize: 40, color: 'primary.main', mb: 2 }} />
        <Typography>
          {isDragActive
            ? 'Drop your resume here'
            : 'Drag & drop your resume, or click to select'}
        </Typography>
        <Typography variant="caption" display="block" color="text.secondary">
          Supported formats: PDF, DOC, DOCX
        </Typography>
      </Paper>

      {file && (
        <Box sx={{ mb: 3 }}>
          <Chip
            icon={<CheckCircle />}
            label={file.name}
            onDelete={() => setFile(null)}
            color="primary"
          />
        </Box>
      )}

      <Typography variant="h6" gutterBottom>
        Or Paste Resume Content
      </Typography>

      <TextField
        fullWidth
        multiline
        rows={10}
        value={resumeText}
        onChange={(e) => setResumeText(e.target.value)}
        placeholder="Paste your resume content here..."
        error={!!error}
        helperText={error}
        sx={{ mb: 3 }}
      />

      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={handleSubmit}
          disabled={!resumeText.trim()}
        >
          Analyze Resume
        </Button>
      </Box>

      <Box sx={{ mt: 4 }}>
        <Typography variant="subtitle1" gutterBottom>
          What We Analyze:
        </Typography>
        <List>
          {[
            'Executive presence and leadership impact',
            'Quantifiable achievements and results',
            'Strategic initiatives and vision',
            'Industry-specific keywords and terminology',
            'Career progression and growth potential',
            'Areas for improvement and optimization',
          ].map((item, index) => (
            <ListItem key={index}>
              <ListItemIcon>
                <CheckCircle color="primary" />
              </ListItemIcon>
              <ListItemText primary={item} />
            </ListItem>
          ))}
        </List>
      </Box>
    </Box>
  );
};

export default ResumeAnalysis;
