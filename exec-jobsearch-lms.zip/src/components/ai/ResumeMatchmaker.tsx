import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  TextField,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Grid,
  Paper,
  CircularProgress,
  Chip,
  Stack,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  LinearProgress,
  Stepper,
  Step,
  StepLabel,
  Tooltip,
} from '@mui/material';
import {
  Close as CloseIcon,
  CompareArrows as CompareArrowsIcon,
  Upload as UploadIcon,
  Description as DescriptionIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  Info as InfoIcon,
  TipsAndUpdates as TipsAndUpdatesIcon,
  Download as DownloadIcon,
  Visibility as VisibilityIcon,
  Edit as EditIcon,
} from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';

interface ProcessingStep {
  step: string;
  progress: number;
}

interface ATSScore {
  total: number;
  readability: number;
  keywords: number;
  formatting: number;
  compatibility: number;
}

interface SectionContent {
  score: number;
  suggestions: string[];
  examples?: Array<{
    current: string;
    improved: string;
  }>;
}

interface Suggestions {
  sections: {
    [key: string]: SectionContent;
  };
}

interface AnalysisResult {
  success: boolean;
  content?: string;
  error?: string;
  score?: {
    total: number;
    skillsMatch: number;
    experienceMatch: number;
    achievementsScore: number;
    keywordDensity: number;
    formatScore: number;
  };
  atsScore?: ATSScore;
  atsRecommendations?: string[];
  review?: string;
  recommendations?: string[];
  details?: {
    ats_compatibility: {
      system_specific_issues: {
        [key: string]: {
          compatible: boolean;
          issues: string[];
        };
      };
    };
  };
}

const ResumeMatchmaker: React.FC = () => {
  const [resume, setResume] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState('');
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editInstruction, setEditInstruction] = useState('');
  const [processingStep, setProcessingStep] = useState<ProcessingStep | null>(null);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewUrl, setPreviewUrl] = useState('');
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestions | null>(null);
  const [selectedATS, setSelectedATS] = useState<string | null>(null);
  const [atsOptimizations, setATSOptimizations] = useState<any>(null);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    onDrop: async (acceptedFiles) => {
      try {
        const file = acceptedFiles[0];
        const formData = new FormData();
        formData.append('file', file);
        const response = await fetch('/api/parse-resume', {
          method: 'POST',
          body: formData,
        });
        const data = await response.json();
        if (data.success) {
          setResume(data.text);
          setError('');
        } else {
          throw new Error(data.error);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      }
    },
  });

  // WebSocket connection for real-time progress updates
  useEffect(() => {
    if (loading) {
      const ws = new WebSocket('ws://localhost:8000/ws/progress');
      
      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        setProcessingStep(data);
      };
      
      return () => ws.close();
    }
  }, [loading]);

  const handleAnalysis = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/resume-matchmaker/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resume, jobDescription }),
      });
      
      const data = await response.json();
      if (data.success) {
        setResult(data);
      } else {
        throw new Error(data.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
      setProcessingStep(null);
    }
  };

  const handleEdit = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/resume-matchmaker/edit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resume: result?.content || '',
          editInstruction,
        }),
      });
      
      const data = await response.json();
      if (data.success) {
        setResult({
          ...result!,
          content: data.edited_resume,
        });
        setEditDialogOpen(false);
      } else {
        throw new Error(data.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      const response = await fetch('/api/resume-matchmaker/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resume: result?.content || '',
          preview: false,
        }),
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'optimized_resume.docx';
        a.click();
      } else {
        throw new Error('Failed to export resume');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handlePreview = async () => {
    try {
      const response = await fetch('/api/resume-matchmaker/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resume: result?.content || '',
          preview: true,
        }),
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.preview_url) {
          setPreviewUrl(data.preview_url);
          setPreviewDialogOpen(true);
        }
      } else {
        throw new Error('Failed to generate preview');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleSectionEdit = (section: string) => {
    setSelectedSection(section);
    setEditDialogOpen(true);
  };

  const handleGetSuggestions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/resume-matchmaker/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resume: result?.content || '',
          jobDescription,
        }),
      });
      
      const data = await response.json();
      if (data.success) {
        setSuggestions(data);
        setShowSuggestions(true);
      } else {
        throw new Error(data.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleATSSelect = async (ats: string | null) => {
    setSelectedATS(ats);
    if (ats && result?.content) {
      const response = await fetch('/api/resume/optimize-ats', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          resume: result.content,
          target_ats: ats
        })
      });
      
      const data = await response.json();
      if (data.success) {
        setATSOptimizations(data.optimizations);
      }
    }
  };

  const renderATSExamples = (examples: Array<{ issue: string, bad: string, good: string }>) => (
    <Box sx={{ mt: 2 }}>
      <Typography variant="subtitle2" gutterBottom>
        Example Fixes
      </Typography>
      {examples.map((example, index) => (
        <Paper key={index} sx={{ p: 2, mb: 2 }}>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            {example.issue.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Box sx={{ p: 1, bgcolor: 'error.light', borderRadius: 1 }}>
                <Typography variant="caption" color="error.dark">
                  ❌ Incorrect
                </Typography>
                <Typography variant="body2" sx={{ mt: 1, fontFamily: 'monospace' }}>
                  {example.bad}
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box sx={{ p: 1, bgcolor: 'success.light', borderRadius: 1 }}>
                <Typography variant="caption" color="success.dark">
                  ✅ Correct
                </Typography>
                <Typography variant="body2" sx={{ mt: 1, fontFamily: 'monospace' }}>
                  {example.good}
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      ))}
    </Box>
  );

  const renderATSFeedback = () => {
    if (!result?.atsScore) return null;

    return (
      <Box sx={{ mb: 2 }}>
        <Typography variant="subtitle1" gutterBottom>
          ATS Compatibility Analysis
        </Typography>
        
        {/* ATS System Selection */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="body2" gutterBottom>
            Target specific ATS system:
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            {['Workday', 'Greenhouse', 'Lever', 'iCIMS', 'Taleo', 'Jobvite', 'BambooHR', 'Zoho Recruit', 'SAP SuccessFactors', 'JazzHR'].map((ats) => (
              <Chip
                key={ats}
                label={ats}
                onClick={() => handleATSSelect(ats)}
                onDelete={selectedATS === ats ? () => handleATSSelect(null) : undefined}
                color={selectedATS === ats ? "primary" : "default"}
                sx={{ m: 0.5 }}
              />
            ))}
          </Box>
        </Box>
        
        {/* Overall ATS Score */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="body1" gutterBottom>
            Overall ATS Score: {result.atsScore.total}%
          </Typography>
          <LinearProgress 
            variant="determinate" 
            value={result.atsScore.total}
            sx={{
              height: 10,
              borderRadius: 5,
              bgcolor: 'grey.200',
              '& .MuiLinearProgress-bar': {
                borderRadius: 5,
                bgcolor: result.atsScore.total >= 80 ? 'success.main' 
                  : result.atsScore.total >= 60 ? 'warning.main' 
                  : 'error.main'
              }
            }}
          />
        </Box>

        {/* Detailed Scores */}
        <Grid container spacing={2} sx={{ mb: 2 }}>
          {Object.entries(result.atsScore).map(([key, value]) => {
            if (key === 'total') return null;
            return (
              <Grid item xs={12} sm={6} md={4} key={key}>
                <Paper 
                  sx={{ 
                    p: 2,
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                  }}
                >
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </Typography>
                  <Box sx={{ position: 'relative', display: 'inline-flex' }}>
                    <CircularProgress
                      variant="determinate"
                      value={value as number}
                      size={60}
                      sx={{
                        color: (value as number) >= 80 ? 'success.main'
                          : (value as number) >= 60 ? 'warning.main'
                          : 'error.main'
                      }}
                    />
                    <Box
                      sx={{
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        position: 'absolute',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Typography variant="caption" component="div">
                        {`${Math.round(value as number)}%`}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
            );
          })}
        </Grid>

        {/* ATS-Specific Compatibility */}
        {result.details?.ats_compatibility && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="subtitle2" gutterBottom>
              ATS System Compatibility
            </Typography>
            <Grid container spacing={2}>
              {Object.entries(result.details.ats_compatibility.system_specific_issues).map(([ats, data]) => (
                <Grid item xs={12} sm={6} md={4} key={ats}>
                  <Paper 
                    sx={{ 
                      p: 2,
                      border: selectedATS === ats ? 2 : 0,
                      borderColor: 'primary.main'
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                      <Typography variant="body1">
                        {ats}
                      </Typography>
                      {data.compatible ? (
                        <CheckCircleIcon color="success" sx={{ ml: 1 }} />
                      ) : (
                        <ErrorIcon color="warning" sx={{ ml: 1 }} />
                      )}
                    </Box>
                    {data.issues.length > 0 && (
                      <List dense>
                        {data.issues.map((issue, index) => (
                          <ListItem key={index}>
                            <ListItemIcon sx={{ minWidth: 36 }}>
                              <InfoIcon fontSize="small" color="info" />
                            </ListItemIcon>
                            <ListItemText 
                              primary={issue}
                              primaryTypographyProps={{ variant: 'body2' }}
                            />
                          </ListItem>
                        ))}
                      </List>
                    )}
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </Box>
        )}

        {/* ATS-Specific Optimizations */}
        {atsOptimizations && selectedATS && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="h6" gutterBottom>
              {selectedATS} Optimization Details
            </Typography>
            
            <Alert 
              severity={atsOptimizations[selectedATS].format_compatible ? "success" : "warning"}
              sx={{ mb: 2 }}
            >
              {atsOptimizations[selectedATS].format_compatible 
                ? "✅ File format is compatible" 
                : "⚠️ File format may not be optimal"}
            </Alert>

            {atsOptimizations[selectedATS].examples && 
              renderATSExamples(atsOptimizations[selectedATS].examples)}

            <Box sx={{ mt: 3 }}>
              <Typography variant="subtitle2" gutterBottom>
                System-Specific Recommendations
              </Typography>
              <List>
                {atsOptimizations[selectedATS].recommendations.map((rec: string, index: number) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <TipsAndUpdatesIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText primary={rec} />
                  </ListItem>
                ))}
              </List>
            </Box>
          </Box>
        )}

        {/* General Recommendations */}
        {result.atsRecommendations && result.atsRecommendations.length > 0 && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="subtitle2" gutterBottom>
              General ATS Optimization Recommendations
            </Typography>
            <List>
              {result.atsRecommendations.map((rec, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <TipsAndUpdatesIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText primary={rec} />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </Box>
    );
  };

  const renderSuggestionsDialog = () => (
    <Dialog
      open={showSuggestions}
      onClose={() => setShowSuggestions(false)}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>
        Improvement Suggestions
        <IconButton
          aria-label="close"
          onClick={() => setShowSuggestions(false)}
          sx={{ position: 'absolute', right: 8, top: 8 }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers>
        {suggestions?.sections && Object.entries(suggestions.sections).map(([section, content]: [string, SectionContent]) => (
          <Box key={section} sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              {section}
              <IconButton
                size="small"
                onClick={() => handleSectionEdit(section)}
                sx={{ ml: 1 }}
              >
                <EditIcon fontSize="small" />
              </IconButton>
            </Typography>
            <Box sx={{ ml: 2 }}>
              <Typography variant="subtitle2" gutterBottom>
                Effectiveness Score: {content.score}%
              </Typography>
              <List>
                {content.suggestions.map((suggestion: string, index: number) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <InfoIcon color="info" />
                    </ListItemIcon>
                    <ListItemText primary={suggestion} />
                  </ListItem>
                ))}
              </List>
              {content.examples && (
                <Box sx={{ mt: 1 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Suggested Improvements:
                  </Typography>
                  <List>
                    {content.examples.map((example: any, index: number) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <CompareArrowsIcon color="success" />
                        </ListItemIcon>
                        <ListItemText
                          primary={
                            <Box>
                              <Typography color="text.secondary" sx={{ textDecoration: 'line-through' }}>
                                {example.current}
                              </Typography>
                              <Typography color="success.main">
                                {example.improved}
                              </Typography>
                            </Box>
                          }
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </Box>
          </Box>
        ))}
      </DialogContent>
      <DialogActions>
        <Button onClick={() => setShowSuggestions(false)}>Close</Button>
        <Button
          variant="contained"
          onClick={() => {
            setShowSuggestions(false);
            setEditDialogOpen(true);
          }}
        >
          Make Changes
        </Button>
      </DialogActions>
    </Dialog>
  );

  return (
    <Box sx={{ width: '100%', p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Resume Matchmaker Plus
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {!result && (
        <Box>
          <Paper
            {...getRootProps()}
            sx={{
              p: 3,
              mb: 3,
              textAlign: 'center',
              cursor: 'pointer',
              bgcolor: 'background.paper',
              border: '2px dashed',
              borderColor: 'divider',
            }}
          >
            <input {...getInputProps()} />
            <UploadIcon sx={{ fontSize: 40, color: 'primary.main', mb: 2 }} />
            <Typography>Drop your resume or click to select</Typography>
          </Paper>

          <TextField
            fullWidth
            multiline
            rows={6}
            label="Resume Content"
            value={resume}
            onChange={(e) => setResume(e.target.value)}
            sx={{ mb: 3 }}
          />

          <TextField
            fullWidth
            multiline
            rows={6}
            label="Job Description"
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            sx={{ mb: 3 }}
          />

          <Button
            variant="contained"
            onClick={handleAnalysis}
            disabled={!resume || !jobDescription || loading}
            fullWidth
          >
            Analyze and Optimize Resume
          </Button>
        </Box>
      )}

      {loading && processingStep && (
        <Box sx={{ mt: 3 }}>
          <LinearProgress variant="determinate" value={processingStep.progress} />
          <Typography sx={{ mt: 1 }} color="text.secondary">
            {processingStep.step}
          </Typography>
        </Box>
      )}

      {result?.content && (
        <Box sx={{ mt: 3 }}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Analysis Results
              </Typography>
              
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Resume Score: {result.score?.total}%
                </Typography>
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                  <Tooltip title="Match with required skills">
                    <Typography>✅ Skills: {result.score?.skillsMatch}%</Typography>
                  </Tooltip>
                  <Tooltip title="Relevance of experience">
                    <Typography>✅ Experience: {result.score?.experienceMatch}%</Typography>
                  </Tooltip>
                  <Tooltip title="Impact of achievements">
                    <Typography>✅ Achievements: {result.score?.achievementsScore}%</Typography>
                  </Tooltip>
                  <Tooltip title="Keyword optimization">
                    <Typography>✅ Keywords: {result.score?.keywordDensity}%</Typography>
                  </Tooltip>
                  <Tooltip title="Format and structure">
                    <Typography>✅ Format: {result.score?.formatScore}%</Typography>
                  </Tooltip>
                </Box>
              </Box>

              {renderATSFeedback()}

              {result.recommendations && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Recommendations:
                  </Typography>
                  {result.recommendations.map((rec, index) => (
                    <Typography key={index} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <InfoIcon fontSize="small" color="info" />
                      {rec}
                    </Typography>
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>

          <Paper sx={{ p: 2, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Optimized Resume
              </Typography>
              <Button
                variant="outlined"
                startIcon={<InfoIcon />}
                onClick={handleGetSuggestions}
                disabled={loading}
              >
                Get Section Suggestions
              </Button>
            </Box>
            <Box sx={{ whiteSpace: 'pre-line' }}>
              {result.content.split('\n\n').map((section, index) => {
                const sectionTitle = section.match(/^#\s*(.+)/);
                if (sectionTitle) {
                  return (
                    <Box key={index} sx={{ mb: 3 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="h6">{sectionTitle[1]}</Typography>
                        <IconButton
                          size="small"
                          onClick={() => handleSectionEdit(sectionTitle[1])}
                          title={`Edit ${sectionTitle[1]} section`}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Box>
                      <Typography>{section.replace(/^#\s*.+\n/, '')}</Typography>
                    </Box>
                  );
                }
                return <Typography key={index} paragraph>{section}</Typography>;
              })}
            </Box>
          </Paper>

          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              variant="outlined"
              startIcon={<EditIcon />}
              onClick={() => setEditDialogOpen(true)}
            >
              Edit Full Resume
            </Button>
            <Button
              variant="outlined"
              startIcon={<VisibilityIcon />}
              onClick={handlePreview}
            >
              Preview
            </Button>
            <Button
              variant="contained"
              startIcon={<DownloadIcon />}
              onClick={handleExport}
            >
              Export to Word
            </Button>
          </Box>
        </Box>
      )}

      <Dialog
        open={editDialogOpen}
        onClose={() => {
          setEditDialogOpen(false);
          setSelectedSection(null);
        }}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          {selectedSection ? `Edit ${selectedSection} Section` : 'Edit Resume'}
        </DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            multiline
            rows={4}
            label="Describe your changes"
            value={editInstruction}
            onChange={(e) => setEditInstruction(e.target.value)}
            sx={{ mt: 2 }}
            placeholder={selectedSection 
              ? `Describe the changes you want to make to the ${selectedSection} section`
              : "Describe the changes you want to make to your resume"
            }
          />
          {result?.atsScore && (
            <Alert severity="info" sx={{ mt: 2 }}>
              Your changes will be automatically checked for ATS compatibility
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={() => {
              setEditDialogOpen(false);
              setSelectedSection(null);
            }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleEdit}
            disabled={!editInstruction.trim()}
          >
            Apply Changes
          </Button>
        </DialogActions>
      </Dialog>

      {renderSuggestionsDialog()}

      <Dialog
        open={previewDialogOpen}
        onClose={() => setPreviewDialogOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>Resume Preview</DialogTitle>
        <DialogContent>
          <iframe
            src={previewUrl}
            style={{ width: '100%', height: '80vh', border: 'none' }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewDialogOpen(false)}>Close</Button>
          <Button variant="contained" onClick={handleExport}>
            Export to Word
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ResumeMatchmaker;
