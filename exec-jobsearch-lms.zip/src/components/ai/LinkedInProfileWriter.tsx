import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  TextField,
  Typography,
  CircularProgress,
  Snackbar,
  Alert,
  Grid,
  Divider,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import SaveIcon from '@mui/icons-material/Save';
import HistoryIcon from '@mui/icons-material/History';
import RestoreIcon from '@mui/icons-material/Restore';
import CloseIcon from '@mui/icons-material/Close';

interface ProfileSection {
  title: string;
  content: string;
  suggestions: string[];
}

interface LinkedInProfile {
  headline: string;
  summary: string;
  sections: ProfileSection[];
  keywords: string[];
  optimizationScore: number;
}

export const LinkedInProfileWriter: React.FC = () => {
  const [jobTitle, setJobTitle] = useState('');
  const [experience, setExperience] = useState('');
  const [skills, setSkills] = useState('');
  const [achievements, setAchievements] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<LinkedInProfile | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  
  // New state for editing and version history
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingSectionTitle, setEditingSectionTitle] = useState('');
  const [editingSectionContent, setEditingSectionContent] = useState('');
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [profileVersions, setProfileVersions] = useState<Array<{
    version: number;
    timestamp: string;
    profile: LinkedInProfile;
  }>>([]);

  useEffect(() => {
    const loadVersions = async () => {
      try {
        const response = await fetch('/api/linkedin/versions');
        if (!response.ok) {
          throw new Error('Failed to fetch profile versions');
        }
        const versions = await response.json();
        setProfileVersions(versions);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch versions');
      }
    };

    loadVersions();
  }, []);

  const fetchProfileVersions = async () => {
    try {
      const response = await fetch('/api/linkedin/versions');
      if (!response.ok) {
        throw new Error('Failed to fetch profile versions');
      }
      const versions = await response.json();
      setProfileVersions(versions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch versions');
    }
  };

  const handleSubmit = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch('/api/linkedin/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobTitle,
          experience,
          skills,
          achievements,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate LinkedIn profile');
      }

      const data = await response.json();
      setProfile(data);
      setSuccessMessage('Profile generated successfully!');
      await fetchProfileVersions(); // Refresh versions after generation
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditSection = (title: string, content: string) => {
    setEditingSectionTitle(title);
    setEditingSectionContent(content);
    setEditDialogOpen(true);
  };

  const handleSaveSection = async () => {
    try {
      const response = await fetch(`/api/linkedin/sections/${editingSectionTitle}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: editingSectionContent,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update section');
      }

      const updatedProfile = await response.json();
      setProfile(updatedProfile);
      setSuccessMessage('Section updated successfully!');
      setEditDialogOpen(false);
      await fetchProfileVersions(); // Refresh versions after update
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update section');
    }
  };

  const handleRestoreVersion = async (version: number) => {
    try {
      const response = await fetch(`/api/linkedin/restore/${version}`, {
        method: 'POST',
      });
      if (!response.ok) {
        throw new Error('Failed to restore version');
      }
      const restoredProfile = await response.json();
      setProfile(restoredProfile);
      setHistoryDialogOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to restore version');
    }
  };

  const handleCopyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setSuccessMessage('Copied to clipboard!');
    } catch (err) {
      setError('Failed to copy to clipboard');
    }
  };

  const renderProfileSection = (section: ProfileSection) => (
    <Box key={section.title} sx={{ mb: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
        <Typography variant="h6">{section.title}</Typography>
        <Box>
          <Button
            startIcon={<EditIcon />}
            size="small"
            sx={{ mr: 1 }}
            onClick={() => handleEditSection(section.title, section.content)}
          >
            Edit
          </Button>
          <Button
            startIcon={<ContentCopyIcon />}
            size="small"
            onClick={() => handleCopyToClipboard(section.content)}
          >
            Copy
          </Button>
        </Box>
      </Box>
      <Typography variant="body1" sx={{ mb: 1 }}>
        {section.content}
      </Typography>
      <Box>
        {section.suggestions.map((suggestion, index) => (
          <Chip
            key={index}
            label={suggestion}
            size="small"
            color="primary"
            variant="outlined"
            sx={{ mr: 1, mb: 1 }}
          />
        ))}
      </Box>
    </Box>
  );

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        LinkedIn Profile Writer
      </Typography>

      {/* Input Form */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Job Title"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Professional Experience"
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                multiline
                rows={4}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Skills"
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                multiline
                rows={2}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Key Achievements"
                value={achievements}
                onChange={(e) => setAchievements(e.target.value)}
                multiline
                rows={3}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={isLoading || !jobTitle || !experience || !skills}
                  startIcon={isLoading ? <CircularProgress size={20} /> : null}
                >
                  Generate Profile
                </Button>
                <Button
                  variant="outlined"
                  onClick={() => setHistoryDialogOpen(true)}
                  startIcon={<HistoryIcon />}
                  disabled={!profileVersions.length}
                >
                  Version History
                </Button>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Generated Profile */}
      {profile && (
        <Card>
          <CardContent>
            <Box sx={{ mb: 3 }}>
              <Typography variant="h5" gutterBottom>
                {profile.headline}
              </Typography>
              <Button
                startIcon={<ContentCopyIcon />}
                size="small"
                onClick={() => handleCopyToClipboard(profile.headline)}
              >
                Copy Headline
              </Button>
            </Box>

            <Box sx={{ mb: 3 }}>
              <Typography variant="h6" gutterBottom>
                Summary
              </Typography>
              <Typography variant="body1">{profile.summary}</Typography>
              <Button
                startIcon={<ContentCopyIcon />}
                size="small"
                sx={{ mt: 1 }}
                onClick={() => handleCopyToClipboard(profile.summary)}
              >
                Copy Summary
              </Button>
            </Box>

            <Divider sx={{ my: 2 }} />

            {profile.sections?.map(renderProfileSection)}

            <Box sx={{ mt: 3 }}>
              <Typography variant="subtitle1" sx={{ mb: 1 }}>
                Recommended Keywords
              </Typography>
              <Box>
                {profile.keywords?.map((keyword, index) => (
                  <Chip
                    key={index}
                    label={keyword}
                    size="small"
                    color="primary"
                    sx={{ mr: 1, mb: 1 }}
                  />
                ))}
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <Typography variant="subtitle1">
                Profile Optimization Score: {profile.optimizationScore}%
              </Typography>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog
        open={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Edit {editingSectionTitle}
          <IconButton
            aria-label="close"
            onClick={() => setEditDialogOpen(false)}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            multiline
            rows={6}
            value={editingSectionContent}
            onChange={(e) => setEditingSectionContent(e.target.value)}
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleSaveSection}
            variant="contained"
            startIcon={<SaveIcon />}
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>

      {/* Version History Dialog */}
      <Dialog
        open={historyDialogOpen}
        onClose={() => setHistoryDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Version History
          <IconButton
            aria-label="close"
            onClick={() => setHistoryDialogOpen(false)}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <List>
            {profileVersions.map((version) => (
              <ListItem key={version.version}>
                <ListItemText
                  primary={`Version ${version.version}`}
                  secondary={new Date(version.timestamp).toLocaleString()}
                />
                <ListItemSecondaryAction>
                  <Button
                    startIcon={<RestoreIcon />}
                    onClick={() => handleRestoreVersion(version.version)}
                  >
                    Restore
                  </Button>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setHistoryDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Success Message */}
      <Snackbar
        open={!!successMessage}
        autoHideDuration={3000}
        onClose={() => setSuccessMessage(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSuccessMessage(null)} severity="success">
          {successMessage}
        </Alert>
      </Snackbar>

      {/* Error Message */}
      <Snackbar
        open={!!error}
        autoHideDuration={5000}
        onClose={() => setError(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setError(null)} severity="error">
          {error}
        </Alert>
      </Snackbar>
    </Box>
  );
};
