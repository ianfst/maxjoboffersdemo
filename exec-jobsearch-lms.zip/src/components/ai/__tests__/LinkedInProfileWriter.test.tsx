import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { LinkedInProfileWriter } from '../LinkedInProfileWriter';
import '@testing-library/jest-dom';

const mockProfile = {
  headline: 'Senior Software Engineer',
  summary: 'Experienced software engineer',
  sections: [
    {
      title: 'Experience',
      content: '10+ years of experience',
      suggestions: ['Add metrics'],
    },
  ],
  keywords: ['JavaScript', 'React'],
  optimizationScore: 85,
};

const mockVersions = [
  {
    version: 1,
    timestamp: '2025-03-05T12:00:00Z',
    profile: mockProfile,
  },
];

const fillForm = async (user: ReturnType<typeof userEvent.setup>) => {
  await user.type(screen.getByLabelText(/job title/i), 'Software Engineer');
  await user.type(screen.getByLabelText(/professional experience/i), 'Test experience');
  await user.type(screen.getByLabelText(/skills/i), 'React, Node.js');
  await user.type(screen.getByLabelText(/key achievements/i), 'Increased performance');
};

describe('LinkedInProfileWriter', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    global.fetch = jest.fn().mockImplementation((url) => {
      if (url === '/api/linkedin/generate') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockProfile),
        });
      }
      if (url === '/api/linkedin/sections/Experience') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockProfile),
        });
      }
      if (url === '/api/linkedin/versions') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockVersions),
        });
      }
      return Promise.resolve({
        ok: false,
        json: () => Promise.resolve({ error: 'Not found' }),
      });
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('handles section editing', async () => {
    const user = userEvent.setup();
    render(<LinkedInProfileWriter />);

    await fillForm(user);
    await user.click(screen.getByText(/generate profile/i));

    await waitFor(() => {
      expect(screen.getByText(mockProfile.headline)).toBeInTheDocument();
    });

    const editButton = await screen.findByRole('button', { name: /edit/i });
    await user.click(editButton);

    const textarea = screen.getByRole('textbox');
    await user.clear(textarea);
    await user.type(textarea, 'Updated content');

    await user.click(screen.getByRole('button', { name: /save/i }));

    expect(global.fetch).toHaveBeenCalledWith(
      '/api/linkedin/sections/Experience',
      expect.any(Object)
    );
  });

  it('handles version history', async () => {
    const user = userEvent.setup();
    render(<LinkedInProfileWriter />);

    await fillForm(user);
    await user.click(screen.getByText(/generate profile/i));

    await waitFor(() => {
      expect(screen.getByText(mockProfile.headline)).toBeInTheDocument();
    });

    const versionHistoryButton = screen.getByRole('button', { name: /version history/i });
    await user.click(versionHistoryButton);

    expect(screen.getByRole('dialog')).toBeInTheDocument();
    expect(screen.getByText(/Version 1/)).toBeInTheDocument();
  });

  it('handles copy to clipboard', async () => {
    const user = userEvent.setup();
    const { container } = render(<LinkedInProfileWriter />);

    await fillForm(user);
    await user.click(screen.getByText(/generate profile/i));

    await waitFor(() => {
      expect(screen.getByText(mockProfile.headline)).toBeInTheDocument();
    });

    // Find the copy button for the headline
    const copyButton = screen.getByRole('button', { name: /copy headline/i });
    await user.click(copyButton);

    // Wait for the success message
    await waitFor(() => {
      expect(screen.getByText(/copied to clipboard/i)).toBeInTheDocument();
    });

    // Verify that the text was copied to clipboard
    const clipboardText = await navigator.clipboard.readText();
    expect(clipboardText).toBe(mockProfile.headline);
  });

  it('handles API errors', async () => {
    global.fetch = jest.fn().mockImplementation(() =>
      Promise.resolve({
        ok: false,
        json: () => Promise.resolve({ error: 'API Error' }),
      })
    );

    const user = userEvent.setup();
    render(<LinkedInProfileWriter />);

    await fillForm(user);
    await user.click(screen.getByText(/generate profile/i));

    await waitFor(() => {
      expect(screen.getByText(/failed to generate/i)).toBeInTheDocument();
    });
  });

  it('validates required fields', async () => {
    const user = userEvent.setup();
    render(<LinkedInProfileWriter />);

    const generateButton = screen.getByText(/generate profile/i);
    expect(generateButton).toBeDisabled();

    await user.type(screen.getByLabelText(/job title/i), 'Software Engineer');
    expect(generateButton).toBeDisabled();

    await user.type(screen.getByLabelText(/professional experience/i), 'Test experience');
    expect(generateButton).toBeDisabled();

    await user.type(screen.getByLabelText(/skills/i), 'React, Node.js');
    expect(generateButton).not.toBeDisabled();
  });
});
