import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ResumeMatchmaker } from '../ResumeMatchmaker';
import '@testing-library/jest-dom';

// Mock Material-UI components
jest.mock('@mui/material', () => ({
  Box: ({ children }) => <div className="MuiBox-root">{children}</div>,
  Paper: ({ children }) => <div className="MuiPaper-root">{children}</div>,
  Card: ({ children }) => <div className="MuiCard-root">{children}</div>,
  CardContent: ({ children }) => <div className="MuiCardContent-root">{children}</div>,
  Typography: ({ children, variant }) => <div data-variant={variant}>{children}</div>,
  TextField: ({ label, value, onChange, multiline, rows }) => (
    <div>
      <label>{label}</label>
      <textarea
        data-testid={`textarea-${label}`}
        value={value}
        onChange={onChange}
        rows={rows}
        aria-label={label}
      />
    </div>
  ),
  Dialog: ({ open, onClose, children }) => open ? <div role="dialog">{children}</div> : null,
  DialogTitle: ({ children }) => <div>{children}</div>,
  DialogContent: ({ children }) => <div>{children}</div>,
  DialogActions: ({ children }) => <div>{children}</div>,
  Button: ({ children, onClick, disabled, variant }) => (
    <button onClick={onClick} disabled={disabled} data-variant={variant}>
      {children}
    </button>
  ),
  IconButton: ({ children, onClick, title }) => (
    <button onClick={onClick} title={title}>
      {children}
    </button>
  ),
  CircularProgress: () => <div>Loading...</div>,
  Alert: ({ children, severity }) => <div data-severity={severity}>{children}</div>,
  List: ({ children }) => <div>{children}</div>,
  ListItem: ({ children }) => <div>{children}</div>,
  ListItemText: ({ primary, secondary }) => (
    <div>
      <div>{primary}</div>
      {secondary && <div>{secondary}</div>}
    </div>
  ),
  ListItemIcon: ({ children }) => <div>{children}</div>,
  Tooltip: ({ children, title }) => <div title={title}>{children}</div>,
  LinearProgress: ({ value }) => <div>Progress: {value}%</div>,
  Chip: ({ label, onClick, onDelete, color }) => (
    <button onClick={onClick} data-color={color}>
      {label}
      {onDelete && <span onClick={onDelete}>✕</span>}
    </button>
  ),
  Grid: ({ children, container, item }) => (
    <div data-container={container} data-item={item}>
      {children}
    </div>
  ),
  Stack: ({ children }) => <div>{children}</div>,
  Stepper: ({ children }) => <div>{children}</div>,
  Step: ({ children }) => <div>{children}</div>,
  StepLabel: ({ children }) => <div>{children}</div>,
  Divider: () => <hr />,
}));

// Mock Material Icons
jest.mock('@mui/icons-material', () => ({
  Upload: () => 'UploadIcon',
  Edit: () => 'EditIcon',
  Download: () => 'DownloadIcon',
  Close: () => 'CloseIcon',
  CompareArrows: () => 'CompareArrowsIcon',
  Description: () => 'DescriptionIcon',
  CheckCircle: () => 'CheckCircleIcon',
  Warning: () => 'WarningIcon',
  Error: () => 'ErrorIcon',
  Info: () => 'InfoIcon',
  TipsAndUpdates: () => 'TipsAndUpdatesIcon',
  Visibility: () => 'VisibilityIcon',
}));

// Mock react-dropzone
jest.mock('react-dropzone', () => ({
  useDropzone: () => ({
    getRootProps: () => ({}),
    getInputProps: () => ({ accept: {} }),
    isDragActive: false,
  }),
}));

class MockWebSocket {
  static CONNECTING = 0;
  static OPEN = 1;
  static CLOSING = 2;
  static CLOSED = 3;

  onopen: ((event: Event) => void) | null = null;
  onclose: ((event: CloseEvent) => void) | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: Event) => void) | null = null;
  readyState: number = MockWebSocket.CONNECTING;

  constructor(url: string) {
    setTimeout(() => {
      this.readyState = MockWebSocket.OPEN;
      this.onopen?.({} as Event);
    }, 0);
  }

  send(data: string): void {
    // Mock implementation
  }

  close(): void {
    this.readyState = MockWebSocket.CLOSED;
    this.onclose?.({} as CloseEvent);
  }
}

describe('ResumeMatchmaker', () => {
  const mockResponse = new Response(JSON.stringify({
    success: true,
    score: {
      total: 85,
      skillsMatch: 90,
      experienceMatch: 85,
      achievementsScore: 80,
      keywordDensity: 85,
      formatScore: 90
    },
    suggestions: [],
    details: {}
  }));

  beforeEach(() => {
    // Mock WebSocket
    (global as any).WebSocket = MockWebSocket;

    // Mock fetch with proper Response objects
    global.fetch = jest.fn().mockImplementation((input: RequestInfo | URL) => {
      const url = input.toString();
      
      if (url.includes('export')) {
        return Promise.resolve(new Response(new Blob(), {
          status: 200,
          statusText: 'OK'
        }));
      }
      
      return Promise.resolve(mockResponse);
    });

    // Mock createElement for file download
    const mockElement = {
      href: '',
      download: '',
      click: jest.fn(),
      remove: jest.fn()
    };
    document.createElement = jest.fn().mockReturnValue(mockElement as unknown as HTMLElement);

    // Mock URL methods
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
  });

  const fillFormAndAnalyze = async () => {
    // Fill in resume content
    const resumeInput = screen.getByTestId('textarea-Resume Content');
    await act(async () => {
      await userEvent.type(resumeInput, 'Senior Manager with 10 years experience');
    });

    // Fill in job description
    const jobInput = screen.getByTestId('textarea-Job Description');
    await act(async () => {
      await userEvent.type(jobInput, 'Looking for a Senior Manager with experience');
    });

    // Wait for analyze button to be enabled
    await waitFor(() => {
      const analyzeButton = screen.getByText(/Analyze and Optimize Resume/i);
      expect(analyzeButton).not.toBeDisabled();
    });

    // Click analyze button and wait for fetch
    const analyzeButton = screen.getByText(/Analyze and Optimize Resume/i);
    await act(async () => {
      await userEvent.click(analyzeButton);
      await new Promise(resolve => setTimeout(resolve, 0)); // Wait for state update
    });

    // Wait for the fetch to complete and result to be displayed
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalled();
      expect(screen.getByText(/Resume Score/i)).toBeInTheDocument();
      expect(screen.getByText(/Professional Experience/i)).toBeInTheDocument();
    });
  };

  it('allows section editing', async () => {
    render(<ResumeMatchmaker />);
    await fillFormAndAnalyze();

    // Click edit button
    const editButton = screen.getByTitle(/Edit Professional Experience section/i);
    await act(async () => {
      await userEvent.click(editButton);
      await new Promise(resolve => setTimeout(resolve, 0)); // Wait for state update
    });

    // Wait for dialog to be displayed
    await waitFor(() => {
      expect(screen.getByRole('dialog')).toBeInTheDocument();
      expect(screen.getByText(/Describe your changes/i)).toBeInTheDocument();
    });

    // Fill in changes
    const textarea = screen.getByTestId('textarea-Describe your changes');
    await act(async () => {
      await userEvent.type(textarea, 'Added more achievements');
      await new Promise(resolve => setTimeout(resolve, 0)); // Wait for state update
    });

    // Wait for apply button to be enabled
    await waitFor(() => {
      const applyButton = screen.getByText(/Apply Changes/i);
      expect(applyButton).not.toBeDisabled();
    });

    // Click apply button
    const applyButton = screen.getByText(/Apply Changes/i);
    await act(async () => {
      await userEvent.click(applyButton);
      await new Promise(resolve => setTimeout(resolve, 0)); // Wait for state update
    });

    // Wait for dialog to be closed
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  }, 30000); // Increase test timeout

  it('exports optimized resume', async () => {
    // Mock window.URL.createObjectURL
    const mockUrl = 'mock-blob-url';
    window.URL.createObjectURL = jest.fn(() => mockUrl);
    window.URL.revokeObjectURL = jest.fn();

    // Mock document.createElement
    const mockAnchor = {
      href: '',
      download: '',
      click: jest.fn(function() {
        window.URL.revokeObjectURL(mockUrl);
        this.remove();
      }),
      remove: jest.fn(),
    };
    const origCreateElement = document.createElement;
    document.createElement = jest.fn((tag) => {
      if (tag === 'a') {
        return mockAnchor;
      }
      return origCreateElement.call(document, tag);
    });

    render(<ResumeMatchmaker />);
    await fillFormAndAnalyze();

    // Click Export to Word button
    const exportButton = screen.getByText(/Export to Word/i);
    await act(async () => {
      await userEvent.click(exportButton);
    });

    // Wait for fetch and blob creation
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalled();
      expect(window.URL.createObjectURL).toHaveBeenCalled();
    });

    // Wait for anchor element setup and click
    await waitFor(() => {
      expect(mockAnchor.href).toBe(mockUrl);
      expect(mockAnchor.download).toBe('optimized_resume.docx');
      expect(mockAnchor.click).toHaveBeenCalled();
    });

    // Wait for cleanup
    await waitFor(() => {
      expect(window.URL.revokeObjectURL).toHaveBeenCalledWith(mockUrl);
      expect(mockAnchor.remove).toHaveBeenCalled();
    });

    // Restore original functions
    document.createElement = origCreateElement;
    delete window.URL.createObjectURL;
    delete window.URL.revokeObjectURL;
  }, 30000); // Increase test timeout
});
