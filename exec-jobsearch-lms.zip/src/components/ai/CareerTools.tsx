import React, { useState } from 'react';
import {
  Box,
  Card,
  Grid,
  Typography,
  Button,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Stepper,
  Step,
  StepLabel,
  CardContent,
  IconButton,
} from '@mui/material';
import {
  Description as DescriptionOutlined,
  Email as EmailOutlined,
  RateReview as RateReviewOutlined,
  AttachMoney as AttachMoneyOutlined,
  TrendingUp as TrendingUpOutlined,
  Person as PersonOutlined,
  WorkOutline as WorkOutlined,
  School as SchoolOutlined,
} from '@mui/icons-material';

interface AIResponse {
  success: boolean;
  error?: string;
  [key: string]: any;
}

interface Tool {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  action: string;
}

const CareerTools: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [activeDialog, setActiveDialog] = useState<string | null>(null);
  const [result, setResult] = useState<AIResponse | null>(null);

  const tools: Tool[] = [
    {
      id: 'resume-builder',
      title: 'Resume Builder',
      description: 'Create a professional resume with our AI-powered builder',
      icon: <DescriptionOutlined />,
      action: 'Build Resume',
    },
    {
      id: 'cover-letter',
      title: 'Cover Letter Generator',
      description: 'Generate customized cover letters for your applications',
      icon: <EmailOutlined />,
      action: 'Write Letter',
    },
    {
      id: 'interview-prep',
      title: 'Interview Preparation',
      description: 'Practice with AI-powered mock interviews',
      icon: <RateReviewOutlined />,
      action: 'Start Practice',
    },
    {
      id: 'salary-negotiation',
      title: 'Salary Negotiation',
      description: 'Get tips and scripts for negotiating your compensation',
      icon: <AttachMoneyOutlined />,
      action: 'Learn More',
    },
    {
      id: 'career-path',
      title: 'Career Path Planning',
      description: 'Map out your career progression and goals',
      icon: <TrendingUpOutlined />,
      action: 'Plan Career',
    },
    {
      id: 'personal-brand',
      title: 'Personal Branding',
      description: 'Build your professional online presence',
      icon: <PersonOutlined />,
      action: 'Start Building',
    },
    {
      id: 'job-search',
      title: 'Job Search Strategy',
      description: 'Develop an effective job search plan',
      icon: <WorkOutlined />,
      action: 'Create Plan',
    },
    {
      id: 'skill-development',
      title: 'Skill Development',
      description: 'Identify and develop key skills for your career',
      icon: <SchoolOutlined />,
      action: 'Explore Skills',
    },
  ];

  const handleToolClick = (toolId: string) => {
    setActiveDialog(toolId);
    setResult(null);
  };

  const handleClose = () => {
    setActiveDialog(null);
    setResult(null);
  };

  const handleSubmit = async (data: any) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/ai/${activeDialog}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      setResult(result);
    } catch (error) {
      setResult({ success: false, error: 'Failed to process request' });
    }
    setLoading(false);
  };

  const renderToolContent = () => {
    switch (activeDialog) {
      case 'resume-builder':
        return <ResumeAnalysis onSubmit={handleSubmit} />;
      case 'cover-letter':
        return <CoverLetterGenerator onSubmit={handleSubmit} />;
      case 'interview-prep':
        return <InterviewPrep onSubmit={handleSubmit} />;
      case 'salary-negotiation':
        return <SalaryNegotiation onSubmit={handleSubmit} />;
      case 'career-path':
        return <CareerPathAnalysis onSubmit={handleSubmit} />;
      case 'personal-brand':
        return <PersonalBrandOptimization onSubmit={handleSubmit} />;
      case 'job-search':
        return <JobSearchStrategy onSubmit={handleSubmit} />;
      case 'skill-development':
        return <SkillDevelopment onSubmit={handleSubmit} />;
      default:
        return null;
    }
  };

  return (
    <Box sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        Career Development Tools
      </Typography>
      <Grid container spacing={3}>
        {tools.map((tool) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={tool.id}>
            <Card
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                '&:hover': {
                  boxShadow: 4,
                  transform: 'translateY(-4px)',
                  transition: 'all 0.3s ease',
                },
              }}
              onClick={() => handleToolClick(tool.id)}
            >
              <CardContent sx={{ flexGrow: 1 }}>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                    color: 'primary.main',
                  }}
                >
                  {tool.icon}
                  <Typography
                    variant="h6"
                    sx={{ ml: 1, fontSize: '1.1rem' }}
                  >
                    {tool.title}
                  </Typography>
                </Box>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mb: 2 }}
                >
                  {tool.description}
                </Typography>
                <Button
                  variant="outlined"
                  color="primary"
                  fullWidth
                  sx={{
                    mt: 'auto',
                    textTransform: 'none',
                  }}
                >
                  {tool.action}
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog
        open={!!activeDialog}
        onClose={handleClose}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          {tools.find((t) => t.id === activeDialog)?.title}
        </DialogTitle>
        <DialogContent>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
              <CircularProgress />
            </Box>
          ) : result ? (
            <ResultView result={result} onClose={handleClose} />
          ) : (
            renderToolContent()
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

// Individual tool components would be implemented here
const ResumeAnalysis: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Resume Analysis Component</div>;
};

const CoverLetterGenerator: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Cover Letter Generator Component</div>;
};

const InterviewPrep: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Interview Prep Component</div>;
};

const SalaryNegotiation: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Salary Negotiation Component</div>;
};

const CareerPathAnalysis: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Career Path Analysis Component</div>;
};

const PersonalBrandOptimization: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Personal Brand Optimization Component</div>;
};

const JobSearchStrategy: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Job Search Strategy Component</div>;
};

const SkillDevelopment: React.FC<{ onSubmit: (data: any) => void }> = ({
  onSubmit,
}) => {
  // Implementation
  return <div>Skill Development Component</div>;
};

const ResultView: React.FC<{ result: AIResponse; onClose: () => void }> = ({
  result,
  onClose,
}) => {
  return (
    <Box sx={{ p: 2 }}>
      {result.success ? (
        <Box>
          <Typography variant="h6" gutterBottom>
            Analysis Results
          </Typography>
          <Typography variant="body1" whiteSpace="pre-line">
            {result.analysis || result.recommendations || result.strategy}
          </Typography>
        </Box>
      ) : (
        <Typography color="error">{result.error}</Typography>
      )}
      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
        <Button onClick={onClose} variant="contained">
          Close
        </Button>
      </Box>
    </Box>
  );
};

export default CareerTools;
