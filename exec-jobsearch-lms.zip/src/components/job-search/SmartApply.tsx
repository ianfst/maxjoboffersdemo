import React, { useState, useEffect } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Typography,
  Paper,
  CircularProgress,
  Alert,
  TextField,
  Chip,
  Stack
} from '@mui/material';
import { Job, JobApplication } from '../../types/job';
import { ResumeVersion } from '../../types/resume';
import { CoverLetter } from '../../types/coverLetter';

interface SmartApplyProps {
  job: Job;
  resumes: ResumeVersion[];
  coverLetters: CoverLetter[];
  onApply: (application: JobApplication) => Promise<void>;
}

const steps = [
  'Job Analysis',
  'Document Preparation',
  'Application Form',
  'Review & Submit'
];

export const SmartApply: React.FC<SmartApplyProps> = ({
  job,
  resumes,
  coverLetters,
  onApply
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [selectedResume, setSelectedResume] = useState<ResumeVersion | null>(null);
  const [selectedCoverLetter, setSelectedCoverLetter] = useState<CoverLetter | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [suggestions, setSuggestions] = useState<Record<string, string[]>>({});

  // Step 1: Analyze job and prepare recommendations
  const analyzeJob = async () => {
    setLoading(true);
    try {
      // Call your job analysis service
      const jobAnalysis = await fetch('/api/jobs/analyze', {
        method: 'POST',
        body: JSON.stringify({ jobId: job.id })
      }).then(res => res.json());

      setAnalysis(jobAnalysis);
      
      // Get resume recommendations
      const bestResume = resumes.reduce((best, current) => {
        const score = jobAnalysis.matchScores[current.id] || 0;
        return score > (jobAnalysis.matchScores[best?.id] || 0) ? current : best;
      }, null);
      setSelectedResume(bestResume);

      // Generate cover letter if needed
      if (job.requiresCoverLetter) {
        const newCoverLetter = await fetch('/api/cover-letters/generate', {
          method: 'POST',
          body: JSON.stringify({ 
            jobId: job.id,
            resumeId: bestResume?.id 
          })
        }).then(res => res.json());
        setSelectedCoverLetter(newCoverLetter);
      }

      setActiveStep(1);
    } catch (error) {
      console.error('Error analyzing job:', error);
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Document preparation
  const prepareDocuments = async () => {
    setLoading(true);
    try {
      if (selectedResume) {
        // Optimize resume for ATS
        await fetch('/api/resumes/optimize', {
          method: 'POST',
          body: JSON.stringify({ 
            resumeId: selectedResume.id,
            jobId: job.id 
          })
        });
      }

      if (selectedCoverLetter) {
        // Optimize cover letter
        await fetch('/api/cover-letters/optimize', {
          method: 'POST',
          body: JSON.stringify({ 
            coverLetterId: selectedCoverLetter.id,
            jobId: job.id 
          })
        });
      }

      setActiveStep(2);
    } catch (error) {
      console.error('Error preparing documents:', error);
    } finally {
      setLoading(false);
    }
  };

  // Step 3: Fill application form
  const generateResponses = async (question: string) => {
    try {
      const responses = await fetch('/api/applications/suggest-response', {
        method: 'POST',
        body: JSON.stringify({ 
          question,
          jobId: job.id,
          resumeId: selectedResume?.id 
        })
      }).then(res => res.json());

      setSuggestions({
        ...suggestions,
        [question]: responses
      });
    } catch (error) {
      console.error('Error generating responses:', error);
    }
  };

  // Step 4: Review and submit
  const reviewAndSubmit = async () => {
    setLoading(true);
    try {
      // Create application record
      const application: JobApplication = {
        jobId: job.id,
        resumeId: selectedResume?.id!,
        coverLetterId: selectedCoverLetter?.id,
        responses: formData,
        status: 'draft',
        appliedDate: new Date(),
        platform: job.platform,
        trackingData: {
          submissionUrl: job.applyUrl,
          formData: formData,
          documents: {
            resume: selectedResume?.id,
            coverLetter: selectedCoverLetter?.id
          }
        }
      };

      await onApply(application);
      setActiveStep(4);
    } catch (error) {
      console.error('Error submitting application:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Analyzing Job Requirements
            </Typography>
            <Button
              variant="contained"
              onClick={analyzeJob}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Start Analysis'}
            </Button>
          </Box>
        );

      case 1:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Document Preparation
            </Typography>
            {analysis && (
              <>
                <Alert severity="info" sx={{ mb: 2 }}>
                  Match Score: {analysis.overallScore}%
                </Alert>
                <Stack spacing={2}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      Selected Resume
                    </Typography>
                    <Typography>
                      {selectedResume?.content.substring(0, 100)}...
                    </Typography>
                    <Button
                      variant="outlined"
                      size="small"
                      sx={{ mt: 1 }}
                      onClick={() => {/* Open resume editor */}}
                    >
                      Edit Resume
                    </Button>
                  </Paper>
                  
                  {job.requiresCoverLetter && (
                    <Paper sx={{ p: 2 }}>
                      <Typography variant="subtitle1" gutterBottom>
                        Cover Letter
                      </Typography>
                      <Typography>
                        {selectedCoverLetter?.content.substring(0, 100)}...
                      </Typography>
                      <Button
                        variant="outlined"
                        size="small"
                        sx={{ mt: 1 }}
                        onClick={() => {/* Open cover letter editor */}}
                      >
                        Edit Cover Letter
                      </Button>
                    </Paper>
                  )}
                </Stack>
                <Button
                  variant="contained"
                  onClick={prepareDocuments}
                  sx={{ mt: 2 }}
                  disabled={loading}
                >
                  {loading ? <CircularProgress size={24} /> : 'Prepare Documents'}
                </Button>
              </>
            )}
          </Box>
        );

      case 2:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Application Form
            </Typography>
            <Stack spacing={2}>
              {job.questions?.map((question, index) => (
                <Paper key={index} sx={{ p: 2 }}>
                  <Typography gutterBottom>{question}</Typography>
                  <TextField
                    fullWidth
                    multiline
                    rows={3}
                    value={formData[question] || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      [question]: e.target.value
                    })}
                    sx={{ mb: 1 }}
                  />
                  <Button
                    size="small"
                    onClick={() => generateResponses(question)}
                  >
                    Suggest Responses
                  </Button>
                  {suggestions[question]?.map((suggestion, idx) => (
                    <Chip
                      key={idx}
                      label={suggestion}
                      onClick={() => setFormData({
                        ...formData,
                        [question]: suggestion
                      })}
                      sx={{ m: 0.5 }}
                    />
                  ))}
                </Paper>
              ))}
              <Button
                variant="contained"
                onClick={() => setActiveStep(3)}
                disabled={!Object.keys(formData).length}
              >
                Review Application
              </Button>
            </Stack>
          </Box>
        );

      case 3:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Review Application
            </Typography>
            <Alert severity="info" sx={{ mb: 2 }}>
              Please review your application carefully before submitting.
            </Alert>
            <Stack spacing={2}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Selected Documents
                </Typography>
                <Typography>Resume: {selectedResume?.version}</Typography>
                {selectedCoverLetter && (
                  <Typography>Cover Letter: {selectedCoverLetter.version}</Typography>
                )}
              </Paper>
              <Paper sx={{ p: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Application Responses
                </Typography>
                {Object.entries(formData).map(([question, answer], index) => (
                  <Box key={index} sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {question}
                    </Typography>
                    <Typography>{answer}</Typography>
                  </Box>
                ))}
              </Paper>
            </Stack>
            <Button
              variant="contained"
              onClick={reviewAndSubmit}
              sx={{ mt: 2 }}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Submit Application'}
            </Button>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      {renderStepContent(activeStep)}
    </Box>
  );
};
