import React, { useState, useEffect } from 'react';
import {
  Box,
  TextField,
  Button,
  Card,
  CardContent,
  Grid,
  Typography,
  Chip,
  IconButton,
  InputAdornment,
  Slider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Paper,
  Tooltip,
  Alert,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Step,
  Stepper,
  StepLabel
} from '@mui/material';
import {
  Search as SearchIcon,
  LocationOn as LocationIcon,
  WorkOutline as WorkTypeIcon,
  AttachMoney as SalaryIcon,
  Save as SaveIcon,
  FilterList as FilterIcon,
  Sort as SortIcon,
  OpenInNew as OpenInNewIcon,
  Description as ResumeIcon,
  Email as CoverLetterIcon,
  Send as ApplyIcon
} from '@mui/icons-material';
import { ResumeManager } from '../resume/ResumeManager';
import { CoverLetterGenerator } from '../cover-letter/CoverLetterGenerator';

interface JobSearchProps {
  onJobSelect?: (job: any) => void;
  onSaveJob?: (job: any) => void;
}

interface SearchFilters {
  title: string;
  location: string;
  radius: number;
  workType: 'all' | 'remote' | 'hybrid' | 'onsite';
  minSalary: number;
  maxSalary: number;
  datePosted: 'all' | 'today' | 'week' | 'month';
  sortBy: 'relevance' | 'date' | 'salary';
}

export const JobSearch: React.FC<JobSearchProps> = ({
  onJobSelect,
  onSaveJob
}) => {
  const [loading, setLoading] = useState(false);
  const [jobs, setJobs] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    title: '',
    location: '',
    radius: 25,
    workType: 'all',
    minSalary: 0,
    maxSalary: 500000,
    datePosted: 'all',
    sortBy: 'relevance'
  });

  const [selectedJob, setSelectedJob] = useState<any | null>(null);
  const [applyDialogOpen, setApplyDialogOpen] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [applicationData, setApplicationData] = useState<{
    resumeId?: string;
    coverLetterId?: string;
  }>({});

  const searchJobs = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/job-search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(filters),
      });

      if (!response.ok) throw new Error('Failed to fetch jobs');

      const data = await response.json();
      setJobs(data.jobs);
    } catch (err) {
      console.error('Failed to search jobs:', err);
      setError('Failed to search jobs. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (field: keyof SearchFilters, value: any) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const formatSalary = (salary: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(salary);
  };

  const handleApply = (job: any) => {
    setSelectedJob(job);
    setApplyDialogOpen(true);
  };

  const handleStepComplete = (type: 'resume' | 'coverLetter', id: string) => {
    setApplicationData(prev => ({
      ...prev,
      [type === 'resume' ? 'resumeId' : 'coverLetterId']: id
    }));
    setActiveStep(activeStep + 1);
  };

  const handleApplySubmit = async () => {
    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobId: selectedJob.id,
          resumeId: applicationData.resumeId,
          coverLetterId: applicationData.coverLetterId,
          jobData: selectedJob
        }),
      });

      if (!response.ok) throw new Error('Failed to submit application');

      // Close dialog and reset state
      setApplyDialogOpen(false);
      setSelectedJob(null);
      setActiveStep(0);
      setApplicationData({});
    } catch (err) {
      console.error('Failed to submit application:', err);
      setError('Failed to submit application. Please try again.');
    }
  };

  const renderApplyDialog = () => (
    <Dialog
      open={applyDialogOpen}
      onClose={() => setApplyDialogOpen(false)}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>
        Apply: {selectedJob?.title} at {selectedJob?.company}
      </DialogTitle>
      <DialogContent>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          <Step>
            <StepLabel>Customize Resume</StepLabel>
          </Step>
          <Step>
            <StepLabel>Generate Cover Letter</StepLabel>
          </Step>
          <Step>
            <StepLabel>Review & Submit</StepLabel>
          </Step>
        </Stepper>

        {activeStep === 0 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              Tailor Your Resume
            </Typography>
            <ResumeManager
              jobData={selectedJob}
              onComplete={(resumeId) => handleStepComplete('resume', resumeId)}
            />
          </Box>
        )}

        {activeStep === 1 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              Create Cover Letter
            </Typography>
            <CoverLetterGenerator
              jobData={selectedJob}
              resumeId={applicationData.resumeId}
              onComplete={(coverLetterId) => handleStepComplete('coverLetter', coverLetterId)}
            />
          </Box>
        )}

        {activeStep === 2 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              Review Application
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Job Details
                  </Typography>
                  <Typography>
                    {selectedJob?.title} at {selectedJob?.company}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {selectedJob?.location}
                  </Typography>
                </Paper>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Selected Resume
                  </Typography>
                  <Button
                    startIcon={<ResumeIcon />}
                    onClick={() => {/* Preview resume */}}
                  >
                    Preview Resume
                  </Button>
                </Paper>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Cover Letter
                  </Typography>
                  <Button
                    startIcon={<CoverLetterIcon />}
                    onClick={() => {/* Preview cover letter */}}
                  >
                    Preview Cover Letter
                  </Button>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button 
          onClick={() => setApplyDialogOpen(false)}
        >
          Cancel
        </Button>
        {activeStep > 0 && (
          <Button
            onClick={() => setActiveStep(activeStep - 1)}
          >
            Back
          </Button>
        )}
        {activeStep === 2 ? (
          <Button
            variant="contained"
            startIcon={<ApplyIcon />}
            onClick={handleApplySubmit}
          >
            Submit Application
          </Button>
        ) : (
          <Button
            variant="contained"
            onClick={() => setActiveStep(activeStep + 1)}
            disabled={
              (activeStep === 0 && !applicationData.resumeId) ||
              (activeStep === 1 && !applicationData.coverLetterId)
            }
          >
            Next
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );

  const renderJobCard = (job: any) => (
    <Card key={job.id} sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box>
            <Typography variant="h6" gutterBottom>
              {job.title}
            </Typography>
            <Typography color="text.secondary" gutterBottom>
              {job.company}
            </Typography>
          </Box>
          <Box>
            <Button
              variant="contained"
              startIcon={<ApplyIcon />}
              onClick={() => handleApply(job)}
              sx={{ mr: 1 }}
            >
              Apply
            </Button>
            <IconButton
              onClick={() => onSaveJob?.(job)}
              size="small"
              sx={{ mr: 1 }}
            >
              <SaveIcon />
            </IconButton>
            <IconButton
              href={job.url}
              target="_blank"
              rel="noopener noreferrer"
              size="small"
            >
              <OpenInNewIcon />
            </IconButton>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <LocationIcon fontSize="small" color="action" />
          <Typography variant="body2">
            {job.location}
          </Typography>
          {job.workType && (
            <>
              <WorkTypeIcon fontSize="small" color="action" sx={{ ml: 2 }} />
              <Typography variant="body2">
                {job.workType}
              </Typography>
            </>
          )}
        </Box>

        <Typography variant="body2" paragraph>
          {job.description}
        </Typography>

        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
          {job.skills?.map((skill: string, index: number) => (
            <Chip
              key={index}
              label={skill}
              size="small"
              variant="outlined"
            />
          ))}
        </Box>

        {job.salary && (
          <Typography variant="body2" color="text.secondary">
            Salary: {formatSalary(job.salary.min)} - {formatSalary(job.salary.max)}
          </Typography>
        )}

        <Typography variant="body2" color="text.secondary">
          Posted: {new Date(job.datePosted).toLocaleDateString()}
        </Typography>
      </CardContent>
    </Card>
  );

  return (
    <Box>
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Job Title / Keywords"
              value={filters.title}
              onChange={(e) => handleFilterChange('title', e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Location"
              value={filters.location}
              onChange={(e) => handleFilterChange('location', e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LocationIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>

          <Grid item xs={12} md={4}>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                variant="contained"
                onClick={searchJobs}
                disabled={loading}
                sx={{ flexGrow: 1 }}
              >
                Search Jobs
              </Button>
              <Button
                variant="outlined"
                onClick={() => setShowFilters(!showFilters)}
                startIcon={<FilterIcon />}
              >
                Filters
              </Button>
            </Box>
          </Grid>

          {showFilters && (
            <>
              <Grid item xs={12} md={3}>
                <FormControl fullWidth>
                  <InputLabel>Work Type</InputLabel>
                  <Select
                    value={filters.workType}
                    onChange={(e) => handleFilterChange('workType', e.target.value)}
                    label="Work Type"
                  >
                    <MenuItem value="all">All Types</MenuItem>
                    <MenuItem value="remote">Remote</MenuItem>
                    <MenuItem value="hybrid">Hybrid</MenuItem>
                    <MenuItem value="onsite">On-site</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} md={3}>
                <FormControl fullWidth>
                  <InputLabel>Date Posted</InputLabel>
                  <Select
                    value={filters.datePosted}
                    onChange={(e) => handleFilterChange('datePosted', e.target.value)}
                    label="Date Posted"
                  >
                    <MenuItem value="all">Any Time</MenuItem>
                    <MenuItem value="today">Past 24 hours</MenuItem>
                    <MenuItem value="week">Past Week</MenuItem>
                    <MenuItem value="month">Past Month</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} md={3}>
                <FormControl fullWidth>
                  <InputLabel>Sort By</InputLabel>
                  <Select
                    value={filters.sortBy}
                    onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                    label="Sort By"
                  >
                    <MenuItem value="relevance">Most Relevant</MenuItem>
                    <MenuItem value="date">Most Recent</MenuItem>
                    <MenuItem value="salary">Highest Salary</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} md={3}>
                <Typography gutterBottom>
                  Search Radius (miles)
                </Typography>
                <Slider
                  value={filters.radius}
                  onChange={(e, value) => handleFilterChange('radius', value)}
                  min={5}
                  max={100}
                  step={5}
                  marks={[
                    { value: 5, label: '5' },
                    { value: 25, label: '25' },
                    { value: 50, label: '50' },
                    { value: 100, label: '100' }
                  ]}
                />
              </Grid>

              <Grid item xs={12}>
                <Typography gutterBottom>
                  Salary Range
                </Typography>
                <Slider
                  value={[filters.minSalary, filters.maxSalary]}
                  onChange={(e, value) => {
                    const [min, max] = value as number[];
                    handleFilterChange('minSalary', min);
                    handleFilterChange('maxSalary', max);
                  }}
                  min={0}
                  max={500000}
                  step={10000}
                  marks={[
                    { value: 0, label: '$0' },
                    { value: 100000, label: '$100k' },
                    { value: 250000, label: '$250k' },
                    { value: 500000, label: '$500k' }
                  ]}
                />
              </Grid>
            </>
          )}
        </Grid>
      </Paper>

      {loading && <LinearProgress sx={{ mb: 2 }} />}

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Box>
        {jobs.map(renderJobCard)}
      </Box>

      {jobs.length === 0 && !loading && (
        <Typography color="text.secondary" align="center">
          No jobs found. Try adjusting your search criteria.
        </Typography>
      )}
      {renderApplyDialog()}
    </Box>
  );
};
