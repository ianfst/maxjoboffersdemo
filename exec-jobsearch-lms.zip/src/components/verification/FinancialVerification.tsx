import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Stepper,
  Step,
  StepLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import { PlayArrow as PlayIcon, Check as CheckIcon } from '@mui/icons-material';
import { useMutation, useQuery } from 'react-query';
import api from '../../api/config';

const steps = ['Watch Introduction', 'Express Interest', 'Team Contact'];

export const FinancialVerification = () => {
  const [videoDialogOpen, setVideoDialogOpen] = useState(false);
  const [activeStep, setActiveStep] = useState(0);

  const { data: status, refetch: refetchStatus } = useQuery(
    'verificationStatus',
    async () => {
      const response = await api.get('/api/verification/financial/status');
      return response.data;
    }
  );

  useEffect(() => {
    if (status?.watchedVideo) {
      setActiveStep(1);
      if (status?.verified) {
        setActiveStep(2);
      }
    }
  }, [status]);

  const videoCompleteMutation = useMutation(
    async () => {
      await api.post('/api/verification/financial/video-complete');
    },
    {
      onSuccess: () => {
        setActiveStep(1);
        refetchStatus();
      },
    }
  );

  const optInMutation = useMutation(
    async () => {
      await api.post('/api/verification/financial/opt-in', {
        interested: true,
      });
    },
    {
      onSuccess: () => {
        setActiveStep(2);
        refetchStatus();
      },
    }
  );

  const handleVideoComplete = () => {
    videoCompleteMutation.mutate();
    setVideoDialogOpen(false);
  };

  return (
    <Box>
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h5" gutterBottom>
            Platinum Membership Verification
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            Qualify for our Platinum tier by verifying your retirement assets.
            Members with $150,000+ in retirement assets receive all Platinum
            benefits at no additional cost.
          </Typography>

          <Stepper activeStep={activeStep} sx={{ my: 4 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>

          <Box sx={{ mt: 4 }}>
            {activeStep === 0 && (
              <Button
                variant="contained"
                startIcon={<PlayIcon />}
                onClick={() => setVideoDialogOpen(true)}
              >
                Watch Introduction Video
              </Button>
            )}

            {activeStep === 1 && (
              <Box>
                <Typography paragraph>
                  Now that you've watched our introduction, would you like to
                  proceed with verification?
                </Typography>
                <Button
                  variant="contained"
                  onClick={() => optInMutation.mutate()}
                >
                  Yes, I'm Interested
                </Button>
              </Box>
            )}

            {activeStep === 2 && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <CheckIcon color="success" />
                <Typography>
                  Thank you for your interest! Our team will contact you within
                  1 business day to schedule your consultation.
                </Typography>
              </Box>
            )}
          </Box>
        </CardContent>
      </Card>

      <Dialog
        open={videoDialogOpen}
        onClose={() => setVideoDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Platinum Membership Overview</DialogTitle>
        <DialogContent>
          <Box sx={{ position: 'relative', pb: '56.25%', height: 0 }}>
            <iframe
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
              }}
              src="https://player.vimeo.com/video/YOUR_VIDEO_ID"
              frameBorder="0"
              allow="autoplay; fullscreen"
              allowFullScreen
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setVideoDialogOpen(false)}>Close</Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleVideoComplete}
          >
            I've Watched the Video
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
