import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  TextField,
  Button,
  Chip,
  IconButton,
  Card,
  CardContent,
  CardActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Slider,
  Switch,
  FormControlLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  CircularProgress
} from '@mui/material';
import {
  Search as SearchIcon,
  BookmarkBorder as SaveIcon,
  BookmarkAdded as SavedIcon,
  LocationOn as LocationIcon,
  Work as WorkIcon,
  AttachMoney as SalaryIcon,
  Timer as TimeIcon
} from '@mui/icons-material';
import { debounce } from 'lodash';
import { Job, JobSearchFilters, SavedSearch } from '../../types/job';

interface JobSearchProps {
  userId: string;
}

export const JobSearch: React.FC<JobSearchProps> = ({ userId }) => {
  // State
  const [jobs, setJobs] = useState<Job[]>([]);
  const [filters, setFilters] = useState<JobSearchFilters>({
    sortBy: 'relevance'
  });
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isSaveSearchOpen, setIsSaveSearchOpen] = useState(false);
  const [searchName, setSearchName] = useState('');

  // Load saved searches
  useEffect(() => {
    loadSavedSearches();
  }, []);

  const loadSavedSearches = async () => {
    try {
      const response = await fetch(`/api/jobs/saved-searches/${userId}`);
      const data = await response.json();
      if (data.success) {
        setSavedSearches(data.savedSearches);
      }
    } catch (err) {
      setError('Failed to load saved searches');
    }
  };

  // Search jobs with debounce
  const searchJobs = useCallback(
    debounce(async (searchFilters: JobSearchFilters) => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await fetch('/api/jobs/search', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(searchFilters),
        });
        const data = await response.json();
        if (data.success) {
          setJobs(data.jobs);
        } else {
          setError(data.error);
        }
      } catch (err) {
        setError('Failed to search jobs');
      } finally {
        setIsLoading(false);
      }
    }, 500),
    []
  );

  // Handle filter changes
  const handleFilterChange = (key: keyof JobSearchFilters, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    searchJobs(newFilters);
  };

  // Save search
  const handleSaveSearch = async () => {
    try {
      const response = await fetch('/api/jobs/saved-searches', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          name: searchName,
          filters
        }),
      });
      const data = await response.json();
      if (data.success) {
        setSavedSearches([...savedSearches, data.savedSearch]);
        setSuccess('Search saved successfully!');
        setIsSaveSearchOpen(false);
      }
    } catch (err) {
      setError('Failed to save search');
    }
  };

  // Apply to job
  const handleApply = async (job: Job) => {
    try {
      const response = await fetch('/api/jobs/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jobId: job.id,
          userId
        }),
      });
      const data = await response.json();
      if (data.success) {
        setSuccess('Application submitted successfully!');
      }
    } catch (err) {
      setError('Failed to submit application');
    }
  };

  return (
    <Box sx={{ maxWidth: 1200, margin: '0 auto', p: 3 }}>
      {/* Search Filters */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Keywords"
              variant="outlined"
              value={filters.keywords || ''}
              onChange={(e) => handleFilterChange('keywords', e.target.value)}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Location"
              variant="outlined"
              value={filters.location || ''}
              onChange={(e) => handleFilterChange('location', e.target.value)}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <InputLabel>Job Type</InputLabel>
              <Select
                multiple
                value={filters.jobType || []}
                onChange={(e) => handleFilterChange('jobType', e.target.value)}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {selected.map((value) => (
                      <Chip key={value} label={value} />
                    ))}
                  </Box>
                )}
              >
                <MenuItem value="full-time">Full Time</MenuItem>
                <MenuItem value="part-time">Part Time</MenuItem>
                <MenuItem value="contract">Contract</MenuItem>
                <MenuItem value="internship">Internship</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* Advanced Filters */}
        <Grid container spacing={2} sx={{ mt: 2 }}>
          <Grid item xs={12} md={3}>
            <FormControlLabel
              control={
                <Switch
                  checked={filters.remote || false}
                  onChange={(e) => handleFilterChange('remote', e.target.checked)}
                />
              }
              label="Remote Only"
            />
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Posted Within</InputLabel>
              <Select
                value={filters.postedWithin || 'any'}
                onChange={(e) => handleFilterChange('postedWithin', e.target.value)}
              >
                <MenuItem value="any">Any Time</MenuItem>
                <MenuItem value="day">Past 24 Hours</MenuItem>
                <MenuItem value="week">Past Week</MenuItem>
                <MenuItem value="month">Past Month</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Sort By</InputLabel>
              <Select
                value={filters.sortBy || 'relevance'}
                onChange={(e) => handleFilterChange('sortBy', e.target.value)}
              >
                <MenuItem value="relevance">Relevance</MenuItem>
                <MenuItem value="date">Date</MenuItem>
                <MenuItem value="salary">Salary</MenuItem>
                <MenuItem value="matchScore">Match Score</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <Button
              variant="outlined"
              startIcon={<SaveIcon />}
              onClick={() => setIsSaveSearchOpen(true)}
            >
              Save Search
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Job Results */}
      <Grid container spacing={3}>
        {/* Job List */}
        <Grid item xs={12} md={6}>
          {isLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
              <CircularProgress />
            </Box>
          ) : (
            jobs.map((job) => (
              <Card key={job.id} sx={{ mb: 2, cursor: 'pointer' }} onClick={() => setSelectedJob(job)}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {job.title}
                  </Typography>
                  <Typography variant="subtitle1" color="text.secondary">
                    {job.company}
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 2, mt: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <LocationIcon sx={{ mr: 0.5 }} fontSize="small" />
                      {job.location}
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <WorkIcon sx={{ mr: 0.5 }} fontSize="small" />
                      {job.type}
                    </Box>
                    {job.salary && (
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <SalaryIcon sx={{ mr: 0.5 }} fontSize="small" />
                        {`${job.salary.currency}${job.salary.min}-${job.salary.max}`}
                      </Box>
                    )}
                  </Box>
                  {job.matchScore && (
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="primary">
                        {`${Math.round(job.matchScore * 100)}% Match`}
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </Grid>

        {/* Job Details */}
        <Grid item xs={12} md={6}>
          {selectedJob && (
            <Paper sx={{ p: 3, position: 'sticky', top: 20 }}>
              <Typography variant="h5" gutterBottom>
                {selectedJob.title}
              </Typography>
              <Typography variant="subtitle1" color="text.secondary" gutterBottom>
                {selectedJob.company}
              </Typography>
              
              <Box sx={{ my: 2 }}>
                <Typography variant="body1" paragraph>
                  {selectedJob.description}
                </Typography>
              </Box>

              <Typography variant="h6" gutterBottom>
                Requirements
              </Typography>
              <Box sx={{ mb: 2 }}>
                {selectedJob.requirements.map((req, index) => (
                  <Typography key={index} variant="body1" sx={{ mb: 1 }}>
                    • {req}
                  </Typography>
                ))}
              </Box>

              <Box sx={{ mt: 3 }}>
                <Button
                  variant="contained"
                  color="primary"
                  fullWidth
                  onClick={() => handleApply(selectedJob)}
                >
                  Apply Now
                </Button>
              </Box>
            </Paper>
          )}
        </Grid>
      </Grid>

      {/* Save Search Dialog */}
      <Dialog open={isSaveSearchOpen} onClose={() => setIsSaveSearchOpen(false)}>
        <DialogTitle>Save Search</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Search Name"
            fullWidth
            value={searchName}
            onChange={(e) => setSearchName(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsSaveSearchOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveSearch} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>

      {/* Notifications */}
      <Snackbar
        open={!!error}
        autoHideDuration={6000}
        onClose={() => setError(null)}
      >
        <Alert severity="error" onClose={() => setError(null)}>
          {error}
        </Alert>
      </Snackbar>

      <Snackbar
        open={!!success}
        autoHideDuration={6000}
        onClose={() => setSuccess(null)}
      >
        <Alert severity="success" onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      </Snackbar>
    </Box>
  );
};
