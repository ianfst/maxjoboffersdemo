import React, { useState } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  CircularProgress,
  Alert,
  Tooltip,
  Chip
} from '@mui/material';
import {
  Schedule as ScheduleIcon,
} from '@mui/icons-material';
import { BlogSeries, Blog } from '../../types/linkedin';
import { format, addDays, setHours, setMinutes, isBefore } from 'date-fns';

interface ScheduleManagerProps {
  series: BlogSeries;
  onSchedule: (blog: Blog, date: Date) => Promise<void>;
}

const DEFAULT_SCHEDULE = {
  monday: { time: '14:00', period: 'afternoon' },
  tuesday: { time: '09:00', period: 'morning' },
  wednesday: { time: '09:00', period: 'morning' },
  thursday: { time: '09:00', period: 'morning' }
};

export const ScheduleManager: React.FC<ScheduleManagerProps> = ({
  series,
  onSchedule
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedBlog, setSelectedBlog] = useState<Blog | null>(null);
  const [openDialog, setOpenDialog] = useState(false);

  const isSlotTaken = (date: Date): boolean => {
    return series.blogs.some(blog => 
      blog.scheduledFor && 
      format(new Date(blog.scheduledFor), 'yyyy-MM-dd HH:mm') === 
      format(date, 'yyyy-MM-dd HH:mm')
    );
  };

  const getNextAvailableSlot = (blog: Blog): Date => {
    const today = new Date();
    let nextDate = today;
    let daysToAdd = 0;

    while (true) {
      const dayName = format(nextDate, 'EEEE').toLowerCase();
      if (dayName in DEFAULT_SCHEDULE) {
        const slot = DEFAULT_SCHEDULE[dayName as keyof typeof DEFAULT_SCHEDULE];
        const [hours, minutes] = slot.time.split(':').map(Number);
        const slotTime = setMinutes(setHours(nextDate, hours), minutes);

        if (isBefore(today, slotTime) && !isSlotTaken(slotTime)) {
          return slotTime;
        }
      }
      daysToAdd++;
      nextDate = addDays(today, daysToAdd);
    }
  };

  const handleSchedule = async (blog: Blog) => {
    try {
      setLoading(true);
      setError(null);
      const nextSlot = getNextAvailableSlot(blog);
      await onSchedule(blog, nextSlot);
      setOpenDialog(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to schedule blog');
      console.error('Failed to schedule blog:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Schedule Blog Posts
      </Typography>
      <Typography variant="body2" paragraph>
        Posts are scheduled for Monday afternoon, and Tuesday through Thursday mornings
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Day</TableCell>
              <TableCell>Time</TableCell>
              <TableCell>Blog</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {series.blogs.map((blog) => {
              const scheduledDate = blog.scheduledFor 
                ? new Date(blog.scheduledFor)
                : null;

              return (
                <TableRow key={blog.id}>
                  <TableCell>
                    {scheduledDate
                      ? format(scheduledDate, 'EEEE')
                      : 'Not Scheduled'}
                  </TableCell>
                  <TableCell>
                    {scheduledDate
                      ? format(scheduledDate, 'h:mm a')
                      : '-'}
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {blog.title}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={blog.status}
                      color={blog.status === 'scheduled' ? 'primary' : 'default'}
                    />
                  </TableCell>
                  <TableCell>
                    <IconButton
                      size="small"
                      onClick={() => {
                        setSelectedBlog(blog);
                        setOpenDialog(true);
                      }}
                      disabled={blog.status === 'scheduled'}
                      title="Schedule Post"
                      aria-label="Schedule Post"
                    >
                      <ScheduleIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog
        open={openDialog}
        onClose={() => !loading && setOpenDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Schedule Blog Post</DialogTitle>
        <DialogContent>
          {selectedBlog && (
            <>
              <Typography variant="subtitle1" gutterBottom>
                {selectedBlog.title}
              </Typography>
              <Typography variant="body2" color="textSecondary" paragraph>
                This blog will be scheduled for the next available slot according to your posting schedule:
              </Typography>
              <Box sx={{ mt: 2 }}>
                <Typography variant="body2">
                  Next available slot: {selectedBlog && format(getNextAvailableSlot(selectedBlog), 'EEEE, MMMM d, yyyy h:mm a')}
                </Typography>
              </Box>
              {error && (
                <Typography color="error" sx={{ mt: 2 }}>
                  {error}
                </Typography>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={() => selectedBlog && handleSchedule(selectedBlog)}
            disabled={loading || !selectedBlog}
          >
            {loading ? 'Scheduling...' : 'Schedule Post'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
