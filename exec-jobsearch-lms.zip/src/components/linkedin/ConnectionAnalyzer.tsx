import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Button,
  CircularProgress,
  Divider,
  Avatar,
  AvatarGroup,
} from '@mui/material';
import {
  TrendingUp,
  Group,
  Business,
  Timeline,
  AccountTree,
  Star,
  WorkOutline,
  School,
  People,
  Assignment,
} from '@mui/icons-material';

interface ConnectionPath {
  strength: number;
  path: string[];
  commonFactors: string[];
  recommendedApproach: string;
}

interface CompanyInsight {
  name: string;
  connections: number;
  keyPeople: Array<{
    name: string;
    title: string;
    connectionStrength: number;
  }>;
  recentActivity: string[];
}

export const ConnectionAnalyzer: React.FC = () => {
  const [analyzing, setAnalyzing] = useState(false);

  const connectionPaths: ConnectionPath[] = [
    {
      strength: 85,
      path: ['John Smith (CTO)', 'Sarah Johnson (VP Engineering)', 'Target Executive'],
      commonFactors: ['Harvard Alumni', 'Tech Leadership Forum', 'Cloud Computing Background'],
      recommendedApproach: 'Leverage shared Harvard background and cloud expertise in initial outreach'
    },
    {
      strength: 72,
      path: ['Current Company Board Member', 'Target Executive'],
      commonFactors: ['Board Experience', 'Digital Transformation Projects'],
      recommendedApproach: 'Focus on board-level strategic initiatives and transformation experience'
    }
  ];

  const companyInsights: CompanyInsight[] = [
    {
      name: 'Target Company',
      connections: 47,
      keyPeople: [
        { name: 'Sarah Johnson', title: 'VP Engineering', connectionStrength: 85 },
        { name: 'Michael Chen', title: 'Chief Digital Officer', connectionStrength: 78 },
        { name: 'Lisa Brown', title: 'Head of Talent', connectionStrength: 92 }
      ],
      recentActivity: [
        'Major cloud migration initiative announced',
        'Expanding engineering team by 25%',
        'New digital transformation strategy'
      ]
    }
  ];

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <AccountTree sx={{ mr: 1 }} />
        Strategic Connection Analysis
      </Typography>

      <Grid container spacing={3}>
        {/* Connection Paths */}
        <Grid item xs={12} md={7}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Optimal Connection Paths
              </Typography>
              {connectionPaths.map((path, index) => (
                <Box key={index} sx={{ mb: 4 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <CircularProgress 
                      variant="determinate" 
                      value={path.strength} 
                      sx={{ mr: 2 }}
                    />
                    <Typography variant="subtitle1">
                      Path Strength: {path.strength}%
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    {path.path.map((step, idx) => (
                      <React.Fragment key={idx}>
                        <Chip 
                          label={step}
                          color="primary"
                          variant="outlined"
                        />
                        {idx < path.path.length - 1 && (
                          <Timeline sx={{ mx: 1 }} />
                        )}
                      </React.Fragment>
                    ))}
                  </Box>

                  <Typography variant="subtitle2" gutterBottom>
                    Common Factors
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                    {path.commonFactors.map((factor, idx) => (
                      <Chip
                        key={idx}
                        label={factor}
                        size="small"
                        icon={<Star sx={{ fontSize: 16 }} />}
                      />
                    ))}
                  </Box>

                  <Typography variant="body2" color="text.secondary">
                    <strong>Recommended Approach:</strong> {path.recommendedApproach}
                  </Typography>

                  {index < connectionPaths.length - 1 && (
                    <Divider sx={{ mt: 2 }} />
                  )}
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* Company Intelligence */}
        <Grid item xs={12} md={5}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Company Network Analysis
              </Typography>
              {companyInsights.map((company, index) => (
                <Box key={index}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Business sx={{ mr: 1 }} />
                    <Typography variant="subtitle1">
                      {company.name}
                    </Typography>
                    <Chip 
                      label={`${company.connections} connections`}
                      size="small"
                      sx={{ ml: 2 }}
                    />
                  </Box>

                  <Typography variant="subtitle2" gutterBottom>
                    Key Decision Makers
                  </Typography>
                  <List dense>
                    {company.keyPeople.map((person, idx) => (
                      <ListItem key={idx}>
                        <ListItemIcon>
                          <Avatar sx={{ width: 32, height: 32 }}>
                            {person.name.charAt(0)}
                          </Avatar>
                        </ListItemIcon>
                        <ListItemText 
                          primary={person.name}
                          secondary={person.title}
                        />
                        <Chip 
                          label={`${person.connectionStrength}% match`}
                          size="small"
                          color={person.connectionStrength > 80 ? 'success' : 'primary'}
                        />
                      </ListItem>
                    ))}
                  </List>

                  <Typography variant="subtitle2" gutterBottom sx={{ mt: 2 }}>
                    Recent Company Activity
                  </Typography>
                  <List dense>
                    {company.recentActivity.map((activity, idx) => (
                      <ListItem key={idx}>
                        <ListItemIcon>
                          <WorkOutline />
                        </ListItemIcon>
                        <ListItemText primary={activity} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              ))}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card sx={{ mt: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recommended Actions
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<School />}
                    onClick={() => {/* Handle alumni connection */}}
                  >
                    Connect via Harvard Alumni Network
                  </Button>
                </Grid>
                <Grid item xs={12}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<Group />}
                    onClick={() => {/* Handle group connection */}}
                  >
                    Join Tech Leadership Forum
                  </Button>
                </Grid>
                <Grid item xs={12}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<Assignment />}
                    onClick={() => {/* Handle content sharing */}}
                  >
                    Share Cloud Expertise Content
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* AI Insights */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                AI-Powered Connection Insights
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle2" gutterBottom>
                    Engagement Patterns
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemIcon>
                        <TrendingUp color="primary" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Most Active Times"
                        secondary="Weekday mornings, especially Tuesdays"
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon>
                        <Star color="primary" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Content Preferences"
                        secondary="Technical leadership, cloud strategy"
                      />
                    </ListItem>
                  </List>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle2" gutterBottom>
                    Network Expansion
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemIcon>
                        <People color="primary" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Shared Groups"
                        secondary="3 high-value groups identified"
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon>
                        <Business color="primary" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Company Presence"
                        secondary="Strong in cloud computing events"
                      />
                    </ListItem>
                  </List>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle2" gutterBottom>
                    Success Probability
                  </Typography>
                  <Box sx={{ textAlign: 'center', mt: 2 }}>
                    <CircularProgress 
                      variant="determinate" 
                      value={85} 
                      size={80}
                      sx={{ mb: 2 }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      85% connection success probability based on network analysis
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};
