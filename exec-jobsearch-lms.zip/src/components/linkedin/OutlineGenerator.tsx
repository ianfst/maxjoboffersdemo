import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Grid,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Help as HelpIcon,
  Check as CheckIcon,
  Clear as ClearIcon
} from '@mui/icons-material';
import { BlogOutline, LinkedInGroup } from '../../types/linkedin';

interface OutlineGeneratorProps {
  onGenerate: (topic: string, partCount: number) => Promise<BlogOutline>;
  onApprove: (outline: BlogOutline) => Promise<void>;
  outline: BlogOutline | null;
}

interface TopicSuggestion {
  title: string;
  description: string;
  suggestedParts: number;
}

const TOPIC_SUGGESTIONS: TopicSuggestion[] = [
  {
    title: 'Industry Trends and Analysis',
    description: 'Deep dive into current trends shaping your industry',
    suggestedParts: 4
  },
  {
    title: 'Professional Development Journey',
    description: 'Share your career growth and learning experiences',
    suggestedParts: 4
  },
  {
    title: 'Project Success Stories',
    description: 'Detailed breakdown of successful project implementations',
    suggestedParts: 8
  },
  {
    title: 'Leadership Lessons',
    description: 'Share insights and experiences in leadership roles',
    suggestedParts: 4
  }
];

const OutlineGenerator: React.FC<OutlineGeneratorProps> = ({
  onGenerate,
  onApprove,
  outline
}) => {
  const [topic, setTopic] = useState('');
  const [partCount, setPartCount] = useState(4);
  const [selectedTemplate, setSelectedTemplate] = useState<TopicSuggestion | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedOutline, setGeneratedOutline] = useState<BlogOutline | null>(null);
  const [editingTitle, setEditingTitle] = useState<string | null>(null);

  const handleTemplateSelect = (template: TopicSuggestion) => {
    setSelectedTemplate(template);
    setTopic(template.title);
    setPartCount(template.suggestedParts);
  };

  const handleGenerate = async () => {
    if (!topic || partCount < 4 || partCount > 16) {
      setError('Please enter a valid topic and number of parts (4-16)');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const outline = await onGenerate(topic, partCount);
      setGeneratedOutline(outline);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate outline');
      console.error('Failed to generate outline:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!generatedOutline) return;

    try {
      setLoading(true);
      setError(null);
      await onApprove(generatedOutline);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to approve outline');
      console.error('Failed to approve outline:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditTitle = (index: number, newTitle: string) => {
    if (!generatedOutline) return;

    const updatedBlogs = [...generatedOutline.blogTitles];
    updatedBlogs[index] = newTitle;

    setGeneratedOutline({
      ...generatedOutline,
      blogTitles: updatedBlogs
    });
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Create Blog Series Outline
        <Tooltip title="Generate a structured outline for your LinkedIn blog series">
          <IconButton size="small">
            <HelpIcon />
          </IconButton>
        </Tooltip>
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Topic Templates
              </Typography>
              <Grid container spacing={2}>
                {TOPIC_SUGGESTIONS.map((suggestion) => (
                  <Grid item xs={12} sm={6} key={suggestion.title}>
                    <Card
                      variant="outlined"
                      sx={{
                        cursor: 'pointer',
                        bgcolor: selectedTemplate?.title === suggestion.title
                          ? 'action.selected'
                          : 'background.paper'
                      }}
                      onClick={() => handleTemplateSelect(suggestion)}
                    >
                      <CardContent>
                        <Typography variant="subtitle1">
                          {suggestion.title}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          {suggestion.description}
                        </Typography>
                        <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                          Suggested parts: {suggestion.suggestedParts}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>

          <TextField
            fullWidth
            label="Blog Series Topic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            margin="normal"
            error={!!error && !topic}
            helperText={error && !topic ? 'Topic is required' : ''}
          />

          <FormControl fullWidth margin="normal">
            <InputLabel>Number of Parts</InputLabel>
            <Select
              value={partCount}
              onChange={(e) => setPartCount(Number(e.target.value))}
              label="Number of Parts"
            >
              <MenuItem value={4}>4 Parts</MenuItem>
              <MenuItem value={8}>8 Parts</MenuItem>
              <MenuItem value={12}>12 Parts</MenuItem>
              <MenuItem value={16}>16 Parts</MenuItem>
            </Select>
          </FormControl>

          <Button
            variant="contained"
            onClick={handleGenerate}
            disabled={loading || !topic || partCount < 4 || partCount > 16}
            startIcon={loading ? <CircularProgress size={20} /> : null}
            sx={{ mt: 2 }}
          >
            {loading ? 'Generating...' : 'Generate Outline'}
          </Button>

          {error && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {error}
            </Alert>
          )}
        </Grid>

        {generatedOutline && (
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Generated Outline
                </Typography>
                <Typography variant="subtitle1" gutterBottom>
                  {generatedOutline.seriesTitle}
                </Typography>
                <Typography color="textSecondary" paragraph>
                  {generatedOutline.description}
                </Typography>
                <Box sx={{ mb: 2 }}>
                  {generatedOutline.blogTitles.map((title, index) => (
                    <Typography key={index} variant="body2" sx={{ mb: 1 }}>
                      Part {index + 1}: {title}
                      <IconButton
                        edge="end"
                        onClick={() => setEditingTitle(title)}
                        title="Edit Title"
                      >
                        <EditIcon />
                      </IconButton>
                    </Typography>
                  ))}
                </Box>
                <Box>
                  {generatedOutline.suggestedHashtags.map((tag) => (
                    <Chip
                      key={tag}
                      label={tag}
                      size="small"
                      sx={{ mr: 1, mb: 1 }}
                    />
                  ))}
                </Box>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleApprove}
                  disabled={loading}
                  startIcon={loading ? <CircularProgress size={20} /> : <CheckIcon />}
                >
                  {loading ? 'Approving...' : 'Approve Outline'}
                </Button>
                <Button
                  variant="outlined"
                  onClick={() => {
                    setGeneratedOutline(null);
                    setError(null);
                  }}
                  startIcon={<ClearIcon />}
                >
                  Start Over
                </Button>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>

      <Dialog
        open={!!editingTitle}
        onClose={() => setEditingTitle(null)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Edit Blog Title</DialogTitle>
        <DialogContent>
          {editingTitle && generatedOutline && (
            <TextField
              fullWidth
              margin="normal"
              label="Blog Title"
              defaultValue={
                generatedOutline.blogTitles.find(t => t === editingTitle)
              }
              onChange={(e) => {
                const index = generatedOutline.blogTitles.findIndex(t => t === editingTitle);
                if (index !== -1) {
                  handleEditTitle(index, e.target.value);
                }
              }}
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditingTitle(null)}>Cancel</Button>
          <Button
            onClick={() => setEditingTitle(null)}
            variant="contained"
            color="primary"
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export { OutlineGenerator };
