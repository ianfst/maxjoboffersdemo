import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Chip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Check as CheckIcon,
  Warning as WarningIcon
} from '@mui/icons-material';
import { LinkedInGroup } from '../../types/linkedin';

export interface GroupSelectorProps {
  selectedGroups: LinkedInGroup[];
  onChange: (groups: LinkedInGroup[]) => void;
}

export const GroupSelector: React.FC<GroupSelectorProps> = ({
  selectedGroups,
  onChange
}) => {
  const [groups, setGroups] = useState<LinkedInGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [newGroup, setNewGroup] = useState<Partial<LinkedInGroup>>({});

  useEffect(() => {
    loadGroups();
  }, []);

  const loadGroups = () => {
    try {
      setLoading(true);
      setError(null);
      
      // In a real implementation, this would fetch from an API
      const storedGroups = localStorage.getItem('linkedinGroups');
      
      if (storedGroups) {
        try {
          const parsedGroups = JSON.parse(storedGroups);
          if (Array.isArray(parsedGroups)) {
            setGroups(parsedGroups);
          } else {
            setGroups([]);
            setError('Invalid group data format');
          }
        } catch (parseErr) {
          setGroups([]);
          setError('Failed to parse stored groups');
          console.error('Failed to parse stored groups:', parseErr);
        }
      } else {
        setGroups([]);
      }
    } catch (err) {
      setError('Failed to load groups. Please try again.');
      console.error('Failed to load groups:', err);
      setGroups([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddGroup = async () => {
    if (!newGroup.name?.trim() || !newGroup.url?.trim()) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const trimmedName = newGroup.name.trim();
      const trimmedUrl = newGroup.url.trim();

      // Check for duplicates
      if (groups.some(g => 
        g.name.toLowerCase() === trimmedName.toLowerCase() || 
        g.url.toLowerCase() === trimmedUrl.toLowerCase()
      )) {
        setError('Group already exists');
        return;
      }

      const group: LinkedInGroup = {
        id: Date.now().toString(),
        name: trimmedName,
        url: trimmedUrl,
        requiresApproval: newGroup.requiresApproval || false,
        lastPostStatus: 'pending',
        lastPostDate: undefined
      };

      const updatedGroups = [...groups, group];
      
      try {
        // In a real implementation, this would be an API call
        localStorage.setItem('linkedinGroups', JSON.stringify(updatedGroups));
        setGroups(updatedGroups);
        setNewGroup({});
        setOpenDialog(false);
      } catch (storageErr) {
        setError('Failed to save group. Please try again.');
        console.error('Failed to save group:', storageErr);
      }
    } catch (err) {
      setError('Failed to add group. Please try again.');
      console.error('Failed to add group:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveGroup = async (groupId: string) => {
    if (!groupId) {
      setError('Invalid group ID');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const groupToRemove = groups.find(g => g.id === groupId);
      if (!groupToRemove) {
        setError('Group not found');
        return;
      }

      const updatedGroups = groups.filter(g => g.id !== groupId);
      
      try {
        // In a real implementation, this would be an API call
        localStorage.setItem('linkedinGroups', JSON.stringify(updatedGroups));
        setGroups(updatedGroups);
        onChange(selectedGroups.filter(g => g.id !== groupId));
      } catch (storageErr) {
        setError('Failed to save changes. Please try again.');
        console.error('Failed to save group removal:', storageErr);
      }
    } catch (err) {
      setError('Failed to remove group. Please try again.');
      console.error('Failed to remove group:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleGroup = (group: LinkedInGroup) => {
    const isSelected = selectedGroups.some(g => g.id === group.id);
    let updatedGroups: LinkedInGroup[];

    if (isSelected) {
      updatedGroups = selectedGroups.filter(g => g.id !== group.id);
    } else {
      if (selectedGroups.length >= 3) {
        setError('You can only select up to 3 groups');
        return;
      }
      updatedGroups = [...selectedGroups, group];
    }

    onChange(updatedGroups);
  };

  return (
    <Box>
      <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6">
          LinkedIn Groups
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenDialog(true)}
          disabled={loading}
          aria-label="Add Group"
        >
          Add Group
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
          <CircularProgress role="progressbar" />
        </Box>
      )}
      <List>
        {groups.map((group) => {
          const isSelected = selectedGroups.some(g => g.id === group.id);

          return (
            <ListItem
              key={group.id}
              button
              onClick={() => !group.requiresApproval && handleToggleGroup(group)}
              selected={isSelected}
              aria-disabled={group.requiresApproval}
              component="div"
              role="button"
            >
              <ListItemText
                primary={group.name}
                secondary={
                  <Typography variant="body2" component="div">
                    <span>{group.lastPostStatus}</span>
                    {group.requiresApproval && (
                      <Chip
                        size="small"
                        icon={<WarningIcon />}
                        label="Requires Approval"
                        color="warning"
                        sx={{ ml: 1 }}
                      />
                    )}
                  </Typography>
                }
              />
              <ListItemSecondaryAction>
                {isSelected ? (
                  <IconButton color="primary" edge="end" aria-label="selected">
                    <CheckIcon />
                  </IconButton>
                ) : (
                  <IconButton
                    edge="end"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveGroup(group.id);
                    }}
                    title={`Delete ${group.name}`}
                  >
                    <DeleteIcon />
                  </IconButton>
                )}
              </ListItemSecondaryAction>
            </ListItem>
          );
        })}
      </List>

      <Dialog 
        open={openDialog} 
        onClose={() => setOpenDialog(false)}
        aria-labelledby="add-group-dialog-title"
        role="dialog"
        data-testid="add-group-dialog"
      >
        <DialogTitle id="add-group-dialog-title">Add LinkedIn Group</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1 }}>
            <TextField
              autoFocus
              margin="dense"
              id="group-name"
              name="group-name"
              label="Group Name"
              fullWidth
              value={newGroup.name || ''}
              onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
              aria-label="Group Name"
              inputProps={{
                'data-testid': 'group-name-input'
              }}
            />
            <TextField
              margin="dense"
              id="group-url"
              name="group-url"
              label="Group URL"
              fullWidth
              value={newGroup.url || ''}
              onChange={(e) => setNewGroup({ ...newGroup, url: e.target.value })}
              aria-label="Group URL"
              inputProps={{
                'data-testid': 'group-url-input'
              }}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={() => setOpenDialog(false)}
            data-testid="dialog-cancel-button"
          >
            Cancel
          </Button>
          <Button
            onClick={handleAddGroup}
            disabled={!newGroup.name || !newGroup.url}
            data-testid="dialog-add-button"
          >
            Add Group
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
