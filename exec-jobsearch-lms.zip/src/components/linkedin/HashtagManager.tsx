import React, { useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Chip,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Tooltip,
  Divider
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  Category as CategoryIcon
} from '@mui/icons-material';

interface HashtagManagerProps {
  hashtags: string[];
  onChange: (hashtags: string[]) => void;
}

const SUGGESTED_CATEGORIES = {
  Career: ['careeradvice', 'jobsearch', 'leadership', 'networking'],
  Technology: ['technology', 'innovation', 'digital', 'tech'],
  Business: ['business', 'entrepreneurship', 'marketing', 'strategy']
};

const DEFAULT_SUGGESTIONS = [
  'careeradvice',
  'leadership',
  'technology',
  'business',
  'innovation'
];

export const HashtagManager: React.FC<HashtagManagerProps> = ({
  hashtags,
  onChange
}) => {
  const [newHashtag, setNewHashtag] = useState('');
  const [openCategories, setOpenCategories] = useState(false);
  const [suggestions] = useState(DEFAULT_SUGGESTIONS);

  const formatHashtag = (tag: string): string => {
    return tag
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '')
      .trim();
  };

  const handleAddHashtag = (tag: string) => {
    const formattedTag = formatHashtag(tag);
    if (formattedTag && !hashtags.includes(formattedTag)) {
      onChange([...hashtags, formattedTag]);
    }
    setNewHashtag('');
  };

  const handleRemoveHashtag = (tag: string) => {
    const tagWithoutHash = tag.replace('#', '');
    onChange(hashtags.filter(t => t !== tagWithoutHash));
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && newHashtag) {
      handleAddHashtag(newHashtag);
    }
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Hashtags
      </Typography>

      <Box sx={{ mb: 2 }}>
        <TextField
          size="small"
          placeholder="Add a hashtag"
          value={newHashtag}
          onChange={(e) => setNewHashtag(e.target.value)}
          onKeyPress={handleKeyPress}
          InputProps={{
            startAdornment: <Typography color="textSecondary">#</Typography>,
            endAdornment: (
              <IconButton
                size="small"
                onClick={() => newHashtag && handleAddHashtag(newHashtag)}
                aria-label="Add hashtag"
              >
                <AddIcon />
              </IconButton>
            )
          }}
        />
      </Box>

      <Box sx={{ mb: 2 }}>
        {hashtags.map((tag) => (
          <Chip
            key={tag}
            label={`#${tag}`}
            onDelete={() => handleRemoveHashtag(`#${tag}`)}
            deleteIcon={<DeleteIcon />}
            aria-label="Remove"
            sx={{ mr: 1, mb: 1 }}
          />
        ))}
      </Box>

      <Divider sx={{ my: 2 }} />

      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Typography variant="subtitle2">
            Suggested Hashtags
          </Typography>
          <Box sx={{ ml: 'auto' }}>
            <Button
              size="small"
              startIcon={<CategoryIcon />}
              onClick={() => setOpenCategories(true)}
            >
              Browse Categories
            </Button>
            <Tooltip title="Refresh Suggestions">
              <IconButton size="small">
                <RefreshIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        {suggestions.map((tag) => (
          <Chip
            key={tag}
            label={`#${tag}`}
            onClick={() => handleAddHashtag(tag)}
            sx={{ mr: 1, mb: 1 }}
          />
        ))}
      </Box>

      <Dialog
        open={openCategories}
        onClose={() => setOpenCategories(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Browse Hashtag Categories</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            {Object.entries(SUGGESTED_CATEGORIES).map(([category, tags]) => (
              <Grid item xs={12} key={category}>
                <Typography variant="subtitle1" gutterBottom>
                  {category}
                </Typography>
                <Box sx={{ mb: 2 }}>
                  {tags.map((tag) => (
                    <Chip
                      key={tag}
                      label={`#${tag}`}
                      onClick={() => {
                        handleAddHashtag(tag);
                        setOpenCategories(false);
                      }}
                      sx={{ mr: 1, mb: 1 }}
                    />
                  ))}
                </Box>
              </Grid>
            ))}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenCategories(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
