import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Stepper,
  Step,
  StepLabel,
} from '@mui/material';
import {
  Business,
  Person,
  Group,
  Message,
  Edit,
  Delete,
  PlayArrow,
  Pause,
  Timeline,
} from '@mui/icons-material';
import { NetworkingCampaign, NetworkingStrategy, LinkedInConnection } from '../../types/linkedin';

export const CampaignManager: React.FC = () => {
  const [openNewCampaign, setOpenNewCampaign] = useState(false);
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    'Company Selection',
    'Connection Strategy',
    'Message Templates',
    'Timeline Setup',
  ];

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Target Company Information
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Company Name"
                  variant="outlined"
                  helperText="Enter the name of your target company"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Industry"
                  variant="outlined"
                  select
                >
                  <MenuItem value="tech">Technology</MenuItem>
                  <MenuItem value="finance">Finance</MenuItem>
                  <MenuItem value="healthcare">Healthcare</MenuItem>
                  <MenuItem value="manufacturing">Manufacturing</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Target Roles"
                  variant="outlined"
                  multiline
                  rows={3}
                  helperText="Enter target roles, one per line"
                />
              </Grid>
            </Grid>
          </Box>
        );

      case 1:
        return (
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Connection Strategy
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      First-Degree Connections
                    </Typography>
                    <TextField
                      fullWidth
                      label="Message Template"
                      variant="outlined"
                      multiline
                      rows={3}
                      helperText="Message for existing connections"
                    />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Second-Degree Connections
                    </Typography>
                    <TextField
                      fullWidth
                      label="Connection Request"
                      variant="outlined"
                      multiline
                      rows={3}
                      helperText="Connection request message"
                    />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Talent Acquisition Focus
                    </Typography>
                    <FormControl fullWidth>
                      <InputLabel>Approach Strategy</InputLabel>
                      <Select
                        label="Approach Strategy"
                        value="direct"
                      >
                        <MenuItem value="direct">Direct Outreach</MenuItem>
                        <MenuItem value="warm">Warm Introduction</MenuItem>
                        <MenuItem value="group">Group Connection</MenuItem>
                      </Select>
                    </FormControl>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Box>
        );

      case 2:
        return (
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Message Templates
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Follow-up Sequence
                    </Typography>
                    <List>
                      <ListItem>
                        <ListItemText
                          primary="Initial Follow-up"
                          secondary="Sent 3 days after connection"
                        />
                        <ListItemSecondaryAction>
                          <IconButton edge="end">
                            <Edit />
                          </IconButton>
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText
                          primary="Value Proposition"
                          secondary="Sent 7 days after connection"
                        />
                        <ListItemSecondaryAction>
                          <IconButton edge="end">
                            <Edit />
                          </IconButton>
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText
                          primary="Meeting Request"
                          secondary="Sent 14 days after connection"
                        />
                        <ListItemSecondaryAction>
                          <IconButton edge="end">
                            <Edit />
                          </IconButton>
                        </ListItemSecondaryAction>
                      </ListItem>
                    </List>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Box>
        );

      case 3:
        return (
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Campaign Timeline
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Connection Pacing
                    </Typography>
                    <TextField
                      fullWidth
                      label="Daily Connection Limit"
                      type="number"
                      variant="outlined"
                      defaultValue={15}
                      helperText="Recommended: 15-20 connections per day"
                    />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Group Engagement
                    </Typography>
                    <FormControl fullWidth sx={{ mb: 2 }}>
                      <InputLabel>Post Frequency</InputLabel>
                      <Select
                        label="Post Frequency"
                        value="weekly"
                      >
                        <MenuItem value="daily">Daily</MenuItem>
                        <MenuItem value="weekly">Weekly</MenuItem>
                        <MenuItem value="biweekly">Bi-weekly</MenuItem>
                      </Select>
                    </FormControl>
                    <FormControl fullWidth>
                      <InputLabel>Engagement Type</InputLabel>
                      <Select
                        label="Engagement Type"
                        value="mixed"
                      >
                        <MenuItem value="likes">Likes Only</MenuItem>
                        <MenuItem value="comments">Comments Only</MenuItem>
                        <MenuItem value="mixed">Mixed Engagement</MenuItem>
                      </Select>
                    </FormControl>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Box>
      <Button
        variant="contained"
        startIcon={<Business />}
        onClick={() => setOpenNewCampaign(true)}
      >
        New Campaign
      </Button>

      <Dialog
        open={openNewCampaign}
        onClose={() => setOpenNewCampaign(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Create New Networking Campaign
        </DialogTitle>
        <DialogContent>
          <Stepper activeStep={activeStep} sx={{ py: 3 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          {renderStepContent(activeStep)}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenNewCampaign(false)}>
            Cancel
          </Button>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
          >
            Back
          </Button>
          {activeStep === steps.length - 1 ? (
            <Button
              variant="contained"
              onClick={() => {
                // Handle campaign creation
                setOpenNewCampaign(false);
                setActiveStep(0);
              }}
            >
              Launch Campaign
            </Button>
          ) : (
            <Button
              variant="contained"
              onClick={handleNext}
            >
              Next
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* Active Campaigns List */}
      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" gutterBottom>
          Active Campaigns
        </Typography>
        <Grid container spacing={3}>
          {/* Campaign cards would be mapped here */}
        </Grid>
      </Box>
    </Box>
  );
};
