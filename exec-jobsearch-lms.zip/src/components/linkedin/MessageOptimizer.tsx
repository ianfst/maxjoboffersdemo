import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Rating,
  Slider,
  Tooltip,
} from '@mui/material';
import {
  Psychology,
  Speed,
  TrendingUp,
  CheckCircle,
  Warning,
} from '@mui/icons-material';

interface MessageMetrics {
  personalizedScore: number;
  executiveToneScore: number;
  clarityScore: number;
  callToActionScore: number;
  overallScore: number;
}

interface OptimizationSuggestion {
  type: 'improvement' | 'warning' | 'success';
  message: string;
  example?: string;
}

interface MessageOptimizerProps {
  industry?: string;
}

export const MessageOptimizer: React.FC<MessageOptimizerProps> = ({ industry }) => {
  const [message, setMessage] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [metrics, setMetrics] = useState<MessageMetrics>({
    personalizedScore: 85,
    executiveToneScore: 78,
    clarityScore: 92,
    callToActionScore: 88,
    overallScore: 85,
  });

  const suggestions: OptimizationSuggestion[] = [
    {
      type: 'improvement',
      message: 'Add more specific industry insights',
      example: 'I noticed your recent article on cloud transformation strategies...'
    },
    {
      type: 'success',
      message: 'Strong executive tone and authority',
    },
    {
      type: 'warning',
      message: 'Consider a more specific call to action',
      example: 'Would you be open to a 15-minute call this Thursday?'
    },
  ];

  const highPerformingPhrases = [
    'strategic growth initiatives',
    'digital transformation leadership',
    'proven track record',
    'industry-leading expertise',
  ];

  const analyzeMessage = () => {
    setAnalyzing(true);
    // Simulate API call
    setTimeout(() => {
      setAnalyzing(false);
    }, 1500);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <Psychology sx={{ mr: 1 }} />
        Executive Message Optimizer
      </Typography>

      <Grid container spacing={3}>
        {/* Message Input */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Compose Your Message
              </Typography>
              <TextField
                fullWidth
                multiline
                rows={6}
                variant="outlined"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your networking message..."
                sx={{ mb: 2 }}
              />
              <Button
                variant="contained"
                onClick={analyzeMessage}
                disabled={analyzing}
                startIcon={analyzing ? <CircularProgress size={20} /> : <Speed />}
              >
                {analyzing ? 'Analyzing...' : 'Analyze & Optimize'}
              </Button>
            </CardContent>
          </Card>

          {/* High-Performing Phrases */}
          <Card sx={{ mt: 2 }}>
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>
                High-Performing Phrases
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {highPerformingPhrases.map((phrase, index) => (
                  <Chip
                    key={index}
                    label={phrase}
                    onClick={() => {
                      setMessage((prev) => prev + ' ' + phrase);
                    }}
                    sx={{ cursor: 'pointer' }}
                  />
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Analysis Results */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Message Analysis
              </Typography>
              
              {/* Scores */}
              <Box sx={{ mb: 4 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Personalization Score
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Slider
                    value={metrics.personalizedScore}
                    disabled
                    sx={{ mr: 2 }}
                  />
                  <Typography variant="body2">
                    {metrics.personalizedScore}%
                  </Typography>
                </Box>

                <Typography variant="subtitle2" gutterBottom>
                  Executive Tone
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Slider
                    value={metrics.executiveToneScore}
                    disabled
                    sx={{ mr: 2 }}
                  />
                  <Typography variant="body2">
                    {metrics.executiveToneScore}%
                  </Typography>
                </Box>

                <Typography variant="subtitle2" gutterBottom>
                  Clarity & Conciseness
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Slider
                    value={metrics.clarityScore}
                    disabled
                    sx={{ mr: 2 }}
                  />
                  <Typography variant="body2">
                    {metrics.clarityScore}%
                  </Typography>
                </Box>

                <Typography variant="subtitle2" gutterBottom>
                  Call to Action Strength
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Slider
                    value={metrics.callToActionScore}
                    disabled
                    sx={{ mr: 2 }}
                  />
                  <Typography variant="body2">
                    {metrics.callToActionScore}%
                  </Typography>
                </Box>
              </Box>

              {/* Suggestions */}
              <Typography variant="subtitle1" gutterBottom>
                Optimization Suggestions
              </Typography>
              <List>
                {suggestions.map((suggestion, index) => (
                  <ListItem key={index}>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          {suggestion.type === 'improvement' && <TrendingUp color="primary" sx={{ mr: 1 }} />}
                          {suggestion.type === 'warning' && <Warning color="warning" sx={{ mr: 1 }} />}
                          {suggestion.type === 'success' && <CheckCircle color="success" sx={{ mr: 1 }} />}
                          {suggestion.message}
                        </Box>
                      }
                      secondary={suggestion.example}
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};
