import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BlogEditor } from '../BlogEditor';
import { BlogSeries, Blog } from '../../../types/linkedin';
import '@testing-library/jest-dom';

// Mock child components
jest.mock('../HashtagManager', () => ({
  HashtagManager: ({ hashtags, onChange }: { hashtags: string[], onChange: (tags: string[]) => void }) => (
    <div data-testid="mock-hashtag-manager">
      {hashtags.map((tag: string) => (
        <span key={tag}>{tag}</span>
      ))}
      <button onClick={() => onChange(['test', 'blog'])}>Update Tags</button>
    </div>
  )
}));

jest.mock('../CanvaIntegration', () => ({
  CanvaIntegration: ({ open, onClose, blogTitle, onGenerate }: { open: boolean, onClose: () => void, blogTitle: string, onGenerate: (url: string) => void }) => (
    open ? (
      <div data-testid="mock-canva-integration">
        <div>Blog Title: {blogTitle}</div>
        <button onClick={() => onGenerate('test-url.jpg')}>Generate</button>
        <button onClick={onClose}>Close</button>
      </div>
    ) : null
  )
}));

const mockSeries: BlogSeries = {
  id: '1',
  title: 'Test Series',
  blogs: [{
    id: '1',
    title: 'Test Blog',
    content: '',
    hashtags: ['test'],
    wordCount: 0,
    status: 'draft'
  }]
};

describe('BlogEditor', () => {
  const mockOnGenerate = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders blog editor with initial content', () => {
    render(<BlogEditor series={mockSeries} onGenerate={mockOnGenerate} />);

    expect(screen.getByText('Blog Series: Test Series')).toBeInTheDocument();
    expect(screen.getByText('Test Blog')).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: 'Blog content editor' })).toBeInTheDocument();
  });

  it('updates word count when content changes', () => {
    render(<BlogEditor series={mockSeries} onGenerate={mockOnGenerate} />);

    const editor = screen.getByRole('textbox', { name: 'Blog content editor' });
    fireEvent.change(editor, { target: { value: 'This is a test blog post.' } });

    expect(screen.getByText('5 words (175-250 required)')).toBeInTheDocument();
  });

  it('shows error when word count is invalid', () => {
    render(<BlogEditor series={mockSeries} onGenerate={mockOnGenerate} />);

    const editor = screen.getByRole('textbox', { name: 'Blog content editor' });
    fireEvent.change(editor, { target: { value: 'Too short.' } });

    expect(screen.getByText('2 words (175-250 required)')).toBeInTheDocument();
    expect(screen.getByText('Generate & Save')).toBeDisabled();
  });

  it('updates hashtags when HashtagManager changes', () => {
    render(<BlogEditor series={mockSeries} onGenerate={mockOnGenerate} />);

    const updateButton = screen.getByText('Update Tags');
    fireEvent.click(updateButton);

    expect(screen.getByText('test')).toBeInTheDocument();
    expect(screen.getByText('blog')).toBeInTheDocument();
  });

  it('opens and closes Canva integration', () => {
    render(<BlogEditor series={mockSeries} onGenerate={mockOnGenerate} />);

    const imageButton = screen.getByLabelText('Generate Infographic');
    fireEvent.click(imageButton);

    expect(screen.getByTestId('mock-canva-integration')).toBeInTheDocument();
    expect(screen.getByText('Blog Title: Test Blog')).toBeInTheDocument();

    const closeButton = screen.getByText('Close');
    fireEvent.click(closeButton);

    expect(screen.queryByTestId('mock-canva-integration')).not.toBeInTheDocument();
  });

  it('updates blog with generated infographic', () => {
    render(<BlogEditor series={mockSeries} onGenerate={mockOnGenerate} />);

    // Open Canva integration
    const imageButton = screen.getByLabelText('Generate Infographic');
    fireEvent.click(imageButton);

    // Generate infographic
    const generateButton = screen.getByText('Generate');
    fireEvent.click(generateButton);

    // Open preview to check infographic
    const previewButton = screen.getByTestId('preview-button');
    fireEvent.click(previewButton);

    expect(screen.getByAltText('Blog infographic')).toHaveAttribute('src', 'test-url.jpg');
  });
});
