import React from 'react';
import { render as rtlRender } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import { theme } from '../../../theme';

// Custom render function that includes providers
function render(ui: React.ReactElement, options = {}) {
  return rtlRender(
    <ThemeProvider theme={theme}>
      {ui}
    </ThemeProvider>,
    options
  );
}

// Common mock data
export const mockBlogSeries = {
  id: 'test-series-1',
  title: 'Test Series',
  description: 'Test Description',
  partCount: 4,
  status: 'approved',
  blogs: [
    {
      id: 'test-blog-1',
      seriesId: 'test-series-1',
      partNumber: 1,
      title: 'Blog 1',
      content: 'Test content',
      wordCount: 200,
      status: 'draft',
      postedTo: [],
      hashtags: ['test'],
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ],
  targetGroups: [],
  hashtags: ['test'],
  createdAt: new Date(),
  updatedAt: new Date()
};

export const mockLinkedInGroups = [
  {
    id: 'group-1',
    name: 'Test Group 1',
    url: 'https://linkedin.com/groups/1',
    requiresApproval: false,
    lastPostStatus: 'success'
  },
  {
    id: 'group-2',
    name: 'Test Group 2',
    url: 'https://linkedin.com/groups/2',
    requiresApproval: true,
    lastPostStatus: 'pending'
  }
];

export const mockHashtags = ['test', 'blog', 'linkedin'];

export const mockCanvaTemplates = [
  {
    id: 'template-1',
    name: 'Professional Blog Header',
    dimensions: '1200 x 628',
    category: 'blog'
  },
  {
    id: 'template-2',
    name: 'Modern Article Cover',
    dimensions: '1200 x 628',
    category: 'article'
  }
];

// Mock functions
export const mockOnChange = jest.fn();
export const mockOnSave = jest.fn();
export const mockOnGenerate = jest.fn();
export const mockOnClose = jest.fn();

// Re-export everything
export * from '@testing-library/react';
export { render };
