import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ScheduleManager } from '../ScheduleManager';
import { BlogSeries, Blog } from '../../../types/linkedin';
import { format, addDays } from 'date-fns';

describe('ScheduleManager', () => {
  const mockSeries: BlogSeries = {
    id: '123',
    title: 'Test Series',
    description: 'Test Description',
    partCount: 4,
    status: 'approved',
    blogs: [
      {
        id: '1',
        seriesId: '123',
        partNumber: 1,
        title: 'Blog 1',
        content: 'Test content',
        wordCount: 200,
        status: 'approved',
        postedTo: [],
        hashtags: ['test'],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '2',
        seriesId: '123',
        partNumber: 2,
        title: 'Blog 2',
        content: 'Test content',
        wordCount: 200,
        status: 'approved',
        scheduledFor: addDays(new Date(), 1),
        postedTo: [],
        hashtags: ['test'],
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ],
    targetGroups: [],
    hashtags: ['test'],
    createdAt: new Date(),
    updatedAt: new Date()
  };

  const mockOnSchedule = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  const renderComponent = () => {
    return render(
      <ScheduleManager
        series={mockSeries}
        onSchedule={mockOnSchedule}
      />
    );
  };

  it('renders schedule table with blogs', () => {
    renderComponent();
    expect(screen.getByText('Blog 1')).toBeInTheDocument();
    expect(screen.getByText('Blog 2')).toBeInTheDocument();
  });

  it('displays correct scheduling status', () => {
    renderComponent();
    
    // Unscheduled blog
    expect(screen.getByText('Not Scheduled')).toBeInTheDocument();
    
    // Scheduled blog
    const scheduledDate = format(addDays(new Date(), 1), 'EEEE');
    expect(screen.getByText(scheduledDate)).toBeInTheDocument();
  });

  it('opens scheduling dialog', async () => {
    renderComponent();

    const scheduleButton = screen.getAllByTitle('Schedule Post')[0];
    fireEvent.click(scheduleButton);

    await waitFor(() => {
      expect(screen.getByText('Schedule Blog Post')).toBeInTheDocument();
    });
  });

  it('schedules a blog post', async () => {
    renderComponent();

    const scheduleButton = screen.getAllByTitle('Schedule Post')[0];
    fireEvent.click(scheduleButton);

    const confirmButton = screen.getByText('Schedule Post');
    fireEvent.click(confirmButton);

    await waitFor(() => {
      expect(mockOnSchedule).toHaveBeenCalledWith(
        expect.any(Object),
        expect.any(Date)
      );
    });
  });

  it('prevents scheduling conflicts', async () => {
    renderComponent();

    // Try to schedule for the same slot as Blog 2
    const scheduleButton = screen.getAllByTitle('Schedule Post')[0];
    fireEvent.click(scheduleButton);

    const nextAvailableSlot = screen.getByText(/Next available slot/);
    const conflictDate = format(addDays(new Date(), 1), 'MMMM d, yyyy');
    
    expect(nextAvailableSlot.textContent).not.toContain(conflictDate);
  });

  it('handles scheduling errors', async () => {
    mockOnSchedule.mockRejectedValue(new Error('Scheduling failed'));
    renderComponent();

    const scheduleButton = screen.getAllByTitle('Schedule Post')[0];
    fireEvent.click(scheduleButton);

    const confirmButton = screen.getByText('Schedule Post');
    fireEvent.click(confirmButton);

    await waitFor(() => {
      expect(screen.getByText(/Failed to schedule blog/i)).toBeInTheDocument();
    });
  });

  it('respects posting schedule', async () => {
    renderComponent();

    const scheduleButton = screen.getAllByTitle('Schedule Post')[0];
    fireEvent.click(scheduleButton);

    const nextSlotText = screen.getByText(/Next available slot/);
    
    // Should be scheduled for a valid day (Mon afternoon or Tue-Thu morning)
    const slotDate = nextSlotText.textContent || '';
    const isValidDay = /Monday|Tuesday|Wednesday|Thursday/.test(slotDate);
    expect(isValidDay).toBe(true);

    // Should be scheduled for correct time
    const isValidTime = /2:00 PM|9:00 AM/.test(slotDate);
    expect(isValidTime).toBe(true);
  });

  it('disables scheduling for already scheduled posts', () => {
    renderComponent();

    const scheduleButtons = screen.getAllByTitle('Schedule Post');
    const scheduledBlogButton = scheduleButtons[1]; // Blog 2 is already scheduled

    expect(scheduledBlogButton).toBeDisabled();
  });
});
