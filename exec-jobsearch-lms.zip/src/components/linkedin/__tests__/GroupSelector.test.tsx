import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { GroupSelector } from '../GroupSelector';
import { LinkedInGroup } from '../../../types/linkedin';

describe('GroupSelector', () => {
  const mockGroups: LinkedInGroup[] = [
    {
      id: '1',
      name: 'Test Group 1',
      url: 'https://linkedin.com/groups/1',
      requiresApproval: false,
      lastPostStatus: 'success',
      lastPostDate: undefined
    },
    {
      id: '2',
      name: 'Test Group 2',
      url: 'https://linkedin.com/groups/2',
      requiresApproval: true,
      lastPostStatus: 'pending',
      lastPostDate: undefined
    }
  ];

  const mockOnChange = jest.fn();

  // Mock localStorage
  const mockLocalStorage = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    clear: jest.fn(),
    removeItem: jest.fn()
  };

  beforeAll(() => {
    Object.defineProperty(window, 'localStorage', {
      value: mockLocalStorage,
      writable: true
    });
  });

  beforeEach(() => {
    jest.clearAllMocks();
    mockLocalStorage.getItem.mockImplementation(() => JSON.stringify(mockGroups));
    mockLocalStorage.setItem.mockImplementation(() => {});
  });

  const renderComponent = (selectedGroups: LinkedInGroup[] = []) => {
    const result = render(
      <GroupSelector
        selectedGroups={selectedGroups}
        onChange={mockOnChange}
      />
    );
    
    return result;
  };

  const waitForLoadingComplete = async () => {
    await waitFor(
      () => {
        const progressBar = screen.queryByRole('progressbar');
        const errorMessage = screen.queryByText(/failed|error/i);
        return !progressBar && !errorMessage;
      },
      { timeout: 3000 }
    );
  };

  const openDialog = async () => {
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    });
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });
  };

  const fillGroupForm = async (name: string, url: string) => {
    const nameInput = screen.getByTestId('group-name-input');
    const urlInput = screen.getByTestId('group-url-input');
    await userEvent.type(nameInput, name);
    await userEvent.type(urlInput, url);
    return { nameInput, urlInput };
  };

  it('loads groups from localStorage', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
      expect(screen.getByText('Test Group 2')).toBeInTheDocument();
    });
  });

  it('handles localStorage errors', async () => {
    mockLocalStorage.getItem.mockImplementation(() => { throw new Error('Storage error'); });
    renderComponent();
    
    await waitFor(() => {
      expect(screen.getByText(/Failed to load groups/i)).toBeInTheDocument();
    });
    
    expect(screen.queryAllByRole('listitem')).toHaveLength(0);
  });

  it('handles localStorage save errors', async () => {
    renderComponent();
    
    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });
    
    // Store references to elements before triggering error
    const deleteButtons = screen.getAllByRole('button', { name: /delete/i });
    const initialCount = deleteButtons.length;
    const groupName = screen.getByText('Test Group 1');
    
    mockLocalStorage.setItem.mockImplementation(() => { throw new Error('Storage error'); });

    fireEvent.click(deleteButtons[0]);
    
    await waitFor(() => {
      expect(screen.getByText(/Failed to save changes/i)).toBeInTheDocument();
    });
    
    // Verify group still exists
    expect(screen.getAllByRole('button', { name: /delete/i })).toHaveLength(initialCount);
    expect(groupName).toBeInTheDocument();
  });

  it('handles add group errors', async () => {
    renderComponent();
    
    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });

    const nameInput = screen.getByTestId('group-name-input');
    const urlInput = screen.getByTestId('group-url-input');
    await userEvent.type(nameInput, 'New Group');
    await userEvent.type(urlInput, 'https://linkedin.com/groups/new');
    
    mockLocalStorage.setItem.mockImplementation(() => {
      throw new Error('Storage error');
    });

    fireEvent.click(screen.getByRole('button', { name: /add/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/Failed to save group/i)).toBeInTheDocument();
    });

    // Dialog should stay open with form values preserved
    expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    expect(nameInput).toHaveValue('New Group');
    expect(urlInput).toHaveValue('https://linkedin.com/groups/new');
  });

  it('handles dialog close', async () => {
    renderComponent();
    
    // Open dialog
    fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });
    
    // Close dialog
    fireEvent.click(screen.getByTestId('dialog-cancel-button'));
    await waitFor(() => {
      expect(screen.queryByTestId('add-group-dialog')).not.toBeInTheDocument();
    });
  });

  it('adds new group', async () => {
    renderComponent();

    // Open dialog
    fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });

    // Fill in form fields
    const nameInput = screen.getByTestId('group-name-input');
    const urlInput = screen.getByTestId('group-url-input');
    await userEvent.type(nameInput, 'New Group');
    await userEvent.type(urlInput, 'https://linkedin.com/groups/new');
    
    // Submit form
    fireEvent.click(screen.getByRole('button', { name: /add/i }));

    // Verify localStorage was updated
    await waitFor(() => {
      expect(mockLocalStorage.setItem).toHaveBeenCalledWith(
        'linkedinGroups',
        expect.stringContaining('New Group')
      );
      expect(screen.queryByTestId('add-group-dialog')).not.toBeInTheDocument();
    });

    // Verify group appears in list
    expect(screen.getByText('New Group')).toBeInTheDocument();
  });

  it('removes group', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByRole('button', { name: /delete/i });
    fireEvent.click(deleteButtons[0]);

    await waitFor(() => {
      expect(mockLocalStorage.setItem).toHaveBeenCalledWith(
        'linkedinGroups',
        expect.not.stringContaining('Test Group 1')
      );
    });
  });

  it('handles group selection', async () => {
    renderComponent([mockGroups[0]]);

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Test Group 1'));
    expect(mockOnChange).toHaveBeenCalledWith([]);
  });

  it('prevents selecting more than 3 groups', async () => {
    const selectedGroups = [mockGroups[0], mockGroups[1]];
    renderComponent(selectedGroups);

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('Test Group 1'));
    expect(mockOnChange).toHaveBeenCalledTimes(1);
  });

  it('prevents selecting disabled groups', async () => {
    renderComponent();
    
    await waitFor(() => {
      expect(screen.getByText('Test Group 2')).toBeInTheDocument();
    });

    const disabledGroup = screen.getByText('Test Group 2').closest('div[role="button"]');
    if (!disabledGroup) throw new Error('Disabled group not found');
    
    fireEvent.click(disabledGroup);
    expect(mockOnChange).not.toHaveBeenCalled();
    expect(screen.getByText('Requires Approval')).toBeInTheDocument();
  });

  it('disables groups requiring approval', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 2')).toBeInTheDocument();
    });

    const group2Item = screen.getByText('Test Group 2').closest('div[role="button"]');
    if (!group2Item) throw new Error('Group item not found');
    
    expect(group2Item).toHaveAttribute('aria-disabled', 'true');
    fireEvent.click(group2Item);
    expect(mockOnChange).not.toHaveBeenCalled();
  });

  it('displays group status indicators', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('success')).toBeInTheDocument();
      expect(screen.getByText('pending')).toBeInTheDocument();
      expect(screen.getByText('Requires Approval')).toBeInTheDocument();
    });
  });

  it('validates new group input', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });
    
    const nameInput = screen.getByTestId('group-name-input');
    const urlInput = screen.getByTestId('group-url-input');
    const addButton = screen.getByRole('button', { name: /add/i });

    // Initial state - button should be disabled
    expect(addButton).toBeDisabled();

    // Fill name only - button should still be disabled
    await userEvent.type(nameInput, 'New Group');
    expect(addButton).toBeDisabled();

    // Clear name and fill only URL - button should still be disabled
    await userEvent.clear(nameInput);
    await userEvent.type(urlInput, 'https://linkedin.com/groups/new');
    expect(addButton).toBeDisabled();

    // Fill both fields - button should be enabled
    await userEvent.type(nameInput, 'New Group');
    expect(addButton).not.toBeDisabled();
  });

  it('validates required fields and shows error messages', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });

    const nameInput = screen.getByTestId('group-name-input');
    const urlInput = screen.getByTestId('group-url-input');
    const addButton = screen.getByRole('button', { name: /add/i });

    // Try to submit empty form
    expect(addButton).toBeDisabled();

    // Fill valid data but same as existing group
    await userEvent.type(nameInput, 'Test Group 1');
    await userEvent.type(urlInput, 'https://linkedin.com/groups/1');
    fireEvent.click(addButton);
    
    await waitFor(() => {
      expect(screen.getByText(/Group already exists/i)).toBeInTheDocument();
    });

    // Fill valid new group data
    await userEvent.clear(nameInput);
    await userEvent.clear(urlInput);
    await userEvent.type(nameInput, 'New Group');
    await userEvent.type(urlInput, 'https://linkedin.com/groups/new');
    expect(addButton).not.toBeDisabled();
  });

  it('shows loading state', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });
  });

  it('handles empty localStorage', async () => {
    mockLocalStorage.getItem.mockReturnValue(null);
    renderComponent();
    
    await waitFor(() => {
      expect(screen.queryByText('Test Group 1')).not.toBeInTheDocument();
      expect(screen.queryByText('Test Group 2')).not.toBeInTheDocument();
    });
  });

  it('prevents adding duplicate groups and maintains form state', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: /add group/i }));
    await waitFor(() => {
      expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    });

    const nameInput = screen.getByTestId('group-name-input');
    const urlInput = screen.getByTestId('group-url-input');

    // Try to add group with same name
    await userEvent.type(nameInput, 'Test Group 1');
    await userEvent.type(urlInput, 'https://linkedin.com/groups/new');
    fireEvent.click(screen.getByRole('button', { name: /add/i }));

    await waitFor(() => {
      expect(screen.getByText(/Group already exists/i)).toBeInTheDocument();
    });

    // Try to add group with same URL
    await userEvent.clear(nameInput);
    await userEvent.clear(urlInput);
    await userEvent.type(nameInput, 'New Group');
    await userEvent.type(urlInput, 'https://linkedin.com/groups/1');
    fireEvent.click(screen.getByRole('button', { name: /add/i }));

    await waitFor(() => {
      expect(screen.getByText(/Group already exists/i)).toBeInTheDocument();
    });

    // Dialog should stay open with form values preserved
    expect(screen.getByTestId('add-group-dialog')).toBeInTheDocument();
    expect(nameInput).toHaveValue('New Group');
    expect(urlInput).toHaveValue('https://linkedin.com/groups/1');
  });

  it('handles error during group removal', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });

    // Get initial group count
    const deleteButtons = screen.getAllByRole('button', { name: /delete/i });
    const initialCount = deleteButtons.length;

    mockLocalStorage.setItem.mockImplementation(() => {
      throw new Error('Storage error');
    });

    // Try to delete a group
    fireEvent.click(deleteButtons[0]);

    // Verify error state and group still exists
    await waitFor(() => {
      expect(screen.getByText(/Failed to save changes/i)).toBeInTheDocument();
      expect(screen.getAllByRole('button', { name: /delete/i })).toHaveLength(initialCount);
      expect(screen.getByText('Test Group 1')).toBeInTheDocument();
    });
  });
});
