import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { OutlineGenerator } from '../OutlineGenerator';
import { BlogOutline } from '../../../types/linkedin';
import '@testing-library/jest-dom';

describe('OutlineGenerator', () => {
  const mockOutline: BlogOutline = {
    seriesTitle: 'Test Series',
    description: 'Test Description',
    partCount: 4,
    blogTitles: [
      'Part 1: Introduction',
      'Part 2: Main Concepts',
      'Part 3: Advanced Topics',
      'Part 4: Conclusion'
    ],
    targetGroups: [],
    suggestedHashtags: ['test', 'series']
  };

  const mockOnGenerate = jest.fn().mockResolvedValue(mockOutline);
  const mockOnApprove = jest.fn().mockResolvedValue(undefined);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders topic templates', () => {
    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={null}
      />
    );

    expect(screen.getByText('Industry Trends and Analysis')).toBeInTheDocument();
    expect(screen.getByText('Professional Development Journey')).toBeInTheDocument();
    expect(screen.getByText('Project Success Stories')).toBeInTheDocument();
    expect(screen.getByText('Leadership Lessons')).toBeInTheDocument();
  });

  it('allows template selection', () => {
    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={null}
      />
    );

    const template = screen.getByText('Industry Trends and Analysis').closest('.MuiCard-root');
    fireEvent.click(template!);

    const topicInput = screen.getByLabelText('Blog Series Topic');
    expect(topicInput).toHaveValue('Industry Trends and Analysis');
  });

  it('validates input before generation', async () => {
    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={null}
      />
    );

    const generateButton = screen.getByText('Generate & Save');
    fireEvent.click(generateButton);

    expect(screen.getByText('Please enter a valid topic and number of parts (4-16)')).toBeInTheDocument();
    expect(mockOnGenerate).not.toHaveBeenCalled();
  });

  it('generates and approves outline', async () => {
    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={null}
      />
    );

    // Fill in topic
    const topicInput = screen.getByLabelText('Blog Series Topic');
    fireEvent.change(topicInput, { target: { value: 'Test Topic' } });

    // Generate outline
    const generateButton = screen.getByText('Generate & Save');
    fireEvent.click(generateButton);

    await waitFor(() => {
      expect(mockOnGenerate).toHaveBeenCalledWith('Test Topic', 4);
    });

    // Verify outline is displayed
    expect(screen.getByText('Part 1: Introduction')).toBeInTheDocument();
    expect(screen.getByText('Part 2: Main Concepts')).toBeInTheDocument();
    expect(screen.getByText('Part 3: Advanced Topics')).toBeInTheDocument();
    expect(screen.getByText('Part 4: Conclusion')).toBeInTheDocument();

    // Approve outline
    const approveButton = screen.getByText('Approve');
    fireEvent.click(approveButton);

    await waitFor(() => {
      expect(mockOnApprove).toHaveBeenCalledWith(mockOutline);
    });
  });

  it('handles generation errors', async () => {
    mockOnGenerate.mockRejectedValueOnce(new Error('Generation failed'));

    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={null}
      />
    );

    // Fill in topic
    const topicInput = screen.getByLabelText('Blog Series Topic');
    fireEvent.change(topicInput, { target: { value: 'Test Topic' } });

    // Generate outline
    const generateButton = screen.getByText('Generate & Save');
    fireEvent.click(generateButton);

    await waitFor(() => {
      expect(screen.getByText('Failed to generate outline')).toBeInTheDocument();
    });
  });

  it('handles approval errors', async () => {
    mockOnApprove.mockRejectedValueOnce(new Error('Approval failed'));

    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={mockOutline}
      />
    );

    const approveButton = screen.getByText('Approve');
    fireEvent.click(approveButton);

    await waitFor(() => {
      expect(screen.getByText('Failed to approve outline')).toBeInTheDocument();
    });
  });

  it('shows loading state during generation and approval', async () => {
    mockOnGenerate.mockImplementation(() => new Promise(resolve => setTimeout(() => resolve(mockOutline), 100)));
    mockOnApprove.mockImplementation(() => new Promise(resolve => setTimeout(resolve, 100)));

    render(
      <OutlineGenerator
        onGenerate={mockOnGenerate}
        onApprove={mockOnApprove}
        outline={null}
      />
    );

    // Fill in topic
    const topicInput = screen.getByLabelText('Blog Series Topic');
    fireEvent.change(topicInput, { target: { value: 'Test Topic' } });

    // Generate outline
    const generateButton = screen.getByText('Generate & Save');
    fireEvent.click(generateButton);

    // Check loading state during generation
    expect(screen.getByText('Generating...')).toBeInTheDocument();

    // Wait for generation to complete
    await waitFor(() => {
      expect(screen.getByText('Approve')).toBeInTheDocument();
    });

    // Approve outline
    const approveButton = screen.getByText('Approve');
    fireEvent.click(approveButton);

    // Check loading state during approval
    expect(screen.getByText('Generating...')).toBeInTheDocument();
  });
});
