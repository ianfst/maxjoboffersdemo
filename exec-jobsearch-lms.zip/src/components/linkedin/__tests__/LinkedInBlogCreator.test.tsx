import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { LinkedInBlogCreator } from '../LinkedInBlogCreator';
import { BlogSeries, Blog } from '../../../types/linkedin';
import { Alert } from '@mui/material';

// Mock child components
jest.mock('../OutlineGenerator', () => ({
  OutlineGenerator: ({ onGenerate, onApprove, outline }) => (
    <div data-testid="mock-outline-generator">
      <button onClick={() => onGenerate('Test Topic', 4)}>Generate Outline</button>
      {outline && <button onClick={onApprove}>Approve Outline</button>}
    </div>
  )
}));

jest.mock('../BlogEditor', () => ({
  BlogEditor: ({ series, onGenerate }) => (
    <div data-testid="mock-blog-editor">
      <button onClick={() => onGenerate(series.blogs[0])}>Generate Content</button>
    </div>
  )
}));

jest.mock('../ScheduleManager', () => ({
  ScheduleManager: ({ series, onSchedule }) => (
    <div data-testid="mock-schedule-manager">
      <button onClick={() => onSchedule(series.blogs[0], new Date())}>Schedule Post</button>
    </div>
  )
}));

// Mock localStorage
const mockLocalStorage = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  clear: jest.fn()
};
Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });

// Mock crypto.randomUUID
const mockRandomUUID = jest.fn(() => '123');
Object.defineProperty(global.crypto, 'randomUUID', { value: mockRandomUUID });

describe('LinkedInBlogCreator', () => {
  const mockOnSave = jest.fn().mockResolvedValue(undefined);
  const mockOnPublish = jest.fn().mockResolvedValue(undefined);
  const mockOnGenerateInfographic = jest.fn().mockResolvedValue('infographic-url');

  beforeEach(() => {
    jest.clearAllMocks();
    mockLocalStorage.getItem.mockReturnValue(null);
  });

  const renderComponent = () => {
    return render(
      <LinkedInBlogCreator
        onSave={mockOnSave}
        onPublish={mockOnPublish}
        onGenerateInfographic={mockOnGenerateInfographic}
      />
    );
  };

  it('renders initial step with outline generator', () => {
    renderComponent();
    expect(screen.getByText('LinkedIn Blog Creator')).toBeInTheDocument();
    expect(screen.getByTestId('mock-outline-generator')).toBeInTheDocument();
  });

  it('loads saved progress from localStorage', async () => {
    const mockSavedData = {
      series: {
        id: '123',
        title: 'Test Series',
        blogs: []
      },
      outline: {
        seriesTitle: 'Test Series',
        blogTitles: ['Blog 1', 'Blog 2']
      }
    };
    mockLocalStorage.getItem.mockReturnValue(JSON.stringify(mockSavedData));

    renderComponent();
    await waitFor(() => {
      expect(mockLocalStorage.getItem).toHaveBeenCalledWith('linkedinBlogCreator');
    });
  });

  it('handles localStorage errors gracefully', async () => {
    mockLocalStorage.getItem.mockImplementation(() => {
      throw new Error('Storage error');
    });

    renderComponent();
    await waitFor(() => {
      expect(screen.getByText('Failed to load saved progress')).toBeInTheDocument();
    });
  });

  it('generates and approves outline', async () => {
    renderComponent();

    // Generate outline
    const generateButton = screen.getByText('Generate Outline');
    fireEvent.click(generateButton);

    await waitFor(() => {
      expect(screen.getByText('Approve Outline')).toBeInTheDocument();
    });

    // Approve outline
    const approveButton = screen.getByText('Approve Outline');
    fireEvent.click(approveButton);

    await waitFor(() => {
      expect(mockOnSave).toHaveBeenCalled();
      expect(screen.getByTestId('mock-blog-editor')).toBeInTheDocument();
    });
  });

  it('generates content and schedules posts', async () => {
    renderComponent();

    // Generate and approve outline
    const generateButton = screen.getByText('Generate Outline');
    fireEvent.click(generateButton);

    await waitFor(() => {
      expect(screen.getByText('Approve Outline')).toBeInTheDocument();
    });

    const approveButton = screen.getByText('Approve Outline');
    fireEvent.click(approveButton);

    await waitFor(() => {
      expect(screen.getByTestId('mock-blog-editor')).toBeInTheDocument();
    });

    // Generate content
    const generateContentButton = screen.getByText('Generate Content');
    fireEvent.click(generateContentButton);

    await waitFor(() => {
      expect(mockOnGenerateInfographic).toHaveBeenCalled();
      expect(mockOnSave).toHaveBeenCalledTimes(2);
    });

    // Move to scheduling
    const nextButton = screen.getByText('Next');
    fireEvent.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId('mock-schedule-manager')).toBeInTheDocument();
    });

    // Schedule post
    const scheduleButton = screen.getByText('Schedule Post');
    fireEvent.click(scheduleButton);

    await waitFor(() => {
      expect(mockOnSave).toHaveBeenCalledTimes(3);
    });
  });

  it('handles errors during content generation', async () => {
    mockOnGenerateInfographic.mockRejectedValueOnce(new Error('Generation failed'));
    renderComponent();

    // Generate and approve outline
    const generateButton = screen.getByText('Generate Outline');
    fireEvent.click(generateButton);

    await waitFor(() => {
      expect(screen.getByText('Approve Outline')).toBeInTheDocument();
    });

    const approveButton = screen.getByText('Approve Outline');
    fireEvent.click(approveButton);

    await waitFor(() => {
      expect(screen.getByTestId('mock-blog-editor')).toBeInTheDocument();
    });

    // Generate content
    const generateContentButton = screen.getByText('Generate Content');
    fireEvent.click(generateContentButton);

    await waitFor(() => {
      expect(screen.getByText('Failed to generate content')).toBeInTheDocument();
    });
  });

  it('handles errors during scheduling', async () => {
    mockOnSave.mockRejectedValueOnce(new Error('Scheduling failed'));
    renderComponent();

    // Generate and approve outline
    const generateButton = screen.getByText('Generate Outline');
    fireEvent.click(generateButton);

    await waitFor(() => {
      expect(screen.getByText('Approve Outline')).toBeInTheDocument();
    });

    const approveButton = screen.getByText('Approve Outline');
    fireEvent.click(approveButton);

    await waitFor(() => {
      expect(screen.getByTestId('mock-blog-editor')).toBeInTheDocument();
    });

    // Move to scheduling
    const nextButton = screen.getByText('Next');
    fireEvent.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId('mock-schedule-manager')).toBeInTheDocument();
    });

    // Schedule post
    const scheduleButton = screen.getByText('Schedule Post');
    fireEvent.click(scheduleButton);

    await waitFor(() => {
      expect(screen.getByText('Failed to schedule blog')).toBeInTheDocument();
    });
  });
});
