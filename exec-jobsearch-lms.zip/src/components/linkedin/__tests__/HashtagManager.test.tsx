import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { HashtagManager } from '../HashtagManager';
import '@testing-library/jest-dom';

const mockHashtags = {
  categories: {
    career: ['#careeradvice', '#jobsearch', '#networking'],
    industry: ['#technology', '#finance', '#healthcare'],
    skills: ['#leadership', '#management', '#strategy'],
  },
  trending: ['#executivejobs', '#careertransition', '#leadership'],
  suggested: ['#business', '#innovation', '#growth'],
};

jest.mock('../../../utils/api', () => ({
  fetchHashtags: jest.fn().mockResolvedValue(mockHashtags),
}));

describe('HashtagManager', () => {
  const renderComponent = (props = {}) => {
    return render(
      <HashtagManager
        hashtags={[]}
        onChange={() => {}}
        {...props}
      />
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders hashtag input and suggestions', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByPlaceholderText('Add a hashtag')).toBeInTheDocument();
      expect(screen.getByText('Suggested Hashtags')).toBeInTheDocument();
    });
  });

  it('allows adding new hashtags', async () => {
    const onChangeMock = jest.fn();
    renderComponent({ onChange: onChangeMock });

    const input = screen.getByPlaceholderText('Add a hashtag');
    fireEvent.change(input, { target: { value: 'newhashtag' } });
    fireEvent.keyPress(input, { key: 'Enter', code: 13, charCode: 13 });

    await waitFor(() => {
      expect(onChangeMock).toHaveBeenCalledWith(['newhashtag']);
    });
  });

  it('shows and allows removing existing hashtags', async () => {
    const existingHashtags = ['tech', 'leadership'];
    const onChangeMock = jest.fn();
    renderComponent({
      hashtags: existingHashtags,
      onChange: onChangeMock
    });

    await waitFor(() => {
      existingHashtags.forEach(tag => {
        const chips = screen.getAllByRole('button').filter(el => 
          el.textContent === `#${tag}` && el.closest('.MuiChip-root')
        );
        expect(chips.length).toBeGreaterThan(0);
      });
    });

    const deleteIcon = screen.getAllByTestId('DeleteIcon')[0];
    fireEvent.click(deleteIcon);

    await waitFor(() => {
      expect(onChangeMock).toHaveBeenCalledWith(['leadership']);
    });
  });

  it('shows suggested hashtags', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByText('#careeradvice')).toBeInTheDocument();
      expect(screen.getByText('#leadership')).toBeInTheDocument();
    });
  });

  it('allows adding suggested hashtags', async () => {
    const onChangeMock = jest.fn();
    renderComponent({ onChange: onChangeMock });

    const suggestedTag = screen.getByText('#careeradvice');
    fireEvent.click(suggestedTag);

    await waitFor(() => {
      expect(onChangeMock).toHaveBeenCalledWith(['careeradvice']);
    });
  });

  it('opens category dialog when browse button is clicked', async () => {
    renderComponent();
    
    const browseButton = screen.getByText('Browse Categories');
    fireEvent.click(browseButton);

    await waitFor(() => {
      expect(screen.getByText('Career')).toBeInTheDocument();
      expect(screen.getByText('Technology')).toBeInTheDocument();
      expect(screen.getByText('Business')).toBeInTheDocument();
    });
  });

  it('prevents duplicate hashtags', async () => {
    const existingHashtags = ['tech'];
    const onChangeMock = jest.fn();
    renderComponent({
      hashtags: existingHashtags,
      onChange: onChangeMock
    });

    const input = screen.getByPlaceholderText('Add a hashtag');
    fireEvent.change(input, { target: { value: 'tech' } });
    fireEvent.keyPress(input, { key: 'Enter', code: 13, charCode: 13 });

    await waitFor(() => {
      expect(onChangeMock).not.toHaveBeenCalled();
    });
  });
});
