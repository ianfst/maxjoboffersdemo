import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { CanvaIntegration } from '../CanvaIntegration';
import '@testing-library/jest-dom';

describe('CanvaIntegration', () => {
  const mockOnClose = jest.fn();
  const mockOnGenerate = jest.fn();
  const mockBlogTitle = 'Test Blog Title';

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    act(() => {
      jest.runOnlyPendingTimers();
    });
    jest.useRealTimers();
  });

  const renderComponent = () => {
    return render(
      <CanvaIntegration
        open={true}
        onClose={mockOnClose}
        blogTitle={mockBlogTitle}
        onGenerate={mockOnGenerate}
      />
    );
  };

  it('renders with blog title', () => {
    renderComponent();
    const titleInput = screen.getByLabelText('Infographic Title');
    expect(titleInput).toHaveValue(mockBlogTitle);
  });

  it('displays template options', () => {
    renderComponent();
    expect(screen.getByText('Professional Blog Header')).toBeInTheDocument();
    expect(screen.getByText('Modern Article Cover')).toBeInTheDocument();
    expect(screen.getByText('Business Insights')).toBeInTheDocument();
  });

  it('allows template selection and generation', async () => {
    renderComponent();
    const template = screen.getByRole('button', { name: /select professional blog header template/i });
    expect(template).toBeInTheDocument();
    
    await act(async () => {
      fireEvent.click(template);
    });

    expect(screen.getByRole('progressbar', { name: 'Generating infographic' })).toBeInTheDocument();

    await act(async () => {
      jest.advanceTimersByTime(2000);
    });

    expect(mockOnGenerate).toHaveBeenCalledWith(expect.stringContaining('generated-1.jpg'));
  });

  it('handles title customization', async () => {
    renderComponent();
    const titleInput = screen.getByLabelText('Infographic Title');
    
    // Clear and type synchronously since we're not dealing with real timers
    fireEvent.change(titleInput, { target: { value: '' } });
    fireEvent.change(titleInput, { target: { value: 'Custom Title' } });

    expect(titleInput).toHaveValue('Custom Title');
  });

  it('shows loading state during generation', async () => {
    renderComponent();
    const template = screen.getByRole('button', { name: /select professional blog header template/i });
    
    await act(async () => {
      fireEvent.click(template);
    });

    expect(screen.getByRole('progressbar', { name: 'Generating infographic' })).toBeInTheDocument();

    await act(async () => {
      jest.advanceTimersByTime(2000);
    });

    expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
  });

  it('handles generation errors', async () => {
    mockOnGenerate.mockRejectedValue(new Error('Generation failed'));
    renderComponent();

    const template = screen.getByRole('button', { name: /select professional blog header template/i });
    
    await act(async () => {
      fireEvent.click(template);
      jest.advanceTimersByTime(2000);
    });

    const alert = screen.getByRole('alert');
    expect(alert).toBeInTheDocument();
    expect(alert).toHaveTextContent(/Failed to generate image/i);
  });

  it('refreshes templates', async () => {
    renderComponent();
    const refreshButton = screen.getByRole('button', { name: /refresh templates/i });
    
    await act(async () => {
      fireEvent.click(refreshButton);
      jest.advanceTimersByTime(1000);
    });

    expect(screen.getByText('Professional Blog Header')).toBeInTheDocument();
  });

  it('displays template dimensions', () => {
    renderComponent();
    const dimensionsText = screen.getAllByText('1200 x 628')[0];
    expect(dimensionsText).toBeInTheDocument();
    expect(dimensionsText.tagName.toLowerCase()).toBe('p');
  });

  it('shows preview after generation', async () => {
    mockOnGenerate.mockResolvedValue(undefined);
    renderComponent();
    const template = screen.getByRole('button', { name: /select professional blog header template/i });
    
    await act(async () => {
      fireEvent.click(template);
      jest.advanceTimersByTime(2000);
    });

    expect(screen.getByAltText('Generated Infographic')).toBeInTheDocument();
  });

  it('closes dialog', () => {
    renderComponent();
    const closeButton = screen.getByRole('button', { name: /cancel/i });
    fireEvent.click(closeButton);
    expect(mockOnClose).toHaveBeenCalled();
  });
});
