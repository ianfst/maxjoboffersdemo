import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MessageOptimizer } from '../MessageOptimizer';
import { mockMessageData } from '../../../__mocks__/messageData';
import '@testing-library/jest-dom';

jest.mock('../../../utils/ai', () => ({
  analyzeMessage: jest.fn().mockResolvedValue({
    score: 85,
    suggestions: ['Add more personalization', 'Include a specific call to action'],
    tone: 'professional',
    engagement_probability: 0.75,
  }),
  generateImprovedMessage: jest.fn().mockResolvedValue({
    message: 'Improved message content',
    changes: ['Added personalization', 'Enhanced call to action'],
  }),
}));

describe('MessageOptimizer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('analyzes message content', async () => {
    render(<MessageOptimizer />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Hello, I noticed your profile and wanted to connect.' },
    });

    const analyzeButton = screen.getByText('Analyze Message');
    fireEvent.click(analyzeButton);

    await waitFor(() => {
      expect(screen.getByText('Message Score: 85')).toBeInTheDocument();
      expect(screen.getByText('Add more personalization')).toBeInTheDocument();
    });
  });

  it('suggests improvements based on industry', async () => {
    render(<MessageOptimizer industry="technology" />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Interested in discussing technology trends.' },
    });

    const analyzeButton = screen.getByText('Analyze Message');
    fireEvent.click(analyzeButton);

    await waitFor(() => {
      expect(screen.getByText(/technology/i)).toBeInTheDocument();
      expect(screen.getByText(/trends/i)).toBeInTheDocument();
    });
  });

  it('provides tone analysis', async () => {
    render(<MessageOptimizer />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Professional message content.' },
    });

    const analyzeButton = screen.getByText('Analyze Message');
    fireEvent.click(analyzeButton);

    await waitFor(() => {
      expect(screen.getByText('Tone: Professional')).toBeInTheDocument();
    });
  });

  it('shows engagement probability', async () => {
    render(<MessageOptimizer />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Test message' },
    });

    const analyzeButton = screen.getByText('Analyze Message');
    fireEvent.click(analyzeButton);

    await waitFor(() => {
      expect(screen.getByText('75% Engagement Probability')).toBeInTheDocument();
    });
  });

  it('generates improved versions', async () => {
    render(<MessageOptimizer />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Original message' },
    });

    const improveButton = screen.getByText('Generate Improved Version');
    fireEvent.click(improveButton);

    await waitFor(() => {
      expect(screen.getByText('Improved message content')).toBeInTheDocument();
      expect(screen.getByText('Added personalization')).toBeInTheDocument();
    });
  });

  it('saves message templates', async () => {
    render(<MessageOptimizer />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Template message' },
    });

    const saveButton = screen.getByText('Save as Template');
    fireEvent.click(saveButton);

    await waitFor(() => {
      expect(screen.getByText('Template Saved')).toBeInTheDocument();
    });
  });

  it('handles message categories', async () => {
    render(<MessageOptimizer />);

    const categorySelect = screen.getByLabelText('Message Category');
    fireEvent.change(categorySelect, {
      target: { value: 'follow_up' },
    });

    await waitFor(() => {
      expect(screen.getByText('Follow-up Templates')).toBeInTheDocument();
    });
  });

  it('provides keyword suggestions', async () => {
    render(<MessageOptimizer industry="finance" />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Basic message' },
    });

    await waitFor(() => {
      expect(screen.getByText('Suggested Keywords')).toBeInTheDocument();
      expect(screen.getAllByRole('button')).toHaveLength(5); // Keyword chips
    });
  });

  it('tracks message history', async () => {
    render(<MessageOptimizer />);

    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Version 1' },
    });

    const analyzeButton = screen.getByText('Analyze Message');
    fireEvent.click(analyzeButton);

    await waitFor(() => {
      expect(screen.getByText('Message History')).toBeInTheDocument();
      expect(screen.getByText('Version 1')).toBeInTheDocument();
    });
  });

  it('compares message versions', async () => {
    render(<MessageOptimizer />);

    // Add first version
    const messageInput = screen.getByPlaceholderText('Enter your message');
    fireEvent.change(messageInput, {
      target: { value: 'Version 1' },
    });

    const improveButton = screen.getByText('Generate Improved Version');
    fireEvent.click(improveButton);

    await waitFor(() => {
      expect(screen.getByText('Compare Versions')).toBeInTheDocument();
      expect(screen.getByText('Version 1')).toBeInTheDocument();
      expect(screen.getByText('Improved message content')).toBeInTheDocument();
    });
  });
});
