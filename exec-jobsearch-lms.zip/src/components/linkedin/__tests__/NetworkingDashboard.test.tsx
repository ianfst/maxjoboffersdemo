import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { NetworkingDashboard } from '../NetworkingDashboard';
import '@testing-library/jest-dom';

describe('NetworkingDashboard', () => {
  it('renders dashboard header', () => {
    render(<NetworkingDashboard />);

    expect(screen.getByText('Strategic Networking Dashboard')).toBeInTheDocument();
    expect(screen.getByText('Leverage our AI-powered networking system to build meaningful connections')).toBeInTheDocument();
  });

  it('displays campaign metrics', () => {
    render(<NetworkingDashboard />);

    expect(screen.getByText('Total Connections')).toBeInTheDocument();
    expect(screen.getByText('150')).toBeInTheDocument();
    expect(screen.getByText('Across all campaigns')).toBeInTheDocument();

    expect(screen.getByText('Pending Requests')).toBeInTheDocument();
    expect(screen.getByText('45')).toBeInTheDocument();
    expect(screen.getByText('Awaiting response')).toBeInTheDocument();

    expect(screen.getByText('Messages')).toBeInTheDocument();
    expect(screen.getByText('280')).toBeInTheDocument();
    expect(screen.getByText('Conversations started')).toBeInTheDocument();

    expect(screen.getByText('Meetings')).toBeInTheDocument();
    expect(screen.getByText('12')).toBeInTheDocument();
    expect(screen.getByText('Successfully scheduled')).toBeInTheDocument();
  });

  it('shows navigation tabs', () => {
    render(<NetworkingDashboard />);

    const tabs = screen.getAllByRole('tab');
    expect(tabs).toHaveLength(4);
    expect(tabs[0]).toHaveTextContent('Active Campaigns');
    expect(tabs[1]).toHaveTextContent('Connection Manager');
    expect(tabs[2]).toHaveTextContent('Message Templates');
    expect(tabs[3]).toHaveTextContent('Analytics');
  });

  it('allows tab navigation', () => {
    render(<NetworkingDashboard />);

    const tabs = screen.getAllByRole('tab');
    fireEvent.click(tabs[1]); // Click Connection Manager tab

    // Check that the Connection Manager tab panel is visible
    const tabPanel = screen.getByRole('tabpanel');
    expect(tabPanel).toBeVisible();
    expect(tabPanel).toHaveTextContent('Connection Manager');
  });

  it('shows launch campaign button', () => {
    render(<NetworkingDashboard />);

    expect(screen.getByRole('button', { name: 'Launch New Campaign' })).toBeInTheDocument();
  });
});
