import React from 'react';
import { render, screen } from '@testing-library/react';
import { IndustryInsights } from '../IndustryInsights';
import '@testing-library/jest-dom';

describe('IndustryInsights', () => {
  it('displays industry growth trends', () => {
    render(<IndustryInsights industry="Technology" />);

    expect(screen.getByText('Executive Market Intelligence')).toBeInTheDocument();
    expect(screen.getByText('Technology')).toBeInTheDocument();
    expect(screen.getByText('28% Growth')).toBeInTheDocument();
  });

  it('shows company insights', () => {
    render(<IndustryInsights industry="Technology" />);

    expect(screen.getByText('Company Intelligence')).toBeInTheDocument();
    expect(screen.getByText('Microsoft')).toBeInTheDocument();
    expect(screen.getByText('Hiring Intensity')).toBeInTheDocument();
    expect(screen.getByText('85%')).toBeInTheDocument();
  });

  it('displays executive movements', () => {
    render(<IndustryInsights industry="Technology" />);

    expect(screen.getByText('145 executive movements in last 90 days')).toBeInTheDocument();
  });

  it('shows top roles', () => {
    render(<IndustryInsights industry="Technology" />);

    expect(screen.getByText('CTO')).toBeInTheDocument();
    expect(screen.getByText('VP Engineering')).toBeInTheDocument();
    expect(screen.getByText('Chief Digital Officer')).toBeInTheDocument();
  });

  it('displays key companies', () => {
    render(<IndustryInsights industry="Technology" />);

    expect(screen.getByText('Key Companies:')).toBeInTheDocument();
    expect(screen.getByText('Apple')).toBeInTheDocument();
    expect(screen.getByText('Microsoft')).toBeInTheDocument();
    expect(screen.getByText('Google')).toBeInTheDocument();
  });

  it('shows networking opportunities', () => {
    render(<IndustryInsights industry="Technology" />);

    expect(screen.getByText('Networking Opportunities')).toBeInTheDocument();
    expect(screen.getByText('Tech Leadership Summit')).toBeInTheDocument();
    expect(screen.getByText('Cloud Computing Group')).toBeInTheDocument();
    expect(screen.getByText('Digital Transformation Forum')).toBeInTheDocument();
  });
});
