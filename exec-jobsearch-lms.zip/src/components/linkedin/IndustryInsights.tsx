import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  List,
  ListItem,
  ListItemText,
  Chip,
  LinearProgress,
  Button,
} from '@mui/material';
import {
  TrendingUp,
  Business,
  Person,
  Timeline,
} from '@mui/icons-material';

interface IndustryTrend {
  industry: string;
  growthRate: number;
  keyCompanies: string[];
  executiveMovements: number;
  topRoles: string[];
}

interface CompanyInsight {
  name: string;
  hiringIntensity: number;
  recentExecutiveHires: number;
  preferredBackgrounds: string[];
  networkingOpportunities: string[];
}

interface IndustryInsightsProps {
  industry?: string;
}

export const IndustryInsights: React.FC<IndustryInsightsProps> = ({ industry }) => {
  const industryTrends: IndustryTrend[] = [
    {
      industry: 'Technology',
      growthRate: 28,
      keyCompanies: ['Apple', 'Microsoft', 'Google'],
      executiveMovements: 145,
      topRoles: ['CTO', 'VP Engineering', 'Chief Digital Officer']
    },
    {
      industry: 'Healthcare',
      growthRate: 22,
      keyCompanies: ['UnitedHealth', 'Johnson & Johnson', 'Pfizer'],
      executiveMovements: 98,
      topRoles: ['Chief Medical Officer', 'VP Operations', 'Regional Director']
    }
  ];

  const companyInsights: CompanyInsight[] = [
    {
      name: 'Microsoft',
      hiringIntensity: 85,
      recentExecutiveHires: 12,
      preferredBackgrounds: ['Enterprise Software', 'Cloud Infrastructure', 'AI/ML'],
      networkingOpportunities: ['Tech Leadership Summit', 'Cloud Computing Group', 'Digital Transformation Forum']
    }
  ];

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <TrendingUp sx={{ mr: 1 }} />
        Executive Market Intelligence
      </Typography>
      
      <Grid container spacing={3}>
        {/* Industry Trends */}
        <Grid item xs={12} md={7}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Industry Growth & Movement Analysis
              </Typography>
              {industryTrends.map((trend, index) => (
                <Box key={index} sx={{ mb: 4 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                    <Typography variant="subtitle1">
                      {trend.industry}
                    </Typography>
                    <Chip 
                      label={`${trend.growthRate}% Growth`}
                      color="primary"
                      size="small"
                    />
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={trend.growthRate} 
                    sx={{ mb: 2 }}
                  />
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {trend.executiveMovements} executive movements in last 90 days
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                    {trend.topRoles.map((role, idx) => (
                      <Chip
                        key={idx}
                        label={role}
                        size="small"
                        variant="outlined"
                      />
                    ))}
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Key Companies:
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {trend.keyCompanies.map((company, idx) => (
                      <Chip
                        key={idx}
                        label={company}
                        size="small"
                        variant="outlined"
                        icon={<Business />}
                      />
                    ))}
                  </Box>
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* Company Deep Dive */}
        <Grid item xs={12} md={5}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Company Intelligence
              </Typography>
              {companyInsights.map((company, index) => (
                <Box key={index}>
                  <Typography variant="subtitle1" gutterBottom>
                    {company.name}
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="Hiring Intensity"
                        secondary={
                          <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                            <LinearProgress 
                              variant="determinate" 
                              value={company.hiringIntensity} 
                              sx={{ flexGrow: 1, mr: 1 }}
                            />
                            <Typography variant="body2">
                              {company.hiringIntensity}%
                            </Typography>
                          </Box>
                        }
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Recent Executive Hires"
                        secondary={`${company.recentExecutiveHires} in last 90 days`}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Preferred Backgrounds"
                        secondary={
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                            {company.preferredBackgrounds.map((bg, idx) => (
                              <Chip
                                key={idx}
                                label={bg}
                                size="small"
                                variant="outlined"
                              />
                            ))}
                          </Box>
                        }
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Networking Opportunities"
                        secondary={
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                            {company.networkingOpportunities.map((opp, idx) => (
                              <Chip
                                key={idx}
                                label={opp}
                                size="small"
                                variant="outlined"
                                icon={<Person />}
                                onClick={() => {/* Handle networking opportunity */}}
                              />
                            ))}
                          </Box>
                        }
                      />
                    </ListItem>
                  </List>
                  <Button 
                    variant="outlined" 
                    fullWidth 
                    sx={{ mt: 2 }}
                    startIcon={<Timeline />}
                  >
                    Generate Connection Strategy
                  </Button>
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* AI Recommendations */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                AI-Powered Networking Recommendations
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle2" gutterBottom>
                    Best Connection Paths
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="Via John Smith (CTO at Microsoft)"
                        secondary="7 shared connections, same alumni network"
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Tech Leadership Summit Group"
                        secondary="Active discussion participation recommended"
                      />
                    </ListItem>
                  </List>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle2" gutterBottom>
                    Content Strategy
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="Share Cloud Computing Insights"
                        secondary="Aligns with Microsoft's current focus"
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Engage with Digital Transformation Posts"
                        secondary="High engagement from target executives"
                      />
                    </ListItem>
                  </List>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle2" gutterBottom>
                    Timing & Approach
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="Optimal Contact Times"
                        secondary="Tuesday/Thursday mornings (PST)"
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Recommended First Message"
                        secondary="Focus on shared cloud computing background"
                      />
                    </ListItem>
                  </List>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};
