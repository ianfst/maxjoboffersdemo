import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Box,
  CircularProgress,
  TextField,
  IconButton,
  Tooltip,
  Alert
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Edit as EditIcon,
  Download as DownloadIcon
} from '@mui/icons-material';
import { CanvaTemplate } from '../../types/linkedin';

interface CanvaIntegrationProps {
  open: boolean;
  onClose: () => void;
  blogTitle: string;
  onGenerate: (imageUrl: string) => void;
}

// Mock templates - in production, these would come from Canva API
const MOCK_TEMPLATES: CanvaTemplate[] = [
  {
    id: '1',
    name: 'Professional Blog Header',
    previewUrl: 'https://example.com/template1.jpg',
    category: 'blog',
    dimensions: { width: 1200, height: 628 }
  },
  {
    id: '2',
    name: 'Modern Article Cover',
    previewUrl: 'https://example.com/template2.jpg',
    category: 'article',
    dimensions: { width: 1200, height: 628 }
  },
  {
    id: '3',
    name: 'Business Insights',
    previewUrl: 'https://example.com/template3.jpg',
    category: 'business',
    dimensions: { width: 1200, height: 628 }
  }
];

const CanvaIntegration: React.FC<CanvaIntegrationProps> = ({
  open,
  onClose,
  blogTitle,
  onGenerate
}) => {
  const [templates, setTemplates] = useState<CanvaTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<CanvaTemplate | null>(null);
  const [customText, setCustomText] = useState(blogTitle);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedUrl, setGeneratedUrl] = useState<string | null>(null);

  useEffect(() => {
    // In production, this would fetch templates from Canva API
    setTemplates(MOCK_TEMPLATES);
    setCustomText(blogTitle);
  }, [blogTitle]);

  const handleGenerate = async (template: CanvaTemplate) => {
    if (!template) return;

    try {
      setLoading(true);
      setError(null);
      setSelectedTemplate(template);

      // Mock API call to Canva
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock generated image URL
      const mockUrl = `https://example.com/generated-${template.id}.jpg`;
      setGeneratedUrl(mockUrl);
      await onGenerate(mockUrl);
    } catch (err) {
      console.error('Failed to generate image:', err);
      setError('Failed to generate image');
    } finally {
      setLoading(false);
    }
  };

  const handleRefreshTemplates = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock API call to refresh templates
      await new Promise(resolve => setTimeout(resolve, 1000));
      setTemplates(MOCK_TEMPLATES.sort(() => Math.random() - 0.5));
    } catch (err) {
      console.error('Failed to refresh templates:', err);
      setError('Failed to refresh templates');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      aria-labelledby="canva-dialog-title"
    >
      <DialogTitle id="canva-dialog-title">
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="h6">
            Generate Infographic with Canva
          </Typography>
          <Tooltip title="Refresh Templates">
            <IconButton
              onClick={handleRefreshTemplates}
              disabled={loading}
              aria-label="Refresh Templates"
            >
              <RefreshIcon />
            </IconButton>
          </Tooltip>
        </Box>
      </DialogTitle>

      <DialogContent>
        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            label="Infographic Title"
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            margin="normal"
            inputProps={{ 'aria-label': 'Infographic Title' }}
          />
        </Box>

        <Typography variant="subtitle1" gutterBottom>
          Select a Template
        </Typography>

        <Grid container spacing={2}>
          {templates.map((template) => (
            <Grid item xs={12} sm={6} md={4} key={template.id}>
              <Card
                sx={{
                  cursor: 'pointer',
                  border: selectedTemplate?.id === template.id
                    ? '2px solid primary.main'
                    : 'none'
                }}
                onClick={() => handleGenerate(template)}
                role="button"
                aria-label={`Select ${template.name} Template`}
                tabIndex={0}
              >
                <CardMedia
                  component="img"
                  height="140"
                  image={template.previewUrl}
                  alt={template.name}
                />
                <CardContent>
                  <Typography variant="subtitle2">
                    {template.name}
                  </Typography>
                  <Typography variant="caption" color="textSecondary" component="p">
                    {`${template.dimensions.width} x ${template.dimensions.height}`}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <CircularProgress role="progressbar" aria-label="Generating infographic" />
          </Box>
        )}

        {error && (
          <Alert severity="error" sx={{ mt: 2 }} role="alert">
            {error}
          </Alert>
        )}

        {generatedUrl && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Generated Infographic
            </Typography>
            <Card>
              <CardMedia
                component="img"
                height="300"
                image={generatedUrl}
                alt="Generated Infographic"
              />
            </Card>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} aria-label="Cancel">
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export { CanvaIntegration };
