import React, { useState, useEffect } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Typography,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  Chip,
  IconButton,
  Tooltip,
  Alert
} from '@mui/material';
import {
  Edit as EditIcon,
  Preview as PreviewIcon,
  Schedule as ScheduleIcon,
  PostAdd as PostAddIcon,
  Help as HelpIcon
} from '@mui/icons-material';
import { BlogSeries, BlogOutline, Blog, LinkedInGroup } from '../../types/linkedin';
import { BlogEditor } from './BlogEditor';
import { ScheduleManager } from './ScheduleManager';
import { GroupSelector } from './GroupSelector';
import { HashtagManager } from './HashtagManager';
import { CanvaIntegration } from './CanvaIntegration';

interface LinkedInBlogCreatorProps {
  onSave: (series: BlogSeries) => Promise<void>;
  onPublish: (blog: Blog) => Promise<void>;
  onGenerateInfographic: (title: string) => Promise<string>;
}

const LinkedInBlogCreator: React.FC<LinkedInBlogCreatorProps> = ({
  onSave,
  onPublish,
  onGenerateInfographic
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const [currentSeries, setCurrentSeries] = useState<BlogSeries | null>(null);
  const [outline, setOutline] = useState<BlogOutline | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openPreview, setOpenPreview] = useState(false);

  const steps = [
    'Create Series Outline',
    'Review and Approve',
    'Generate Content',
    'Schedule Posts'
  ];

  useEffect(() => {
    // Load any saved progress
    const savedProgress = localStorage.getItem('linkedinBlogCreator');
    if (savedProgress) {
      try {
        const { series, outline } = JSON.parse(savedProgress);
        setCurrentSeries(series);
        setOutline(outline);
      } catch (err) {
        console.error('Failed to load saved progress:', err);
        setError('Failed to load saved progress');
      }
    }
  }, []);

  const handleOutlineGeneration = async (topic: string, partCount: number) => {
    try {
      // Create outline structure
      const newOutline: BlogOutline = {
        seriesTitle: topic,
        description: `A ${partCount}-part series about ${topic}`,
        partCount,
        blogTitles: Array.from({ length: partCount }, (_, i) => `Part ${i + 1}: ${topic}`),
        targetGroups: [],
        suggestedHashtags: [topic.toLowerCase().replace(/\s+/g, '')]
      };

      setOutline(newOutline);
      localStorage.setItem('linkedinBlogCreator', JSON.stringify({
        series: currentSeries,
        outline: newOutline
      }));

      return newOutline;
    } catch (err) {
      console.error('Failed to generate outline:', err);
      setError('Failed to generate outline');
      throw err;
    }
  };

  const handleOutlineApproval = async () => {
    if (!outline) return;

    try {
      const newSeries: BlogSeries = {
        id: crypto.randomUUID(),
        title: outline.seriesTitle,
        description: outline.description,
        partCount: outline.partCount,
        status: 'approved',
        blogs: outline.blogTitles.map((title, index) => ({
          id: crypto.randomUUID(),
          seriesId: '', // Will be set after series creation
          partNumber: index + 1,
          title,
          content: '',
          wordCount: 0,
          status: 'draft',
          postedTo: [],
          hashtags: outline.suggestedHashtags,
          createdAt: new Date(),
          updatedAt: new Date()
        })),
        targetGroups: outline.targetGroups,
        hashtags: outline.suggestedHashtags,
        createdAt: new Date(),
        updatedAt: new Date()
      };

      // Update series IDs
      newSeries.blogs = newSeries.blogs.map(blog => ({
        ...blog,
        seriesId: newSeries.id
      }));

      await onSave(newSeries);
      setCurrentSeries(newSeries);
      setActiveStep(2);
    } catch (err) {
      console.error('Failed to approve outline:', err);
      setError('Failed to approve outline');
    }
  };

  const handleContentGeneration = async (blog: Blog) => {
    try {
      // Generate infographic
      const infographicUrl = await onGenerateInfographic(blog.title);
      
      // Update blog with infographic
      const updatedBlog = {
        ...blog,
        infographicUrl,
        status: 'approved' as const
      };

      // Update series
      if (currentSeries) {
        const updatedSeries = {
          ...currentSeries,
          blogs: currentSeries.blogs.map(b =>
            b.id === blog.id ? updatedBlog : b
          )
        };
        await onSave(updatedSeries);
        setCurrentSeries(updatedSeries);
      }
    } catch (err) {
      console.error('Failed to generate content:', err);
      setError('Failed to generate content');
    }
  };

  const handleScheduling = async (blog: Blog, scheduledFor: Date) => {
    try {
      const updatedBlog = {
        ...blog,
        scheduledFor,
        status: 'scheduled' as const
      };

      if (currentSeries) {
        const updatedSeries = {
          ...currentSeries,
          blogs: currentSeries.blogs.map(b =>
            b.id === blog.id ? updatedBlog : b
          )
        };
        await onSave(updatedSeries);
        setCurrentSeries(updatedSeries);
      }
    } catch (err) {
      console.error('Failed to schedule blog:', err);
      setError('Failed to schedule blog');
    }
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Create Series Outline
            </Typography>
            <Box sx={{ mt: 2 }}>
              <TextField
                label="Series Title"
                variant="outlined"
                fullWidth
                sx={{ mb: 2 }}
              />
              <TextField
                label="Number of Parts"
                variant="outlined"
                type="number"
                fullWidth
                sx={{ mb: 2 }}
              />
              <Button
                variant="contained"
                onClick={() => handleOutlineGeneration('Test Series', 3)}
              >
                Generate Outline
              </Button>
            </Box>
          </Box>
        );
      case 1:
        return outline ? (
          <Box>
            <Typography variant="h6" gutterBottom>
              Review Series Outline
            </Typography>
            <Card>
              <CardContent>
                <Typography variant="h5" gutterBottom>
                  {outline.seriesTitle}
                </Typography>
                <Typography variant="body1" paragraph>
                  {outline.description}
                </Typography>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Blog Posts ({outline.partCount}):
                  </Typography>
                  {outline.blogTitles.map((title, index) => (
                    <Typography key={index} variant="body2">
                      {index + 1}. {title}
                    </Typography>
                  ))}
                </Box>
                <Box>
                  <Typography variant="subtitle1" gutterBottom>
                    Suggested Hashtags:
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {outline.suggestedHashtags.map((tag) => (
                      <Chip key={tag} label={`#${tag}`} />
                    ))}
                  </Box>
                </Box>
              </CardContent>
            </Card>
            <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                variant="contained"
                onClick={handleOutlineApproval}
              >
                Approve Outline
              </Button>
            </Box>
          </Box>
        ) : null;
      case 2:
        return currentSeries ? (
          <BlogEditor
            series={currentSeries}
            onGenerate={handleContentGeneration}
          />
        ) : null;
      case 3:
        return currentSeries ? (
          <ScheduleManager
            series={currentSeries}
            onSchedule={handleScheduling}
          />
        ) : null;
      default:
        return null;
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        LinkedIn Blog Creator
        <Tooltip title="Create and schedule a series of professional LinkedIn blog posts">
          <IconButton size="small" sx={{ ml: 1 }}>
            <HelpIcon />
          </IconButton>
        </Tooltip>
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {renderStepContent()}

      <Box sx={{ mt: 4, display: 'flex', justifyContent: 'space-between' }}>
        <Button
          onClick={() => setActiveStep((prev) => prev - 1)}
          disabled={activeStep === 0}
        >
          Back
        </Button>
        <Button
          variant="contained"
          onClick={() => setActiveStep((prev) => prev + 1)}
          disabled={
            activeStep === steps.length - 1 ||
            (activeStep === 0 && !outline) ||
            (activeStep === 1 && !currentSeries)
          }
        >
          {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
        </Button>
      </Box>
    </Box>
  );
};

export { LinkedInBlogCreator };
