import React, { useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  Button,
  Card,
  CardContent,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Chip,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Business,
  Group,
  Message,
  Timeline,
  TrendingUp,
  PersonAdd,
  CheckCircle,
  Schedule,
} from '@mui/icons-material';
import { NetworkingCampaign, LinkedInConnection } from '../../types/linkedin';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`networking-tabpanel-${index}`}
      aria-labelledby={`networking-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
};

export const NetworkingDashboard: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);
  const [activeCampaign, setActiveCampaign] = useState<NetworkingCampaign | null>(null);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const campaignMetrics = {
    totalConnections: 150,
    pendingRequests: 45,
    messagesExchanged: 280,
    meetingsScheduled: 12,
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ py: 4 }}>
        {/* Header */}
        <Grid container spacing={3} alignItems="center" sx={{ mb: 4 }}>
          <Grid item xs={12} md={8}>
            <Typography variant="h4" gutterBottom>
              Strategic Networking Dashboard
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Leverage our AI-powered networking system to build meaningful connections
            </Typography>
          </Grid>
          <Grid item xs={12} md={4} sx={{ textAlign: 'right' }}>
            <Button
              variant="contained"
              startIcon={<Business />}
              size="large"
              onClick={() => {/* Launch new campaign */}}
            >
              Launch New Campaign
            </Button>
          </Grid>
        </Grid>

        {/* Metrics Overview */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <PersonAdd color="primary" />
                  <Typography variant="h6" sx={{ ml: 1 }}>
                    Total Connections
                  </Typography>
                </Box>
                <Typography variant="h3">{campaignMetrics.totalConnections}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Across all campaigns
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Schedule color="warning" />
                  <Typography variant="h6" sx={{ ml: 1 }}>
                    Pending Requests
                  </Typography>
                </Box>
                <Typography variant="h3">{campaignMetrics.pendingRequests}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Awaiting response
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Message color="info" />
                  <Typography variant="h6" sx={{ ml: 1 }}>
                    Messages
                  </Typography>
                </Box>
                <Typography variant="h3">{campaignMetrics.messagesExchanged}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Conversations started
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <CheckCircle color="success" />
                  <Typography variant="h6" sx={{ ml: 1 }}>
                    Meetings
                  </Typography>
                </Box>
                <Typography variant="h3">{campaignMetrics.meetingsScheduled}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Successfully scheduled
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Main Content */}
        <Paper sx={{ mb: 4 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            aria-label="networking tabs"
            sx={{ borderBottom: 1, borderColor: 'divider' }}
          >
            <Tab icon={<Timeline />} label="Active Campaigns" />
            <Tab icon={<Group />} label="Connection Manager" />
            <Tab icon={<Message />} label="Message Templates" />
            <Tab icon={<TrendingUp />} label="Analytics" />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            <Typography variant="h6" gutterBottom>
              Active Networking Campaigns
            </Typography>
            {/* Campaign list would go here */}
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            <Typography variant="h6" gutterBottom>
              Connection Manager
            </Typography>
            {/* Connection management interface would go here */}
          </TabPanel>

          <TabPanel value={tabValue} index={2}>
            <Typography variant="h6" gutterBottom>
              Message Templates
            </Typography>
            {/* Message template manager would go here */}
          </TabPanel>

          <TabPanel value={tabValue} index={3}>
            <Typography variant="h6" gutterBottom>
              Networking Analytics
            </Typography>
            {/* Analytics dashboard would go here */}
          </TabPanel>
        </Paper>

        {/* AI Recommendations */}
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            AI-Powered Recommendations
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="subtitle1" color="primary" gutterBottom>
                    Best Time to Connect
                  </Typography>
                  <Typography variant="body2">
                    Based on your target audience's activity patterns, the best times to send connection requests are:
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText primary="Tuesday 9-11 AM" secondary="High acceptance rate" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="Thursday 2-4 PM" secondary="Quick response time" />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="subtitle1" color="primary" gutterBottom>
                    Message Optimization
                  </Typography>
                  <Typography variant="body2">
                    Your message templates are performing well. Consider these adjustments:
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="Add more personalization" 
                        secondary="Messages with custom research have 3x higher response rate" 
                      />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="subtitle1" color="primary" gutterBottom>
                    Network Expansion
                  </Typography>
                  <Typography variant="body2">
                    Recommended groups to join based on your target companies:
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemText 
                        primary="Executive Leadership Forum" 
                        secondary="15 target company employees active" 
                      />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Container>
  );
};
