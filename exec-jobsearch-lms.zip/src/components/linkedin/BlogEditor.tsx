import React, { useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  IconButton,
  Card,
  CardContent,
  Grid,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Tooltip
} from '@mui/material';
import {
  Preview as PreviewIcon,
  Image as ImageIcon,
  Save as SaveIcon
} from '@mui/icons-material';
import { BlogSeries, Blog } from '../../types/linkedin';
import { HashtagManager } from './HashtagManager';
import { CanvaIntegration } from './CanvaIntegration';

interface BlogEditorProps {
  series: BlogSeries;
  onGenerate: (blog: Blog) => Promise<void>;
}

export const BlogEditor: React.FC<BlogEditorProps> = ({
  series,
  onGenerate
}) => {
  const [selectedBlog, setSelectedBlog] = useState<Blog | null>(series.blogs[0]);
  const [content, setContent] = useState(series.blogs[0]?.content || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showCanva, setShowCanva] = useState(false);

  const handleContentChange = (text: string) => {
    setContent(text);
    if (selectedBlog) {
      const words = text.trim().split(/\s+/).filter(word => word.length > 0).length;
      setSelectedBlog({
        ...selectedBlog,
        content: text,
        wordCount: words
      });
    }
  };

  const handleGenerate = async () => {
    if (!selectedBlog) return;

    try {
      setLoading(true);
      setError(null);
      await onGenerate({
        ...selectedBlog,
        content,
        wordCount: content.trim().split(/\s+/).filter(word => word.length > 0).length
      });
    } catch (err) {
      setError('Failed to generate blog content');
      console.error('Failed to generate blog content:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleHashtagChange = (hashtags: string[]) => {
    if (selectedBlog) {
      setSelectedBlog({
        ...selectedBlog,
        hashtags
      });
    }
  };

  const handleInfographicGenerate = (url: string) => {
    if (selectedBlog) {
      const updatedBlog = {
        ...selectedBlog,
        infographicUrl: url
      };
      setSelectedBlog(updatedBlog);
      series.blogs[0] = updatedBlog;  // Update the mock series for testing
      setShowCanva(false);
    }
  };

  const isValidWordCount = content.trim().split(/\s+/).filter(word => word.length > 0).length >= 175 &&
    content.trim().split(/\s+/).filter(word => word.length > 0).length <= 250;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Blog Series: {series.title}
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={2}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  {selectedBlog?.title}
                </Typography>
                <Box sx={{ ml: 'auto' }}>
                  <IconButton 
                    onClick={() => setShowCanva(true)}
                    aria-label="Generate Infographic"
                  >
                    <ImageIcon />
                  </IconButton>
                  <IconButton 
                    onClick={() => setShowPreview(true)}
                    data-testid="preview-button"
                  >
                    <PreviewIcon />
                  </IconButton>
                </Box>
              </Box>

              <TextField
                fullWidth
                multiline
                rows={10}
                placeholder="Write your blog content here (175-250 words)"
                value={content}
                onChange={(e) => handleContentChange(e.target.value)}
                error={content.length > 0 && !isValidWordCount}
                helperText={`${content.trim().split(/\s+/).filter(word => word.length > 0).length} words (175-250 required)`}
                inputProps={{
                  'aria-label': 'Blog content editor',
                  role: 'textbox'
                }}
              />

              <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  variant="contained"
                  startIcon={loading ? <CircularProgress size={20} /> : <SaveIcon />}
                  onClick={handleGenerate}
                  disabled={loading || !isValidWordCount}
                >
                  {loading ? 'Generating...' : 'Generate & Save'}
                </Button>
              </Box>
            </CardContent>
          </Card>

          <Box sx={{ mt: 2 }}>
            <HashtagManager
              hashtags={selectedBlog?.hashtags || []}
              onChange={handleHashtagChange}
            />
          </Box>
        </Grid>
      </Grid>

      <Dialog
        open={showPreview}
        onClose={() => setShowPreview(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Blog Preview</DialogTitle>
        <DialogContent>
          <Typography variant="h6" gutterBottom>
            {selectedBlog?.title}
          </Typography>
          <Typography variant="body1" paragraph>
            {content}
          </Typography>
          <Box sx={{ mt: 2 }}>
            {selectedBlog?.hashtags.map(tag => (
              <Typography key={tag} component="span" sx={{ mr: 1, color: 'primary.main' }}>
                #{tag}
              </Typography>
            ))}
          </Box>
          {selectedBlog?.infographicUrl && (
            <Box sx={{ mt: 2 }}>
              <img 
                src={selectedBlog.infographicUrl} 
                alt="Blog infographic" 
                style={{ maxWidth: '100%', height: 'auto' }}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowPreview(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={showCanva}
        onClose={() => setShowCanva(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Generate Infographic</DialogTitle>
        <DialogContent>
          <CanvaIntegration
            open={showCanva}
            onClose={() => setShowCanva(false)}
            blogTitle={selectedBlog?.title || ''}
            onGenerate={handleInfographicGenerate}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowCanva(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
