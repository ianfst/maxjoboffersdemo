import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Checkbox,
  FormControlLabel,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Alert,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { securityUtils } from '../../utils/securityUtils';

interface ConsentSettings {
  marketingConsent: boolean;
  aiDataProcessing: boolean;
  termsAccepted: boolean;
  privacyAccepted: boolean;
  timestamp: string;
  version: string;
}

const CONSENT_VERSION = '1.0.0';

export const ConsentManager: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [consents, setConsents] = useState<ConsentSettings>({
    marketingConsent: false,
    aiDataProcessing: false,
    termsAccepted: false,
    privacyAccepted: false,
    timestamp: '',
    version: CONSENT_VERSION,
  });

  useEffect(() => {
    const savedConsents = securityUtils.getSecureItem('userConsents');
    if (!savedConsents || JSON.parse(savedConsents).version !== CONSENT_VERSION) {
      setOpen(true);
    } else {
      setConsents(JSON.parse(savedConsents));
    }
  }, []);

  const handleSave = () => {
    const updatedConsents = {
      ...consents,
      timestamp: new Date().toISOString(),
    };
    securityUtils.setSecureItem('userConsents', JSON.stringify(updatedConsents));
    setOpen(false);
  };

  const handleChange = (field: keyof ConsentSettings) => (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setConsents((prev) => ({
      ...prev,
      [field]: event.target.checked,
    }));
  };

  const isValid = consents.termsAccepted && consents.privacyAccepted;

  return (
    <Dialog
      open={open}
      maxWidth="md"
      fullWidth
      disableEscapeKeyDown
      disableBackdropClick
    >
      <DialogTitle>
        <Typography variant="h5" component="div">
          Privacy & Consent Settings
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Alert severity="info" sx={{ mb: 2 }}>
          Please review and accept our terms to continue using our services.
        </Alert>

        <Accordion defaultExpanded>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography fontWeight="bold">Terms of Service & Liability Waiver</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography paragraph>
              By using our services, you acknowledge and agree that:
            </Typography>
            <Typography component="div" sx={{ mb: 2 }}>
              <ul>
                <li>The information provided is for general guidance only and does not constitute professional advice.</li>
                <li>We are not liable for any decisions, actions, or outcomes resulting from the use of our services.</li>
                <li>You release us from all claims, damages, and liabilities arising from the use of our platform.</li>
                <li>We make no guarantees regarding job placement, financial outcomes, or service effectiveness.</li>
              </ul>
            </Typography>
            <FormControlLabel
              control={
                <Checkbox
                  checked={consents.termsAccepted}
                  onChange={handleChange('termsAccepted')}
                />
              }
              label="I accept the Terms of Service and Liability Waiver"
            />
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography fontWeight="bold">AI Data Processing Consent</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography paragraph>
              We use artificial intelligence to process your information and provide personalized services.
              This includes:
            </Typography>
            <Typography component="div" sx={{ mb: 2 }}>
              <ul>
                <li>Analysis of your professional background and career goals</li>
                <li>Processing of personal contact information</li>
                <li>Generation of personalized recommendations and insights</li>
                <li>Secure storage and handling of your data</li>
              </ul>
            </Typography>
            <FormControlLabel
              control={
                <Checkbox
                  checked={consents.aiDataProcessing}
                  onChange={handleChange('aiDataProcessing')}
                />
              }
              label="I consent to AI processing of my data"
            />
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography fontWeight="bold">Marketing & Communications Consent</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography paragraph>
              By accepting, you grant us comprehensive permission to:
            </Typography>
            <Typography component="div" sx={{ mb: 2 }}>
              <ul>
                <li>Contact you about our full range of career development services</li>
                <li>Share information about financial planning and wealth management opportunities</li>
                <li>Provide updates about professional development and educational resources</li>
                <li>Inform you about related services including, but not limited to:
                  <ul>
                    <li>Career coaching and professional development</li>
                    <li>Financial planning and investment services</li>
                    <li>Retirement and estate planning</li>
                    <li>Insurance and healthcare planning</li>
                    <li>Professional networking opportunities</li>
                    <li>Any future services within the professional development ecosystem</li>
                  </ul>
                </li>
              </ul>
            </Typography>
            <FormControlLabel
              control={
                <Checkbox
                  checked={consents.marketingConsent}
                  onChange={handleChange('marketingConsent')}
                />
              }
              label="I accept comprehensive marketing communications"
            />
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography fontWeight="bold">Privacy Policy</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography paragraph>
              Our privacy policy details how we collect, use, and protect your personal information.
              Key points include:
            </Typography>
            <Typography component="div" sx={{ mb: 2 }}>
              <ul>
                <li>Secure encryption of personal data</li>
                <li>Strict data handling procedures</li>
                <li>Third-party data sharing policies</li>
                <li>Your data access and control rights</li>
              </ul>
            </Typography>
            <FormControlLabel
              control={
                <Checkbox
                  checked={consents.privacyAccepted}
                  onChange={handleChange('privacyAccepted')}
                />
              }
              label="I accept the Privacy Policy"
            />
          </AccordionDetails>
        </Accordion>
      </DialogContent>
      <DialogActions>
        <Box sx={{ p: 2, width: '100%' }}>
          <Button
            variant="contained"
            fullWidth
            onClick={handleSave}
            disabled={!isValid}
            color="primary"
          >
            Accept and Continue
          </Button>
          {!isValid && (
            <Typography color="error" sx={{ mt: 1, textAlign: 'center' }}>
              Please accept the Terms of Service and Privacy Policy to continue
            </Typography>
          )}
        </Box>
      </DialogActions>
    </Dialog>
  );
};
