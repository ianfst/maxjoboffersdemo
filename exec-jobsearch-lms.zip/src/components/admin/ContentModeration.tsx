import React, { useState, useCallback } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Paper,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Chip,
  Tooltip,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  TableSortLabel,
  Snackbar,
} from '@mui/material';
import {
  Check as CheckIcon,
  Close as CloseIcon,
  Preview as PreviewIcon,
  History as HistoryIcon,
} from '@mui/icons-material';
import { BlogPost } from '../../types/blog';
import { useQuery, useMutation } from 'react-query';
import api from '../../api/config';
import { debounce } from 'lodash';

interface ContentModerationProps {
  posts: BlogPost[];
  onStatusChange: (postId: string, status: 'approved' | 'rejected') => void;
}

interface SortConfig {
  field: keyof BlogPost | '';
  direction: 'asc' | 'desc';
}

interface FilterConfig {
  status: string;
  author: string;
  dateRange: {
    start: string;
    end: string;
  };
}

interface AuditLog {
  timestamp: string;
  action: string;
  user: string;
  details: string;
}

export const ContentModeration: React.FC<ContentModerationProps> = ({ posts: initialPosts, onStatusChange }) => {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedPosts, setSelectedPosts] = useState<string[]>([]);
  const [previewPost, setPreviewPost] = useState<BlogPost | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{ open: boolean; postId: string; action: 'approved' | 'rejected' } | null>(null);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ field: '', direction: 'asc' });
  const [filterConfig, setFilterConfig] = useState<FilterConfig>({
    status: 'all',
    author: '',
    dateRange: { start: '', end: '' },
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success',
  });
  const [auditLogOpen, setAuditLogOpen] = useState(false);
  const [selectedPostAuditLog, setSelectedPostAuditLog] = useState<string | null>(null);

  // Fetch posts with filters and sorting
  const { data: filteredPosts, isLoading } = useQuery(
    ['posts', filterConfig, sortConfig],
    async () => {
      const response = await api.get('/api/posts/moderate', {
        params: {
          status: filterConfig.status,
          author: filterConfig.author,
          startDate: filterConfig.dateRange.start,
          endDate: filterConfig.dateRange.end,
          sortField: sortConfig.field,
          sortDirection: sortConfig.direction,
        },
      });
      return response.data.posts;
    },
    {
      initialData: initialPosts,
    }
  );

  // Fetch audit logs
  const { data: auditLogs } = useQuery(
    ['auditLogs', selectedPostAuditLog],
    async () => {
      if (!selectedPostAuditLog) return [];
      const response = await api.get(`/api/posts/${selectedPostAuditLog}/audit-log`);
      return response.data.logs;
    },
    {
      enabled: !!selectedPostAuditLog,
    }
  );

  const handleStatusChange = async (postId: string, status: 'approved' | 'rejected') => {
    try {
      await onStatusChange(postId, status);
      setSnackbar({
        open: true,
        message: `Post ${status} successfully`,
        severity: 'success',
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `Error: Failed to ${status} post`,
        severity: 'error',
      });
    }
  };

  const handleBulkAction = async (action: 'approved' | 'rejected') => {
    try {
      await Promise.all(
        selectedPosts.map((postId) => handleStatusChange(postId, action))
      );
      setSelectedPosts([]);
    } catch (error) {
      setSnackbar({
        open: true,
        message: 'Error performing bulk action',
        severity: 'error',
      });
    }
  };

  const handleSort = (field: keyof BlogPost) => {
    setSortConfig((prev) => ({
      field,
      direction:
        prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const handleFilterChange = useCallback(
    debounce((newFilter: Partial<FilterConfig>) => {
      setFilterConfig((prev) => ({ ...prev, ...newFilter }));
    }, 300),
    []
  );

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      setSelectedPosts(filteredPosts.map((post) => post.id));
    } else {
      setSelectedPosts([]);
    }
  };

  const handleRowSelect = (postId: string) => {
    setSelectedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId]
    );
  };

  return (
    <Box>
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6">Content Moderation</Typography>
        <Box>
          <Button
            variant="contained"
            color="success"
            disabled={selectedPosts.length === 0}
            onClick={() => handleBulkAction('approved')}
            sx={{ mr: 1 }}
          >
            Approve Selected
          </Button>
          <Button
            variant="contained"
            color="error"
            disabled={selectedPosts.length === 0}
            onClick={() => handleBulkAction('rejected')}
          >
            Reject Selected
          </Button>
        </Box>
      </Box>

      {/* Filters */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Box display="flex" gap={2}>
          <FormControl size="small">
            <InputLabel>Status</InputLabel>
            <Select
              value={filterConfig.status}
              onChange={(e) => handleFilterChange({ status: e.target.value })}
              label="Status"
            >
              <MenuItem value="all">All</MenuItem>
              <MenuItem value="pending">Pending</MenuItem>
              <MenuItem value="approved">Approved</MenuItem>
              <MenuItem value="rejected">Rejected</MenuItem>
            </Select>
          </FormControl>
          <TextField
            size="small"
            label="Author"
            value={filterConfig.author}
            onChange={(e) => handleFilterChange({ author: e.target.value })}
          />
          <TextField
            size="small"
            type="date"
            label="Start Date"
            value={filterConfig.dateRange.start}
            onChange={(e) =>
              handleFilterChange({
                dateRange: { ...filterConfig.dateRange, start: e.target.value },
              })
            }
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            size="small"
            type="date"
            label="End Date"
            value={filterConfig.dateRange.end}
            onChange={(e) =>
              handleFilterChange({
                dateRange: { ...filterConfig.dateRange, end: e.target.value },
              })
            }
            InputLabelProps={{ shrink: true }}
          />
        </Box>
      </Paper>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell padding="checkbox">
                <Checkbox
                  indeterminate={selectedPosts.length > 0 && selectedPosts.length < filteredPosts.length}
                  checked={selectedPosts.length === filteredPosts.length}
                  onChange={handleSelectAllClick}
                />
              </TableCell>
              <TableCell>
                <TableSortLabel
                  active={sortConfig.field === 'title'}
                  direction={sortConfig.direction}
                  onClick={() => handleSort('title')}
                >
                  Title
                </TableSortLabel>
              </TableCell>
              <TableCell>
                <TableSortLabel
                  active={sortConfig.field === 'author'}
                  direction={sortConfig.direction}
                  onClick={() => handleSort('author')}
                >
                  Author
                </TableSortLabel>
              </TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(filteredPosts || [])
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((post) => (
                <TableRow key={post.id}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedPosts.includes(post.id)}
                      onChange={() => handleRowSelect(post.id)}
                    />
                  </TableCell>
                  <TableCell>{post.title}</TableCell>
                  <TableCell>{post.author.name}</TableCell>
                  <TableCell>
                    <Chip
                      label={post.status}
                      color={
                        post.status === 'approved'
                          ? 'success'
                          : post.status === 'rejected'
                          ? 'error'
                          : 'default'
                      }
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Tooltip title="Preview">
                      <IconButton
                        size="small"
                        onClick={() => setPreviewPost(post)}
                      >
                        <PreviewIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="View History">
                      <IconButton
                        size="small"
                        onClick={() => {
                          setSelectedPostAuditLog(post.id);
                          setAuditLogOpen(true);
                        }}
                      >
                        <HistoryIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Approve">
                      <IconButton
                        size="small"
                        onClick={() =>
                          setConfirmDialog({
                            open: true,
                            postId: post.id,
                            action: 'approved',
                          })
                        }
                        color={post.status === 'approved' ? 'success' : 'default'}
                      >
                        <CheckIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Reject">
                      <IconButton
                        size="small"
                        onClick={() =>
                          setConfirmDialog({
                            open: true,
                            postId: post.id,
                            action: 'rejected',
                          })
                        }
                        color={post.status === 'rejected' ? 'error' : 'default'}
                      >
                        <CloseIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={filteredPosts?.length || 0}
          page={page}
          onPageChange={(_, newPage) => setPage(newPage)}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
        />
      </TableContainer>

      {/* Preview Dialog */}
      <Dialog
        open={!!previewPost}
        onClose={() => setPreviewPost(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>{previewPost?.title}</DialogTitle>
        <DialogContent>
          <Typography variant="subtitle1" gutterBottom>
            By {previewPost?.author.name}
          </Typography>
          <Typography>{previewPost?.content}</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewPost(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog
        open={!!confirmDialog?.open}
        onClose={() => setConfirmDialog(null)}
      >
        <DialogTitle>
          Confirm {confirmDialog?.action === 'approved' ? 'Approve' : 'Reject'}
        </DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to{' '}
            {confirmDialog?.action === 'approved' ? 'approve' : 'reject'} this
            post?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialog(null)}>Cancel</Button>
          <Button
            onClick={() => {
              if (confirmDialog) {
                handleStatusChange(confirmDialog.postId, confirmDialog.action);
                setConfirmDialog(null);
              }
            }}
            color={confirmDialog?.action === 'approved' ? 'success' : 'error'}
            variant="contained"
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Audit Log Dialog */}
      <Dialog
        open={auditLogOpen}
        onClose={() => {
          setAuditLogOpen(false);
          setSelectedPostAuditLog(null);
        }}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Moderation History</DialogTitle>
        <DialogContent>
          {auditLogs?.map((log: AuditLog) => (
            <Box key={log.timestamp} sx={{ mb: 2 }}>
              <Typography variant="subtitle2">
                {new Date(log.timestamp).toLocaleString()}
              </Typography>
              <Typography>
                {log.user} - {log.action}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {log.details}
              </Typography>
            </Box>
          ))}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setAuditLogOpen(false);
            setSelectedPostAuditLog(null);
          }}>
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};
