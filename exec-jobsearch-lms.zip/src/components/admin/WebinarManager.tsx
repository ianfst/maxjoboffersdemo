import React, { useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Typography,
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { format } from 'date-fns';
import api from '../../api/config';

interface Webinar {
  id: number;
  title: string;
  description: string;
  datetime: string;
  registrationUrl: string;
  gotowebinarId: string;
}

export const WebinarManager = () => {
  const [open, setOpen] = useState(false);
  const [editingWebinar, setEditingWebinar] = useState<Partial<Webinar> | null>(null);
  const queryClient = useQueryClient();

  const { data: webinars } = useQuery<Webinar[]>('webinars', async () => {
    const response = await api.get('/api/webinars');
    return response.data;
  });

  const updateMutation = useMutation(
    async (webinar: Partial<Webinar>) => {
      if (webinar.id) {
        await api.put(`/api/webinars/${webinar.id}`, webinar);
      } else {
        await api.post('/api/webinars', webinar);
      }
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('webinars');
        setOpen(false);
        setEditingWebinar(null);
      },
    }
  );

  const handleEdit = (webinar: Webinar) => {
    setEditingWebinar(webinar);
    setOpen(true);
  };

  const handleSave = async () => {
    if (editingWebinar) {
      await updateMutation.mutateAsync(editingWebinar);
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Manage Webinars</Typography>
        <Button
          variant="contained"
          onClick={() => {
            setEditingWebinar({});
            setOpen(true);
          }}
        >
          Add Webinar
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>Title</TableCell>
              <TableCell>Registration URL</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {webinars?.map((webinar) => (
              <TableRow key={webinar.id}>
                <TableCell>
                  {format(new Date(webinar.datetime), 'MMM d, yyyy h:mm a')}
                </TableCell>
                <TableCell>{webinar.title}</TableCell>
                <TableCell>{webinar.registrationUrl}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleEdit(webinar)} size="small">
                    <EditIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingWebinar?.id ? 'Edit Webinar' : 'Add Webinar'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 2 }}>
            <TextField
              label="Title"
              value={editingWebinar?.title || ''}
              onChange={(e) =>
                setEditingWebinar((prev) => ({
                  ...prev,
                  title: e.target.value,
                }))
              }
              fullWidth
            />
            <TextField
              label="Description"
              value={editingWebinar?.description || ''}
              onChange={(e) =>
                setEditingWebinar((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
              multiline
              rows={3}
              fullWidth
            />
            <TextField
              label="Date and Time"
              type="datetime-local"
              value={editingWebinar?.datetime?.slice(0, 16) || ''}
              onChange={(e) =>
                setEditingWebinar((prev) => ({
                  ...prev,
                  datetime: e.target.value,
                }))
              }
              fullWidth
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              label="GoToWebinar Registration URL"
              value={editingWebinar?.registrationUrl || ''}
              onChange={(e) =>
                setEditingWebinar((prev) => ({
                  ...prev,
                  registrationUrl: e.target.value,
                }))
              }
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSave} variant="contained" color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
