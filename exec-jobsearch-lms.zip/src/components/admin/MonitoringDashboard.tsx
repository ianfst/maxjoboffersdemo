import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Grid,
  Typography,
  CircularProgress,
  Alert,
  LinearProgress,
  useTheme
} from '@mui/material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { useQuery } from 'react-query';
import api from '../../api/config';

interface MetricData {
  timestamp: string;
  value: number;
}

interface SystemMetrics {
  cpu_usage: MetricData[];
  memory_usage: MetricData[];
  request_latency: MetricData[];
  error_rate: MetricData[];
  active_users: number;
  cache_hit_rate: number;
  db_connections: number;
  queue_size: number;
}

const MetricCard: React.FC<{
  title: string;
  value: number;
  unit: string;
  color: string;
  loading?: boolean;
}> = ({ title, value, unit, color, loading }) => (
  <Card>
    <CardContent>
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>
      {loading ? (
        <CircularProgress size={20} />
      ) : (
        <Typography variant="h4" color={color}>
          {value}
          <Typography variant="caption" sx={{ ml: 1 }}>
            {unit}
          </Typography>
        </Typography>
      )}
    </CardContent>
  </Card>
);

const TimeSeriesChart: React.FC<{
  data: MetricData[];
  title: string;
  color: string;
}> = ({ data, title, color }) => (
  <Card sx={{ height: 300 }}>
    <CardContent>
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={(value) => new Date(value).toLocaleTimeString()}
          />
          <YAxis />
          <Tooltip
            labelFormatter={(value) => new Date(value).toLocaleString()}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke={color}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

export const MonitoringDashboard: React.FC = () => {
  const theme = useTheme();
  
  const { data: metrics, error, isLoading } = useQuery<SystemMetrics>(
    'system-metrics',
    async () => {
      const response = await api.get('/api/admin/metrics');
      return response.data;
    },
    {
      refetchInterval: 10000, // Refresh every 10 seconds
    }
  );

  if (error) {
    return (
      <Alert severity="error">
        Error loading monitoring data. Please try again later.
      </Alert>
    );
  }

  if (isLoading || !metrics) {
    return <LinearProgress />;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        System Monitoring
      </Typography>

      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Active Users"
            value={metrics.active_users}
            unit="users"
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Cache Hit Rate"
            value={metrics.cache_hit_rate}
            unit="%"
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="DB Connections"
            value={metrics.db_connections}
            unit="active"
            color={theme.palette.info.main}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Queue Size"
            value={metrics.queue_size}
            unit="tasks"
            color={theme.palette.warning.main}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <TimeSeriesChart
            data={metrics.cpu_usage}
            title="CPU Usage"
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TimeSeriesChart
            data={metrics.memory_usage}
            title="Memory Usage"
            color={theme.palette.secondary.main}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TimeSeriesChart
            data={metrics.request_latency}
            title="Request Latency"
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TimeSeriesChart
            data={metrics.error_rate}
            title="Error Rate"
            color={theme.palette.error.main}
          />
        </Grid>
      </Grid>
    </Box>
  );
};
