import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Paper,
  Tabs,
  Tab,
} from '@mui/material';
import { UserManagement } from './UserManagement';
import { ContentModeration } from './ContentModeration';
import { NewsletterManagement } from './NewsletterManagement';
import api from '../../api/config';
import { NewsletterSubscriber } from '../../services/newsletter';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`admin-tabpanel-${index}`}
      aria-labelledby={`admin-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

interface AdminDashboardProps {
  recentPosts?: any[];
  recentUsers?: any[];
  recentSubscribers?: NewsletterSubscriber[];
}

export function AdminDashboard({
  recentPosts = [],
  recentUsers = [],
  recentSubscribers = [],
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState(0);
  const [fetchedRecentSubscribers, setFetchedRecentSubscribers] = useState<NewsletterSubscriber[]>([]);
  const [recentPostsState, setRecentPosts] = useState(recentPosts);

  useEffect(() => {
    const fetchSubscribers = async () => {
      try {
        const response = await api.get('/api/newsletter/subscribers');
        const subscribers = response.data.subscribers.map((subscriber: any) => ({
          ...subscriber,
          subscribedAt: subscriber.subscribedAt.toISOString(),
          unsubscribedAt: subscriber.unsubscribedAt?.toISOString()
        }));
        setFetchedRecentSubscribers(subscribers);
      } catch (error) {
        console.error('Error fetching subscribers:', error);
      }
    };
    fetchSubscribers();
  }, []);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleSubscribersUpdate = () => {
    const fetchSubscribers = async () => {
      try {
        const response = await api.get('/api/newsletter/subscribers');
        const subscribers = response.data.subscribers.map((subscriber: any) => ({
          ...subscriber,
          subscribedAt: subscriber.subscribedAt.toISOString(),
          unsubscribedAt: subscriber.unsubscribedAt?.toISOString()
        }));
        setFetchedRecentSubscribers(subscribers);
      } catch (error) {
        console.error('Error fetching subscribers:', error);
      }
    };
    fetchSubscribers();
  };

  const handlePostStatusChange = async (postId: string, status: 'approved' | 'rejected') => {
    try {
      await api.patch(`/api/posts/${postId}/status`, { status });
      // Refresh posts
      const response = await api.get('/api/posts');
      setRecentPosts(response.data.posts);
    } catch (error) {
      console.error('Error updating post status:', error);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Admin Dashboard
      </Typography>

      <Paper sx={{ width: '100%', mb: 2 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          aria-label="admin tabs"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Users" />
          <Tab label="Content" />
          <Tab label="Analytics" />
          <Tab label="Newsletter" />
        </Tabs>

        <TabPanel value={activeTab} index={0}>
          <UserManagement users={recentUsers} />
        </TabPanel>

        <TabPanel value={activeTab} index={1}>
          <ContentModeration posts={recentPostsState} onStatusChange={handlePostStatusChange} />
        </TabPanel>

        <TabPanel value={activeTab} index={2}>
          <Typography>Analytics Dashboard Coming Soon</Typography>
        </TabPanel>

        <TabPanel value={activeTab} index={3}>
          <NewsletterManagement subscribers={fetchedRecentSubscribers} onUpdate={handleSubscribersUpdate} />
        </TabPanel>
      </Paper>
    </Container>
  );
}
