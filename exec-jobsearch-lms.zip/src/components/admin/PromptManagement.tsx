import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Grid,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  Snackbar,
  Alert,
  Paper,
  Tooltip
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  History as HistoryIcon,
  Save as SaveIcon,
  Add as AddIcon,
  Assessment as AssessmentIcon
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';

interface Prompt {
  id: string;
  name: string;
  description: string;
  content: string;
  category: string;
  version: number;
  performance: {
    successRate: number;
    userSatisfaction: number;
    averageResponseTime: number;
  };
  tags: string[];
  lastModified: string;
  history: {
    version: number;
    content: string;
    performance: {
      successRate: number;
      userSatisfaction: number;
    };
    timestamp: string;
  }[];
}

export const PromptManagement: React.FC = () => {
  const theme = useTheme();
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [newTag, setNewTag] = useState('');
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' as const });

  // Fetch prompts from backend
  useEffect(() => {
    // Mock data for demonstration
    const mockPrompts: Prompt[] = [{
      id: '1',
      name: 'Resume Improvement',
      description: 'Analyzes and enhances resumes with industry best practices',
      content: `You are an expert resume writer with deep experience in executive hiring.
Follow these steps:
1. Analyze the resume's current format and content
2. Identify key achievements and metrics
3. Enhance professional language and impact
4. Ensure ATS compatibility
5. Maintain industry-specific terminology
Previous successful patterns:
- Quantifiable achievements increased interview rates by 40%
- Action verbs improved engagement
- Clear hierarchy in job descriptions
Remember: Focus on {{industry}} specific requirements and {{seniority_level}} expectations.`,
      category: 'Resume',
      version: 3,
      performance: {
        successRate: 92,
        userSatisfaction: 4.8,
        averageResponseTime: 2.3
      },
      tags: ['executive', 'metrics-focused', 'ATS-optimized'],
      lastModified: '2025-03-04T09:00:00Z',
      history: [
        {
          version: 2,
          content: 'Previous version content...',
          performance: {
            successRate: 85,
            userSatisfaction: 4.5
          },
          timestamp: '2025-02-28T09:00:00Z'
        }
      ]
    }];
    setPrompts(mockPrompts);
  }, []);

  const handleSave = async (prompt: Prompt) => {
    try {
      // Save to backend
      const updatedPrompts = prompts.map(p => 
        p.id === prompt.id ? { ...prompt, version: prompt.version + 1 } : p
      );
      setPrompts(updatedPrompts);
      setEditMode(false);
      setNotification({
        open: true,
        message: 'Prompt updated successfully',
        severity: 'success'
      });
    } catch (error) {
      setNotification({
        open: true,
        message: 'Failed to update prompt',
        severity: 'error'
      });
    }
  };

  const handleAddTag = (promptId: string, tag: string) => {
    if (!tag.trim()) return;
    setPrompts(prompts.map(p => {
      if (p.id === promptId && !p.tags.includes(tag)) {
        return { ...p, tags: [...p.tags, tag] };
      }
      return p;
    }));
    setNewTag('');
  };

  const handleRemoveTag = (promptId: string, tagToRemove: string) => {
    setPrompts(prompts.map(p => {
      if (p.id === promptId) {
        return { ...p, tags: p.tags.filter(tag => tag !== tagToRemove) };
      }
      return p;
    }));
  };

  const PerformanceIndicator: React.FC<{ value: number; label: string }> = ({ value, label }) => (
    <Box textAlign="center" p={1}>
      <Typography variant="h6" color="primary">
        {typeof value === 'number' ? value.toFixed(1) : value}
      </Typography>
      <Typography variant="caption" color="textSecondary">
        {label}
      </Typography>
    </Box>
  );

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        AI Prompt Management
      </Typography>
      
      <Grid container spacing={3}>
        {prompts.map(prompt => (
          <Grid item xs={12} key={prompt.id}>
            <Card>
              <CardContent>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={8}>
                    <Box display="flex" alignItems="center" mb={2}>
                      <Typography variant="h5" component="div">
                        {prompt.name}
                      </Typography>
                      <IconButton
                        size="small"
                        onClick={() => {
                          setSelectedPrompt(prompt);
                          setEditMode(true);
                        }}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => {
                          setSelectedPrompt(prompt);
                          setShowHistory(true);
                        }}
                      >
                        <HistoryIcon />
                      </IconButton>
                    </Box>
                    
                    <Typography color="textSecondary" gutterBottom>
                      {prompt.description}
                    </Typography>
                    
                    <Paper variant="outlined" sx={{ p: 2, mt: 2, bgcolor: 'grey.50' }}>
                      <Typography
                        component="pre"
                        sx={{
                          whiteSpace: 'pre-wrap',
                          fontFamily: 'monospace',
                          fontSize: '0.9rem'
                        }}
                      >
                        {prompt.content}
                      </Typography>
                    </Paper>
                  </Grid>
                  
                  <Grid item xs={12} md={4}>
                    <Box bgcolor={theme.palette.background.default} p={2} borderRadius={1}>
                      <Typography variant="h6" gutterBottom>
                        Performance Metrics
                      </Typography>
                      <Grid container>
                        <Grid item xs={4}>
                          <PerformanceIndicator
                            value={prompt.performance.successRate}
                            label="Success Rate"
                          />
                        </Grid>
                        <Grid item xs={4}>
                          <PerformanceIndicator
                            value={prompt.performance.userSatisfaction}
                            label="User Rating"
                          />
                        </Grid>
                        <Grid item xs={4}>
                          <PerformanceIndicator
                            value={prompt.performance.averageResponseTime}
                            label="Avg Time (s)"
                          />
                        </Grid>
                      </Grid>
                    </Box>

                    <Box mt={2}>
                      <Typography variant="subtitle2" gutterBottom>
                        Tags
                      </Typography>
                      <Box display="flex" flexWrap="wrap" gap={1}>
                        {prompt.tags.map(tag => (
                          <Chip
                            key={tag}
                            label={tag}
                            onDelete={() => handleRemoveTag(prompt.id, tag)}
                            size="small"
                          />
                        ))}
                      </Box>
                      <Box display="flex" mt={1}>
                        <TextField
                          size="small"
                          value={newTag}
                          onChange={(e) => setNewTag(e.target.value)}
                          placeholder="Add tag"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              handleAddTag(prompt.id, newTag);
                            }
                          }}
                        />
                        <Button
                          size="small"
                          onClick={() => handleAddTag(prompt.id, newTag)}
                          startIcon={<AddIcon />}
                        >
                          Add
                        </Button>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Edit Dialog */}
      <Dialog
        open={editMode}
        onClose={() => setEditMode(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Edit Prompt</DialogTitle>
        <DialogContent>
          {selectedPrompt && (
            <Box mt={2}>
              <TextField
                fullWidth
                label="Name"
                value={selectedPrompt.name}
                onChange={(e) => setSelectedPrompt({
                  ...selectedPrompt,
                  name: e.target.value
                })}
                margin="normal"
              />
              <TextField
                fullWidth
                label="Description"
                value={selectedPrompt.description}
                onChange={(e) => setSelectedPrompt({
                  ...selectedPrompt,
                  description: e.target.value
                })}
                margin="normal"
              />
              <TextField
                fullWidth
                label="Content"
                value={selectedPrompt.content}
                onChange={(e) => setSelectedPrompt({
                  ...selectedPrompt,
                  content: e.target.value
                })}
                margin="normal"
                multiline
                rows={10}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditMode(false)}>Cancel</Button>
          <Button
            onClick={() => selectedPrompt && handleSave(selectedPrompt)}
            startIcon={<SaveIcon />}
            variant="contained"
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>

      {/* History Dialog */}
      <Dialog
        open={showHistory}
        onClose={() => setShowHistory(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Prompt History</DialogTitle>
        <DialogContent>
          {selectedPrompt?.history.map((version) => (
            <Box key={version.version} mb={3}>
              <Typography variant="h6">
                Version {version.version}
                <Typography variant="caption" ml={1}>
                  {new Date(version.timestamp).toLocaleString()}
                </Typography>
              </Typography>
              <Paper variant="outlined" sx={{ p: 2, mt: 1, bgcolor: 'grey.50' }}>
                <Typography
                  component="pre"
                  sx={{
                    whiteSpace: 'pre-wrap',
                    fontFamily: 'monospace',
                    fontSize: '0.9rem'
                  }}
                >
                  {version.content}
                </Typography>
              </Paper>
              <Box mt={1}>
                <Chip
                  label={`Success Rate: ${version.performance.successRate}%`}
                  size="small"
                  sx={{ mr: 1 }}
                />
                <Chip
                  label={`User Satisfaction: ${version.performance.userSatisfaction}`}
                  size="small"
                />
              </Box>
            </Box>
          ))}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowHistory(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={() => setNotification({ ...notification, open: false })}
      >
        <Alert
          onClose={() => setNotification({ ...notification, open: false })}
          severity={notification.severity}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};
