import React from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { BlogPost } from '../../types/blog';

interface BlogAnalyticsProps {
  posts: BlogPost[];
}

export function BlogAnalytics({ posts }: BlogAnalyticsProps) {
  // Calculate views over time
  const viewsData = posts.map(post => ({
    date: new Date(post.publishedAt || new Date()).toLocaleDateString(),
    views: post.views || 0,
  }));

  // Calculate top posts
  const topPosts = [...posts]
    .sort((a, b) => (b.views || 0) - (a.views || 0))
    .slice(0, 5);

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Blog Performance
      </Typography>

      {/* Views Over Time Chart */}
      <Paper sx={{ p: 2, mb: 4 }}>
        <Typography variant="subtitle1" gutterBottom>
          Views Over Time
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={viewsData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="views"
              stroke="#8884d8"
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </Paper>

      {/* Top Posts Table */}
      <Paper sx={{ p: 2 }}>
        <Typography variant="subtitle1" gutterBottom>
          Top Performing Posts
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Title</TableCell>
                <TableCell align="right">Views</TableCell>
                <TableCell align="right">Comments</TableCell>
                <TableCell align="right">Published</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {topPosts.map((post) => (
                <TableRow key={post.id}>
                  <TableCell component="th" scope="row">
                    {post.title}
                  </TableCell>
                  <TableCell align="right">{post.views || 0}</TableCell>
                  <TableCell align="right">
                    {post.comments?.length || 0}
                  </TableCell>
                  <TableCell align="right">
                    {new Date(post.publishedAt || new Date()).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
}
