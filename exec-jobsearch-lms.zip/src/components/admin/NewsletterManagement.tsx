import React, { useState, useCallback } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Chip,
  Grid,
  CircularProgress,
  IconButton,
  TablePagination,
  Tooltip,
  Alert,
  Snackbar,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TableSortLabel,
  Checkbox,
} from '@mui/material';
import {
  Send as SendIcon,
  Preview as PreviewIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Schedule as ScheduleIcon,
  History as HistoryIcon,
} from '@mui/icons-material';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { debounce } from 'lodash';
import api from '../../api/config';
import { Editor } from '@tinymce/tinymce-react';

interface NewsletterSubscriber {
  id: string;
  email: string;
  name?: string;
  subscribed: boolean;
  subscribedAt: string;
  preferences?: {
    frequency: string;
    categories: string[];
  };
}

interface NewsletterTemplate {
  id: string;
  subject: string;
  content: string;
  createdAt: string;
  lastUsed?: string;
}

interface SortConfig {
  field: keyof NewsletterSubscriber | '';
  direction: 'asc' | 'desc';
}

interface FilterConfig {
  status: string;
  category: string;
  dateRange: {
    start: string;
    end: string;
  };
}

interface NewsletterSchedule {
  id: string;
  templateId: string;
  scheduledFor: string;
  recipients: string[];
  status: 'scheduled' | 'sent' | 'failed';
}

export const NewsletterManagement: React.FC = () => {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedSubscribers, setSelectedSubscribers] = useState<string[]>([]);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<NewsletterTemplate | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<NewsletterTemplate | null>(null);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ field: '', direction: 'asc' });
  const [filterConfig, setFilterConfig] = useState<FilterConfig>({
    status: 'all',
    category: 'all',
    dateRange: { start: '', end: '' },
  });
  const [scheduledDate, setScheduledDate] = useState<Date | null>(null);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success',
  });

  // Fetch subscribers with filters and sorting
  const { data: subscribers, isLoading: loadingSubscribers } = useQuery(
    ['subscribers', filterConfig, sortConfig],
    async () => {
      const response = await api.get('/api/newsletter/subscribers', {
        params: {
          status: filterConfig.status,
          category: filterConfig.category,
          startDate: filterConfig.dateRange.start,
          endDate: filterConfig.dateRange.end,
          sortField: sortConfig.field,
          sortDirection: sortConfig.direction,
        },
      });
      return response.data.subscribers;
    }
  );

  // Fetch templates
  const { data: templates, isLoading: loadingTemplates } = useQuery(
    'newsletter-templates',
    async () => {
      const response = await api.get('/api/newsletter/templates');
      return response.data.templates;
    }
  );

  // Fetch scheduled newsletters
  const { data: scheduledNewsletters } = useQuery(
    'scheduled-newsletters',
    async () => {
      const response = await api.get('/api/newsletter/scheduled');
      return response.data.scheduled;
    }
  );

  const createTemplateMutation = useMutation(
    async (template: Partial<NewsletterTemplate>) => {
      const response = await api.post('/api/newsletter/templates', template);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('newsletter-templates');
        setTemplateDialogOpen(false);
        setSnackbar({
          open: true,
          message: 'Template created successfully',
          severity: 'success',
        });
      },
      onError: () => {
        setSnackbar({
          open: true,
          message: 'Error creating template',
          severity: 'error',
        });
      },
    }
  );

  const scheduleNewsletterMutation = useMutation(
    async (data: { templateId: string; scheduledFor: string; recipients: string[] }) => {
      const response = await api.post('/api/newsletter/schedule', data);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('scheduled-newsletters');
        setScheduleDialogOpen(false);
        setSnackbar({
          open: true,
          message: 'Newsletter scheduled successfully',
          severity: 'success',
        });
      },
      onError: () => {
        setSnackbar({
          open: true,
          message: 'Error scheduling newsletter',
          severity: 'error',
        });
      },
    }
  );

  const sendNewsletterMutation = useMutation(
    async (data: { templateId: string; recipients: string[] }) => {
      const response = await api.post('/api/newsletter/send', data);
      return response.data;
    },
    {
      onSuccess: () => {
        setSnackbar({
          open: true,
          message: 'Newsletter sent successfully',
          severity: 'success',
        });
      },
      onError: () => {
        setSnackbar({
          open: true,
          message: 'Error sending newsletter',
          severity: 'error',
        });
      },
    }
  );

  const handleSort = (field: keyof NewsletterSubscriber) => {
    setSortConfig((prev) => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const handleFilterChange = useCallback(
    debounce((newFilter: Partial<FilterConfig>) => {
      setFilterConfig((prev) => ({ ...prev, ...newFilter }));
    }, 300),
    []
  );

  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      setSelectedSubscribers(subscribers.map((s) => s.id));
    } else {
      setSelectedSubscribers([]);
    }
  };

  const handleRowSelect = (subscriberId: string) => {
    setSelectedSubscribers((prev) =>
      prev.includes(subscriberId)
        ? prev.filter((id) => id !== subscriberId)
        : [...prev, subscriberId]
    );
  };

  const handleScheduleNewsletter = () => {
    if (!selectedTemplate || !scheduledDate) return;

    scheduleNewsletterMutation.mutate({
      templateId: selectedTemplate.id,
      scheduledFor: scheduledDate.toISOString(),
      recipients: selectedSubscribers,
    });
  };

  const handleSendNewsletter = () => {
    if (!selectedTemplate) return;

    sendNewsletterMutation.mutate({
      templateId: selectedTemplate.id,
      recipients: selectedSubscribers,
    });
  };

  if (loadingSubscribers || loadingTemplates) {
    return <CircularProgress />;
  }

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box>
        <Grid container spacing={2} sx={{ mb: 4 }}>
          <Grid item xs={12}>
            <Typography variant="h6" gutterBottom>
              Newsletter Management
            </Typography>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              onClick={() => setTemplateDialogOpen(true)}
              startIcon={<EditIcon />}
            >
              Create Template
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color="primary"
              onClick={() => setScheduleDialogOpen(true)}
              startIcon={<ScheduleIcon />}
              disabled={selectedSubscribers.length === 0}
            >
              Schedule Newsletter
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color="secondary"
              onClick={handleSendNewsletter}
              startIcon={<SendIcon />}
              disabled={selectedSubscribers.length === 0 || !selectedTemplate}
            >
              Send Now
            </Button>
          </Grid>
        </Grid>

        {/* Filters */}
        <Paper sx={{ p: 2, mb: 2 }}>
          <Box display="flex" gap={2}>
            <FormControl size="small">
              <InputLabel>Status</InputLabel>
              <Select
                value={filterConfig.status}
                onChange={(e) => handleFilterChange({ status: e.target.value })}
                label="Status"
              >
                <MenuItem value="all">All</MenuItem>
                <MenuItem value="active">Active</MenuItem>
                <MenuItem value="inactive">Inactive</MenuItem>
              </Select>
            </FormControl>
            <FormControl size="small">
              <InputLabel>Category</InputLabel>
              <Select
                value={filterConfig.category}
                onChange={(e) => handleFilterChange({ category: e.target.value })}
                label="Category"
              >
                <MenuItem value="all">All Categories</MenuItem>
                <MenuItem value="news">News</MenuItem>
                <MenuItem value="updates">Updates</MenuItem>
                <MenuItem value="promotions">Promotions</MenuItem>
              </Select>
            </FormControl>
            <TextField
              size="small"
              type="date"
              label="Start Date"
              value={filterConfig.dateRange.start}
              onChange={(e) =>
                handleFilterChange({
                  dateRange: { ...filterConfig.dateRange, start: e.target.value },
                })
              }
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              size="small"
              type="date"
              label="End Date"
              value={filterConfig.dateRange.end}
              onChange={(e) =>
                handleFilterChange({
                  dateRange: { ...filterConfig.dateRange, end: e.target.value },
                })
              }
              InputLabelProps={{ shrink: true }}
            />
          </Box>
        </Paper>

        {/* Subscribers Table */}
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    indeterminate={
                      selectedSubscribers.length > 0 &&
                      selectedSubscribers.length < subscribers.length
                    }
                    checked={selectedSubscribers.length === subscribers.length}
                    onChange={handleSelectAllClick}
                  />
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={sortConfig.field === 'email'}
                    direction={sortConfig.direction}
                    onClick={() => handleSort('email')}
                  >
                    Email
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={sortConfig.field === 'name'}
                    direction={sortConfig.direction}
                    onClick={() => handleSort('name')}
                  >
                    Name
                  </TableSortLabel>
                </TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Subscribed Date</TableCell>
                <TableCell>Preferences</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {subscribers
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((subscriber) => (
                  <TableRow key={subscriber.id}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedSubscribers.includes(subscriber.id)}
                        onChange={() => handleRowSelect(subscriber.id)}
                      />
                    </TableCell>
                    <TableCell>{subscriber.email}</TableCell>
                    <TableCell>{subscriber.name || '-'}</TableCell>
                    <TableCell>
                      <Chip
                        label={subscriber.subscribed ? 'Active' : 'Inactive'}
                        color={subscriber.subscribed ? 'success' : 'default'}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      {new Date(subscriber.subscribedAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {subscriber.preferences ? (
                        <Box>
                          <Typography variant="body2">
                            Frequency: {subscriber.preferences.frequency}
                          </Typography>
                          <Typography variant="body2">
                            Categories: {subscriber.preferences.categories.join(', ')}
                          </Typography>
                        </Box>
                      ) : (
                        '-'
                      )}
                    </TableCell>
                    <TableCell>
                      <Tooltip title="View History">
                        <IconButton size="small">
                          <HistoryIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Edit">
                        <IconButton size="small">
                          <EditIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete">
                        <IconButton size="small" color="error">
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={subscribers.length}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
          />
        </TableContainer>

        {/* Template Dialog */}
        <Dialog
          open={templateDialogOpen}
          onClose={() => setTemplateDialogOpen(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            {editingTemplate ? 'Edit Template' : 'Create Template'}
          </DialogTitle>
          <DialogContent>
            <Box sx={{ mt: 2 }}>
              <TextField
                fullWidth
                label="Subject"
                value={editingTemplate?.subject || ''}
                onChange={(e) =>
                  setEditingTemplate((prev) =>
                    prev ? { ...prev, subject: e.target.value } : null
                  )
                }
                sx={{ mb: 2 }}
              />
              <Editor
                apiKey="your-tinymce-api-key"
                value={editingTemplate?.content || ''}
                init={{
                  height: 400,
                  menubar: true,
                  plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table paste code help wordcount',
                  ],
                  toolbar:
                    'undo redo | formatselect | bold italic backcolor | \
                    alignleft aligncenter alignright alignjustify | \
                    bullist numlist outdent indent | removeformat | help',
                }}
                onEditorChange={(content) =>
                  setEditingTemplate((prev) =>
                    prev ? { ...prev, content } : null
                  )
                }
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setTemplateDialogOpen(false)}>Cancel</Button>
            <Button
              onClick={() => {
                if (editingTemplate) {
                  createTemplateMutation.mutate(editingTemplate);
                }
              }}
              variant="contained"
              color="primary"
            >
              Save
            </Button>
          </DialogActions>
        </Dialog>

        {/* Schedule Dialog */}
        <Dialog
          open={scheduleDialogOpen}
          onClose={() => setScheduleDialogOpen(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>Schedule Newsletter</DialogTitle>
          <DialogContent>
            <Box sx={{ mt: 2 }}>
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>Template</InputLabel>
                <Select
                  value={selectedTemplate?.id || ''}
                  onChange={(e) => {
                    const template = templates.find((t) => t.id === e.target.value);
                    setSelectedTemplate(template || null);
                  }}
                  label="Template"
                >
                  {templates.map((template) => (
                    <MenuItem key={template.id} value={template.id}>
                      {template.subject}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <DateTimePicker
                label="Schedule Date"
                value={scheduledDate}
                onChange={(newValue) => setScheduledDate(newValue)}
                sx={{ width: '100%' }}
              />
              <Typography variant="body2" sx={{ mt: 2 }}>
                Selected Recipients: {selectedSubscribers.length}
              </Typography>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setScheduleDialogOpen(false)}>Cancel</Button>
            <Button
              onClick={handleScheduleNewsletter}
              variant="contained"
              color="primary"
              disabled={!selectedTemplate || !scheduledDate}
            >
              Schedule
            </Button>
          </DialogActions>
        </Dialog>

        {/* Preview Dialog */}
        <Dialog
          open={previewDialogOpen}
          onClose={() => setPreviewDialogOpen(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>{selectedTemplate?.subject}</DialogTitle>
          <DialogContent>
            <div
              dangerouslySetInnerHTML={{
                __html: selectedTemplate?.content || '',
              }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setPreviewDialogOpen(false)}>Close</Button>
          </DialogActions>
        </Dialog>

        {/* Snackbar */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          <Alert
            onClose={() => setSnackbar({ ...snackbar, open: false })}
            severity={snackbar.severity}
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
};
