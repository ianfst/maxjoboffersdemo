import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Grid,
  Typography,
  Tab,
  Tabs,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  TextField,
} from '@mui/material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Scatter,
  ScatterChart,
} from 'recharts';
import { useQuery } from 'react-query';
import { DateRangePicker } from '@mui/lab';
import api from '../../api/config';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`analytics-tabpanel-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
};

interface PerformanceData {
  response_time: {
    timestamp: string;
    value: number;
  }[];
  error_rate: {
    timestamp: string;
    value: number;
  }[];
}

interface UserMetrics {
  growth: {
    date: string;
    new_users: number;
  }[];
  distribution: {
    name: string;
    value: number;
  }[];
}

interface EngagementData {
  feature_usage: {
    feature: string;
    usage_count: number;
  }[];
  session_duration: {
    duration: number;
    count: number;
  }[];
}

interface ConversionData {
  funnel: {
    stage: string;
    count: number;
  }[];
  by_source: {
    source: string;
    rate: number;
  }[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export const AnalyticsDashboard: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);
  const [dateRange, setDateRange] = useState([null, null]);
  const [metricType, setMetricType] = useState('daily');

  const { data: performanceData } = useQuery<PerformanceData>(
    ['performance-metrics', dateRange, metricType],
    async () => {
      const response = await api.get('/api/analytics/performance', {
        params: {
          start_date: dateRange[0],
          end_date: dateRange[1],
          type: metricType
        }
      });
      return response.data;
    }
  );

  const { data: userMetrics } = useQuery<UserMetrics>(
    ['user-metrics', dateRange],
    async () => {
      const response = await api.get('/api/analytics/users', {
        params: {
          start_date: dateRange[0],
          end_date: dateRange[1]
        }
      });
      return response.data;
    }
  );

  const { data: engagementData } = useQuery<EngagementData>(
    ['engagement-metrics', dateRange],
    async () => {
      const response = await api.get('/api/analytics/engagement', {
        params: {
          start_date: dateRange[0],
          end_date: dateRange[1]
        }
      });
      return response.data;
    }
  );

  const { data: conversionData } = useQuery<ConversionData>(
    ['conversion-metrics', dateRange],
    async () => {
      const response = await api.get('/api/analytics/conversions', {
        params: {
          start_date: dateRange[0],
          end_date: dateRange[1]
        }
      });
      return response.data;
    }
  );

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={(_, newValue) => setTabValue(newValue)}>
          <Tab label="Performance" />
          <Tab label="User Analytics" />
          <Tab label="Engagement" />
          <Tab label="Conversions" />
        </Tabs>
      </Box>

      <Box sx={{ mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item>
            <DateRangePicker
              value={dateRange}
              onChange={setDateRange}
              renderInput={(startProps: any, endProps: any) => (
                <>
                  <TextField {...startProps} />
                  <Box sx={{ mx: 2 }}> to </Box>
                  <TextField {...endProps} />
                </>
              )}
            />
          </Grid>
          <Grid item>
            <FormControl>
              <InputLabel>Metric Type</InputLabel>
              <Select
                value={metricType}
                onChange={(e) => setMetricType(e.target.value)}
              >
                <MenuItem value="hourly">Hourly</MenuItem>
                <MenuItem value="daily">Daily</MenuItem>
                <MenuItem value="weekly">Weekly</MenuItem>
                <MenuItem value="monthly">Monthly</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Box>

      <TabPanel value={tabValue} index={0}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Response Time
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceData?.response_time}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="value" stroke="#8884d8" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Error Rate
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceData?.error_rate}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="value" stroke="#82ca9d" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  User Growth
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={userMetrics?.growth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="new_users" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  User Distribution by Tier
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={userMetrics?.distribution}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      label
                    >
                      {userMetrics?.distribution.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={2}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Feature Usage
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={engagementData?.feature_usage}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="feature" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="usage_count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Session Duration Distribution
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="duration" name="Duration (minutes)" />
                    <YAxis dataKey="count" name="Number of Sessions" />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                    <Scatter name="Sessions" data={engagementData?.session_duration} fill="#8884d8" />
                  </ScatterChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </TabPanel>

      <TabPanel value={tabValue} index={3}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Conversion Funnel
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={conversionData?.funnel}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="stage" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Conversion Rate by Source
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={conversionData?.by_source}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="source" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="rate" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </TabPanel>
    </Box>
  );
};
