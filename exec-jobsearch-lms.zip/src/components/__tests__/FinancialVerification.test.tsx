import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { FinancialVerification } from '../verification/FinancialVerification';
import { QueryClient, QueryClientProvider } from 'react-query';
import api from '../../api/config';

// Mock next/router
jest.mock('next/router', () => ({
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

// Mock api
jest.mock('../../api/config', () => ({
  get: jest.fn(),
  post: jest.fn(),
}));

describe('FinancialVerification', () => {
  let queryClient: QueryClient;

  beforeEach(() => {
    jest.clearAllMocks();
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
        },
      },
    });
    (api.get as jest.Mock).mockResolvedValue({
      data: {
        verified: false,
        watchedVideo: false
      }
    });
  });

  const renderComponent = () => {
    return render(
      <QueryClientProvider client={queryClient}>
        <FinancialVerification />
      </QueryClientProvider>
    );
  };

  it('renders initial verification step', async () => {
    renderComponent();
    expect(await screen.findByText(/Watch Introduction Video/i)).toBeInTheDocument();
    expect(screen.getByText(/Qualify for our Platinum tier/i)).toBeInTheDocument();
  });

  it('handles video completion flow', async () => {
    renderComponent();
    
    // Open video dialog
    fireEvent.click(await screen.findByText(/Watch Introduction Video/i));
    expect(screen.getByText(/Platinum Membership Overview/i)).toBeInTheDocument();
    
    // Mock successful video completion
    (api.post as jest.Mock).mockResolvedValueOnce({
      data: { success: true }
    });

    // Mock updated status after video completion
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        verified: false,
        watchedVideo: true
      }
    });
    
    // Complete video
    fireEvent.click(screen.getByText(/I've Watched the Video/i));
    
    await waitFor(() => {
      expect(api.post).toHaveBeenCalledWith('/api/verification/financial/video-complete');
    });

    // Verify next step is shown
    await waitFor(() => {
      expect(screen.getByText(/would you like to proceed with verification/i)).toBeInTheDocument();
    });
  });

  it('shows opt-in step after video completion', async () => {
    // Mock video watched state
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        verified: false,
        watchedVideo: true
      }
    });
    
    renderComponent();
    
    await waitFor(() => {
      expect(screen.getByText(/would you like to proceed with verification/i)).toBeInTheDocument();
      expect(screen.getByText(/Yes, I'm Interested/i)).toBeInTheDocument();
    });
  });

  it('handles opt-in submission', async () => {
    // Mock video watched state
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        verified: false,
        watchedVideo: true
      }
    });
    
    renderComponent();
    
    // Mock successful opt-in
    (api.post as jest.Mock).mockResolvedValueOnce({
      data: { success: true }
    });

    // Mock updated status after opt-in
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        verified: true,
        watchedVideo: true
      }
    });
    
    // Wait for and click opt-in button
    const optInButton = await screen.findByText(/Yes, I'm Interested/i);
    fireEvent.click(optInButton);
    
    // Verify API call and success message
    await waitFor(() => {
      expect(api.post).toHaveBeenCalledWith('/api/verification/financial/opt-in', {
        interested: true
      });
    });

    await waitFor(() => {
      expect(screen.getByText(/Thank you for your interest/i)).toBeInTheDocument();
    });
  });

  it('handles API errors gracefully', async () => {
    // Mock video watched state
    (api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        verified: false,
        watchedVideo: true
      }
    });
    
    renderComponent();
    
    // Mock API error
    (api.post as jest.Mock).mockRejectedValueOnce(new Error('API Error'));
    
    // Wait for and click opt-in button
    const optInButton = await screen.findByText(/Yes, I'm Interested/i);
    fireEvent.click(optInButton);
    
    await waitFor(() => {
      expect(api.post).toHaveBeenCalledWith('/api/verification/financial/opt-in', {
        interested: true
      });
    });
  });
});
