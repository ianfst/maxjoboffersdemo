import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from 'react-query';
import { WebinarList } from '../webinars/WebinarList';
import api from '../../api/config';

jest.mock('../../api/config');

const mockWebinars = [
  {
    id: 1,
    title: 'Advanced LinkedIn Networking',
    description: 'Learn networking strategies',
    datetime: '2025-03-15T14:00:00Z',
    registrationUrl: 'https://example.com/webinar1'
  },
  {
    id: 2,
    title: 'Resume Building Workshop',
    description: 'Create compelling resumes',
    datetime: '2025-03-20T15:00:00Z',
    registrationUrl: 'https://example.com/webinar2'
  }
];

describe('WebinarList', () => {
  let queryClient: QueryClient;

  beforeEach(() => {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: false,
          cacheTime: 0,
        },
      },
    });
    (api.get as jest.Mock).mockResolvedValue({ data: mockWebinars });
  });

  afterEach(() => {
    queryClient.clear();
  });

  const renderComponent = () => {
    return render(
      <QueryClientProvider client={queryClient}>
        <WebinarList />
      </QueryClientProvider>
    );
  };

  it('renders webinar cards with correct information', async () => {
    renderComponent();

    // Wait for data to load
    await waitFor(() => {
      expect(screen.getByText('Advanced LinkedIn Networking')).toBeInTheDocument();
    });

    // Check if all webinars are rendered
    mockWebinars.forEach(webinar => {
      expect(screen.getByText(webinar.title)).toBeInTheDocument();
      expect(screen.getByText(webinar.description)).toBeInTheDocument();
    });

    // Check if register buttons are present
    const registerButtons = screen.getAllByText('Register Now');
    expect(registerButtons).toHaveLength(mockWebinars.length);
  });

  it('shows loading state initially', async () => {
    // Mock a delayed response
    (api.get as jest.Mock).mockImplementation(() => 
      new Promise((resolve) => setTimeout(resolve, 100))
    );

    const { container } = renderComponent();

    // Check for loading skeletons
    const skeletons = container.querySelectorAll('.MuiSkeleton-root');
    expect(skeletons.length).toBeGreaterThan(0);
  });

  it('handles API errors gracefully', async () => {
    // Mock API error
    (api.get as jest.Mock).mockRejectedValue(new Error('Failed to fetch'));

    renderComponent();

    // Wait for loading state to finish
    await waitFor(() => {
      const skeletons = screen.queryAllByTestId('skeleton');
      expect(skeletons.length).toBe(0);
    });

    // Verify that webinars are not rendered
    expect(screen.queryByText('Advanced LinkedIn Networking')).not.toBeInTheDocument();
  });
});
