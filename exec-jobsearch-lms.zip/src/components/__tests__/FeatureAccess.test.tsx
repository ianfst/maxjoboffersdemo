import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { FeatureAccess } from '../common/FeatureAccess';

// Mock next/router
jest.mock('next/router', () => ({
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

// Mock useUser hook
jest.mock('../../hooks/useUser', () => ({
  useUser: () => ({
    user: null,
  }),
}));

describe('FeatureAccess', () => {
  const mockFeatures = {
    aiTools: true,
    premiumContent: true,
    coaching: false,
    doneForYou: false,
    financialPlanning: false,
  };

  it('renders children when user has access to feature', () => {
    render(
      <FeatureAccess feature="ai_tools" features={mockFeatures}>
        <div data-testid="protected-content">Protected Content</div>
      </FeatureAccess>
    );

    expect(screen.getByTestId('protected-content')).toBeInTheDocument();
  });

  it('shows upgrade message when user does not have access', () => {
    render(
      <FeatureAccess feature="coaching" features={mockFeatures}>
        <div>Protected Content</div>
      </FeatureAccess>
    );

    expect(screen.getByText(/Upgrade to premium to access this feature/i)).toBeInTheDocument();
    expect(screen.getByText(/Upgrade Now/i)).toBeInTheDocument();
  });

  it('handles unknown features gracefully', () => {
    render(
      <FeatureAccess feature="nonexistent_feature" features={mockFeatures}>
        <div>Protected Content</div>
      </FeatureAccess>
    );

    expect(screen.getByText(/Upgrade to free to access this feature/i)).toBeInTheDocument();
  });
});
