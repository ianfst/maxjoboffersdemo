import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  TextField,
  CircularProgress,
  LinearProgress,
  Chip,
  Stack,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DescriptionIcon from '@mui/icons-material/Description';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import { Job, Resume } from '../../types/jobApplication';

interface ResumeOptimizerProps {
  job: Job;
  baseResumes: Resume[];
  onOptimizationComplete: (optimizedResume: Resume) => void;
}

export const ResumeOptimizer: React.FC<ResumeOptimizerProps> = ({
  job,
  baseResumes,
  onOptimizationComplete
}) => {
  const [selectedResume, setSelectedResume] = useState<Resume | null>(null);
  const [customInstructions, setCustomInstructions] = useState('');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationProgress, setOptimizationProgress] = useState(0);
  const [keywordMatches, setKeywordMatches] = useState<string[]>([]);

  // Simulated optimization steps
  const optimizationSteps = [
    'Analyzing job requirements',
    'Extracting key qualifications',
    'Matching experience with requirements',
    'Optimizing content for ATS',
    'Enhancing professional summary',
    'Finalizing formatting'
  ];

  const startOptimization = async () => {
    if (!selectedResume) return;

    setIsOptimizing(true);
    setOptimizationProgress(0);

    // Simulate optimization process
    for (let i = 0; i < optimizationSteps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setOptimizationProgress((i + 1) * (100 / optimizationSteps.length));
    }

    // Create optimized resume
    const optimizedResume: Resume = {
      ...selectedResume,
      id: `${selectedResume.id}-optimized`,
      title: `${selectedResume.title} (Optimized for ${job.title})`,
      isBase: false,
      lastModified: new Date().toISOString(),
      atsScore: 95,
      keywords: [...selectedResume.keywords, ...extractJobKeywords(job)]
    };

    setIsOptimizing(false);
    onOptimizationComplete(optimizedResume);
  };

  const extractJobKeywords = (job: Job): string[] => {
    const keywords = new Set<string>();
    [...job.requirements, ...job.responsibilities].forEach(text => {
      // Extract key technical and leadership terms
      const terms = text.toLowerCase().match(/\b\w+(?:[-']\w+)*\b/g) || [];
      terms.forEach(term => keywords.add(term));
    });
    return Array.from(keywords);
  };

  const calculateResumeMatch = (resume: Resume): number => {
    const jobKeywords = extractJobKeywords(job);
    const matchingKeywords = resume.keywords.filter(keyword => 
      jobKeywords.includes(keyword.toLowerCase())
    );
    return Math.round((matchingKeywords.length / jobKeywords.length) * 100);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Resume Optimization for {job.title}
      </Typography>

      <Grid container spacing={3}>
        {/* Job Details Section */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Job Details
            </Typography>
            <List dense>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <ListItemText 
                  primary="Company"
                  secondary={job.company}
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <ListItemText 
                  primary="Location"
                  secondary={job.location}
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <ListItemText 
                  primary="Level"
                  secondary={job.level}
                />
              </ListItem>
            </List>
            
            <Typography variant="subtitle1" sx={{ mt: 2 }}>
              Key Requirements
            </Typography>
            <List dense>
              {job.requirements.slice(0, 4).map((req, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <CheckCircleIcon fontSize="small" color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary={req}
                    primaryTypographyProps={{ variant: 'body2' }}
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>

        {/* Base Resume Selection */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Select Base Resume
            </Typography>
            <Stack spacing={2}>
              {baseResumes.map((resume) => {
                const matchScore = calculateResumeMatch(resume);
                return (
                  <Card 
                    key={resume.id}
                    variant={selectedResume?.id === resume.id ? 'elevation' : 'outlined'}
                    sx={{ 
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      '&:hover': { transform: 'translateY(-2px)' },
                      border: selectedResume?.id === resume.id ? 2 : 1,
                      borderColor: selectedResume?.id === resume.id ? 'primary.main' : 'divider'
                    }}
                    onClick={() => setSelectedResume(resume)}
                  >
                    <CardContent>
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="subtitle1">
                          {resume.title}
                        </Typography>
                        <Chip 
                          label={`${matchScore}% Match`}
                          color={matchScore > 70 ? 'success' : 'warning'}
                          size="small"
                        />
                      </Stack>
                      <Typography variant="body2" color="textSecondary">
                        Last modified: {new Date(resume.lastModified).toLocaleDateString()}
                      </Typography>
                      <Stack direction="row" spacing={1} mt={1}>
                        {resume.keywords.slice(0, 3).map((keyword, index) => (
                          <Chip
                            key={index}
                            label={keyword}
                            size="small"
                            variant="outlined"
                          />
                        ))}
                      </Stack>
                    </CardContent>
                  </Card>
                );
              })}
            </Stack>
          </Paper>
        </Grid>

        {/* Optimization Controls */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Optimization Settings
            </Typography>
            
            <TextField
              fullWidth
              multiline
              rows={4}
              variant="outlined"
              label="Custom Instructions (Optional)"
              placeholder="Add any specific instructions for resume optimization..."
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              sx={{ mb: 2 }}
            />

            {isOptimizing ? (
              <Box sx={{ width: '100%' }}>
                <LinearProgress 
                  variant="determinate" 
                  value={optimizationProgress} 
                  sx={{ mb: 2 }}
                />
                <Typography variant="body2" color="textSecondary" align="center">
                  {optimizationSteps[Math.floor((optimizationProgress / 100) * optimizationSteps.length) - 1]}
                </Typography>
              </Box>
            ) : (
              <Button
                fullWidth
                variant="contained"
                color="primary"
                size="large"
                startIcon={<TrendingUpIcon />}
                disabled={!selectedResume}
                onClick={startOptimization}
              >
                Start Optimization
              </Button>
            )}

            {selectedResume && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Current ATS Score
                </Typography>
                <LinearProgress 
                  variant="determinate" 
                  value={selectedResume.atsScore}
                  sx={{ height: 8, borderRadius: 4 }}
                />
                <Typography variant="body2" color="textSecondary" align="right">
                  {selectedResume.atsScore}/100
                </Typography>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};
