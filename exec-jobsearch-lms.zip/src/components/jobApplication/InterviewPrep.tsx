import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Stepper,
  Step,
  StepLabel,
  TextField,
  CircularProgress,
  Chip,
  Stack,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Rating,
  Divider
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import { Job, Resume, InterviewQuestion, InterviewPrepSession } from '../../types/jobApplication';

interface InterviewPrepProps {
  job: Job;
  optimizedResume: Resume;
  onComplete: (session: InterviewPrepSession) => void;
}

const questionCategories = [
  { id: 'leadership', label: 'Leadership & Strategy', icon: <WorkIcon /> },
  { id: 'technical', label: 'Technical Expertise', icon: <SchoolIcon /> },
  { id: 'behavioral', label: 'Behavioral', icon: <QuestionAnswerIcon /> }
];

export const InterviewPrep: React.FC<InterviewPrepProps> = ({
  job,
  optimizedResume,
  onComplete
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string>('leadership');
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [feedback, setFeedback] = useState<Record<string, string>>({});
  const [ratings, setRatings] = useState<Record<string, number>>({});

  useEffect(() => {
    generateQuestionsForCategory(selectedCategory);
  }, [selectedCategory]);

  const generateQuestionsForCategory = async (category: string) => {
    setIsGenerating(true);
    try {
      // In a real implementation, this would call an API
      // For now, we'll simulate question generation based on job requirements
      const generatedQuestions = generateMockQuestions(category, job);
      setQuestions(generatedQuestions);
    } catch (error) {
      console.error('Failed to generate questions:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateMockQuestions = (category: string, job: Job): InterviewQuestion[] => {
    const baseQuestions: Record<string, InterviewQuestion[]> = {
      leadership: [
        {
          id: '1',
          question: `How would you approach leading the ${job.company} technology team and implementing the digital transformation initiatives mentioned in the job description?`,
          category: 'leadership',
          sampleAnswer: 'Start by assessing current technology landscape, then create a phased transformation plan...'
        },
        {
          id: '2',
          question: 'Describe a situation where you had to make a difficult technical decision that impacted business strategy.',
          category: 'leadership',
          sampleAnswer: 'Focus on a specific example that demonstrates leadership and decision-making skills...'
        }
      ],
      technical: [
        {
          id: '3',
          question: `Given ${job.company}'s scale, how would you design a resilient and scalable system architecture?`,
          category: 'technical',
          sampleAnswer: 'Discuss microservices architecture, cloud infrastructure, and scalability patterns...'
        },
        {
          id: '4',
          question: 'How do you ensure security and compliance in large-scale enterprise applications?',
          category: 'technical',
          sampleAnswer: 'Cover security best practices, compliance frameworks, and implementation strategies...'
        }
      ],
      behavioral: [
        {
          id: '5',
          question: 'Tell me about a time when you had to lead a team through a challenging project.',
          category: 'behavioral',
          sampleAnswer: 'Use the STAR method: Situation, Task, Action, Result...'
        },
        {
          id: '6',
          question: 'How do you handle disagreements with other executives or board members?',
          category: 'behavioral',
          sampleAnswer: 'Focus on communication, conflict resolution, and positive outcomes...'
        }
      ]
    };

    return baseQuestions[category] || [];
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleFeedbackSubmit = async () => {
    // Simulate AI feedback generation
    const newFeedback: Record<string, string> = {};
    const newRatings: Record<string, number> = {};

    questions.forEach(question => {
      const answer = answers[question.id];
      if (answer) {
        newFeedback[question.id] = generateMockFeedback(answer);
        newRatings[question.id] = Math.floor(Math.random() * 3) + 3; // Random rating between 3-5
      }
    });

    setFeedback(newFeedback);
    setRatings(newRatings);
  };

  const generateMockFeedback = (answer: string): string => {
    const feedbackTemplates = [
      'Strong response that effectively demonstrates leadership experience. Consider adding more specific metrics.',
      'Good structure using the STAR method. Could be enhanced with more strategic context.',
      'Excellent technical depth. Consider simplifying some technical terms for non-technical stakeholders.'
    ];
    return feedbackTemplates[Math.floor(Math.random() * feedbackTemplates.length)];
  };

  const handleComplete = () => {
    const session: InterviewPrepSession = {
      id: Math.random().toString(36).substr(2, 9),
      jobId: job.id,
      type: selectedCategory as 'behavioral' | 'technical' | 'leadership',
      questions: questions.map(q => ({
        ...q,
        userAnswer: answers[q.id],
        feedback: feedback[q.id],
        rating: ratings[q.id]
      })),
      completed: true
    };
    onComplete(session);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Interview Preparation for {job.title}
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Question Categories
            </Typography>
            <Stack spacing={2}>
              {questionCategories.map(category => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? 'contained' : 'outlined'}
                  startIcon={category.icon}
                  fullWidth
                  onClick={() => setSelectedCategory(category.id)}
                  sx={{ justifyContent: 'flex-start' }}
                >
                  {category.label}
                </Button>
              ))}
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12} md={9}>
          <Paper sx={{ p: 2 }}>
            {isGenerating ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : (
              <Stack spacing={2}>
                {questions.map((question, index) => (
                  <Accordion key={question.id}>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography>
                        <strong>Q{index + 1}:</strong> {question.question}
                      </Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Stack spacing={2}>
                        <TextField
                          fullWidth
                          multiline
                          rows={4}
                          label="Your Answer"
                          value={answers[question.id] || ''}
                          onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                          variant="outlined"
                        />
                        
                        {feedback[question.id] && (
                          <Box sx={{ mt: 2 }}>
                            <Typography variant="subtitle2" gutterBottom>
                              AI Feedback:
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {feedback[question.id]}
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                              <Typography variant="body2" sx={{ mr: 1 }}>
                                Rating:
                              </Typography>
                              <Rating
                                value={ratings[question.id] || 0}
                                readOnly
                                size="small"
                              />
                            </Box>
                          </Box>
                        )}

                        <Divider />
                        
                        <Box>
                          <Typography variant="subtitle2" gutterBottom>
                            Sample Answer Structure:
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {question.sampleAnswer}
                          </Typography>
                        </Box>
                      </Stack>
                    </AccordionDetails>
                  </Accordion>
                ))}

                <Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mt: 2 }}>
                  <Button
                    variant="outlined"
                    onClick={handleFeedbackSubmit}
                    disabled={Object.keys(answers).length === 0}
                  >
                    Get AI Feedback
                  </Button>
                  <Button
                    variant="contained"
                    onClick={handleComplete}
                    disabled={Object.keys(answers).length === 0}
                  >
                    Complete Preparation
                  </Button>
                </Stack>
              </Stack>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};
