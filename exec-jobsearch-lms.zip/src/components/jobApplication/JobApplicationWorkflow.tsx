import React, { useState, useEffect } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Typography,
  Paper,
  Grid,
  CircularProgress,
  Alert,
  Snackbar
} from '@mui/material';
import { jobBoardService } from '../../services/jobBoard';
import { Job, Resume, ApplicationStatus, ResumeOptimizationRequest } from '../../types/jobApplication';

interface JobApplicationWorkflowProps {
  jobId?: string; // If provided, starts workflow with specific job
  onComplete?: () => void;
}

const steps = ['Select Job', 'Optimize Resume', 'Interview Prep'];

export const JobApplicationWorkflow: React.FC<JobApplicationWorkflowProps> = ({
  jobId,
  onComplete
}) => {
  const [activeStep, setActiveStep] = useState(jobId ? 1 : 0);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [baseResumes, setBaseResumes] = useState<Resume[]>([]);
  const [selectedBaseResume, setSelectedBaseResume] = useState<Resume | null>(null);
  const [optimizedResume, setOptimizedResume] = useState<Resume | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Snackbar state
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    if (jobId) {
      loadInitialJob(jobId);
    }
    loadBaseResumes();
  }, [jobId]);

  const loadInitialJob = async (id: string) => {
    try {
      setIsLoading(true);
      const jobs = await jobBoardService.searchJobs('', { id });
      if (jobs.length > 0) {
        setSelectedJob(jobs[0]);
      }
    } catch (err) {
      setError('Failed to load job details');
    } finally {
      setIsLoading(false);
    }
  };

  const loadBaseResumes = async () => {
    try {
      const resumes = await jobBoardService.getBaseResumes();
      setBaseResumes(resumes);
      if (resumes.length > 0) {
        setSelectedBaseResume(resumes[0]);
      }
    } catch (err) {
      setError('Failed to load base resumes');
    }
  };

  const handleOptimizeResume = async () => {
    if (!selectedJob || !selectedBaseResume) return;

    try {
      setIsLoading(true);
      const request: ResumeOptimizationRequest = {
        baseResumeId: selectedBaseResume.id,
        jobId: selectedJob.id
      };

      const optimized = await jobBoardService.optimizeResume(request);
      setOptimizedResume(optimized);
      
      // Update application status
      await jobBoardService.updateApplicationStatus(selectedJob.id, {
        status: 'in-progress',
        nextSteps: [{
          type: 'interview-prep',
          dueDate: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
          completed: false
        }]
      });

      showNotification('Resume successfully optimized!', 'success');
      setActiveStep(2);
    } catch (err) {
      showNotification('Failed to optimize resume', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const showNotification = (message: string, severity: 'success' | 'error') => {
    setSnackbar({
      open: true,
      message,
      severity
    });
  };

  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <JobSelector
            onJobSelect={setSelectedJob}
            selectedJob={selectedJob}
          />
        );
      case 1:
        return (
          <ResumeOptimizer
            job={selectedJob!}
            baseResumes={baseResumes}
            selectedBaseResume={selectedBaseResume}
            onBaseResumeSelect={setSelectedBaseResume}
            onOptimize={handleOptimizeResume}
            isLoading={isLoading}
          />
        );
      case 2:
        return (
          <InterviewPrepStarter
            job={selectedJob!}
            optimizedResume={optimizedResume!}
            onComplete={() => {
              if (onComplete) onComplete();
            }}
          />
        );
      default:
        return null;
    }
  };

  if (isLoading && !selectedJob) {
    return <CircularProgress />;
  }

  return (
    <Box sx={{ width: '100%', p: 3 }}>
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      <Paper sx={{ p: 3 }}>
        {error ? (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        ) : (
          renderStepContent()
        )}
      </Paper>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// Sub-components
interface JobSelectorProps {
  onJobSelect: (job: Job) => void;
  selectedJob: Job | null;
}

const JobSelector: React.FC<JobSelectorProps> = ({
  onJobSelect,
  selectedJob
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async () => {
    try {
      setIsSearching(true);
      const results = await jobBoardService.searchJobs(searchQuery, {});
      setJobs(results);
    } catch (err) {
      console.error('Failed to search jobs:', err);
    } finally {
      setIsSearching(false);
    }
  };

  // Implementation details...
  return (
    <Box>
      {/* Job search and selection UI */}
      <Typography variant="h6">Select a Job to Apply</Typography>
      {/* Add job search and selection components */}
    </Box>
  );
};

interface ResumeOptimizerProps {
  job: Job;
  baseResumes: Resume[];
  selectedBaseResume: Resume | null;
  onBaseResumeSelect: (resume: Resume) => void;
  onOptimize: () => void;
  isLoading: boolean;
}

const ResumeOptimizer: React.FC<ResumeOptimizerProps> = ({
  job,
  baseResumes,
  selectedBaseResume,
  onBaseResumeSelect,
  onOptimize,
  isLoading
}) => {
  return (
    <Box>
      <Typography variant="h6">Optimize Resume</Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Typography variant="subtitle1">Selected Job</Typography>
          <Paper sx={{ p: 2, mt: 1 }}>
            <Typography variant="h6">{job.title}</Typography>
            <Typography color="textSecondary">{job.company}</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Typography variant="subtitle1">Select Base Resume</Typography>
          {/* Add resume selection components */}
        </Grid>
      </Grid>
      <Button
        variant="contained"
        color="primary"
        onClick={onOptimize}
        disabled={isLoading || !selectedBaseResume}
        sx={{ mt: 3 }}
      >
        {isLoading ? <CircularProgress size={24} /> : 'Optimize Resume'}
      </Button>
    </Box>
  );
};

interface InterviewPrepStarterProps {
  job: Job;
  optimizedResume: Resume;
  onComplete: () => void;
}

const InterviewPrepStarter: React.FC<InterviewPrepStarterProps> = ({
  job,
  optimizedResume,
  onComplete
}) => {
  return (
    <Box>
      <Typography variant="h6">Prepare for Interview</Typography>
      {/* Add interview prep components */}
    </Box>
  );
};
