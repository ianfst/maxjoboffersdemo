import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  LinearProgress,
  Grid,
  Tooltip,
  IconButton,
} from '@mui/material';
import {
  Description as ResumeIcon,
  LinkedIn as LinkedInIcon,
  Info as InfoIcon,
} from '@mui/icons-material';
import { useQuery } from 'react-query';
import api from '../../api/config';

interface Progress {
  resumesCreated: number;
  resumeWeeklyGoal: number;
  linkedInPosts: number;
  linkedInWeeklyGoal: number;
  lastUpdated: string;
}

export const ProgressTracker = () => {
  const { data: progress } = useQuery<Progress>(
    'userProgress',
    async () => {
      const response = await api.get('/api/user/progress');
      return response.data;
    },
    {
      refetchInterval: 300000, // Refresh every 5 minutes
    }
  );

  const calculateProgress = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  const renderProgressSection = (
    icon: React.ReactNode,
    title: string,
    current: number,
    goal: number,
    tooltip: string
  ) => (
    <Box sx={{ mb: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
        {icon}
        <Typography variant="h6" sx={{ ml: 1, flex: 1 }}>
          {title}
        </Typography>
        <Tooltip title={tooltip}>
          <IconButton size="small">
            <InfoIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
        <Box sx={{ flex: 1, mr: 1 }}>
          <LinearProgress
            variant="determinate"
            value={calculateProgress(current, goal)}
            sx={{
              height: 8,
              borderRadius: 4,
            }}
          />
        </Box>
        <Typography variant="body2" color="text.secondary">
          {current}/{goal}
        </Typography>
      </Box>
    </Box>
  );

  if (!progress) {
    return null;
  }

  return (
    <Card>
      <CardContent>
        <Typography variant="h5" gutterBottom>
          Weekly Progress
        </Typography>
        {renderProgressSection(
          <ResumeIcon color="primary" />,
          'Resumes Created',
          progress.resumesCreated,
          progress.resumeWeeklyGoal,
          'Number of resumes customized this week'
        )}
        {renderProgressSection(
          <LinkedInIcon color="primary" />,
          'LinkedIn Posts',
          progress.linkedInPosts,
          progress.linkedInWeeklyGoal,
          'Number of LinkedIn posts created this week'
        )}
        <Typography variant="caption" color="text.secondary">
          Last updated: {new Date(progress.lastUpdated).toLocaleString()}
        </Typography>
      </CardContent>
    </Card>
  );
};
