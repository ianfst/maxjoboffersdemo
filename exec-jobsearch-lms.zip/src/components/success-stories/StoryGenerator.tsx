import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  TextField,
  Button,
  Stepper,
  Step,
  StepLabel,
  List,
  ListItem,
  ListItemText,
  Chip,
  CircularProgress,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Psychology,
  Edit,
  Save,
  ContentCopy,
  Share,
  Analytics,
  Timeline,
  TrendingUp,
  Star,
} from '@mui/icons-material';

interface StoryElement {
  situation: string;
  task: string;
  action: string;
  result: string;
  metrics: string[];
  keywords: string[];
}

interface StoryContext {
  industry: string;
  role: string;
  audience: string;
  platform: 'linkedin' | 'interview' | 'networking';
}

export const StoryGenerator: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  const [story, setStory] = useState<StoryElement>({
    situation: '',
    task: '',
    action: '',
    result: '',
    metrics: [],
    keywords: [],
  });
  const [context, setContext] = useState<StoryContext>({
    industry: '',
    role: '',
    audience: '',
    platform: 'linkedin',
  });

  const steps = ['Context', 'Story Elements', 'AI Enhancement', 'Final Review'];

  const industryKeywords = {
    technology: ['digital transformation', 'innovation', 'scalability', 'cloud adoption'],
    finance: ['risk management', 'portfolio optimization', 'market analysis'],
    healthcare: ['patient outcomes', 'operational efficiency', 'regulatory compliance'],
  };

  const renderContextStep = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Story Context
            </Typography>
            <TextField
              fullWidth
              label="Industry"
              select
              value={context.industry}
              onChange={(e) => setContext({ ...context, industry: e.target.value })}
              SelectProps={{ native: true }}
              sx={{ mb: 2 }}
            >
              <option value="">Select Industry</option>
              <option value="technology">Technology</option>
              <option value="finance">Finance</option>
              <option value="healthcare">Healthcare</option>
            </TextField>
            <TextField
              fullWidth
              label="Target Role"
              value={context.role}
              onChange={(e) => setContext({ ...context, role: e.target.value })}
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="Target Audience"
              value={context.audience}
              onChange={(e) => setContext({ ...context, audience: e.target.value })}
              sx={{ mb: 2 }}
            />
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Platform Optimization
            </Typography>
            <Grid container spacing={2}>
              {['linkedin', 'interview', 'networking'].map((platform) => (
                <Grid item xs={4} key={platform}>
                  <Button
                    fullWidth
                    variant={context.platform === platform ? 'contained' : 'outlined'}
                    onClick={() => setContext({ ...context, platform })}
                    sx={{ textTransform: 'capitalize' }}
                  >
                    {platform}
                  </Button>
                </Grid>
              ))}
            </Grid>
            <Box sx={{ mt: 3 }}>
              <Typography variant="subtitle2" gutterBottom>
                Platform-Specific Tips
              </Typography>
              <List dense>
                <ListItem>
                  <ListItemText 
                    primary="LinkedIn: Focus on measurable achievements"
                    secondary="Use industry-specific metrics and keywords"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText 
                    primary="Interview: Emphasize leadership and decision-making"
                    secondary="Include specific challenges overcome"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText 
                    primary="Networking: Keep it conversational yet impactful"
                    secondary="Highlight mutual interests and opportunities"
                  />
                </ListItem>
              </List>
            </Box>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderStoryElements = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              STAR Framework
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Situation"
                  multiline
                  rows={3}
                  value={story.situation}
                  onChange={(e) => setStory({ ...story, situation: e.target.value })}
                  sx={{ mb: 2 }}
                />
                <TextField
                  fullWidth
                  label="Task"
                  multiline
                  rows={3}
                  value={story.task}
                  onChange={(e) => setStory({ ...story, task: e.target.value })}
                  sx={{ mb: 2 }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Action"
                  multiline
                  rows={3}
                  value={story.action}
                  onChange={(e) => setStory({ ...story, action: e.target.value })}
                  sx={{ mb: 2 }}
                />
                <TextField
                  fullWidth
                  label="Result"
                  multiline
                  rows={3}
                  value={story.result}
                  onChange={(e) => setStory({ ...story, result: e.target.value })}
                />
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Key Metrics & Keywords
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" gutterBottom>
                  Quantifiable Metrics
                </Typography>
                <TextField
                  fullWidth
                  placeholder="e.g., Increased revenue by 25%"
                  value={story.metrics.join('\n')}
                  onChange={(e) => setStory({ ...story, metrics: e.target.value.split('\n') })}
                  multiline
                  rows={4}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" gutterBottom>
                  Industry Keywords
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {industryKeywords[context.industry as keyof typeof industryKeywords]?.map((keyword, index) => (
                    <Chip
                      key={index}
                      label={keyword}
                      onClick={() => {
                        if (!story.keywords.includes(keyword)) {
                          setStory({ ...story, keywords: [...story.keywords, keyword] });
                        }
                      }}
                    />
                  ))}
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderAIEnhancement = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={8}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              AI-Enhanced Story
            </Typography>
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" color="primary" gutterBottom>
                Original Story
              </Typography>
              <Typography variant="body2" sx={{ mb: 2 }}>
                {`${story.situation}\n${story.task}\n${story.action}\n${story.result}`}
              </Typography>
              <Button
                variant="contained"
                startIcon={<Psychology />}
                onClick={() => {
                  setAnalyzing(true);
                  setTimeout(() => setAnalyzing(false), 2000);
                }}
                disabled={analyzing}
              >
                {analyzing ? 'Enhancing...' : 'Enhance with AI'}
              </Button>
            </Box>
            <Divider sx={{ my: 3 }} />
            <Typography variant="subtitle2" color="primary" gutterBottom>
              Enhanced Version
            </Typography>
            <Typography variant="body2">
              {/* AI-enhanced version would go here */}
            </Typography>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={4}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Enhancement Metrics
            </Typography>
            <List>
              <ListItem>
                <ListItemText
                  primary="Executive Tone"
                  secondary={
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <CircularProgress
                        variant="determinate"
                        value={85}
                        size={24}
                        sx={{ mr: 1 }}
                      />
                      85%
                    </Box>
                  }
                />
              </ListItem>
              <ListItem>
                <ListItemText
                  primary="Impact Clarity"
                  secondary={
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <CircularProgress
                        variant="determinate"
                        value={92}
                        size={24}
                        sx={{ mr: 1 }}
                      />
                      92%
                    </Box>
                  }
                />
              </ListItem>
              <ListItem>
                <ListItemText
                  primary="Keyword Optimization"
                  secondary={
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <CircularProgress
                        variant="determinate"
                        value={78}
                        size={24}
                        sx={{ mr: 1 }}
                      />
                      78%
                    </Box>
                  }
                />
              </ListItem>
            </List>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderFinalReview = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6">
                Final Story
              </Typography>
              <Box>
                <Tooltip title="Copy to clipboard">
                  <IconButton>
                    <ContentCopy />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Save to library">
                  <IconButton>
                    <Save />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Share">
                  <IconButton>
                    <Share />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
            <Typography variant="body1" sx={{ mb: 3 }}>
              {/* Final story content */}
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" gutterBottom>
                  Usage Recommendations
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText
                      primary="LinkedIn Profile"
                      secondary="Add to 'Experience' section"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="Interview Response"
                      secondary="Use for leadership questions"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="Networking"
                      secondary="Share during industry discussions"
                    />
                  </ListItem>
                </List>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" gutterBottom>
                  Impact Analysis
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText
                      primary="Engagement Prediction"
                      secondary="High (92% match with successful stories)"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="Memorability Score"
                      secondary="Very High (specific metrics + clear outcome)"
                    />
                  </ListItem>
                </List>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return renderContextStep();
      case 1:
        return renderStoryElements();
      case 2:
        return renderAIEnhancement();
      case 3:
        return renderFinalReview();
      default:
        return null;
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <Star sx={{ mr: 1 }} />
        Executive Success Story Generator
      </Typography>
      
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {getStepContent(activeStep)}

      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
        <Button
          disabled={activeStep === 0}
          onClick={() => setActiveStep((prev) => prev - 1)}
          sx={{ mr: 1 }}
        >
          Back
        </Button>
        <Button
          variant="contained"
          onClick={() => {
            if (activeStep === steps.length - 1) {
              // Handle completion
            } else {
              setActiveStep((prev) => prev + 1);
            }
          }}
        >
          {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
        </Button>
      </Box>
    </Box>
  );
};
