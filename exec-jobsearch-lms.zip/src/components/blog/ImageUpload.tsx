import React, { useState } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Typography,
  Alert,
} from '@mui/material';
import { fileUploadService, FileUploadProgress, FileUploadError } from '../../services/fileUpload';

interface ImageUploadProps {
  onUploadComplete: (imageUrl: string) => void;
}

export function ImageUpload({ onUploadComplete }: ImageUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<FileUploadProgress | null>(null);
  const [error, setError] = useState<FileUploadError | null>(null);

  const handleUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setError(null);
    setUploading(true);

    try {
      const validationError = fileUploadService.validateFile(file);
      if (validationError) {
        setError(validationError);
        return;
      }

      const { url } = await fileUploadService.uploadBlogImage(file, (progress) => {
        setProgress(progress);
      });

      onUploadComplete(url);
    } catch (err) {
      setError(err as FileUploadError);
    } finally {
      setUploading(false);
      setProgress(null);
    }
  };

  return (
    <Box sx={{ mb: 2 }}>
      <input
        accept="image/*"
        style={{ display: 'none' }}
        id="image-upload"
        type="file"
        onChange={handleUpload}
        disabled={uploading}
      />
      <label htmlFor="image-upload">
        <Button
          variant="outlined"
          component="span"
          disabled={uploading}
          sx={{ mr: 2 }}
        >
          {uploading ? 'Uploading...' : 'Upload Image'}
        </Button>
      </label>

      {uploading && progress && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <CircularProgress
            variant="determinate"
            value={progress.percent}
            size={24}
          />
          <Typography variant="body2" color="text.secondary">
            {Math.round(progress.percent)}%
          </Typography>
        </Box>
      )}

      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error.message}
        </Alert>
      )}
    </Box>
  );
}
