import React from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import { useAuth } from '../../hooks/useAuth';

interface BlogLayoutProps {
  children: React.ReactNode;
  sidebar?: React.ReactNode;
  title?: string;
  description?: string;
}

const BlogLayout: React.FC<BlogLayoutProps> = ({
  children,
  sidebar,
  title,
  description,
}) => {
  const theme = useTheme();
  const isLargeScreen = useMediaQuery(theme.breakpoints.up('lg'));
  const { user } = useAuth();

  return (
    <Box sx={{ py: 4 }}>
      <Container maxWidth="lg">
        {(title || description) && (
          <Box sx={{ mb: 6, textAlign: 'center' }}>
            {title && (
              <Typography
                variant="h2"
                component="h1"
                gutterBottom
                sx={{
                  fontSize: { xs: '2rem', md: '2.5rem' },
                  fontWeight: 700,
                }}
              >
                {title}
              </Typography>
            )}
            {description && (
              <Typography
                variant="subtitle1"
                color="text.secondary"
                sx={{ maxWidth: '600px', mx: 'auto' }}
              >
                {description}
              </Typography>
            )}
          </Box>
        )}

        <Grid container spacing={4}>
          <Grid item xs={12} lg={sidebar ? 8 : 12}>
            {children}
          </Grid>
          {sidebar && isLargeScreen && (
            <Grid item xs={12} lg={4}>
              {sidebar}
            </Grid>
          )}
        </Grid>
      </Container>
    </Box>
  );
};

export default BlogLayout;
