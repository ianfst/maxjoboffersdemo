import React from 'react';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Box,
  Chip,
  Avatar,
  CardActionArea,
} from '@mui/material';
import { useRouter } from 'next/router';
import { BlogPost } from '../../types/blog';

interface BlogCardProps {
  post: BlogPost;
  variant?: 'default' | 'featured';
}

const BlogCard: React.FC<BlogCardProps> = ({ post, variant = 'default' }) => {
  const router = useRouter();
  const isFeatured = variant === 'featured';

  const handleClick = () => {
    router.push(`/blog/${post.slug}`);
  };

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        ...(isFeatured && {
          boxShadow: (theme) => theme.shadows[10],
        }),
      }}
    >
      <CardActionArea onClick={handleClick}>
        {post.coverImage && (
          <CardMedia
            component="img"
            height={isFeatured ? 400 : 200}
            image={post.coverImage}
            alt={post.title}
            sx={{
              objectFit: 'cover',
            }}
          />
        )}
        <CardContent sx={{ flexGrow: 1 }}>
          <Box sx={{ mb: 2 }}>
            {post.tags.slice(0, 2).map((tag) => (
              <Chip
                key={tag}
                label={tag}
                size="small"
                sx={{ mr: 1, mb: 1 }}
              />
            ))}
          </Box>
          <Typography
            gutterBottom
            variant={isFeatured ? 'h4' : 'h5'}
            component="h2"
            sx={{
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
            }}
          >
            {post.title}
          </Typography>
          <Typography
            color="text.secondary"
            sx={{
              mb: 2,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: '-webkit-box',
              WebkitLineClamp: 3,
              WebkitBoxOrient: 'vertical',
            }}
          >
            {post.excerpt}
          </Typography>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              mt: 'auto',
              pt: 2,
            }}
          >
            <Avatar
              src={post.author.avatar}
              alt={post.author.name}
              sx={{ width: 32, height: 32, mr: 1 }}
            />
            <Box>
              <Typography variant="subtitle2" component="p">
                {post.author.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {new Date(post.publishedAt || new Date()).toLocaleDateString()} · {post.readingTime}
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </CardActionArea>
    </Card>
  );
};

export default BlogCard;
