import React from 'react';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  Chip,
  Paper,
  Divider,
  Button,
} from '@mui/material';
import { BlogCategory, BlogTag } from '../../types/blog';
import { useRouter } from 'next/router';

interface BlogSidebarProps {
  categories: BlogCategory[];
  tags: BlogTag[];
  popularPosts: Array<{
    title: string;
    slug: string;
    publishedAt: string;
  }>;
}

const BlogSidebar: React.FC<BlogSidebarProps> = ({
  categories,
  tags,
  popularPosts,
}) => {
  const router = useRouter();

  return (
    <Box component="aside">
      {/* Categories Section */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Categories
        </Typography>
        <List disablePadding>
          {categories.map((category) => (
            <ListItem
              key={category.id}
              disablePadding
              sx={{ py: 1 }}
              onClick={() => router.push(`/blog/category/${category.slug}`)}
              button
            >
              <ListItemText
                primary={category.name}
                secondary={category.description}
                primaryTypographyProps={{
                  sx: { fontWeight: 500 },
                }}
              />
            </ListItem>
          ))}
        </List>
      </Paper>

      {/* Popular Posts Section */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Popular Posts
        </Typography>
        <List disablePadding>
          {popularPosts.map((post) => (
            <React.Fragment key={post.slug}>
              <ListItem
                disablePadding
                sx={{ py: 1.5 }}
                onClick={() => router.push(`/blog/${post.slug}`)}
                button
              >
                <ListItemText
                  primary={post.title}
                  secondary={new Date(post.publishedAt).toLocaleDateString()}
                  primaryTypographyProps={{
                    sx: {
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                    },
                  }}
                />
              </ListItem>
              <Divider component="li" />
            </React.Fragment>
          ))}
        </List>
      </Paper>

      {/* Tags Section */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Popular Tags
        </Typography>
        <Box sx={{ mt: 2 }}>
          {tags.map((tag) => (
            <Chip
              key={tag.id}
              label={`${tag.name} (${tag.count})`}
              onClick={() => router.push(`/blog/tag/${tag.slug}`)}
              sx={{ m: 0.5 }}
            />
          ))}
        </Box>
      </Paper>

      {/* Newsletter Signup */}
      <Paper sx={{ p: 3, mt: 3, textAlign: 'center' }}>
        <Typography variant="h6" gutterBottom>
          Subscribe to Our Newsletter
        </Typography>
        <Typography variant="body2" color="text.secondary" paragraph>
          Get the latest posts and updates delivered to your inbox.
        </Typography>
        <Button
          variant="contained"
          fullWidth
          onClick={() => router.push('/newsletter')}
        >
          Subscribe Now
        </Button>
      </Paper>
    </Box>
  );
};

export default BlogSidebar;
