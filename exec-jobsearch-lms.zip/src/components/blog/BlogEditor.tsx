import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  Typography,
  useTheme,
} from '@mui/material';
import { aiService, BlogPostIdeas, BlogPostOutline } from '../../services/ai';
import { useAuth } from '../../contexts/AuthContext';

interface BlogEditorProps {
  onSave: (content: string) => void;
}

export const BlogEditor: React.FC<BlogEditorProps> = ({ onSave }) => {
  const theme = useTheme();
  const { user } = useAuth();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState<BlogPostIdeas[]>([]);
  const [selectedIdea, setSelectedIdea] = useState<BlogPostIdeas | null>(null);
  const [outline, setOutline] = useState<BlogPostOutline | undefined>(undefined);
  const [showOutlineDialog, setShowOutlineDialog] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateIdeas = async () => {
    if (!topic || !user) return;
    
    setLoading(true);
    setError(null);
    try {
      const generatedIdeas = await aiService.generateBlogIdeas(user.id.toString(), topic);
      setIdeas(generatedIdeas);
    } catch (error) {
      console.error('Error generating ideas:', error);
      setError(error instanceof Error ? error.message : 'Failed to generate ideas');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectIdea = async (idea: BlogPostIdeas) => {
    if (!user) return;
    
    setSelectedIdea(idea);
    setLoading(true);
    setError(null);
    try {
      const generatedOutline = await aiService.generateBlogOutline(
        `${idea.title}\n\nKey Points:\n${idea.keyPoints.join('\n- ')}`
      );
      setOutline(generatedOutline || undefined);
      setShowOutlineDialog(true);
    } catch (error) {
      console.error('Error generating outline:', error);
      setError(error instanceof Error ? error.message : 'Failed to generate outline');
    } finally {
      setLoading(false);
    }
  };

  const handleCloseOutlineDialog = () => {
    setShowOutlineDialog(false);
  };

  const handleUseOutline = () => {
    if (outline) {
      // Format the outline into markdown/content
      const content = `
# ${outline.title}

${outline.introduction}

${outline.sections.map(section => `
## ${section.heading}

${section.content.join('\n')}

**Key Takeaway:** ${section.keyTakeaway}
`).join('\n')}

## Conclusion

${outline.conclusion}

${outline.callToAction}
      `.trim();

      onSave(content);
      setShowOutlineDialog(false);
    }
  };

  return (
    <Box>
      <Card sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Generate Blog Ideas
          </Typography>
          <TextField
            fullWidth
            label="Topic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            disabled={loading}
            sx={{ mb: 2 }}
          />
          <Button
            variant="contained"
            onClick={handleGenerateIdeas}
            disabled={!topic || loading}
          >
            {loading ? <CircularProgress size={24} /> : 'Generate Ideas'}
          </Button>
          {error && (
            <Typography color="error" sx={{ mt: 2 }}>
              {error}
            </Typography>
          )}
        </CardContent>
      </Card>

      {ideas.length > 0 && (
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Blog Ideas
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {ideas.map((idea, index) => (
                <Card
                  key={index}
                  variant="outlined"
                  sx={{
                    cursor: 'pointer',
                    '&:hover': {
                      backgroundColor: theme.palette.action.hover,
                    },
                  }}
                  onClick={() => handleSelectIdea(idea)}
                >
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      {idea.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      {idea.description}
                    </Typography>
                    <Typography variant="body2" gutterBottom>
                      Target Audience: {idea.targetAudience}
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                      {idea.suggestedTags.map((tag, i) => (
                        <Chip key={i} label={tag} size="small" />
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              ))}
            </Box>
          </CardContent>
        </Card>
      )}

      <Dialog
        open={showOutlineDialog}
        onClose={handleCloseOutlineDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Blog Outline</DialogTitle>
        <DialogContent dividers>
          {outline && (
            <Box>
              <Typography variant="h5" gutterBottom>
                {outline.title}
              </Typography>
              <Typography paragraph>{outline.introduction}</Typography>
              
              {outline.sections.map((section, index) => (
                <Box key={index} sx={{ mb: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    {section.heading}
                  </Typography>
                  {section.content.map((point, i) => (
                    <Typography key={i} paragraph>
                      {point}
                    </Typography>
                  ))}
                  <Typography
                    variant="body2"
                    color="primary"
                    sx={{ fontStyle: 'italic' }}
                  >
                    Key Takeaway: {section.keyTakeaway}
                  </Typography>
                </Box>
              ))}

              <Typography variant="h6" gutterBottom>
                Conclusion
              </Typography>
              <Typography paragraph>{outline.conclusion}</Typography>
              
              <Typography color="primary" sx={{ fontStyle: 'italic' }}>
                {outline.callToAction}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseOutlineDialog}>Cancel</Button>
          <Button onClick={handleUseOutline} variant="contained">
            Use This Outline
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
