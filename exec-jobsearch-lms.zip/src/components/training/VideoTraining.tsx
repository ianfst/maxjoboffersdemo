import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Container,
  Grid,
  Typography,
  LinearProgress,
  Tabs,
  Tab,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction
} from '@mui/material';
import {
  PlayArrow as PlayIcon,
  CheckCircle as CheckIcon,
  Pause as PauseIcon
} from '@mui/icons-material';
import api from '../../api/config';

interface Video {
  id: string;
  title: string;
  description: string;
  url: string;
  duration: string;
  order: number;
}

interface Category {
  title: string;
  description: string;
  videos: Video[];
}

interface VideoProgress {
  [key: string]: number;
}

export const VideoTraining: React.FC = () => {
  const [categories, setCategories] = useState<{[key: string]: Category}>({});
  const [activeCategory, setActiveCategory] = useState<string>('');
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [progress, setProgress] = useState<VideoProgress>({});
  
  useEffect(() => {
    loadCategories();
  }, []);
  
  const loadCategories = async () => {
    try {
      const response = await api.get('/training/video-categories');
      setCategories(response.data);
      if (Object.keys(response.data).length > 0) {
        setActiveCategory(Object.keys(response.data)[0]);
      }
    } catch (error) {
      console.error('Failed to load video categories:', error);
    }
  };
  
  const handleCategoryChange = (event: React.SyntheticEvent, newValue: string) => {
    setActiveCategory(newValue);
    setCurrentVideo(null);
  };
  
  const handleVideoSelect = (video: Video) => {
    setCurrentVideo(video);
    setIsPlaying(true);
  };
  
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const handleProgress = (videoId: string, newProgress: number) => {
    setProgress(prev => ({
      ...prev,
      [videoId]: newProgress
    }));
    
    // Update progress on server
    api.post('/training/track-progress', {
      video_id: videoId,
      progress: newProgress
    });
  };
  
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Interview Training Videos
        </Typography>
        
        <Tabs
          value={activeCategory}
          onChange={handleCategoryChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{ mb: 3 }}
        >
          {Object.entries(categories).map(([id, category]) => (
            <Tab
              key={id}
              label={category.title}
              value={id}
            />
          ))}
        </Tabs>
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            {currentVideo ? (
              <Card>
                <CardMedia
                  component="video"
                  height="400"
                  src={currentVideo.url}
                  title={currentVideo.title}
                />
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <IconButton onClick={handlePlayPause}>
                      {isPlaying ? <PauseIcon /> : <PlayIcon />}
                    </IconButton>
                    <LinearProgress
                      variant="determinate"
                      value={progress[currentVideo.id] || 0}
                      sx={{ flexGrow: 1, mx: 2 }}
                    />
                    <Typography variant="body2">
                      {currentVideo.duration}
                    </Typography>
                  </Box>
                  <Typography variant="h6" gutterBottom>
                    {currentVideo.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {currentVideo.description}
                  </Typography>
                </CardContent>
              </Card>
            ) : (
              <Box
                sx={{
                  height: 400,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  bgcolor: 'grey.100',
                  borderRadius: 1
                }}
              >
                <Typography variant="h6" color="text.secondary">
                  Select a video to begin
                </Typography>
              </Box>
            )}
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              {categories[activeCategory]?.title} Videos
            </Typography>
            <List>
              {categories[activeCategory]?.videos.map((video) => (
                <ListItem
                  key={video.id}
                  button
                  selected={currentVideo?.id === video.id}
                  onClick={() => handleVideoSelect(video)}
                >
                  <ListItemText
                    primary={video.title}
                    secondary={`${video.duration} • ${video.description}`}
                  />
                  <ListItemSecondaryAction>
                    {progress[video.id] === 100 && (
                      <CheckIcon color="success" />
                    )}
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};
